"""
============================================================
CF20 - MODEL INTERPRETATION + BIOLOGICAL VALIDATION
============================================================

Purpose:
    Explain the locked CF18 Elastic-Net HER2 prediction model.

Rules:
    - NO retraining
    - NO feature selection
    - NO threshold optimization
    - NO SCAN-B access
    - NO APOLLO access

Inputs:
    CF18 locked Elastic-Net model bundle

Outputs:
    Coefficient ranking, stable signature overlap,
    and publication-ready interpretation files.

============================================================
"""

import os
import time
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

START = time.time()

BASE = r"D:\Masters\Research\TCGA_BRCA"

MODEL_FILE = os.path.join(
    BASE,
    "data",
    "processed",
    "ml_ready",
    "CF18_final_model",
    "CF18_final_ElasticNet_model_bundle.joblib"
)

OUT = os.path.join(
    BASE,
    "results",
    "CF20_model_interpretation"
)

os.makedirs(OUT, exist_ok=True)


print("""
============================================================
 CF20 - MODEL INTERPRETATION + BIOLOGICAL VALIDATION
============================================================

NO MODEL RETRAINING
NO FEATURE SELECTION
NO THRESHOLD OPTIMIZATION
NO SCAN-B ACCESS
NO APOLLO ACCESS

""")


bundle = joblib.load(MODEL_FILE)

print("[1/6] Loading CF18 locked model...")

model = bundle["elasticnet_model"]
genes = np.array(bundle["feature_universe_gene_symbols"])

selected_mask = bundle["select_k_best"].get_support()

selected_genes = genes[selected_mask]

coef = model.coef_.flatten()

if len(selected_genes) != len(coef):
    raise RuntimeError(
        "Coefficient length does not match selected genes"
    )

coef_table = pd.DataFrame({
    "gene": selected_genes,
    "coefficient": coef
})

coef_table["abs_coefficient"] = (
    coef_table["coefficient"].abs()
)

coef_table = coef_table.sort_values(
    "abs_coefficient",
    ascending=False
)

coef_table.to_csv(
    os.path.join(
        OUT,
        "CF20_all_selected_coefficients.tsv"
    ),
    sep="\t",
    index=False
)


print("[2/6] Writing positive and negative predictors...")

positive = (
    coef_table
    .sort_values("coefficient", ascending=False)
    .head(50)
)

negative = (
    coef_table
    .sort_values("coefficient", ascending=True)
    .head(50)
)

positive.to_csv(
    os.path.join(
        OUT,
        "CF20_top_positive_genes.tsv"
    ),
    sep="\t",
    index=False
)

negative.to_csv(
    os.path.join(
        OUT,
        "CF20_top_negative_genes.tsv"
    ),
    sep="\t",
    index=False
)


print("[3/6] Checking stable signature overlap...")

signature = bundle.get(
    "core_signature_definition",
    {}
)

signature_genes = []

if isinstance(signature, dict):
    for value in signature.values():
        if isinstance(value, list):
            signature_genes.extend(value)

signature_genes = sorted(set(signature_genes))

overlap = pd.DataFrame({
    "signature_gene": signature_genes,
    "present_in_final_model": [
        g in set(coef_table["gene"])
        for g in signature_genes
    ]
})

overlap.to_csv(
    os.path.join(
        OUT,
        "CF20_signature_overlap.tsv"
    ),
    sep="\t",
    index=False
)


print("[4/6] Generating figures...")

plt.figure(figsize=(7,5))
plt.hist(
    coef_table["coefficient"],
    bins=40
)
plt.xlabel("Elastic-Net coefficient")
plt.ylabel("Number of genes")
plt.title("CF20 Elastic-Net coefficient distribution")
plt.savefig(
    os.path.join(
        OUT,
        "CF20_coefficient_distribution.png"
    ),
    dpi=300,
    bbox_inches="tight"
)
plt.close()


top_plot = (
    coef_table
    .head(20)
    .sort_values("coefficient")
)

plt.figure(figsize=(7,6))
plt.barh(
    top_plot["gene"],
    top_plot["coefficient"]
)
plt.xlabel("Coefficient")
plt.ylabel("Gene")
plt.title("CF20 Top model predictors")
plt.savefig(
    os.path.join(
        OUT,
        "CF20_gene_importance.png"
    ),
    dpi=300,
    bbox_inches="tight"
)
plt.close()


print("[5/6] Writing summary...")


summary = pd.DataFrame({
    "item": [
        "Model",
        "Selected genes",
        "Nonzero coefficients",
        "Stable signature genes",
        "Stable genes found in model"
    ],
    "value": [
        bundle["primary_model_family"],
        len(selected_genes),
        int(np.sum(coef != 0)),
        len(signature_genes),
        int(overlap["present_in_final_model"].sum())
    ]
})


summary.to_csv(
    os.path.join(
        OUT,
        "CF20_summary.tsv"
    ),
    sep="\t",
    index=False
)


pd.DataFrame({
    "item": [
        "CF18_model_file",
        "SCAN-B_used",
        "APOLLO_used"
    ],
    "value": [
        MODEL_FILE,
        "NO",
        "NO"
    ]
}).to_csv(
    os.path.join(
        OUT,
        "CF20_provenance.tsv"
    ),
    sep="\t",
    index=False
)


print("[6/6] Final gate...")


print("""
============================================================
 CF20 COMPLETE - MODEL INTERPRETATION PASSED
============================================================
""")

print(
    "Selected genes:",
    len(selected_genes)
)

print(
    "Nonzero coefficients:",
    int(np.sum(coef != 0))
)

print(
    "Runtime:",
    round((time.time()-START)/60,2),
    "min"
)

print("STATUS: READY_FOR_CF21")
