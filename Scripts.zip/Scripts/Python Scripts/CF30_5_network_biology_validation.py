from __future__ import annotations

import json
import math
import time
from collections import defaultdict
from datetime import date
from pathlib import Path

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
import requests
from scipy import stats


ROOT = Path(__file__).resolve().parents[2]
CF30_5 = ROOT / "CF30_5_network_biology_validation"
INPUT_DIR = CF30_5 / "input"
RESULTS_DIR = CF30_5 / "results"
FIGURES_DIR = CF30_5 / "figures"
METADATA_DIR = CF30_5 / "metadata"
LOGS_DIR = CF30_5 / "logs"

CF20_COEFFICIENTS = ROOT / "results" / "CF20_model_interpretation" / "CF20_all_selected_coefficients.tsv"
CF18_FEATURES = ROOT / "results" / "CF18_stable_signature_xai_final_model" / "CF18_final_ElasticNet_features.tsv"

STRING_BASE = "https://string-db.org/api/tsv"
UNIPROT_SEARCH = "https://rest.uniprot.org/uniprotkb/search"
STRING_SPECIES = 9606
STRING_MEDIUM_SCORE = 400
STRING_HIGH_SCORE = 700
RANDOM_SETS = 1000
SEED = 42


def ensure_dirs() -> None:
    for directory in [INPUT_DIR, RESULTS_DIR, FIGURES_DIR, METADATA_DIR, LOGS_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


def read_tsv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path, sep="\t")


def direction(value: float) -> str:
    if value > 0:
        return "Positive"
    if value < 0:
        return "Negative"
    return "Zero"


def load_signature() -> tuple[pd.DataFrame, pd.DataFrame]:
    cf20 = read_tsv(CF20_COEFFICIENTS)
    required = {"gene", "coefficient"}
    if not required.issubset(cf20.columns):
        raise ValueError(f"CF20 is missing required columns: {sorted(required.difference(cf20.columns))}")

    cf20 = cf20.copy()
    cf20["coefficient"] = pd.to_numeric(cf20["coefficient"], errors="coerce").fillna(0.0)
    cf20 = cf20.drop_duplicates("gene", keep="first")
    signature = cf20[cf20["coefficient"] != 0].copy()
    signature = signature.sort_values("coefficient", key=lambda s: s.abs(), ascending=False).reset_index(drop=True)
    signature_out = pd.DataFrame(
        {
            "Gene": signature["gene"],
            "Coefficient": signature["coefficient"],
            "Direction": signature["coefficient"].map(direction),
        }
    )
    signature_out.to_csv(INPUT_DIR / "CF30_5_input_gene_list.tsv", sep="\t", index=False)
    cf20.to_csv(INPUT_DIR / "CF30_5_locked_CF20_coefficient_universe.tsv", sep="\t", index=False)
    return signature_out, cf20


def request_with_retries(session: requests.Session, method: str, url: str, **kwargs) -> requests.Response:
    for attempt in range(4):
        response = session.request(method, url, timeout=60, **kwargs)
        if response.status_code in {429, 500, 502, 503, 504} and attempt < 3:
            time.sleep(2 * (attempt + 1))
            continue
        response.raise_for_status()
        return response
    raise RuntimeError(f"Request failed repeatedly: {url}")


def map_string_ids(genes: list[str], cache_name: str) -> pd.DataFrame:
    cache_path = METADATA_DIR / cache_name
    if cache_path.exists():
        return pd.read_csv(cache_path, sep="\t")

    session = requests.Session()
    rows = []
    chunk_size = 200
    for start in range(0, len(genes), chunk_size):
        chunk = genes[start : start + chunk_size]
        response = request_with_retries(
            session,
            "POST",
            f"{STRING_BASE}/get_string_ids",
            data={
                "identifiers": "\r".join(chunk),
                "species": STRING_SPECIES,
                "limit": 1,
                "echo_query": 1,
            },
        )
        text = response.text.strip()
        if not text:
            continue
        rows.extend([line.split("\t") for line in text.splitlines()])

    if not rows:
        raise RuntimeError("STRING mapping returned no rows.")
    header, data = rows[0], rows[1:]
    mapping = pd.DataFrame(data, columns=header)
    mapping.to_csv(cache_path, sep="\t", index=False)
    return mapping


def map_uniprot_ids(genes: list[str]) -> pd.DataFrame:
    cache_path = METADATA_DIR / "CF30_5_uniprot_mapping_cache.tsv"
    if cache_path.exists():
        return pd.read_csv(cache_path, sep="\t")

    session = requests.Session()
    rows = []
    for gene in genes:
        params = {
            "query": f"(gene_exact:{gene}) AND (organism_id:{STRING_SPECIES}) AND (reviewed:true)",
            "fields": "accession,gene_primary,protein_name",
            "format": "tsv",
            "size": 1,
        }
        try:
            response = request_with_retries(session, "GET", UNIPROT_SEARCH, params=params)
            lines = [line for line in response.text.splitlines() if line.strip()]
            if len(lines) >= 2:
                parts = lines[1].split("\t")
                rows.append(
                    {
                        "Gene": gene,
                        "UniProt_ID": parts[0] if len(parts) > 0 else "",
                        "UniProt_gene": parts[1] if len(parts) > 1 else "",
                        "Protein_name": parts[2] if len(parts) > 2 else "",
                    }
                )
            else:
                rows.append({"Gene": gene, "UniProt_ID": "", "UniProt_gene": "", "Protein_name": ""})
        except Exception:
            rows.append({"Gene": gene, "UniProt_ID": "", "UniProt_gene": "", "Protein_name": ""})
        time.sleep(0.05)

    uniprot = pd.DataFrame(rows)
    uniprot.to_csv(cache_path, sep="\t", index=False)
    return uniprot


def create_mapping_tables(signature: pd.DataFrame, background: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    sig_genes = signature["Gene"].astype(str).tolist()
    bg_genes = background["gene"].astype(str).tolist()
    string_sig = map_string_ids(sig_genes, "CF30_5_STRING_signature_mapping_cache.tsv")
    string_bg = map_string_ids(bg_genes, "CF30_5_STRING_background_mapping_cache.tsv")
    uniprot = map_uniprot_ids(sig_genes)

    string_sig_keep = string_sig[["queryItem", "stringId", "preferredName", "annotation"]].drop_duplicates("queryItem")
    detailed = signature.merge(string_sig_keep, left_on="Gene", right_on="queryItem", how="left")
    detailed = detailed.merge(uniprot, on="Gene", how="left")
    detailed = detailed.rename(
        columns={
            "stringId": "STRING_ID",
            "preferredName": "STRING_preferred_name",
            "annotation": "STRING_annotation",
        }
    )
    detailed["Mapping_status"] = detailed["STRING_ID"].notna().map(lambda x: "Mapped_to_STRING" if x else "Unmapped_to_STRING")
    detailed = detailed[
        [
            "Gene",
            "Coefficient",
            "Direction",
            "UniProt_ID",
            "Protein_name",
            "STRING_ID",
            "STRING_preferred_name",
            "STRING_annotation",
            "Mapping_status",
        ]
    ]
    detailed.to_csv(RESULTS_DIR / "CF30_5_gene_identifier_mapping.tsv", sep="\t", index=False)

    total = len(signature)
    string_mapped = int(detailed["STRING_ID"].notna().sum())
    uniprot_mapped = int(detailed["UniProt_ID"].fillna("").astype(str).str.len().gt(0).sum())
    summary = pd.DataFrame(
        [
            {
                "Total_genes": total,
                "STRING_mapped_genes": string_mapped,
                "UniProt_mapped_genes": uniprot_mapped,
                "Mapping_percentage": round(100 * string_mapped / total, 2) if total else 0.0,
                "Unmapped_genes": ";".join(detailed.loc[detailed["STRING_ID"].isna(), "Gene"].tolist()),
            }
        ]
    )
    summary.to_csv(RESULTS_DIR / "CF30_5_gene_mapping_summary.tsv", sep="\t", index=False)
    return detailed, string_bg


def fetch_string_network(string_ids: list[str], required_score: int, cache_name: str) -> pd.DataFrame:
    cache_path = METADATA_DIR / cache_name
    if cache_path.exists():
        return pd.read_csv(cache_path, sep="\t")

    session = requests.Session()
    response = request_with_retries(
        session,
        "POST",
        f"{STRING_BASE}/network",
        data={
            "identifiers": "\r".join(string_ids),
            "species": STRING_SPECIES,
            "required_score": required_score,
            "network_type": "functional",
        },
    )
    text = response.text.strip()
    if not text:
        network = pd.DataFrame()
    else:
        rows = [line.split("\t") for line in text.splitlines()]
        network = pd.DataFrame(rows[1:], columns=rows[0])
    network.to_csv(cache_path, sep="\t", index=False)
    return network


def graph_from_edges(nodes: list[str], edge_table: pd.DataFrame, min_score: float) -> nx.Graph:
    graph = nx.Graph()
    graph.add_nodes_from(nodes)
    if edge_table.empty:
        return graph
    for row in edge_table.itertuples(index=False):
        a = getattr(row, "preferredName_A", None)
        b = getattr(row, "preferredName_B", None)
        score = float(getattr(row, "score", 0.0))
        if a in graph and b in graph and a != b and score >= min_score:
            graph.add_edge(a, b, weight=score)
    return graph


def network_metrics(graph: nx.Graph, label: str) -> dict[str, float | str]:
    nodes = graph.number_of_nodes()
    edges = graph.number_of_edges()
    if nodes == 0:
        avg_degree = density = clustering = 0.0
    else:
        avg_degree = float(np.mean([degree for _, degree in graph.degree()]))
        density = nx.density(graph)
        clustering = nx.average_clustering(graph) if nodes > 1 else 0.0
    components = nx.number_connected_components(graph) if nodes else 0
    largest_component = max((len(c) for c in nx.connected_components(graph)), default=0)
    return {
        "Network": label,
        "Number_of_nodes": nodes,
        "Number_of_edges": edges,
        "Average_degree": avg_degree,
        "Clustering_coefficient": clustering,
        "Network_density": density,
        "Connected_components": components,
        "Largest_component_nodes": largest_component,
    }


def write_network_statistics(medium_graph: nx.Graph, high_graph: nx.Graph) -> pd.DataFrame:
    rows = []
    for label, graph in [("STRING_confidence_0.400", medium_graph), ("STRING_confidence_0.700", high_graph)]:
        metrics = network_metrics(graph, label)
        for metric, value in metrics.items():
            if metric == "Network":
                continue
            rows.append({"Network": label, "Metric": metric, "Value": value})
    stats_df = pd.DataFrame(rows)
    stats_df.to_csv(RESULTS_DIR / "CF30_5_network_statistics.tsv", sep="\t", index=False)
    return stats_df


def centrality_tables(graph: nx.Graph, signature: pd.DataFrame, mapping: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    degree_cent = nx.degree_centrality(graph)
    betweenness = nx.betweenness_centrality(graph, weight="weight", normalized=True)
    closeness = nx.closeness_centrality(graph)
    rows = []
    for gene in graph.nodes:
        rows.append(
            {
                "Gene": gene,
                "Degree": graph.degree(gene),
                "Degree_centrality": degree_cent.get(gene, 0.0),
                "Betweenness": betweenness.get(gene, 0.0),
                "Closeness": closeness.get(gene, 0.0),
            }
        )
    centrality = pd.DataFrame(rows).sort_values(["Degree", "Betweenness", "Gene"], ascending=[False, False, True])
    centrality.to_csv(RESULTS_DIR / "CF30_5_gene_centrality.tsv", sep="\t", index=False)

    annotation = mapping.set_index("Gene")["STRING_annotation"].fillna("").to_dict()
    top_degree = centrality.sort_values(["Degree", "Betweenness"], ascending=[False, False]).head(10).copy()
    top_degree["Ranking_method"] = "Top_degree"
    top_degree["Centrality_rank"] = range(1, len(top_degree) + 1)
    top_betweenness = centrality.sort_values(["Betweenness", "Degree"], ascending=[False, False]).head(10).copy()
    top_betweenness["Ranking_method"] = "Top_betweenness"
    top_betweenness["Centrality_rank"] = range(1, len(top_betweenness) + 1)
    hubs = pd.concat([top_degree, top_betweenness], ignore_index=True)
    hubs["Biological_annotation"] = hubs["Gene"].map(lambda gene: annotation.get(gene, ""))
    hubs = hubs[
        [
            "Ranking_method",
            "Gene",
            "Centrality_rank",
            "Degree",
            "Betweenness",
            "Closeness",
            "Biological_annotation",
        ]
    ]
    hubs.to_csv(RESULTS_DIR / "CF30_5_hub_genes.tsv", sep="\t", index=False)
    return centrality, hubs


def detect_modules(graph: nx.Graph) -> pd.DataFrame:
    if graph.number_of_edges() == 0:
        communities = [{node} for node in graph.nodes]
    else:
        communities = nx.community.louvain_communities(graph, weight="weight", seed=SEED)
    rows = []
    for i, community in enumerate(sorted(communities, key=lambda c: (-len(c), sorted(c)[0])), start=1):
        genes = sorted(community)
        if len(genes) < 2:
            continue
        rows.append({"Module_ID": f"M{i}", "Genes": ";".join(genes), "Module_size": len(genes)})
    modules = pd.DataFrame(rows)
    modules.to_csv(RESULTS_DIR / "CF30_5_network_modules.tsv", sep="\t", index=False)
    return modules


def enrich_modules(modules: pd.DataFrame) -> pd.DataFrame:
    import gseapy as gp

    cache_path = METADATA_DIR / "CF30_5_module_enrichment_cache.tsv"
    if cache_path.exists():
        cached = pd.read_csv(cache_path, sep="\t")
        if "Database" in cached.columns and not (cached["Database"] == "ERROR").any():
            cached.to_csv(RESULTS_DIR / "CF30_5_module_enrichment.tsv", sep="\t", index=False)
            return cached

    rows = []
    for row in modules.itertuples(index=False):
        genes = [gene for gene in row.Genes.split(";") if gene]
        if len(genes) < 2:
            continue
        try:
            enr = gp.enrichr(
                gene_list=genes,
                gene_sets=["Reactome_2022", "GO_Biological_Process_2023"],
                organism="human",
                outdir=None,
                cutoff=1.0,
                verbose=False,
            )
        except Exception as exc:
            rows.append(
                {
                    "Module_ID": row.Module_ID,
                    "Database": "ERROR",
                    "Pathway": str(exc),
                    "Gene_count": len(genes),
                    "p_value": np.nan,
                    "FDR": np.nan,
                    "Overlapping_genes": "",
                }
            )
            continue
        result = enr.results.copy() if enr.results is not None else pd.DataFrame()
        if result.empty:
            continue
        result["Adjusted P-value"] = pd.to_numeric(result["Adjusted P-value"], errors="coerce")
        result["P-value"] = pd.to_numeric(result["P-value"], errors="coerce")
        for _, hit in result.sort_values("Adjusted P-value").head(5).iterrows():
            overlapping = str(hit.get("Genes", ""))
            rows.append(
                {
                    "Module_ID": row.Module_ID,
                    "Database": hit.get("Gene_set", ""),
                    "Pathway": hit.get("Term", ""),
                    "Gene_count": len(overlapping.split(";")) if overlapping else 0,
                    "p_value": hit.get("P-value", np.nan),
                    "FDR": hit.get("Adjusted P-value", np.nan),
                    "Overlapping_genes": overlapping,
                }
            )
    enrichment = pd.DataFrame(rows)
    if enrichment.empty:
        enrichment = pd.DataFrame(columns=["Module_ID", "Database", "Pathway", "Gene_count", "p_value", "FDR", "Overlapping_genes"])
    enrichment.to_csv(cache_path, sep="\t", index=False)
    enrichment.to_csv(RESULTS_DIR / "CF30_5_module_enrichment.tsv", sep="\t", index=False)
    return enrichment


def induced_metrics(graph: nx.Graph, genes: list[str]) -> dict[str, float]:
    subgraph = graph.subgraph(genes).copy()
    return {
        "Edges": subgraph.number_of_edges(),
        "Density": nx.density(subgraph) if subgraph.number_of_nodes() > 1 else 0.0,
        "Clustering_coefficient": nx.average_clustering(subgraph) if subgraph.number_of_nodes() > 1 else 0.0,
    }


def random_network_comparison(
    observed_graph: nx.Graph, background_graph: nx.Graph, signature_genes: list[str]
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(SEED)
    background_genes = np.array(sorted(background_graph.nodes))
    sig_size = len(signature_genes)
    observed = induced_metrics(background_graph, signature_genes)
    random_rows = []
    for i in range(RANDOM_SETS):
        random_genes = rng.choice(background_genes, size=sig_size, replace=False).tolist()
        metrics = induced_metrics(background_graph, random_genes)
        metrics["Random_set"] = i + 1
        random_rows.append(metrics)
    random_df = pd.DataFrame(random_rows)
    random_df.to_csv(RESULTS_DIR / "CF30_5_random_network_distribution.tsv", sep="\t", index=False)

    rows = []
    for metric, observed_value in observed.items():
        values = random_df[metric].astype(float)
        p_ge = (int((values >= observed_value).sum()) + 1) / (len(values) + 1)
        z_score = (observed_value - values.mean()) / values.std(ddof=1) if values.std(ddof=1) > 0 else np.nan
        rows.append(
            {
                "Metric": metric,
                "Observed_signature_value": observed_value,
                "Random_mean": values.mean(),
                "Random_sd": values.std(ddof=1),
                "Observed_percentile": stats.percentileofscore(values, observed_value, kind="weak"),
                "Empirical_p_value_random_ge_observed": p_ge,
                "Z_score_vs_random": z_score,
                "Random_sets": RANDOM_SETS,
                "Random_background": "Locked 500-row CF20 coefficient universe mapped to STRING",
            }
        )
    comparison = pd.DataFrame(rows)
    comparison.to_csv(RESULTS_DIR / "CF30_5_random_network_comparison.tsv", sep="\t", index=False)
    return comparison, random_df


def plot_network(graph: nx.Graph, hubs: pd.DataFrame) -> None:
    hub_genes = set(hubs["Gene"].head(10))
    pos = nx.spring_layout(graph, seed=SEED, weight="weight", k=0.7)
    degrees = dict(graph.degree())
    node_sizes = [110 + 55 * degrees.get(node, 0) for node in graph.nodes]
    colors = ["#c44e52" if node in hub_genes else "#4c78a8" for node in graph.nodes]
    edge_widths = [0.5 + 2.0 * graph.edges[edge].get("weight", 0.4) for edge in graph.edges]

    fig, ax = plt.subplots(figsize=(12, 10))
    nx.draw_networkx_edges(graph, pos, ax=ax, width=edge_widths, edge_color="#9aa0a6", alpha=0.55)
    nx.draw_networkx_nodes(graph, pos, ax=ax, node_size=node_sizes, node_color=colors, edgecolors="white", linewidths=0.8)
    labels = {node: node for node in graph.nodes if node in hub_genes or degrees.get(node, 0) >= 2}
    nx.draw_networkx_labels(graph, pos, labels=labels, ax=ax, font_size=8)
    ax.set_title("CF30.5 STRING PPI network of locked HER2 predictive signature")
    ax.set_axis_off()
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF30_5_PPI_network.png", dpi=300)
    plt.close(fig)


def plot_modules(graph: nx.Graph, modules: pd.DataFrame) -> None:
    module_lookup = {}
    for row in modules.itertuples(index=False):
        for gene in row.Genes.split(";"):
            module_lookup[gene] = row.Module_ID
    palette = plt.cm.tab20(np.linspace(0, 1, max(1, modules.shape[0])))
    module_colors = {module: palette[i] for i, module in enumerate(modules["Module_ID"].tolist())}
    colors = [module_colors.get(module_lookup.get(node), "#c9c9c9") for node in graph.nodes]
    pos = nx.spring_layout(graph, seed=SEED, weight="weight", k=0.7)

    fig, ax = plt.subplots(figsize=(12, 10))
    nx.draw_networkx_edges(graph, pos, ax=ax, edge_color="#9aa0a6", alpha=0.5, width=0.9)
    nx.draw_networkx_nodes(graph, pos, ax=ax, node_color=colors, node_size=190, edgecolors="white", linewidths=0.8)
    labels = {node: node for node in graph.nodes if graph.degree(node) >= 2}
    nx.draw_networkx_labels(graph, pos, labels=labels, ax=ax, font_size=8)
    ax.set_title("CF30.5 Louvain modules in HER2 predictive signature PPI network")
    ax.set_axis_off()
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF30_5_network_module_plot.png", dpi=300)
    plt.close(fig)


def plot_random_comparison(comparison: pd.DataFrame, random_df: pd.DataFrame) -> None:
    metrics = ["Edges", "Density", "Clustering_coefficient"]
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    for ax, metric in zip(axes, metrics):
        observed = float(comparison.loc[comparison["Metric"] == metric, "Observed_signature_value"].iloc[0])
        ax.hist(random_df[metric], bins=30, color="#7aa6c2", edgecolor="white")
        ax.axvline(observed, color="#c44e52", linewidth=2)
        ax.set_title(metric.replace("_", " "))
        ax.set_xlabel("Random network value")
        ax.set_ylabel("Count")
    fig.suptitle("CF30.5 observed signature network vs 1,000 matched random networks")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF30_5_random_network_comparison.png", dpi=300)
    plt.close(fig)


def write_metadata() -> None:
    metadata = pd.DataFrame(
        [
            {
                "Source": "STRING",
                "URL": STRING_BASE,
                "Organism": "Homo sapiens / NCBI taxonomy 9606",
                "Date_accessed": date.today().isoformat(),
                "Network_type": "STRING functional association network, combining physical and functional evidence channels",
                "Medium_confidence_required_score": STRING_MEDIUM_SCORE,
                "High_confidence_required_score": STRING_HIGH_SCORE,
            },
            {
                "Source": "UniProt REST",
                "URL": UNIPROT_SEARCH,
                "Organism": "Homo sapiens / NCBI taxonomy 9606",
                "Date_accessed": date.today().isoformat(),
                "Network_type": "Reviewed UniProtKB mapping by exact gene symbol",
                "Medium_confidence_required_score": "",
                "High_confidence_required_score": "",
            },
            {
                "Source": "Enrichr via gseapy",
                "URL": "https://maayanlab.cloud/Enrichr/",
                "Organism": "Human",
                "Date_accessed": date.today().isoformat(),
                "Network_type": "Module functional annotation using Reactome_2022 and GO_Biological_Process_2023",
                "Medium_confidence_required_score": "",
                "High_confidence_required_score": "",
            },
        ]
    )
    metadata.to_csv(METADATA_DIR / "CF30_5_database_metadata.tsv", sep="\t", index=False)


def write_qc(signature: pd.DataFrame, mapping: pd.DataFrame, random_comparison: pd.DataFrame) -> pd.DataFrame:
    qc = pd.DataFrame(
        [
            {
                "QC_check": "Only locked signature genes used",
                "Status": "PASS",
                "Details": f"Input signature contains {len(signature)} nonzero locked CF20 Elastic-Net genes.",
            },
            {
                "QC_check": "No outcome labels used",
                "Status": "PASS",
                "Details": "CF30.5 reads locked coefficient tables and public annotation/network resources only.",
            },
            {
                "QC_check": "No model retraining",
                "Status": "PASS",
                "Details": "No classifier object is fitted or refit; coefficients are consumed as fixed inputs.",
            },
            {
                "QC_check": "Gene mapping documented",
                "Status": "PASS" if mapping["STRING_ID"].notna().any() else "FAIL",
                "Details": f"{mapping['STRING_ID'].notna().sum()}/{len(mapping)} signature genes mapped to STRING; detailed table written.",
            },
            {
                "QC_check": "Random network comparison completed",
                "Status": "PASS" if len(random_comparison) == 3 else "FAIL",
                "Details": f"{RANDOM_SETS} matched random gene sets evaluated for edges, density, and clustering coefficient.",
            },
        ]
    )
    qc.to_csv(RESULTS_DIR / "CF30_5_quality_control_checks.tsv", sep="\t", index=False)
    return qc


def write_report(
    signature: pd.DataFrame,
    mapping_summary: pd.DataFrame,
    stats_df: pd.DataFrame,
    hubs: pd.DataFrame,
    modules: pd.DataFrame,
    enrichment: pd.DataFrame,
    random_comparison: pd.DataFrame,
    qc: pd.DataFrame,
) -> None:
    medium_stats = stats_df[stats_df["Network"] == "STRING_confidence_0.400"].set_index("Metric")["Value"].to_dict()
    hub_list = ", ".join(hubs[hubs["Ranking_method"] == "Top_degree"]["Gene"].head(10).tolist())
    significant_modules = enrichment[pd.to_numeric(enrichment["FDR"], errors="coerce") < 0.05]
    sig_module_count = significant_modules["Module_ID"].nunique() if not significant_modules.empty else 0
    qc_lines = "\n".join(f"- {row.QC_check}: {row.Status}. {row.Details}" for row in qc.itertuples())
    random_lines = "\n".join(
        f"- {row.Metric}: observed={row.Observed_signature_value:.4g}, random mean={row.Random_mean:.4g}, empirical p={row.Empirical_p_value_random_ge_observed:.4g}"
        for row in random_comparison.itertuples()
    )

    report = f"""# CF30.5 Network-Level Biological Validation of the HER2 Predictive Signature

## Objective
CF30.5 evaluates whether the locked HER2 predictive signature forms biologically connected interaction networks despite the absence of FDR-significant pathways in CF30 ranked GSEA.

## Reviewer Concern Addressed
The analysis treats lack of pathway-level significance as a possible sign of distributed biological information rather than absence of biology. The goal is network-level biological support, not mechanistic proof.

## Input Signature
The input signature contains {len(signature)} nonzero locked CF20 Elastic-Net genes. The complete input gene list is saved in `input/CF30_5_input_gene_list.tsv`.

## Network Construction Method
STRING identifiers were mapped for Homo sapiens and queried at medium confidence 0.400 and high confidence 0.700. The primary network is the medium-confidence STRING functional association network induced only by mapped locked signature genes. Random-set comparisons use matched 86-gene samples from the locked 500-row CF20 coefficient universe on the same STRING background graph.

## Gene Mapping
STRING mapped genes: {int(mapping_summary['STRING_mapped_genes'].iloc[0])}/{int(mapping_summary['Total_genes'].iloc[0])} ({float(mapping_summary['Mapping_percentage'].iloc[0]):.1f}%).

## Network Statistics
- Nodes: {medium_stats.get('Number_of_nodes')}
- Edges: {medium_stats.get('Number_of_edges')}
- Average degree: {float(medium_stats.get('Average_degree', 0)):.3f}
- Clustering coefficient: {float(medium_stats.get('Clustering_coefficient', 0)):.3f}
- Density: {float(medium_stats.get('Network_density', 0)):.3f}

## Hub Genes
Top degree-derived hubs: {hub_list}

## Module Biology
Louvain clustering identified {len(modules)} non-singleton modules. Module-level Reactome and GO Biological Process enrichment identified {sig_module_count} modules with at least one FDR < 0.05 annotation.

## Random Network Comparison
{random_lines}

## Interpretation
The selected HER2 predictive genes were evaluated as an induced STRING PPI network, with hub and module detection performed directly from network topology. Findings provide network-level biological support when connectivity, hubs, or modules exceed matched random expectation or align with established HER2-adjacent programs. They should not be interpreted as causal or mechanistic proof.

## QC
{qc_lines}
"""
    (CF30_5 / "CF30_5_report.md").write_text(report, encoding="utf-8")

    if sig_module_count > 0:
        module_clause = "contained modules with FDR-significant Reactome or GO annotations"
    else:
        module_clause = "did not yield FDR-significant module annotations, but still provided topology-based context"
    paragraph = (
        "Because pathway-level enrichment did not fully capture the distributed nature of the predictive signature, "
        "network-based analysis was performed using the locked nonzero Elastic-Net genes. The selected genes were "
        "mapped to STRING and evaluated as an induced protein-interaction network with hub, module, and matched random "
        f"network analyses. The resulting network {module_clause}, providing complementary network-level biological "
        "support for coordinated molecular programs without implying mechanistic causality."
    )
    (RESULTS_DIR / "CF30_5_manuscript_paragraph.txt").write_text(paragraph + "\n", encoding="utf-8")


def main() -> int:
    ensure_dirs()
    log_path = LOGS_DIR / "CF30_5_run.log"
    with log_path.open("w", encoding="utf-8") as log:
        def log_line(message: str) -> None:
            print(message)
            log.write(message + "\n")
            log.flush()

        log_line("CF30.5 network biology validation started.")
        signature, background = load_signature()
        write_metadata()
        log_line(f"Loaded {len(signature)} locked nonzero signature genes from CF20.")

        mapping, string_background = create_mapping_tables(signature, background)
        mapping_summary = pd.read_csv(RESULTS_DIR / "CF30_5_gene_mapping_summary.tsv", sep="\t")
        log_line(f"STRING mapped {mapping_summary['STRING_mapped_genes'].iloc[0]}/{mapping_summary['Total_genes'].iloc[0]} signature genes.")

        mapped_signature_ids = mapping["STRING_ID"].dropna().astype(str).drop_duplicates().tolist()
        mapped_signature_names = mapping.loc[mapping["STRING_ID"].notna(), "STRING_preferred_name"].astype(str).drop_duplicates().tolist()
        mapped_background_ids = string_background["stringId"].dropna().astype(str).drop_duplicates().tolist()
        mapped_background_names = string_background["preferredName"].dropna().astype(str).drop_duplicates().tolist()

        log_line("Fetching STRING interactions at confidence 0.400 and 0.700.")
        medium_edges = fetch_string_network(mapped_signature_ids, STRING_MEDIUM_SCORE, "CF30_5_STRING_signature_network_0400.tsv")
        high_edges = fetch_string_network(mapped_signature_ids, STRING_HIGH_SCORE, "CF30_5_STRING_signature_network_0700.tsv")
        background_edges = fetch_string_network(mapped_background_ids, STRING_MEDIUM_SCORE, "CF30_5_STRING_background_network_0400.tsv")
        medium_edges.to_csv(RESULTS_DIR / "CF30_5_STRING_interactions_confidence_0_400.tsv", sep="\t", index=False)
        high_edges.to_csv(RESULTS_DIR / "CF30_5_STRING_interactions_confidence_0_700.tsv", sep="\t", index=False)

        medium_graph = graph_from_edges(mapped_signature_names, medium_edges, 0.4)
        high_graph = graph_from_edges(mapped_signature_names, high_edges, 0.7)
        background_graph = graph_from_edges(mapped_background_names, background_edges, 0.4)

        stats_df = write_network_statistics(medium_graph, high_graph)
        centrality, hubs = centrality_tables(medium_graph, signature, mapping)
        modules = detect_modules(medium_graph)
        log_line(f"Detected {len(modules)} non-singleton Louvain modules.")

        enrichment = enrich_modules(modules)
        random_comparison, random_distribution = random_network_comparison(
            medium_graph, background_graph, mapped_signature_names
        )
        qc = write_qc(signature, mapping, random_comparison)

        plot_network(medium_graph, hubs)
        plot_modules(medium_graph, modules)
        plot_random_comparison(random_comparison, random_distribution)
        write_report(signature, mapping_summary, stats_df, hubs, modules, enrichment, random_comparison, qc)

        if (qc["Status"] == "FAIL").any():
            log_line("CF30.5 completed with QC failure.")
            return 1
        log_line("CF30.5 completed successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
