"""
CF29 - Threshold and Operating Point Analysis

Purpose:
    Evaluate threshold-dependent operating characteristics for the locked CF18
    Elastic-Net model on SCAN-B external validation predictions.

Rules:
    NO retraining
    NO model coefficient changes
    NO recalibration
    NO replacement of the locked threshold

    Alternative thresholds are exploratory only.
"""

from __future__ import annotations

import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    roc_auc_score,
    average_precision_score,
)


BASE = Path(__file__).resolve().parents[2]
CF29 = BASE / "CF29_threshold_operating_point_analysis"

INPUT_DIR = CF29 / "input"
SCRIPTS_DIR = CF29 / "scripts"
RESULTS_DIR = CF29 / "results"
FIGURES_DIR = CF29 / "figures"
METADATA_DIR = CF29 / "metadata"
LOGS_DIR = CF29 / "logs"

CF19_PREDICTIONS_FILE = BASE / "results" / "CF19_scanb_external_validation" / "CF19_predictions.tsv"
CF19_METRICS_FILE = BASE / "results" / "CF19_scanb_external_validation" / "CF19_metrics.tsv"
CF19_SUMMARY_FILE = BASE / "results" / "CF19_scanb_external_validation" / "CF19_summary.tsv"
CF27_ANALYSIS_DATASET_FILE = BASE / "CF27_missing_label_sensitivity_analysis" / "results" / "CF27_analysis_dataset.tsv"

THRESHOLD_LOCKED = 0.4345288894526921
THRESHOLD_GRID = np.round(np.arange(0.05, 0.95 + 0.001, 0.01), 2)


def ensure_directories() -> None:
    for directory in [INPUT_DIR, SCRIPTS_DIR, RESULTS_DIR, FIGURES_DIR, METADATA_DIR, LOGS_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


def calculate_threshold_metrics(y_true: np.ndarray, probability: np.ndarray, threshold: float) -> dict[str, float]:
    y_pred = (probability >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    sensitivity = tp / (tp + fn) if (tp + fn) else np.nan
    specificity = tn / (tn + fp) if (tn + fp) else np.nan
    ppv = tp / (tp + fp) if (tp + fp) else np.nan
    npv = tn / (tn + fn) if (tn + fn) else np.nan
    accuracy = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred) if (tp + fp + fn) else np.nan
    balanced_accuracy = np.nanmean([sensitivity, specificity])
    mcc = matthews_corrcoef(y_true, y_pred) if len(np.unique(y_pred)) > 1 else 0.0
    return {
        "threshold": float(threshold),
        "TP": int(tp),
        "TN": int(tn),
        "FP": int(fp),
        "FN": int(fn),
        "sensitivity": sensitivity,
        "specificity": specificity,
        "PPV": ppv,
        "NPV": npv,
        "accuracy": accuracy,
        "F1": f1,
        "balanced_accuracy": balanced_accuracy,
        "MCC": mcc,
    }


def load_analysis_dataset() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    cf27 = pd.read_csv(CF27_ANALYSIS_DATASET_FILE, sep="\t")
    cf19_predictions = pd.read_csv(CF19_PREDICTIONS_FILE, sep="\t")
    cf19_metrics = pd.read_csv(CF19_METRICS_FILE, sep="\t")
    cf19_summary = pd.read_csv(CF19_SUMMARY_FILE, sep="\t")

    required = {"sample_id", "HER2_probability", "locked_threshold", "HER2_label_cf19"}
    missing = required.difference(cf27.columns)
    if missing:
        raise ValueError(f"CF27 analysis dataset missing columns required for CF29: {sorted(missing)}")

    if not cf27["sample_id"].equals(cf19_predictions["sample_id"]):
        cf27 = cf19_predictions[["sample_id"]].merge(cf27, on="sample_id", how="left", validate="one_to_one")

    cf27["HER2_probability"] = cf27["HER2_probability"].astype(float)
    cf27["HER2_label_cf19"] = cf27["HER2_label_cf19"].astype(int)
    cf27["locked_threshold"] = cf27["locked_threshold"].astype(float)
    return cf27, cf19_predictions, cf19_metrics, cf19_summary


def write_manifest(
    analysis: pd.DataFrame,
    cf19_predictions: pd.DataFrame,
    cf19_metrics: pd.DataFrame,
    cf19_summary: pd.DataFrame,
) -> pd.DataFrame:
    manifest = pd.DataFrame(
        [
            {
                "filename": CF19_PREDICTIONS_FILE.name,
                "path": str(CF19_PREDICTIONS_FILE),
                "sample_count": len(cf19_predictions),
                "columns_used": "sample_id; HER2_probability; prediction; locked_threshold",
                "description": "Locked CF19 SCAN-B prediction probabilities and threshold calls.",
            },
            {
                "filename": CF27_ANALYSIS_DATASET_FILE.name,
                "path": str(CF27_ANALYSIS_DATASET_FILE),
                "sample_count": len(analysis),
                "columns_used": "sample_id; HER2_probability; locked_threshold; HER2_label_cf19",
                "description": "CF27 integrated SCAN-B labels using original CF19 label handling.",
            },
            {
                "filename": CF19_METRICS_FILE.name,
                "path": str(CF19_METRICS_FILE),
                "sample_count": len(cf19_metrics),
                "columns_used": "metric; value",
                "description": "CF19 locked-threshold performance values used for reproduction checks.",
            },
            {
                "filename": CF19_SUMMARY_FILE.name,
                "path": str(CF19_SUMMARY_FILE),
                "sample_count": len(cf19_summary),
                "columns_used": "item; value",
                "description": "CF19 SCAN-B sample count and HER2 class summary.",
            },
        ]
    )
    manifest.to_csv(INPUT_DIR / "CF29_input_manifest.tsv", sep="\t", index=False)
    manifest.to_csv(METADATA_DIR / "CF29_input_manifest.tsv", sep="\t", index=False)
    return manifest


def write_threshold_grid(analysis: pd.DataFrame) -> pd.DataFrame:
    y = analysis["HER2_label_cf19"].to_numpy(dtype=int)
    probability = analysis["HER2_probability"].to_numpy(dtype=float)
    rows = [calculate_threshold_metrics(y, probability, threshold) for threshold in THRESHOLD_GRID]
    table = pd.DataFrame(rows)
    table.to_csv(RESULTS_DIR / "CF29_threshold_metrics.tsv", sep="\t", index=False)
    return table


def write_locked_threshold_metrics(analysis: pd.DataFrame) -> pd.DataFrame:
    y = analysis["HER2_label_cf19"].to_numpy(dtype=int)
    probability = analysis["HER2_probability"].to_numpy(dtype=float)
    locked = pd.DataFrame([calculate_threshold_metrics(y, probability, THRESHOLD_LOCKED)])
    locked["AUROC"] = roc_auc_score(y, probability)
    locked["PR_AUC"] = average_precision_score(y, probability)
    locked.to_csv(RESULTS_DIR / "CF29_locked_threshold_metrics.tsv", sep="\t", index=False)
    return locked


def pick_operating_points(grid: pd.DataFrame) -> pd.DataFrame:
    rows = []

    max_mcc = grid.loc[grid["MCC"].idxmax()]
    rows.append(("Maximum MCC", max_mcc, "Exploratory threshold maximizing MCC on SCAN-B grid."))

    max_balanced = grid.loc[grid["balanced_accuracy"].idxmax()]
    rows.append(("Maximum balanced accuracy", max_balanced, "Exploratory threshold maximizing balanced accuracy on SCAN-B grid."))

    sens_candidates = grid[grid["sensitivity"] >= 0.95]
    sens_point = sens_candidates.sort_values(["specificity", "threshold"], ascending=[False, False]).iloc[0]
    rows.append(("Sensitivity >=95%", sens_point, "Highest-specificity exploratory threshold preserving sensitivity >=95%."))

    spec_candidates = grid[grid["specificity"] >= 0.50]
    spec_point = spec_candidates.sort_values(["sensitivity", "threshold"], ascending=[False, True]).iloc[0]
    rows.append(("Specificity >=50%", spec_point, "Highest-sensitivity exploratory threshold with specificity >=50%."))

    out_rows = []
    for criterion, row, note in rows:
        out_rows.append(
            {
                "Criterion": criterion,
                "Threshold": row["threshold"],
                "Sensitivity": row["sensitivity"],
                "Specificity": row["specificity"],
                "PPV": row["PPV"],
                "NPV": row["NPV"],
                "MCC": row["MCC"],
                "Exploratory_status": "Exploratory only; does not replace locked CF18 threshold.",
                "Selection_rule": note,
            }
        )
    operating_points = pd.DataFrame(out_rows)
    operating_points.to_csv(RESULTS_DIR / "CF29_operating_points_summary.tsv", sep="\t", index=False)
    return operating_points


def write_probability_groups(analysis: pd.DataFrame) -> pd.DataFrame:
    bins = [
        analysis["HER2_probability"] < 0.2,
        (analysis["HER2_probability"] >= 0.2) & (analysis["HER2_probability"] <= 0.7),
        analysis["HER2_probability"] > 0.7,
    ]
    labels = ["Low probability (<0.2)", "Intermediate probability (0.2-0.7)", "High probability (>0.7)"]
    analysis = analysis.copy()
    analysis["Probability_group"] = np.select(bins, labels, default="Unclassified")
    rows = []
    for label in labels:
        group = analysis[analysis["Probability_group"] == label]
        positives = int(group["HER2_label_cf19"].sum())
        rows.append(
            {
                "Probability_group": label,
                "N": len(group),
                "HER2_positive_count": positives,
                "HER2_negative_count": int(len(group) - positives),
                "HER2_positive_proportion": positives / len(group) if len(group) else np.nan,
                "Mean_probability": group["HER2_probability"].mean(),
                "Median_probability": group["HER2_probability"].median(),
            }
        )
    probability_groups = pd.DataFrame(rows)
    probability_groups.to_csv(RESULTS_DIR / "CF29_probability_groups.tsv", sep="\t", index=False)
    return probability_groups


def write_dca_input(analysis: pd.DataFrame) -> pd.DataFrame:
    dca = analysis.rename(
        columns={
            "HER2_label_cf19": "true_label",
            "HER2_probability": "prediction_probability",
        }
    )[["sample_id", "true_label", "prediction_probability"]]
    dca.to_csv(RESULTS_DIR / "CF29_DCA_input.tsv", sep="\t", index=False)
    return dca


def plot_threshold_curves(grid: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(7.5, 5))
    ax.plot(grid["threshold"], grid["sensitivity"], label="Sensitivity", color="#4C78A8", linewidth=2)
    ax.plot(grid["threshold"], grid["specificity"], label="Specificity", color="#59A14F", linewidth=2)
    ax.axvline(THRESHOLD_LOCKED, color="#111111", linestyle="--", linewidth=1.5, label="Locked threshold")
    ax.set_xlabel("Probability threshold")
    ax.set_ylabel("Metric value")
    ax.set_ylim(0, 1.02)
    ax.set_title("CF29 Sensitivity-Specificity Trade-off")
    ax.grid(axis="y", alpha=0.22)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF29_sensitivity_specificity_curve.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.5, 5))
    ax.plot(grid["threshold"], grid["PPV"], label="PPV", color="#F28E2B", linewidth=2)
    ax.plot(grid["threshold"], grid["NPV"], label="NPV", color="#9467BD", linewidth=2)
    ax.axvline(THRESHOLD_LOCKED, color="#111111", linestyle="--", linewidth=1.5, label="Locked threshold")
    ax.set_xlabel("Probability threshold")
    ax.set_ylabel("Metric value")
    ax.set_ylim(0, 1.02)
    ax.set_title("CF29 Predictive Values Across Thresholds")
    ax.grid(axis="y", alpha=0.22)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF29_precision_recall_threshold_curve.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.5, 5))
    ax.plot(grid["threshold"], grid["MCC"], color="#D62728", linewidth=2)
    ax.axvline(THRESHOLD_LOCKED, color="#111111", linestyle="--", linewidth=1.5, label="Locked threshold")
    ax.set_xlabel("Probability threshold")
    ax.set_ylabel("MCC")
    ax.set_title("CF29 Matthews Correlation Across Thresholds")
    ax.grid(axis="y", alpha=0.22)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF29_MCC_threshold_curve.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def write_quality_control(
    analysis: pd.DataFrame,
    locked: pd.DataFrame,
    cf19_metrics: pd.DataFrame,
    grid: pd.DataFrame,
) -> pd.DataFrame:
    cf19 = dict(zip(cf19_metrics["metric"], cf19_metrics["value"].astype(float)))
    threshold_values = analysis["locked_threshold"].astype(float).unique()
    locked_row = locked.iloc[0]
    checks = [
        {
            "check": "Locked threshold unchanged",
            "observed": str(float(threshold_values[0])) if len(threshold_values) == 1 else str(threshold_values),
            "expected": str(THRESHOLD_LOCKED),
            "status": "PASS" if len(threshold_values) == 1 and np.isclose(threshold_values[0], THRESHOLD_LOCKED) else "FAIL",
            "notes": "Locked threshold extracted from CF19 prediction table.",
        },
        {
            "check": "Locked threshold sensitivity reproduces CF19",
            "observed": f"{locked_row['sensitivity']:.12f}",
            "expected": f"{cf19['Sensitivity']:.12f}",
            "status": "PASS" if np.isclose(locked_row["sensitivity"], cf19["Sensitivity"], atol=1e-12) else "FAIL",
            "notes": "Recomputed from CF27 labels and CF19 probabilities.",
        },
        {
            "check": "Locked threshold specificity reproduces CF19",
            "observed": f"{locked_row['specificity']:.12f}",
            "expected": f"{cf19['Specificity']:.12f}",
            "status": "PASS" if np.isclose(locked_row["specificity"], cf19["Specificity"], atol=1e-12) else "FAIL",
            "notes": "Recomputed from CF27 labels and CF19 probabilities.",
        },
        {
            "check": "CF19 discrimination reproduced",
            "observed": f"AUROC={locked_row['AUROC']:.12f}; PR_AUC={locked_row['PR_AUC']:.12f}",
            "expected": f"AUROC={cf19['AUROC']:.12f}; PR_AUC={cf19['PR_AUC']:.12f}",
            "status": "PASS"
            if np.isclose(locked_row["AUROC"], cf19["AUROC"], atol=1e-12)
            and np.isclose(locked_row["PR_AUC"], cf19["PR_AUC"], atol=1e-12)
            else "FAIL",
            "notes": "Discrimination is threshold-independent and unchanged.",
        },
        {
            "check": "Threshold grid evaluated as exploratory",
            "observed": f"{grid['threshold'].min():.2f}-{grid['threshold'].max():.2f}; step 0.01; n={len(grid)}",
            "expected": "0.05-0.95; step 0.01; exploratory only",
            "status": "PASS" if len(grid) == 91 and np.isclose(grid["threshold"].iloc[0], 0.05) and np.isclose(grid["threshold"].iloc[-1], 0.95) else "FAIL",
            "notes": "Alternative operating points are not claimed as new clinical thresholds.",
        },
        {
            "check": "No model retraining or recalibration",
            "observed": "Loaded existing prediction probabilities only",
            "expected": "No retraining; no recalibration",
            "status": "PASS",
            "notes": "CF29 does not load any model object.",
        },
    ]
    qc = pd.DataFrame(checks)
    qc.to_csv(RESULTS_DIR / "CF29_quality_control_checks.tsv", sep="\t", index=False)
    return qc


def metric_percent(value: float) -> str:
    return f"{value * 100:.1f}%"


def write_manuscript_paragraph(locked: pd.DataFrame, operating_points: pd.DataFrame) -> str:
    locked_row = locked.iloc[0]
    mcc_row = operating_points.loc[operating_points["Criterion"] == "Maximum MCC"].iloc[0]
    paragraph = (
        "Threshold-dependent evaluation demonstrated that the locked operating point prioritized sensitivity, "
        f"with sensitivity {metric_percent(locked_row['sensitivity'])}, specificity "
        f"{metric_percent(locked_row['specificity'])}, PPV {metric_percent(locked_row['PPV'])}, and NPV "
        f"{metric_percent(locked_row['NPV'])}. Exploratory threshold scans showed the expected "
        "sensitivity-specificity trade-off; the maximum-MCC grid threshold was "
        f"{mcc_row['Threshold']:.2f} but was not used to replace the prespecified locked threshold. "
        "These results support interpretation of the model as a transcriptomic probability estimation and "
        "screening/inference framework rather than a direct replacement for clinical HER2 testing."
    )
    (RESULTS_DIR / "CF29_manuscript_paragraph.txt").write_text(paragraph + "\n", encoding="utf-8")
    return paragraph


def write_report(
    manifest: pd.DataFrame,
    locked: pd.DataFrame,
    operating_points: pd.DataFrame,
    probability_groups: pd.DataFrame,
    qc: pd.DataFrame,
    manuscript: str,
) -> None:
    manifest_lines = [f"- `{row.filename}`: {row.description}" for row in manifest.itertuples(index=False)]
    locked_row = locked.iloc[0]
    operating_lines = [
        (
            f"- {row.Criterion}: threshold={row.Threshold:.2f}, sensitivity={metric_percent(row.Sensitivity)}, "
            f"specificity={metric_percent(row.Specificity)}, PPV={metric_percent(row.PPV)}, "
            f"NPV={metric_percent(row.NPV)}, MCC={row.MCC:.3f}."
        )
        for row in operating_points.itertuples(index=False)
    ]
    group_lines = [
        (
            f"- {row.Probability_group}: n={row.N}, HER2+ proportion="
            f"{metric_percent(row.HER2_positive_proportion)}."
        )
        for row in probability_groups.itertuples(index=False)
    ]
    qc_sentence = "All quality control checks passed." if (qc["status"] == "PASS").all() else "One or more quality control checks require review."
    report = f"""# CF29 Threshold and Operating Point Analysis

## Objective

CF29 evaluates threshold-dependent performance for the locked CF18 Elastic-Net model on SCAN-B external validation predictions.

## Reviewer Concern Addressed

The locked model has strong discrimination but, at the prespecified threshold, prioritizes sensitivity with lower specificity and PPV. CF29 characterizes this operating behavior without changing the model or replacing the locked threshold.

## Input Files

{chr(10).join(manifest_lines)}

## Locked Threshold Performance

Locked threshold: {THRESHOLD_LOCKED}

- TP={int(locked_row['TP'])}, TN={int(locked_row['TN'])}, FP={int(locked_row['FP'])}, FN={int(locked_row['FN'])}
- Sensitivity={metric_percent(locked_row['sensitivity'])}
- Specificity={metric_percent(locked_row['specificity'])}
- PPV={metric_percent(locked_row['PPV'])}
- NPV={metric_percent(locked_row['NPV'])}
- Accuracy={metric_percent(locked_row['accuracy'])}
- F1={locked_row['F1']:.3f}
- Balanced accuracy={locked_row['balanced_accuracy']:.3f}
- MCC={locked_row['MCC']:.3f}

## Threshold-Dependent Analysis

Thresholds from 0.05 to 0.95 in 0.01 increments were evaluated as exploratory operating points only. The complete grid is saved in `CF29_threshold_metrics.tsv`.

## Operating Point Comparison

{chr(10).join(operating_lines)}

These operating points are exploratory only and do not replace the CF18 locked threshold.

## Clinical Interpretation

{chr(10).join(group_lines)}

The threshold analysis demonstrates the trade-off between sensitivity and specificity and supports interpretation of the model as a transcriptomic probability estimation framework rather than a direct replacement for clinical HER2 testing.

## Quality Control

{qc_sentence}

## Manuscript-Ready Paragraph

{manuscript}
"""
    (CF29 / "CF29_report.md").write_text(report, encoding="utf-8")


def main() -> None:
    start = time.time()
    ensure_directories()
    analysis, cf19_predictions, cf19_metrics, cf19_summary = load_analysis_dataset()
    manifest = write_manifest(analysis, cf19_predictions, cf19_metrics, cf19_summary)
    grid = write_threshold_grid(analysis)
    locked = write_locked_threshold_metrics(analysis)
    operating_points = pick_operating_points(grid)
    probability_groups = write_probability_groups(analysis)
    write_dca_input(analysis)
    plot_threshold_curves(grid)
    qc = write_quality_control(analysis, locked, cf19_metrics, grid)
    manuscript = write_manuscript_paragraph(locked, operating_points)
    write_report(manifest, locked, operating_points, probability_groups, qc, manuscript)

    log_lines = [
        "CF29 Threshold and Operating Point Analysis",
        f"Started: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start))}",
        f"Completed: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"Runtime minutes: {(time.time() - start) / 60:.3f}",
        f"Threshold range: {THRESHOLD_GRID.min():.2f}-{THRESHOLD_GRID.max():.2f}; step 0.01",
        f"Locked threshold: {THRESHOLD_LOCKED}",
        "Model retraining: NO",
        "Threshold optimization for primary results: NO",
        f"Output folder: {CF29}",
    ]
    (LOGS_DIR / "CF29_threshold_operating_point_analysis.log").write_text(
        "\n".join(log_lines) + "\n",
        encoding="utf-8",
    )

    locked_row = locked.iloc[0]
    print("CF29 completed successfully.")
    print("Input files used:")
    for row in manifest.itertuples(index=False):
        print(f"- {row.filename}: {row.path}")
    print(f"Threshold range evaluated: {THRESHOLD_GRID.min():.2f} to {THRESHOLD_GRID.max():.2f}, step 0.01")
    print("Locked threshold metrics:")
    print(
        f"- threshold={THRESHOLD_LOCKED}; TP={int(locked_row['TP'])}; TN={int(locked_row['TN'])}; "
        f"FP={int(locked_row['FP'])}; FN={int(locked_row['FN'])}; "
        f"sensitivity={metric_percent(locked_row['sensitivity'])}; "
        f"specificity={metric_percent(locked_row['specificity'])}; "
        f"PPV={metric_percent(locked_row['PPV'])}; NPV={metric_percent(locked_row['NPV'])}; "
        f"MCC={locked_row['MCC']:.3f}"
    )
    print("Best exploratory operating points:")
    for row in operating_points.itertuples(index=False):
        print(
            f"- {row.Criterion}: threshold={row.Threshold:.2f}; "
            f"sensitivity={metric_percent(row.Sensitivity)}; specificity={metric_percent(row.Specificity)}; "
            f"PPV={metric_percent(row.PPV)}; NPV={metric_percent(row.NPV)}; MCC={row.MCC:.3f}"
        )
    print(f"Output folder: {CF29}")


if __name__ == "__main__":
    main()
