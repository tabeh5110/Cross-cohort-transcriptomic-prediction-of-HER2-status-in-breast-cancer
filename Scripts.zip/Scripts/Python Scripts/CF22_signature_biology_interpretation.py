"""
============================================================
CF22 - SIGNATURE BIOLOGY INTERPRETATION
============================================================

Purpose:
    Biological interpretation of the locked CF18 HER2 Elastic-Net
    predictive signature.

Rules:
    - NO ML
    - NO retraining
    - NO feature selection
    - Uses only locked CF18 predictors

Outputs:
    CF22 predictive genes
    Hallmark enrichment
    Reactome enrichment
    Publication figures
============================================================
"""

import os
import time
import joblib
import pandas as pd
import matplotlib.pyplot as plt
import gseapy as gp


START = time.time()

BASE = r"D:\Masters\Research\TCGA_BRCA"

MODEL_FILE = os.path.join(
    BASE,
    "data",
    "processed",
    "ml_ready",
    "CF18_final_model",
    "CF18_final_ElasticNet_model_bundle.joblib"
)

OUT = os.path.join(
    BASE,
    "results",
    "CF22_signature_biology"
)

os.makedirs(OUT, exist_ok=True)


def load_predictive_genes():

    print("[1/6] Loading CF18 locked model bundle...")

    bundle = joblib.load(MODEL_FILE)

    genes = bundle["feature_universe_gene_symbols"]
    model = bundle["elasticnet_model"]

    coef = model.coef_.ravel()

    if len(genes) != len(coef):
        raise RuntimeError(
            "Gene list and coefficient length mismatch"
        )

    table = pd.DataFrame(
        {
            "Gene": genes,
            "Coefficient": coef
        }
    )

    table = table[
        table["Coefficient"] != 0
    ].copy()

    table["Direction"] = table["Coefficient"].apply(
        lambda x: "Positive_predictor" if x > 0 else "Negative_predictor"
    )

    table = table.sort_values(
        "Coefficient",
        ascending=False
    )

    table.to_csv(
        os.path.join(
            OUT,
            "CF22_predictive_gene_list.tsv"
        ),
        sep="\t",
        index=False
    )

    print(
        "Non-zero predictive genes:",
        len(table)
    )

    return table


def enrichment(genes):

    print("[2/6] Running Hallmark enrichment...")

    enr_h = gp.enrichr(
        gene_list=list(genes),
        gene_sets="MSigDB_Hallmark_2020",
        organism="Human",
        outdir=None
    )

    hallmark = enr_h.results

    hallmark.to_csv(
        os.path.join(
            OUT,
            "CF22_Hallmark_enrichment.tsv"
        ),
        sep="\t",
        index=False
    )


    print("[3/6] Running Reactome enrichment...")

    enr_r = gp.enrichr(
        gene_list=list(genes),
        gene_sets="Reactome_2022",
        organism="Human",
        outdir=None
    )

    reactome = enr_r.results

    reactome.to_csv(
        os.path.join(
            OUT,
            "CF22_Reactome_enrichment.tsv"
        ),
        sep="\t",
        index=False
    )

    return hallmark, reactome


def plot_enrichment(df, name):

    if df.empty:
        return

    top = df.sort_values(
        "Adjusted P-value"
    ).head(15)

    plt.figure(
        figsize=(8,6)
    )

    plt.barh(
        top["Term"][::-1],
        -top["Adjusted P-value"].apply(
            lambda x: __import__("math").log10(x)
        )[::-1]
    )

    plt.xlabel(
        "-log10 Adjusted P-value"
    )

    plt.title(
        name
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            OUT,
            name.replace(" ","_") + ".png"
        ),
        dpi=300
    )

    plt.close()


def main():

    print("""
============================================================
 CF22 - SIGNATURE BIOLOGY INTERPRETATION
============================================================
NO ML
NO RETRAINING
NO FEATURE SELECTION
============================================================
""")

    genes_table = load_predictive_genes()

    hallmark, reactome = enrichment(
        genes_table["Gene"]
    )

    print("[4/6] Generating enrichment figures...")

    plot_enrichment(
        hallmark,
        "CF22_Hallmark_Pathways"
    )

    plot_enrichment(
        reactome,
        "CF22_Reactome_Pathways"
    )


    print("[5/6] Writing summary...")

    summary = pd.DataFrame(
        {
            "Item":[
                "Predictive genes",
                "Hallmark pathways",
                "Reactome pathways"
            ],
            "Value":[
                len(genes_table),
                len(hallmark),
                len(reactome)
            ]
        }
    )

    summary.to_csv(
        os.path.join(
            OUT,
            "CF22_summary.tsv"
        ),
        sep="\t",
        index=False
    )


    print("[6/6] Final gate")

    print("""
============================================================
 CF22 COMPLETE - BIOLOGICAL INTERPRETATION PASSED
============================================================
""")

    print(
        "Predictive genes:",
        len(genes_table)
    )

    print(
        "Runtime:",
        round((time.time()-START)/60,2),
        "min"
    )

    print(
        "STATUS: READY_FOR_CF23"
    )


if __name__ == "__main__":
    main()
