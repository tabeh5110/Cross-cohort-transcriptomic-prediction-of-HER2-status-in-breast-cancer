#!/usr/bin/env python
"""
CF15 - ML experiment design + leakage-safe TCGA model-input preparation

This stage performs NO model fitting.

It validates the locked CF14 protocol, constructs the HER2-classifiable TCGA
discovery matrix over the locked 22,106 TCGA∩SCAN-B gene universe, applies the
locked within-sample percentile-rank representation, freezes the repeated
stratified outer-CV split registry, audits dependencies, and records model
search spaces for CF16.

Important leakage rule:
- The within-sample rank transform is computed independently within each sample
  and therefore may be precomputed before CV.
- StandardScaler, zero-variance filtering, SelectKBest, hyperparameter tuning,
  and any supervised operation remain inside training folds in CF16.
- No SCAN-B expression values or labels are used in CF15.
"""

from __future__ import annotations

import hashlib
import importlib.metadata as ilm
import logging
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.model_selection import RepeatedStratifiedKFold

ROOT = Path.cwd()

CF14_DIR = ROOT / "results" / "CF14_pre_ml_manual_audit"
CF14_LOCKED_SUMMARY = CF14_DIR / "CF14_LOCKED_summary.tsv"
CF14_LOCKED_PROTOCOL = CF14_DIR / "CF14_LOCKED_pre_ml_protocol.tsv"

ML_READY = ROOT / "data" / "processed" / "ml_ready"
TCGA_LOCKED_MANIFEST = ML_READY / "CF14_TCGA_ML_sample_manifest_LOCKED.tsv"
GENE_UNIVERSE = ML_READY / "CF14_external_validation_gene_universe_LOCKED.tsv"

TCGA_TPM = ROOT / "data" / "processed" / "tcga_brca" / "expression" / "CF6_tpm.tsv.gz"
CROSSWALK = ROOT / "data" / "processed" / "cross_cohort" / "CF13_transcriptomic_feature_crosswalk.tsv"

RESULTS = ROOT / "results" / "CF15_ml_experiment_design"
PROCESSED = ROOT / "data" / "processed" / "ml_ready"
LOG_DIR = ROOT / "logs"
LOG_FILE = LOG_DIR / "CF15_ml_experiment_design.log"

MATRIX_NPZ = PROCESSED / "CF15_TCGA_HER2_rank_matrix.npz"
OUTER_SPLITS = RESULTS / "CF15_outer_cv_test_assignments.tsv"
OUTER_COUNTS = RESULTS / "CF15_outer_cv_class_counts.tsv"
DEPENDENCIES = RESULTS / "CF15_dependency_audit.tsv"
SEARCH_SPACE = RESULTS / "CF15_model_search_space.tsv"
METRICS = RESULTS / "CF15_metric_specification.tsv"
DESIGN = RESULTS / "CF15_experiment_design.tsv"
SUMMARY = RESULTS / "CF15_summary.tsv"
PROVENANCE = RESULTS / "CF15_provenance.tsv"

PRIMARY_ENDPOINT = "HER2"
POSITIVE_LABEL = "POSITIVE"
NEGATIVE_LABEL = "NEGATIVE"

EXPECTED_TCGA_CLASSIFIABLE = 938
EXPECTED_POSITIVE = 182
EXPECTED_NEGATIVE = 756
EXPECTED_GENES = 22106

SEED = 20260815
OUTER_SPLITS_N = 5
OUTER_REPEATS = 3
INNER_SPLITS_N = 4
CHUNK_ROWS = 1000


def setup_logging() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    PROCESSED.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(block_size), b""):
            h.update(block)
    return h.hexdigest()


def metric_dict(path: Path) -> Dict[str, str]:
    df = pd.read_csv(path, sep="\t", dtype=str)
    if not {"metric", "value"}.issubset(df.columns):
        raise RuntimeError(f"Expected metric/value columns in {path}")
    return dict(zip(df["metric"].astype(str), df["value"].astype(str)))


def norm_ensembl(x: str) -> str:
    return str(x).strip().split(".", 1)[0]


def package_version(dist_name: str) -> str:
    try:
        return ilm.version(dist_name)
    except ilm.PackageNotFoundError:
        return "MISSING"


def load_locked_her2_manifest() -> pd.DataFrame:
    m = pd.read_csv(TCGA_LOCKED_MANIFEST, sep="\t", dtype=str)
    required = {
        "patient_id", "expression_sample_id", "sample_type",
        "ER", "PR", "HER2", "TNBC",
    }
    missing = required - set(m.columns)
    if missing:
        raise RuntimeError(f"Locked TCGA manifest missing columns: {sorted(missing)}")

    her2 = m.loc[m["HER2"].isin([POSITIVE_LABEL, NEGATIVE_LABEL])].copy()
    her2["y"] = (her2["HER2"] == POSITIVE_LABEL).astype(np.int8)

    if len(her2) != EXPECTED_TCGA_CLASSIFIABLE:
        raise RuntimeError(
            f"HER2-classifiable TCGA tumors={len(her2)}; "
            f"expected {EXPECTED_TCGA_CLASSIFIABLE}."
        )

    pos = int(her2["y"].sum())
    neg = int(len(her2) - pos)
    if pos != EXPECTED_POSITIVE or neg != EXPECTED_NEGATIVE:
        raise RuntimeError(
            f"HER2 counts changed: positive={pos}, negative={neg}; "
            f"expected {EXPECTED_POSITIVE}/{EXPECTED_NEGATIVE}."
        )

    if her2["patient_id"].duplicated().any():
        raise RuntimeError("HER2 manifest contains duplicate patient IDs.")
    if her2["expression_sample_id"].duplicated().any():
        raise RuntimeError("HER2 manifest contains duplicate expression sample IDs.")

    return her2.reset_index(drop=True)


def load_gene_map() -> Tuple[List[str], Dict[str, str]]:
    genes_df = pd.read_csv(GENE_UNIVERSE, sep="\t", dtype=str)
    if "gene_symbol" not in genes_df.columns:
        raise RuntimeError("Locked gene-universe file lacks gene_symbol.")

    genes = genes_df["gene_symbol"].astype(str).tolist()

    if len(genes) != EXPECTED_GENES:
        raise RuntimeError(
            f"Locked gene universe={len(genes)}; expected {EXPECTED_GENES}."
        )
    if len(set(genes)) != len(genes):
        raise RuntimeError("Locked gene universe contains duplicate symbols.")

    cw = pd.read_csv(CROSSWALK, sep="\t", dtype=str)
    required = {
        "gene_symbol",
        "TCGA_ensembl_gene_id",
        "eligible_TCGA_SCANB_external_validation",
    }
    missing = required - set(cw.columns)
    if missing:
        raise RuntimeError(f"CF13 crosswalk missing columns: {sorted(missing)}")

    eligible = (
        cw["eligible_TCGA_SCANB_external_validation"]
        .astype(str)
        .str.lower()
        .isin(["true", "1", "yes"])
    )
    cw = cw.loc[eligible].copy()

    if len(cw) != EXPECTED_GENES:
        raise RuntimeError(
            f"CF13 eligible crosswalk rows={len(cw)}; expected {EXPECTED_GENES}."
        )

    cw = cw.loc[cw["gene_symbol"].isin(genes)].copy()
    if len(cw) != EXPECTED_GENES:
        missing_genes = sorted(set(genes) - set(cw["gene_symbol"].astype(str)))
        raise RuntimeError(
            f"{len(missing_genes)} locked genes are missing from CF13 crosswalk."
        )

    cw["ensembl_base"] = cw["TCGA_ensembl_gene_id"].map(norm_ensembl)

    if cw["ensembl_base"].duplicated().any():
        dup = cw.loc[
            cw["ensembl_base"].duplicated(keep=False),
            ["gene_symbol", "TCGA_ensembl_gene_id"],
        ]
        raise RuntimeError(
            "Normalized TCGA Ensembl IDs are not one-to-one in the locked gene universe. "
            f"Examples: {dup.head(10).to_dict('records')}"
        )

    base_to_symbol = dict(
        zip(cw["ensembl_base"], cw["gene_symbol"].astype(str))
    )
    return genes, base_to_symbol


def build_tcga_matrix(
    sample_ids: List[str],
    genes_order: List[str],
    base_to_symbol: Dict[str, str],
) -> np.ndarray:
    header = pd.read_csv(TCGA_TPM, sep="\t", compression="gzip", nrows=0)
    cols = list(map(str, header.columns))
    if len(cols) < 2:
        raise RuntimeError("TCGA TPM matrix has fewer than 2 columns.")

    gene_id_col = cols[0]
    available_samples = set(cols[1:])

    missing_samples = sorted(set(sample_ids) - available_samples)
    if missing_samples:
        raise RuntimeError(
            f"{len(missing_samples)} locked HER2 sample IDs are missing from TCGA TPM."
        )

    usecols = [gene_id_col] + sample_ids
    target_bases = set(base_to_symbol.keys())

    pieces = []
    total_selected = 0

    for chunk_i, chunk in enumerate(
        pd.read_csv(
            TCGA_TPM,
            sep="\t",
            compression="gzip",
            usecols=usecols,
            chunksize=CHUNK_ROWS,
            low_memory=False,
        ),
        start=1,
    ):
        bases = chunk[gene_id_col].astype(str).map(norm_ensembl)
        keep = bases.isin(target_bases)
        if not keep.any():
            continue

        sub = chunk.loc[keep].copy()
        sub["gene_symbol"] = bases.loc[keep].map(base_to_symbol).values

        numeric = sub[sample_ids].apply(pd.to_numeric, errors="coerce")
        if numeric.isna().any().any():
            raise RuntimeError(
                f"Non-numeric/missing TPM values detected in selected chunk {chunk_i}."
            )

        block = numeric.copy()
        block.index = sub["gene_symbol"].astype(str).values
        pieces.append(block)
        total_selected += len(block)

        if chunk_i % 10 == 0:
            logging.info(
                f"      TPM rows scanned: ~{chunk_i * CHUNK_ROWS:,}; "
                f"locked genes recovered: {total_selected:,}/{EXPECTED_GENES:,}"
            )

    if not pieces:
        raise RuntimeError("No locked genes were recovered from TCGA TPM.")

    gene_by_sample = pd.concat(pieces, axis=0)

    if gene_by_sample.index.duplicated().any():
        dup = gene_by_sample.index[
            gene_by_sample.index.duplicated()
        ].unique().tolist()
        raise RuntimeError(
            f"Duplicate gene symbols recovered across TPM chunks. Examples: {dup[:10]}"
        )

    recovered = set(map(str, gene_by_sample.index))
    missing_genes = sorted(set(genes_order) - recovered)
    extra_genes = sorted(recovered - set(genes_order))

    if missing_genes or extra_genes:
        raise RuntimeError(
            f"TCGA locked-gene recovery mismatch: missing={len(missing_genes)}, "
            f"extra={len(extra_genes)}. Missing examples={missing_genes[:10]}"
        )

    gene_by_sample = gene_by_sample.loc[genes_order, sample_ids]
    X = gene_by_sample.to_numpy(dtype=np.float32, copy=True).T

    if X.shape != (EXPECTED_TCGA_CLASSIFIABLE, EXPECTED_GENES):
        raise RuntimeError(
            f"Raw TCGA ML matrix shape={X.shape}; "
            f"expected {(EXPECTED_TCGA_CLASSIFIABLE, EXPECTED_GENES)}."
        )
    if not np.isfinite(X).all():
        raise RuntimeError("Raw TCGA ML matrix contains non-finite values.")
    if (X < 0).any():
        raise RuntimeError("TPM matrix contains negative values.")

    return X


def percentile_rank_rows(X: np.ndarray) -> np.ndarray:
    from scipy.stats import rankdata

    n_features = X.shape[1]
    ranks = rankdata(X, method="average", axis=1)
    ranks = (ranks / float(n_features)).astype(np.float32, copy=False)

    if ranks.shape != X.shape:
        raise RuntimeError("Rank transformation changed matrix shape.")
    if not np.isfinite(ranks).all():
        raise RuntimeError("Rank matrix contains non-finite values.")
    if ranks.min() <= 0 or ranks.max() > 1.000001:
        raise RuntimeError(
            f"Unexpected percentile-rank range: {ranks.min()} to {ranks.max()}"
        )

    expected_mean = (n_features + 1.0) / (2.0 * n_features)
    observed_means = ranks.mean(axis=1)
    if not np.allclose(observed_means, expected_mean, atol=2e-6):
        raise RuntimeError(
            "Within-sample percentile-rank mean failed deterministic QC."
        )

    return ranks


def write_outer_splits(
    manifest: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    y = manifest["y"].to_numpy(dtype=np.int8)

    cv = RepeatedStratifiedKFold(
        n_splits=OUTER_SPLITS_N,
        n_repeats=OUTER_REPEATS,
        random_state=SEED,
    )

    assignment_rows = []
    count_rows = []

    for split_i, (train_idx, test_idx) in enumerate(
        cv.split(np.zeros(len(y)), y),
        start=0,
    ):
        repeat = split_i // OUTER_SPLITS_N + 1
        fold = split_i % OUTER_SPLITS_N + 1
        split_id = f"R{repeat}_F{fold}"

        y_train = y[train_idx]
        y_test = y[test_idx]

        count_rows.append(
            {
                "split_id": split_id,
                "repeat": repeat,
                "fold": fold,
                "train_n": len(train_idx),
                "train_positive": int(y_train.sum()),
                "train_negative": int(len(y_train) - y_train.sum()),
                "test_n": len(test_idx),
                "test_positive": int(y_test.sum()),
                "test_negative": int(len(y_test) - y_test.sum()),
            }
        )

        for idx in test_idx:
            assignment_rows.append(
                {
                    "split_id": split_id,
                    "repeat": repeat,
                    "fold": fold,
                    "row_index": int(idx),
                    "patient_id": manifest.iloc[idx]["patient_id"],
                    "expression_sample_id": manifest.iloc[idx]["expression_sample_id"],
                    "y_HER2": int(y[idx]),
                }
            )

    assignments = pd.DataFrame(assignment_rows)
    counts = pd.DataFrame(count_rows)

    if len(counts) != OUTER_SPLITS_N * OUTER_REPEATS:
        raise RuntimeError("Unexpected number of outer CV splits.")

    per_repeat = assignments.groupby(["repeat", "patient_id"]).size()
    if not (per_repeat == 1).all():
        raise RuntimeError(
            "Repeated CV registry invalid: each patient must appear exactly "
            "once as test within each repeat."
        )

    if assignments["patient_id"].nunique() != len(manifest):
        raise RuntimeError("Not every HER2 TCGA patient appears in outer test registry.")

    return assignments, counts


def main() -> None:
    setup_logging()
    t0 = time.time()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF15 - ML EXPERIMENT DESIGN + TCGA INPUT PREPARATION")
    logging.info("============================================================")
    logging.info("")
    logging.info("Estimated runtime: ~5-20 minutes")
    logging.info("Likely bottleneck: streaming 22,106 genes from the wide CF6 TPM matrix")
    logging.info("Secondary bottleneck: within-sample ranking + compressed NPZ writing")
    logging.info("A few minutes of limited output may occur during matrix construction.")
    logging.info("NO MODEL FITTING WILL OCCUR.")
    logging.info("")

    required = [
        CF14_LOCKED_SUMMARY,
        CF14_LOCKED_PROTOCOL,
        TCGA_LOCKED_MANIFEST,
        GENE_UNIVERSE,
        TCGA_TPM,
        CROSSWALK,
    ]
    for p in required:
        if not p.exists():
            raise FileNotFoundError(f"Required CF15 input missing: {p}")

    logging.info("[1/7] Validating CF14 protocol lock...")
    logging.info("")

    locked = metric_dict(CF14_LOCKED_SUMMARY)
    if locked.get("CF14 status") != "PROTOCOL_LOCKED_READY_FOR_CF15":
        raise RuntimeError(
            f"CF14 protocol not locked for CF15: {locked.get('CF14 status')}"
        )
    if locked.get("Primary endpoint") != PRIMARY_ENDPOINT:
        raise RuntimeError(
            f"Locked primary endpoint changed: {locked.get('Primary endpoint')}"
        )

    logging.info("CF14 protocol lock: PASS")
    logging.info("Primary endpoint: HER2")
    logging.info("")

    logging.info("[2/7] Auditing ML software dependencies...")
    logging.info("")

    dep_rows = []
    for name, dist in [
        ("python", None),
        ("numpy", "numpy"),
        ("pandas", "pandas"),
        ("scipy", "scipy"),
        ("scikit-learn", "scikit-learn"),
        ("xgboost", "xgboost"),
    ]:
        version = platform.python_version() if dist is None else package_version(dist)
        available = version != "MISSING"
        dep_rows.append((name, version, available))

    dependencies = pd.DataFrame(
        dep_rows,
        columns=["dependency", "version", "available"],
    )
    dependencies.to_csv(DEPENDENCIES, sep="\t", index=False)

    for _, r in dependencies.iterrows():
        logging.info(
            f"{r['dependency']}: {r['version']} "
            f"[{'READY' if r['available'] else 'MISSING'}]"
        )

    essential_now = dependencies.loc[
        dependencies["dependency"].isin(
            ["numpy", "pandas", "scipy", "scikit-learn"]
        )
    ]
    if not essential_now["available"].all():
        raise RuntimeError(
            "A dependency required for CF15 itself is missing. "
            "See CF15_dependency_audit.tsv."
        )

    xgb_available = bool(
        dependencies.loc[
            dependencies["dependency"] == "xgboost", "available"
        ].iloc[0]
    )
    logging.info("")

    logging.info("[3/7] Loading locked HER2 cohort and gene universe...")
    logging.info("")

    manifest = load_locked_her2_manifest()
    genes, base_to_symbol = load_gene_map()

    logging.info(
        f"TCGA HER2-classifiable tumors: {len(manifest)} "
        f"({int(manifest['y'].sum())} positive / "
        f"{int(len(manifest)-manifest['y'].sum())} negative)"
    )
    logging.info(f"Locked external-validation genes: {len(genes)}")
    logging.info("")

    logging.info("[4/7] Constructing locked-gene TCGA TPM matrix...")
    logging.info("      SCAN-B expression is NOT read in CF15.")
    logging.info("")

    sample_ids = manifest["expression_sample_id"].astype(str).tolist()
    X_raw = build_tcga_matrix(sample_ids, genes, base_to_symbol)

    logging.info(
        f"Raw model-input shape: {X_raw.shape[0]} samples x "
        f"{X_raw.shape[1]} genes"
    )
    logging.info(
        f"Raw TPM range: {float(X_raw.min()):.6g} to "
        f"{float(X_raw.max()):.6g}"
    )
    logging.info("")

    logging.info("[5/7] Applying within-sample percentile-rank representation...")
    logging.info("      This transform is independent within each sample and uses no labels.")
    logging.info("")

    X_rank = percentile_rank_rows(X_raw)
    del X_raw

    y = manifest["y"].to_numpy(dtype=np.int8)
    patient_ids = manifest["patient_id"].astype(str).to_numpy()
    sample_ids_np = manifest["expression_sample_id"].astype(str).to_numpy()
    genes_np = np.asarray(genes, dtype=str)

    np.savez_compressed(
        MATRIX_NPZ,
        X=X_rank,
        y=y,
        patient_ids=patient_ids,
        sample_ids=sample_ids_np,
        gene_symbols=genes_np,
    )

    logging.info(
        f"Rank matrix range: {float(X_rank.min()):.6f} to "
        f"{float(X_rank.max()):.6f}"
    )
    logging.info(
        f"Rank matrix size on disk: "
        f"{MATRIX_NPZ.stat().st_size / (1024**2):.1f} MiB"
    )
    logging.info("")

    logging.info("[6/7] Freezing outer CV registry and CF16 search design...")
    logging.info("")

    assignments, counts = write_outer_splits(manifest)
    assignments.to_csv(OUTER_SPLITS, sep="\t", index=False)
    counts.to_csv(OUTER_COUNTS, sep="\t", index=False)

    search_rows = [
        ("ElasticNet_Logistic", "feature_k", "25|50|100|250|500", "inner-CV"),
        ("ElasticNet_Logistic", "C", "0.01|0.1|1|10", "inner-CV"),
        ("ElasticNet_Logistic", "l1_ratio", "0|0.25|0.5|0.75|1", "inner-CV"),
        ("Linear_SVM", "feature_k", "25|50|100|250|500", "inner-CV"),
        ("Linear_SVM", "C", "0.01|0.1|1|10", "inner-CV"),
        ("XGBoost", "feature_k", "25|50|100|250|500", "randomized-inner-CV"),
        ("XGBoost", "n_estimators", "100|200|400", "randomized-inner-CV"),
        ("XGBoost", "max_depth", "2|3|4|5", "randomized-inner-CV"),
        ("XGBoost", "learning_rate", "0.02|0.05|0.1", "randomized-inner-CV"),
        ("XGBoost", "subsample", "0.7|0.9|1.0", "randomized-inner-CV"),
        ("XGBoost", "colsample_bytree", "0.5|0.75|1.0", "randomized-inner-CV"),
        ("XGBoost", "min_child_weight", "1|3|5", "randomized-inner-CV"),
        ("XGBoost", "reg_alpha", "0|0.1|1", "randomized-inner-CV"),
        ("XGBoost", "reg_lambda", "1|5|10", "randomized-inner-CV"),
        ("XGBoost", "random_search_budget", "15 candidates per outer split", "LOCKED_CF15"),
    ]
    pd.DataFrame(
        search_rows,
        columns=["model", "parameter", "values_or_rule", "selection_scope"],
    ).to_csv(SEARCH_SPACE, sep="\t", index=False)

    metrics = pd.DataFrame(
        [
            ("AUROC", "PRIMARY_MODEL_SELECTION", "threshold-free"),
            ("Average precision / PR-AUC", "KEY_SECONDARY", "minority-class sensitive"),
            ("MCC", "SECONDARY", "thresholded"),
            ("Balanced accuracy", "SECONDARY", "thresholded"),
            ("Sensitivity", "SECONDARY", "thresholded"),
            ("Specificity", "SECONDARY", "thresholded"),
            ("Brier score", "SECONDARY", "probability quality"),
            ("Calibration slope/intercept", "SECONDARY", "calibration"),
        ],
        columns=["metric", "role", "note"],
    )
    metrics.to_csv(METRICS, sep="\t", index=False)

    design = pd.DataFrame(
        [
            ("Primary endpoint", "HER2"),
            ("Positive class", POSITIVE_LABEL),
            ("TCGA classifiable N", EXPECTED_TCGA_CLASSIFIABLE),
            ("TCGA positive N", EXPECTED_POSITIVE),
            ("TCGA negative N", EXPECTED_NEGATIVE),
            ("Feature universe", EXPECTED_GENES),
            ("Precomputed unsupervised representation", "within-sample percentile rank"),
            ("Fold-specific scaling", "StandardScaler training fold only"),
            ("Fold-specific feature selection", "SelectKBest(f_classif) training fold only"),
            ("Outer CV", "RepeatedStratifiedKFold: 5 folds x 3 repeats"),
            ("Inner CV", "StratifiedKFold: 4 folds"),
            ("Random seed", SEED),
            ("Class imbalance", "class weighting only; no SMOTE"),
            ("External cohort accessed numerically in CF15", "NO"),
            ("ML model fitting in CF15", "NO"),
        ],
        columns=["item", "locked_value"],
    )
    design.to_csv(DESIGN, sep="\t", index=False)

    logging.info(f"Outer CV evaluations frozen: {len(counts)}")
    logging.info(
        "Outer test positives per split: "
        f"{counts['test_positive'].min()}-{counts['test_positive'].max()}"
    )
    logging.info(
        "Outer test negatives per split: "
        f"{counts['test_negative'].min()}-{counts['test_negative'].max()}"
    )
    logging.info("")

    logging.info("[7/7] Writing CF15 summary and provenance...")
    logging.info("")

    runtime = (time.time() - t0) / 60.0
    gate = (
        "PASS_READY_FOR_CF16"
        if xgb_available
        else "PASS_XGBOOST_INSTALL_REQUIRED"
    )

    summary = pd.DataFrame(
        [
            ("Primary endpoint", PRIMARY_ENDPOINT),
            ("TCGA HER2 classifiable", len(manifest)),
            ("TCGA HER2 positive", int(y.sum())),
            ("TCGA HER2 negative", int(len(y) - y.sum())),
            ("Locked genes", len(genes)),
            ("Rank matrix rows", X_rank.shape[0]),
            ("Rank matrix columns", X_rank.shape[1]),
            ("Outer CV splits", len(counts)),
            ("Outer CV repeats", OUTER_REPEATS),
            ("Inner CV folds", INNER_SPLITS_N),
            ("XGBoost dependency available", "YES" if xgb_available else "NO"),
            ("SCAN-B numerical expression read in CF15", "NO"),
            ("ML performed", "NO"),
            ("CF15 runtime minutes", round(runtime, 2)),
            ("CF15 stage gate", gate),
        ],
        columns=["metric", "value"],
    )
    summary.to_csv(SUMMARY, sep="\t", index=False)

    provenance = pd.DataFrame(
        [
            ("code_file", "CF15_ml_experiment_design.py"),
            ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
            ("CF14_locked_summary_sha256", sha256_file(CF14_LOCKED_SUMMARY)),
            ("CF14_locked_protocol_sha256", sha256_file(CF14_LOCKED_PROTOCOL)),
            ("TCGA_locked_manifest_sha256", sha256_file(TCGA_LOCKED_MANIFEST)),
            ("locked_gene_universe_sha256", sha256_file(GENE_UNIVERSE)),
            ("CF13_crosswalk_sha256", sha256_file(CROSSWALK)),
            ("TCGA_TPM_sha256", sha256_file(TCGA_TPM)),
            ("rank_matrix_sha256", sha256_file(MATRIX_NPZ)),
            ("outer_split_registry_sha256", sha256_file(OUTER_SPLITS)),
            (
                "rank_transform_rule",
                "Average percentile rank independently within each sample across "
                "the fixed 22106-gene universe; no labels/distribution borrowing",
            ),
            (
                "CV_leakage_rule",
                "StandardScaler, zero-variance filtering, SelectKBest and tuning "
                "remain inside training folds in CF16",
            ),
            (
                "external_validation_rule",
                "SCAN-B expression values and labels are not numerically accessed in CF15",
            ),
            ("python_version", platform.python_version()),
            ("numpy_version", package_version("numpy")),
            ("pandas_version", package_version("pandas")),
            ("scipy_version", package_version("scipy")),
            ("scikit_learn_version", package_version("scikit-learn")),
            ("xgboost_version", package_version("xgboost")),
            ("CF15_stage_gate", gate),
        ],
        columns=["field", "value"],
    )
    provenance.to_csv(PROVENANCE, sep="\t", index=False)

    logging.info("============================================================")
    logging.info(" CF15 COMPLETE - ML EXPERIMENT DESIGN FROZEN")
    logging.info("============================================================")
    logging.info("")
    logging.info(f"HER2 TCGA model-development samples: {len(manifest)}")
    logging.info(
        f"Class balance: {int(y.sum())} positive / "
        f"{int(len(y)-y.sum())} negative"
    )
    logging.info(f"Feature universe: {len(genes)} genes")
    logging.info(f"Rank matrix: {X_rank.shape[0]} x {X_rank.shape[1]}")
    logging.info(f"Outer evaluations: {len(counts)}")
    logging.info(
        f"XGBoost dependency: {'READY' if xgb_available else 'MISSING'}"
    )
    logging.info(f"CF15 runtime: {runtime:.1f} min")
    logging.info(f"STATUS: {gate}")
    logging.info("")
    logging.info("NO model fitting occurred.")
    logging.info("SCAN-B numerical expression was not accessed.")
    logging.info("Send the full terminal output before CF16 training.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF15 ERROR: {exc}")
        sys.exit(1)
