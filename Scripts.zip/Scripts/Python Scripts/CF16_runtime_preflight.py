#!/usr/bin/env python
"""
CF16 computational preflight benchmark.

Purpose
-------
Measure representative training cost BEFORE launching the full nested-CV CF16
experiment. This script does not create scientific model-performance results
and does not access SCAN-B or APOLLO.

It uses:
- the frozen CF15 TCGA HER2 rank matrix,
- one locked outer-training partition (R1_F1 complement),
- one 4-fold inner-training partition,
- k=100 representative selected genes,
- one representative configuration for each locked model family.

The benchmark is used only for runtime/resource planning. Its AUROC values are
not saved, interpreted, or used to change the locked protocol.
"""

from __future__ import annotations

import hashlib
import importlib.metadata as ilm
import logging
import os
import platform
import sys
import time
import warnings
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd

from sklearn.feature_selection import SelectKBest, VarianceThreshold, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC


ROOT = Path.cwd()

CF15_DIR = ROOT / "results" / "CF15_ml_experiment_design"
CF15_SUMMARY = CF15_DIR / "CF15_summary.tsv"
OUTER_ASSIGNMENTS = CF15_DIR / "CF15_outer_cv_test_assignments.tsv"

ML_READY = ROOT / "data" / "processed" / "ml_ready"
MATRIX_NPZ = ML_READY / "CF15_TCGA_HER2_rank_matrix.npz"

RESULTS = ROOT / "results" / "CF16_training"
LOG_DIR = ROOT / "logs"
LOG_FILE = LOG_DIR / "CF16_runtime_preflight.log"
BENCHMARK_OUT = RESULTS / "CF16_runtime_preflight.tsv"
PROVENANCE_OUT = RESULTS / "CF16_runtime_preflight_provenance.tsv"

SEED = 20260815
K_REPRESENTATIVE = 100

EXPECTED_N = 938
EXPECTED_P = 22106
EXPECTED_POS = 182
EXPECTED_NEG = 756

# Locked search sizes from CF15.
ELASTIC_CANDIDATES = 5 * 4 * 5      # k × C × l1_ratio
SVM_CANDIDATES = 5 * 4              # k × C
XGB_CANDIDATES = 15                 # randomized candidates
INNER_FOLDS = 4
OUTER_EVALUATIONS = 15

# Conservative desktop-friendly XGBoost threading.
CPU_COUNT = os.cpu_count() or 1
XGB_THREADS = max(1, min(4, CPU_COUNT - 1 if CPU_COUNT > 1 else 1))


def setup_logging() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def package_version(name: str) -> str:
    try:
        return ilm.version(name)
    except ilm.PackageNotFoundError:
        return "MISSING"


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(block_size), b""):
            h.update(block)
    return h.hexdigest()


def metric_dict(path: Path) -> dict:
    df = pd.read_csv(path, sep="\t", dtype=str)
    return dict(zip(df["metric"], df["value"]))


def timed(name, fn):
    t0 = time.perf_counter()
    value = fn()
    elapsed = time.perf_counter() - t0
    logging.info(f"{name}: {elapsed:.3f} s")
    return value, elapsed


def main() -> None:
    setup_logging()
    total_start = time.perf_counter()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF16 - COMPUTATIONAL PREFLIGHT BENCHMARK")
    logging.info("============================================================")
    logging.info("")
    logging.info("Estimated runtime: ~1-5 minutes")
    logging.info("Likely bottleneck: one representative Elastic-Net/SVM/XGBoost fit")
    logging.info("Long silent periods are NOT expected.")
    logging.info("This benchmark does NOT produce scientific performance results.")
    logging.info("SCAN-B and APOLLO are NOT accessed.")
    logging.info("")

    for p in [CF15_SUMMARY, OUTER_ASSIGNMENTS, MATRIX_NPZ]:
        if not p.exists():
            raise FileNotFoundError(f"Required CF16 preflight input missing: {p}")

    cf15 = metric_dict(CF15_SUMMARY)
    if cf15.get("CF15 stage gate") != "PASS_READY_FOR_CF16":
        raise RuntimeError(
            f"CF15 is not ready for CF16: {cf15.get('CF15 stage gate')}"
        )

    logging.info("[1/6] Loading frozen CF15 matrix and locked outer split...")
    logging.info("      Trusted local CF15 NPZ object-string arrays: pickle loading enabled.")
    logging.info("")

    load_start = time.perf_counter()
    # CF15 stored patient/sample IDs from pandas as NumPy object arrays.
    # This NPZ is a trusted, locally generated pipeline artifact, so pickle
    # loading is permitted here only to read those string arrays.
    z = np.load(MATRIX_NPZ, allow_pickle=True)
    X = z["X"]
    y = z["y"].astype(np.int8)
    patient_ids = z["patient_ids"].astype(str)
    load_sec = time.perf_counter() - load_start

    if X.shape != (EXPECTED_N, EXPECTED_P):
        raise RuntimeError(f"Unexpected matrix shape: {X.shape}")
    if int(y.sum()) != EXPECTED_POS or int((y == 0).sum()) != EXPECTED_NEG:
        raise RuntimeError("Unexpected HER2 class counts in CF15 NPZ.")
    if len(np.unique(patient_ids)) != EXPECTED_N:
        raise RuntimeError("Duplicate patient IDs in CF15 NPZ.")

    assignments = pd.read_csv(OUTER_ASSIGNMENTS, sep="\t")
    held = assignments.loc[assignments["split_id"] == "R1_F1", "row_index"].astype(int)
    if len(held) == 0:
        raise RuntimeError("Locked outer split R1_F1 not found.")

    outer_test_idx = np.sort(held.to_numpy())
    all_idx = np.arange(EXPECTED_N)
    outer_train_idx = np.setdiff1d(all_idx, outer_test_idx, assume_unique=True)

    X_outer = X[outer_train_idx]
    y_outer = y[outer_train_idx]

    inner_cv = StratifiedKFold(
        n_splits=4,
        shuffle=True,
        random_state=SEED,
    )
    inner_train_rel, inner_valid_rel = next(
        inner_cv.split(np.zeros(len(y_outer)), y_outer)
    )
    X_train = X_outer[inner_train_rel]
    y_train = y_outer[inner_train_rel]
    X_valid = X_outer[inner_valid_rel]
    y_valid = y_outer[inner_valid_rel]

    logging.info(f"Matrix load: {load_sec:.2f} s")
    logging.info(
        f"Representative inner train: {X_train.shape[0]} samples x "
        f"{X_train.shape[1]} genes"
    )
    logging.info(
        f"Representative inner validation: {X_valid.shape[0]} samples"
    )
    logging.info(
        f"Inner-train positives/negatives: "
        f"{int(y_train.sum())}/{int((y_train == 0).sum())}"
    )
    logging.info("")

    logging.info("[2/6] Timing fold-specific preprocessing...")
    logging.info("")

    vt = VarianceThreshold(threshold=0.0)
    X_vt, vt_fit_sec = timed(
        "VarianceThreshold fit+transform",
        lambda: vt.fit_transform(X_train),
    )
    X_valid_vt = vt.transform(X_valid)

    scaler = StandardScaler()
    X_sc, scale_fit_sec = timed(
        "StandardScaler fit+transform",
        lambda: scaler.fit_transform(X_vt),
    )
    X_valid_sc = scaler.transform(X_valid_vt)

    selector = SelectKBest(score_func=f_classif, k=K_REPRESENTATIVE)
    X_sel, select_fit_sec = timed(
        f"SelectKBest(k={K_REPRESENTATIVE}) fit+transform",
        lambda: selector.fit_transform(X_sc, y_train),
    )
    X_valid_sel = selector.transform(X_valid_sc)

    if X_sel.shape[1] != K_REPRESENTATIVE:
        raise RuntimeError("Representative feature selection returned wrong k.")

    preprocessing_sec = vt_fit_sec + scale_fit_sec + select_fit_sec

    logging.info(
        f"Nonzero-variance genes in representative fold: {X_vt.shape[1]}"
    )
    logging.info("")

    logging.info("[3/6] Timing representative Elastic-Net logistic fit...")
    logging.info("")

    elastic = LogisticRegression(
        penalty="elasticnet",
        solver="saga",
        C=1.0,
        l1_ratio=0.5,
        class_weight="balanced",
        max_iter=3000,
        tol=1e-3,
        random_state=SEED,
    )

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        _, elastic_sec = timed(
            "Elastic-Net logistic fit",
            lambda: elastic.fit(X_sel, y_train),
        )
    elastic_warning_count = len(caught)
    elastic_iter = int(np.max(elastic.n_iter_))

    logging.info(f"Elastic-Net iterations: {elastic_iter}")
    logging.info(f"Elastic-Net warnings: {elastic_warning_count}")
    logging.info("")

    logging.info("[4/6] Timing representative Linear SVM fit...")
    logging.info("")

    svm = LinearSVC(
        C=1.0,
        class_weight="balanced",
        dual="auto",
        max_iter=10000,
        tol=1e-4,
        random_state=SEED,
    )

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        _, svm_sec = timed(
            "LinearSVC fit",
            lambda: svm.fit(X_sel, y_train),
        )
    svm_warning_count = len(caught)
    svm_iter = int(np.max(np.atleast_1d(svm.n_iter_)))

    logging.info(f"LinearSVC iterations: {svm_iter}")
    logging.info(f"LinearSVC warnings: {svm_warning_count}")
    logging.info("")

    logging.info("[5/6] Timing representative XGBoost fit...")
    logging.info("")

    xgb_version = package_version("xgboost")
    if xgb_version == "MISSING":
        raise RuntimeError("xgboost is missing despite CF15 readiness.")

    from xgboost import XGBClassifier

    neg = int((y_train == 0).sum())
    pos = int((y_train == 1).sum())
    scale_pos_weight = neg / pos

    xgb = XGBClassifier(
        objective="binary:logistic",
        eval_metric="logloss",
        tree_method="hist",
        n_estimators=200,
        max_depth=3,
        learning_rate=0.05,
        subsample=0.9,
        colsample_bytree=0.75,
        min_child_weight=3,
        reg_alpha=0.1,
        reg_lambda=5.0,
        scale_pos_weight=scale_pos_weight,
        n_jobs=XGB_THREADS,
        random_state=SEED,
        verbosity=0,
    )

    _, xgb_sec = timed(
        f"XGBoost fit ({XGB_THREADS} threads)",
        lambda: xgb.fit(X_sel, y_train),
    )
    logging.info("")

    logging.info("[6/6] Estimating full CF16 computational budget...")
    logging.info("")

    # Estimator fit counts. The final refit in each outer split is included.
    elastic_fits_per_outer = ELASTIC_CANDIDATES * INNER_FOLDS + 1
    svm_fits_per_outer = SVM_CANDIDATES * INNER_FOLDS + 1
    xgb_fits_per_outer = XGB_CANDIDATES * INNER_FOLDS + 1

    elastic_total_fits = elastic_fits_per_outer * OUTER_EVALUATIONS
    svm_total_fits = svm_fits_per_outer * OUTER_EVALUATIONS
    xgb_total_fits = xgb_fits_per_outer * OUTER_EVALUATIONS
    total_model_fits = elastic_total_fits + svm_total_fits + xgb_total_fits

    # Model-only estimate from representative fits. Search caching will reduce
    # repeated preprocessing; the multiplier gives a deliberately conservative
    # planning interval for CV overhead, different hyperparameters, larger k,
    # I/O, and convergence variation.
    representative_model_seconds = (
        elastic_total_fits * elastic_sec
        + svm_total_fits * svm_sec
        + xgb_total_fits * xgb_sec
    )

    model_hours = representative_model_seconds / 3600.0
    conservative_low_hours = max(
        0.25,
        model_hours * 0.8,
    )
    conservative_high_hours = max(
        conservative_low_hours + 0.25,
        model_hours * 2.5 + 0.5,
    )

    rows = [
        ("matrix_load_seconds", round(load_sec, 4)),
        ("representative_outer_train_n", len(outer_train_idx)),
        ("representative_inner_train_n", len(inner_train_rel)),
        ("representative_inner_valid_n", len(inner_valid_rel)),
        ("representative_k", K_REPRESENTATIVE),
        ("variance_threshold_seconds", round(vt_fit_sec, 4)),
        ("standard_scaler_seconds", round(scale_fit_sec, 4)),
        ("selectkbest_seconds", round(select_fit_sec, 4)),
        ("preprocessing_total_seconds", round(preprocessing_sec, 4)),
        ("elastic_fit_seconds", round(elastic_sec, 4)),
        ("elastic_iterations", elastic_iter),
        ("elastic_warning_count", elastic_warning_count),
        ("linear_svm_fit_seconds", round(svm_sec, 4)),
        ("linear_svm_iterations", svm_iter),
        ("linear_svm_warning_count", svm_warning_count),
        ("xgboost_fit_seconds", round(xgb_sec, 4)),
        ("xgboost_threads", XGB_THREADS),
        ("elastic_total_model_fits_planned", elastic_total_fits),
        ("svm_total_model_fits_planned", svm_total_fits),
        ("xgboost_total_model_fits_planned", xgb_total_fits),
        ("all_model_fits_planned", total_model_fits),
        ("representative_model_only_hours", round(model_hours, 3)),
        ("conservative_full_CF16_low_hours", round(conservative_low_hours, 2)),
        ("conservative_full_CF16_high_hours", round(conservative_high_hours, 2)),
        ("scientific_results_generated", "NO"),
        ("SCANB_accessed", "NO"),
        ("APOLLO_accessed", "NO"),
    ]

    pd.DataFrame(rows, columns=["metric", "value"]).to_csv(
        BENCHMARK_OUT,
        sep="\t",
        index=False,
    )

    total_sec = time.perf_counter() - total_start

    provenance = pd.DataFrame(
        [
            ("code_file", "CF16_runtime_preflight.py"),
            ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
            ("CF15_summary_sha256", sha256_file(CF15_SUMMARY)),
            ("CF15_matrix_sha256", sha256_file(MATRIX_NPZ)),
            (
                "npz_object_array_loading",
                "allow_pickle=True used only because CF15 locally generated patient/sample "
                "ID arrays were stored as NumPy object-string arrays",
            ),
            ("outer_assignments_sha256", sha256_file(OUTER_ASSIGNMENTS)),
            ("python_version", platform.python_version()),
            ("numpy_version", package_version("numpy")),
            ("pandas_version", package_version("pandas")),
            ("scipy_version", package_version("scipy")),
            ("scikit_learn_version", package_version("scikit-learn")),
            ("xgboost_version", xgb_version),
            ("cpu_logical_count", CPU_COUNT),
            ("xgboost_benchmark_threads", XGB_THREADS),
            ("benchmark_scientific_use", "RUNTIME_PLANNING_ONLY"),
        ],
        columns=["field", "value"],
    )
    provenance.to_csv(PROVENANCE_OUT, sep="\t", index=False)

    logging.info(f"Planned Elastic-Net fits: {elastic_total_fits:,}")
    logging.info(f"Planned Linear SVM fits: {svm_total_fits:,}")
    logging.info(f"Planned XGBoost fits: {xgb_total_fits:,}")
    logging.info(f"Total planned estimator fits: {total_model_fits:,}")
    logging.info("")
    logging.info(
        f"Representative model-only estimate: ~{model_hours:.2f} h"
    )
    logging.info(
        f"Conservative full-CF16 planning range: "
        f"~{conservative_low_hours:.2f}-{conservative_high_hours:.2f} h"
    )
    logging.info("")
    logging.info("============================================================")
    logging.info(" CF16 PREFLIGHT COMPLETE")
    logging.info("============================================================")
    logging.info("")
    logging.info(f"Preflight runtime: {total_sec / 60.0:.2f} min")
    logging.info("Scientific model performance generated: NO")
    logging.info("SCAN-B accessed: NO")
    logging.info("APOLLO accessed: NO")
    logging.info("")
    logging.info("Send the full terminal output before launching full CF16.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF16 PREFLIGHT ERROR: {exc}")
        sys.exit(1)