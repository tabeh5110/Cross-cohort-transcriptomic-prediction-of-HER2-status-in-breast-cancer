"""
============================================================
CF23 v2 - PUBLICATION PACKAGE GENERATION
============================================================

Purpose:
    Generate manuscript-oriented figures and summary tables
    from completed CF1-CF22 outputs.

Rules:
    NO ML
    NO retraining
    NO new biological analysis

Creates:
    - workflow figure
    - model comparison figure
    - SCAN-B validation figure
    - APOLLO confirmation figure
    - pathway summary figure
    - publication tables

============================================================
"""

import os
import time
import pandas as pd
import matplotlib.pyplot as plt


START = time.time()

BASE = r"D:\Masters\Research\TCGA_BRCA"

OUT = os.path.join(
    BASE,
    "results",
    "CF23_publication_package_v2"
)

os.makedirs(OUT, exist_ok=True)


def save_fig(name):
    plt.tight_layout()
    plt.savefig(
        os.path.join(OUT, name + ".png"),
        dpi=300,
        bbox_inches="tight"
    )
    plt.savefig(
        os.path.join(OUT, name + ".pdf"),
        bbox_inches="tight"
    )
    plt.close()


def workflow_figure():

    print("[1/6] Creating workflow figure")

    stages = [
        "TCGA-BRCA\nDiscovery",
        "DE + GSEA\nBiology",
        "ML Development\nElastic-Net",
        "Nested CV\nSelection",
        "SCAN-B\nExternal Validation",
        "APOLLO\nMulti-omics",
        "Biological\nInterpretation"
    ]

    plt.figure(figsize=(12,3))

    for i, s in enumerate(stages):
        plt.text(
            i,
            0,
            s,
            ha="center",
            va="center",
            bbox=dict(boxstyle="round")
        )

        if i < len(stages)-1:
            plt.arrow(
                i+0.35,
                0,
                0.3,
                0,
                head_width=0.05,
                length_includes_head=True
            )

    plt.axis("off")
    save_fig("CF23_Figure1_Workflow")


def model_figure():

    print("[2/6] Creating model comparison figure")

    df = pd.DataFrame({
        "Model":[
            "Elastic-Net",
            "LightGBM",
            "XGBoost",
            "Linear SVM",
            "RBF SVM"
        ],
        "AUROC":[
            0.8448,
            0.8473,
            0.8421,
            0.8333,
            0.8316
        ]
    })

    df.to_csv(
        os.path.join(
            OUT,
            "CF23_model_comparison.tsv"
        ),
        sep="\t",
        index=False
    )

    plt.figure(figsize=(7,4))
    plt.bar(
        df["Model"],
        df["AUROC"]
    )
    plt.ylabel("AUROC")
    plt.xticks(rotation=45)
    save_fig("CF23_Figure2_Model_Performance")


def scanb_figure():

    print("[3/6] Creating SCAN-B validation figure")

    df = pd.DataFrame({
        "Metric":[
            "AUROC",
            "PR-AUC"
        ],
        "Value":[
            0.9186,
            0.8145
        ]
    })

    df.to_csv(
        os.path.join(
            OUT,
            "CF23_SCANB_validation.tsv"
        ),
        sep="\t",
        index=False
    )

    plt.figure(figsize=(5,4))
    plt.bar(
        df["Metric"],
        df["Value"]
    )
    plt.ylim(0,1)
    save_fig("CF23_Figure3_SCANB_Validation")


def apollo_figure():

    print("[4/6] Creating APOLLO confirmation figure")

    df = pd.DataFrame({
        "Layer":[
            "RNA",
            "Protein",
            "Phosphoprotein"
        ],
        "Support":[
            66/86,
            39/86,
            15/86
        ]
    })

    df.to_csv(
        os.path.join(
            OUT,
            "CF23_APOLLO_confirmation.tsv"
        ),
        sep="\t",
        index=False
    )

    plt.figure(figsize=(6,4))
    plt.bar(
        df["Layer"],
        df["Support"]
    )
    plt.ylabel("Fraction of 86 genes supported")
    plt.ylim(0,1)

    save_fig("CF23_Figure4_APOLLO_Multiomics")


def pathway_figure():

    print("[5/6] Creating pathway placeholder summary")

    summary = pd.DataFrame({
        "Analysis":[
            "Hallmark enrichment",
            "Reactome enrichment"
        ],
        "Source":[
            "CF22_Hallmark_enrichment.tsv",
            "CF22_Reactome_enrichment.tsv"
        ]
    })

    summary.to_csv(
        os.path.join(
            OUT,
            "CF23_Pathway_Summary.tsv"
        ),
        sep="\t",
        index=False
    )


def final_summary():

    print("[6/6] Writing package summary")

    pd.DataFrame({
        "Item":[
            "Discovery cohort",
            "External validation",
            "Multi-omics confirmation",
            "Final predictive genes"
        ],
        "Value":[
            "TCGA-BRCA",
            "SCAN-B (3273 samples)",
            "APOLLO-BRCA-1",
            "86 Elastic-Net predictors"
        ]
    }).to_csv(
        os.path.join(
            OUT,
            "CF23_final_summary.tsv"
        ),
        sep="\t",
        index=False
    )


if __name__ == "__main__":

    print("""
============================================================
CF23 v2 - PUBLICATION PACKAGE GENERATION
============================================================
NO ML
NO RETRAINING
NO NEW ANALYSIS
============================================================
""")

    workflow_figure()
    model_figure()
    scanb_figure()
    apollo_figure()
    pathway_figure()
    final_summary()

    print("""
============================================================
CF23 v2 COMPLETE
============================================================
""")

    print("Output:")
    print(OUT)
    print(
        "Runtime:",
        round((time.time()-START)/60,2),
        "min"
    )
