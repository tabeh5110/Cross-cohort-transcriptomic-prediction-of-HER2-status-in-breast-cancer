#!/usr/bin/env python
"""
CF8 - TCGA-BRCA RNA-seq Quality Control

Purpose
-------
Perform sample-level QC on the frozen CF6 expression cohort. CF7 clinical
annotations are used only for metadata joins; CF8 does not choose an ML target.

CF8 never removes samples automatically. Any flagged sample is a manual-review
candidate only.
"""

from __future__ import annotations

import hashlib
import logging
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

PROJECT_ROOT = Path.cwd()

CF6_DIR = PROJECT_ROOT / "results" / "CF6_expression_matrix_construction"
CF6_SUMMARY = CF6_DIR / "CF6_summary.tsv"
CF6_PROVENANCE = CF6_DIR / "CF6_provenance.tsv"
CF6_CHECKSUMS = CF6_DIR / "CF6_matrix_checksums.tsv"
EXPR_DIR = PROJECT_ROOT / "data" / "processed" / "tcga_brca" / "expression"
COUNTS_FILE = EXPR_DIR / "CF6_raw_unstranded_counts.tsv.gz"
TPM_FILE = EXPR_DIR / "CF6_tpm.tsv.gz"
SAMPLE_MANIFEST = EXPR_DIR / "CF6_final_sample_manifest.tsv"
GENE_ANNOTATION = EXPR_DIR / "CF6_gene_annotation.tsv"

CF7_DIR = PROJECT_ROOT / "results" / "CF7_clinical_harmonization"
CF7_SUMMARY = CF7_DIR / "CF7_summary.tsv"
CF7_PROVENANCE = CF7_DIR / "CF7_provenance.tsv"
CLINICAL_DIR = PROJECT_ROOT / "data" / "processed" / "tcga_brca" / "clinical"
SAMPLE_PHENOTYPES = CLINICAL_DIR / "CF7_sample_phenotypes.tsv"

OUTPUT_DIR = PROJECT_ROOT / "results" / "CF8_rnaseq_quality_control"
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed" / "tcga_brca" / "qc"
LOG_DIR = PROJECT_ROOT / "logs"
LOG_FILE = LOG_DIR / "CF8_rnaseq_quality_control.log"

EXPECTED_GENES = 60660
EXPECTED_SAMPLES = 1206
EXPECTED_PATIENTS = 1094

QC_MIN_CPM = 1.0
QC_MIN_SAMPLES = 10
QC_TOP_VARIABLE_GENES = 5000
QC_PCS = 10
ROBUST_MAD_K = 4.0
RANDOM_STATE = 20260815

# Intentional publication palette: restrained, accessible, consistent.
COLOR_TUMOR = "#8B3A46"
COLOR_NORMAL = "#2F6F7E"
COLOR_FLAG = "#C98A2E"
COLOR_NEUTRAL = "#5F6874"
COLOR_GRID = "#D8DDE3"
FIG_DPI = 320


def setup_logging() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def load_metric_table(path: Path) -> Dict[str, str]:
    df = pd.read_csv(path, sep="\t", dtype=str)
    if {"metric", "value"}.issubset(df.columns):
        return dict(zip(df["metric"], df["value"]))
    if {"field", "value"}.issubset(df.columns):
        return dict(zip(df["field"], df["value"]))
    return {}


def sha256(path: Path, chunk: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def expected_hash(checksums: pd.DataFrame, artifact: str) -> str:
    row = checksums.loc[checksums["artifact"] == artifact]
    if row.empty:
        raise RuntimeError(f"Missing CF6 checksum record for {artifact}")
    return str(row.iloc[0]["sha256"])


def robust_z(s: pd.Series) -> pd.Series:
    x = pd.to_numeric(s, errors="coerce").astype(float)
    med = float(np.nanmedian(x))
    mad = float(np.nanmedian(np.abs(x - med)))
    if not np.isfinite(mad) or mad == 0:
        return pd.Series(np.zeros(len(x)), index=x.index)
    return (x - med) / (1.4826 * mad)


def style_ax(ax, xlabel: Optional[str] = None, ylabel: Optional[str] = None) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(COLOR_NEUTRAL)
    ax.spines["bottom"].set_color(COLOR_NEUTRAL)
    ax.tick_params(colors="#374151", labelsize=9)
    ax.grid(axis="y", color=COLOR_GRID, linewidth=0.7, alpha=0.55)
    ax.set_axisbelow(True)
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=10, color="#1F2937")
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=10, color="#1F2937")


def save_fig(fig, stem: str) -> None:
    fig.savefig(OUTPUT_DIR / f"{stem}.png", dpi=FIG_DPI, bbox_inches="tight")
    fig.savefig(OUTPUT_DIR / f"{stem}.pdf", bbox_inches="tight")
    plt.close(fig)


def add_review_flags(qc: pd.DataFrame, pca_scores: pd.DataFrame) -> pd.DataFrame:
    out = qc.merge(pca_scores, on="sample_id", how="left", validate="one_to_one")
    flag_cols = []

    for sample_type, idx in out.groupby("sample_type").groups.items():
        idx = list(idx)
        for field, name, two_sided in [
            ("log10_library_size", "library_size", True),
            ("detected_genes_count_gt0", "detected_genes", True),
            ("zero_count_fraction", "zero_fraction", True),
            ("median_within_type_pearson", "low_correlation", False),
        ]:
            z = robust_z(out.loc[idx, field])
            out.loc[idx, f"{name}_robust_z"] = z.values
            flag = np.abs(z.values) > ROBUST_MAD_K if two_sided else z.values < -ROBUST_MAD_K
            col = f"{name}_review_flag"
            out.loc[idx, col] = flag
            flag_cols.append(col)

        pc_cols = [c for c in pca_scores.columns if c.startswith("PC")][:5]
        zmat = np.column_stack([robust_z(out.loc[idx, c]).to_numpy() for c in pc_cols])
        distance = np.sqrt(np.sum(zmat ** 2, axis=1))
        dz = robust_z(pd.Series(distance, index=idx))
        out.loc[idx, "pca_robust_distance"] = distance
        out.loc[idx, "pca_distance_robust_z"] = dz.values
        out.loc[idx, "pca_review_flag"] = dz.values > ROBUST_MAD_K

    flag_cols = sorted(set(flag_cols + ["pca_review_flag"]))
    for col in flag_cols:
        out[col] = out[col].fillna(False).astype(bool)
    out["review_flag_count"] = out[flag_cols].sum(axis=1).astype(int)
    out["CF8_review_candidate"] = out["review_flag_count"] > 0
    out["CF8_action"] = np.where(
        out["CF8_review_candidate"],
        "MANUAL_REVIEW_REQUIRED_NO_AUTOMATIC_EXCLUSION",
        "NO_QC_FLAG",
    )
    return out


def plot_metric_distributions(qc: pd.DataFrame) -> None:
    tumor = qc[qc["sample_type"] == "Primary Tumor"]
    normal = qc[qc["sample_type"] == "Solid Tissue Normal"]
    fig, axes = plt.subplots(1, 3, figsize=(12.2, 3.8))
    panels = [
        ("log10_library_size", "log10 gene-assigned counts", "A"),
        ("detected_genes_count_gt0", "Detected genes (count > 0)", "B"),
        ("zero_count_fraction", "Zero-count fraction", "C"),
    ]
    for ax, (field, label, letter) in zip(axes, panels):
        bp = ax.boxplot(
            [tumor[field].dropna(), normal[field].dropna()],
            tick_labels=["Tumor", "Normal"], widths=0.55, patch_artist=True,
            showfliers=False,
            medianprops={"color": "#111827", "linewidth": 1.5},
            boxprops={"linewidth": 1.0}, whiskerprops={"linewidth": 1.0},
            capprops={"linewidth": 1.0},
        )
        for patch, color in zip(bp["boxes"], [COLOR_TUMOR, COLOR_NORMAL]):
            patch.set_facecolor(color)
            patch.set_alpha(0.80)
        style_ax(ax, ylabel=label)
        ax.text(-0.12, 1.05, letter, transform=ax.transAxes,
                fontsize=12, fontweight="bold", color="#111827")
    fig.suptitle("TCGA-BRCA RNA-seq sample-level QC", fontsize=13,
                 fontweight="bold", color="#111827", y=1.03)
    fig.tight_layout()
    save_fig(fig, "CF8_qc_metric_distributions")


def plot_pca(pca_df: pd.DataFrame, variance: np.ndarray) -> None:
    fig, ax = plt.subplots(figsize=(6.7, 5.3))
    for sample_type, color, label in [
        ("Primary Tumor", COLOR_TUMOR, "Primary tumor"),
        ("Solid Tissue Normal", COLOR_NORMAL, "Solid tissue normal"),
    ]:
        g = pca_df[pca_df["sample_type"] == sample_type]
        ax.scatter(g["PC1"], g["PC2"], s=22, alpha=0.72, c=color,
                   label=f"{label} (n={len(g)})", edgecolors="none")
    style_ax(ax, f"PC1 ({100*variance[0]:.1f}% variance)",
             f"PC2 ({100*variance[1]:.1f}% variance)")
    ax.grid(color=COLOR_GRID, linewidth=0.7, alpha=0.45)
    ax.legend(frameon=False, fontsize=9)
    ax.set_title("PCA of QC-normalized expression", fontsize=12,
                 fontweight="bold", color="#111827", pad=10)
    fig.tight_layout()
    save_fig(fig, "CF8_pca_sample_overview")


def plot_review_candidates(qc: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(7.2, 5.2))
    base = qc[~qc["CF8_review_candidate"]]
    flagged = qc[qc["CF8_review_candidate"]]
    for sample_type, color in [
        ("Primary Tumor", COLOR_TUMOR),
        ("Solid Tissue Normal", COLOR_NORMAL),
    ]:
        g = base[base["sample_type"] == sample_type]
        ax.scatter(g["log10_library_size"], g["detected_genes_count_gt0"],
                   s=18, alpha=0.45, c=color, edgecolors="none")
    if len(flagged):
        ax.scatter(flagged["log10_library_size"], flagged["detected_genes_count_gt0"],
                   s=58, facecolors="none", edgecolors=COLOR_FLAG, linewidths=1.4,
                   label=f"Review candidate (n={len(flagged)})")
        ax.legend(frameon=False, fontsize=9)
    style_ax(ax, "log10 gene-assigned counts", "Detected genes (count > 0)")
    ax.set_title("QC review candidates", fontsize=12, fontweight="bold",
                 color="#111827", pad=10)
    fig.tight_layout()
    save_fig(fig, "CF8_qc_review_candidates")



def read_numeric_expression_matrix(path: Path, numeric_dtype) -> pd.DataFrame:
    """
    Read a genes-x-samples expression matrix while preserving the first
    column (gene_id) as text.

    Important: passing dtype=np.int64/np.float32 directly to pandas.read_csv
    applies the dtype to the gene_id column too, which incorrectly attempts
    to convert Ensembl IDs such as ENSG00000000003.15 to numbers.
    """
    header = pd.read_csv(
        path,
        sep="\t",
        compression="gzip",
        nrows=0,
    )

    if len(header.columns) < 2:
        raise RuntimeError(f"Expression matrix has fewer than 2 columns: {path}")

    gene_col = str(header.columns[0])
    dtype_map = {str(c): numeric_dtype for c in header.columns[1:]}

    df = pd.read_csv(
        path,
        sep="\t",
        compression="gzip",
        index_col=0,
        dtype=dtype_map,
        low_memory=False,
    )

    df.index = df.index.astype(str)
    df.columns = df.columns.astype(str)

    if df.index.name is None:
        df.index.name = gene_col

    return df


def main() -> None:
    setup_logging()
    logging.info("\n============================================================")
    logging.info(" CF8 - RNA-SEQ QUALITY CONTROL")
    logging.info("============================================================\n")

    logging.info("[1/9] Validating frozen CF6 and CF7 inputs...\n")
    required = [CF6_SUMMARY, CF6_PROVENANCE, CF6_CHECKSUMS, COUNTS_FILE, TPM_FILE,
                SAMPLE_MANIFEST, GENE_ANNOTATION, CF7_SUMMARY, CF7_PROVENANCE,
                SAMPLE_PHENOTYPES]
    for path in required:
        if not path.exists():
            raise FileNotFoundError(f"Required upstream file missing: {path}")

    if load_metric_table(CF6_SUMMARY).get("CF6 stage gate", "").upper() != "PASS":
        raise RuntimeError("CF6 stage gate is not PASS.")
    if load_metric_table(CF7_SUMMARY).get("CF7 stage gate", "").upper() != "PASS":
        raise RuntimeError("CF7 stage gate is not PASS.")

    checks = pd.read_csv(CF6_CHECKSUMS, sep="\t", dtype=str)
    for path, artifact in [
        (COUNTS_FILE, "raw_unstranded_counts"),
        (TPM_FILE, "tpm"),
        (SAMPLE_MANIFEST, "final_sample_manifest"),
        (GENE_ANNOTATION, "gene_annotation"),
    ]:
        observed = sha256(path)
        expected = expected_hash(checks, artifact)
        if observed.lower() != expected.lower():
            raise RuntimeError(f"CF6 checksum mismatch: {path.name}")
    logging.info("CF6 processed-output SHA256 verification: PASS")
    logging.info("CF7 stage gate: PASS\n")

    logging.info("[2/9] Loading frozen expression and metadata...\n")
    counts = read_numeric_expression_matrix(COUNTS_FILE, np.int64)
    manifest = pd.read_csv(SAMPLE_MANIFEST, sep="\t", dtype=str)
    phenotypes = pd.read_csv(SAMPLE_PHENOTYPES, sep="\t", dtype=str)
    counts.index = counts.index.astype(str)
    counts.columns = counts.columns.astype(str)

    if counts.shape != (EXPECTED_GENES, EXPECTED_SAMPLES):
        raise RuntimeError(f"Unexpected count-matrix shape: {counts.shape}")
    if set(counts.columns) != set(manifest["sample_id"].astype(str)):
        raise RuntimeError("Count-matrix columns differ from CF6 sample manifest.")
    if set(counts.columns) != set(phenotypes["sample_id"].astype(str)):
        raise RuntimeError("Count-matrix columns differ from CF7 sample phenotypes.")
    if manifest["patient_id"].nunique() != EXPECTED_PATIENTS:
        raise RuntimeError("Unexpected unique-patient count in CF6 manifest.")
    logging.info(f"Raw-count matrix: {counts.shape[0]} genes x {counts.shape[1]} samples\n")

    logging.info("[3/9] Computing sample-level RNA-seq QC metrics...\n")
    arr = counts.to_numpy(dtype=np.int64, copy=False)
    lib = arr.sum(axis=0, dtype=np.int64)
    detected = (arr > 0).sum(axis=0)
    zero_frac = (arr == 0).mean(axis=0)
    if np.any(lib <= 0):
        raise RuntimeError("At least one sample has non-positive gene-assigned library size.")

    qc = pd.DataFrame({
        "sample_id": counts.columns,
        "library_size_gene_assigned": lib,
        "log10_library_size": np.log10(lib.astype(float)),
        "detected_genes_count_gt0": detected,
        "zero_count_fraction": zero_frac,
    })
    keep_meta = [c for c in ["sample_id", "patient_id", "sample_type", "aliquot_barcode",
                             "file_id", "plate", "center"] if c in manifest.columns]
    qc = qc.merge(manifest[keep_meta].drop_duplicates("sample_id"), on="sample_id",
                  how="left", validate="one_to_one")

    # Read TPM only long enough to calculate one interpretable sample metric.
    tpm = read_numeric_expression_matrix(TPM_FILE, np.float32)
    tpm.index = tpm.index.astype(str)
    tpm.columns = tpm.columns.astype(str)
    if not counts.index.equals(tpm.index) or not counts.columns.equals(tpm.columns):
        raise RuntimeError("Counts/TPM gene or sample order mismatch.")
    qc["genes_tpm_ge_1"] = (tpm.to_numpy(copy=False) >= 1.0).sum(axis=0)
    del tpm

    logging.info(f"Gene-assigned library size range: {int(lib.min()):,} - {int(lib.max()):,}")
    logging.info(f"Detected-gene range: {int(detected.min()):,} - {int(detected.max()):,}\n")

    logging.info("[4/9] Building QC-only log2(CPM+1) feature space...\n")
    # CPM>=1 is equivalent to counts >= library_size/1e6; use this relation to
    # avoid allocating a full 60,660 x 1,206 CPM matrix.
    thresholds = lib.astype(np.float64) / 1_000_000.0
    expressed_mask = (arr >= thresholds[np.newaxis, :]).sum(axis=1) >= QC_MIN_SAMPLES
    n_qc_expressed = int(expressed_mask.sum())
    if n_qc_expressed < QC_TOP_VARIABLE_GENES:
        raise RuntimeError(f"Only {n_qc_expressed} genes passed the QC expression screen.")

    sub = arr[expressed_mask, :].astype(np.float32)
    sub /= lib.astype(np.float32)[np.newaxis, :]
    sub *= np.float32(1_000_000.0)
    np.log2(sub + np.float32(1.0), out=sub)
    variances = np.var(sub, axis=1, ddof=1)
    top_idx = np.argpartition(variances, -QC_TOP_VARIABLE_GENES)[-QC_TOP_VARIABLE_GENES:]
    top_idx = top_idx[np.argsort(variances[top_idx])[::-1]]
    log_top = sub[top_idx, :]
    expressed_ids = counts.index.to_numpy()[expressed_mask]
    selected_ids = expressed_ids[top_idx]

    pd.DataFrame({
        "gene_id": selected_ids,
        "log2_cpm_variance": variances[top_idx],
        "rank": np.arange(1, QC_TOP_VARIABLE_GENES + 1),
    }).to_csv(OUTPUT_DIR / "CF8_qc_feature_genes.tsv", sep="\t", index=False)
    logging.info(f"Genes with CPM >= {QC_MIN_CPM:g} in >= {QC_MIN_SAMPLES} samples: {n_qc_expressed}")
    logging.info(f"Top variable genes used for QC PCA/similarity: {QC_TOP_VARIABLE_GENES}\n")
    del sub

    logging.info("[5/9] Running PCA and within-type similarity diagnostics...\n")
    pca = PCA(n_components=QC_PCS, svd_solver="randomized", random_state=RANDOM_STATE)
    scores = pca.fit_transform(log_top.T)
    pca_df = pd.DataFrame(scores, columns=[f"PC{i+1}" for i in range(QC_PCS)])
    pca_df.insert(0, "sample_id", counts.columns)
    pca_meta = manifest[["sample_id", "patient_id", "sample_type"]].drop_duplicates("sample_id")
    pca_plot_df = pca_df.merge(pca_meta, on="sample_id", how="left", validate="one_to_one")

    corr = np.corrcoef(log_top.T)
    np.fill_diagonal(corr, np.nan)
    type_map = manifest.set_index("sample_id").loc[counts.columns, "sample_type"].astype(str).to_numpy()
    med_corr = np.full(EXPECTED_SAMPLES, np.nan)
    for i in range(EXPECTED_SAMPLES):
        mask = type_map == type_map[i]
        mask[i] = False
        vals = corr[i, mask]
        vals = vals[np.isfinite(vals)]
        med_corr[i] = np.median(vals) if len(vals) else np.nan
    qc["median_within_type_pearson"] = med_corr

    pca_df.to_csv(OUTPUT_DIR / "CF8_pca_scores.tsv", sep="\t", index=False)
    pd.DataFrame({
        "principal_component": [f"PC{i+1}" for i in range(QC_PCS)],
        "explained_variance_ratio": pca.explained_variance_ratio_,
        "explained_variance_percent": 100*pca.explained_variance_ratio_,
    }).to_csv(OUTPUT_DIR / "CF8_pca_explained_variance.tsv", sep="\t", index=False)
    logging.info(f"PC1 variance: {100*pca.explained_variance_ratio_[0]:.2f}%")
    logging.info(f"PC2 variance: {100*pca.explained_variance_ratio_[1]:.2f}%\n")

    logging.info("[6/9] Creating conservative QC review-candidate audit...\n")
    qc = add_review_flags(qc, pca_df)
    qc.to_csv(PROCESSED_DIR / "CF8_sample_qc_metrics.tsv", sep="\t", index=False)
    review = qc[qc["CF8_review_candidate"]].copy()
    review.to_csv(OUTPUT_DIR / "CF8_sample_review_candidates.tsv", sep="\t", index=False)

    flag_cols = [
        "library_size_review_flag", "detected_genes_review_flag",
        "zero_fraction_review_flag", "low_correlation_review_flag",
        "pca_review_flag",
    ]
    pd.DataFrame({
        "flag": flag_cols,
        "n_samples": [int(qc[c].sum()) for c in flag_cols],
    }).to_csv(OUTPUT_DIR / "CF8_review_flag_summary.tsv", sep="\t", index=False)
    logging.info(f"Samples flagged for manual review: {len(review)}/{len(qc)}")
    logging.info("Automatic sample exclusions: 0\n")

    logging.info("[7/9] Generating publication-ready QC figures...\n")
    plot_metric_distributions(qc)
    plot_pca(pca_plot_df, pca.explained_variance_ratio_)
    plot_review_candidates(qc)
    logging.info("Figures generated as 320-dpi PNG + vector PDF.\n")

    logging.info("[8/9] Writing CF8 summary and provenance...\n")
    tumor_n = int((qc["sample_type"] == "Primary Tumor").sum())
    normal_n = int((qc["sample_type"] == "Solid Tissue Normal").sum())
    patient_n = int(qc["patient_id"].nunique())
    stage_gate = "PASS_WITH_REVIEW" if len(review) else "PASS"

    pd.DataFrame([
        ("CF6 stage gate", "PASS"),
        ("CF7 stage gate", "PASS"),
        ("Expression genes", EXPECTED_GENES),
        ("Expression samples", EXPECTED_SAMPLES),
        ("Unique patients", patient_n),
        ("Primary Tumor samples", tumor_n),
        ("Solid Tissue Normal samples", normal_n),
        ("QC expressed genes", n_qc_expressed),
        ("QC top variable genes", QC_TOP_VARIABLE_GENES),
        ("PC1 variance percent", round(100*pca.explained_variance_ratio_[0], 4)),
        ("PC2 variance percent", round(100*pca.explained_variance_ratio_[1], 4)),
        ("Manual review candidates", len(review)),
        ("Automatic sample exclusions", 0),
        ("Final analytical cohort frozen", "NO_CF8_REVIEW_PENDING"),
        ("CF8 stage gate", stage_gate),
    ], columns=["metric", "value"]).to_csv(OUTPUT_DIR / "CF8_summary.tsv", sep="\t", index=False)

    pd.DataFrame([
        ("code_file", "CF8_rnaseq_quality_control.py"),
        ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
        ("counts_sha256", sha256(COUNTS_FILE)),
        ("tpm_sha256", sha256(TPM_FILE)),
        ("cf6_sample_manifest_sha256", sha256(SAMPLE_MANIFEST)),
        ("cf7_sample_phenotypes_sha256", sha256(SAMPLE_PHENOTYPES)),
        ("qc_normalization", "log2(CPM+1)"),
        ("qc_gene_screen", f"CPM >= {QC_MIN_CPM:g} in >= {QC_MIN_SAMPLES} samples"),
        ("qc_top_variable_genes", QC_TOP_VARIABLE_GENES),
        ("review_rule", f"within sample type robust MAD; |z| > {ROBUST_MAD_K:g}; review only"),
        ("automatic_exclusions", 0),
        ("primary_ML_endpoint", "NOT_SELECTED"),
        ("python_version", sys.version.replace("\n", " ")),
        ("pandas_version", pd.__version__),
        ("numpy_version", np.__version__),
        ("sklearn_version", __import__("sklearn").__version__),
        ("matplotlib_version", matplotlib.__version__),
        ("platform", platform.platform()),
        ("cf8_stage_gate", stage_gate),
    ], columns=["field", "value"]).to_csv(OUTPUT_DIR / "CF8_provenance.tsv", sep="\t", index=False)

    logging.info("[9/9] Final CF8 stage gate...\n")
    logging.info("============================================================")
    logging.info(" CF8 COMPLETE - RNA-SEQ QC PASSED WITH REVIEW CANDIDATES" if len(review)
                 else " CF8 COMPLETE - RNA-SEQ QC PASSED")
    logging.info("============================================================\n")
    logging.info(f"Expression genes: {EXPECTED_GENES}")
    logging.info(f"Biological samples: {len(qc)}")
    logging.info(f"Unique patients: {patient_n}")
    logging.info(f"Primary Tumor: {tumor_n}")
    logging.info(f"Solid Tissue Normal: {normal_n}")
    logging.info(f"QC expressed genes: {n_qc_expressed}")
    logging.info(f"Top variable genes for QC PCA: {QC_TOP_VARIABLE_GENES}")
    logging.info(f"Manual review candidates: {len(review)}")
    logging.info("Automatic exclusions: 0\n")
    logging.info("IMPORTANT:")
    logging.info("CF8 did not remove any sample.")
    logging.info("Any flagged sample requires manual evidence review.")
    logging.info("QC-only CPM screening/top-variable-gene selection is NOT the DESeq2 or ML feature filter.")
    logging.info("No differential expression or machine learning was performed.\n")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF8 ERROR: {exc}")
        sys.exit(1)
