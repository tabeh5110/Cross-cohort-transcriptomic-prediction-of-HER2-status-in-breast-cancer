"""TCGA-only OOB bootstrap robustness of the fixed CF39/CF18 20-gene panel."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent/'_runtime'))
import json, hashlib, warnings, platform, time
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import joblib, sklearn
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import roc_auc_score,average_precision_score,confusion_matrix
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=Path(__file__).resolve().parents[1]; ROOT=OUT.parent
RES=OUT/'results'; FIG=OUT/'figures'; REPORT=OUT/'report'
CF18=ROOT/'results/CF18_stable_signature_xai_final_model'
CF39=ROOT/'CF39_minimal_HER2_signature/results'
MODEL=ROOT/'data/processed/ml_ready/CF18_final_model/CF18_final_ElasticNet_model_bundle.joblib'
MATRIX=ROOT/'data/processed/ml_ready/CF15_TCGA_HER2_rank_matrix.npz'
B=1000; SEED=20260924; THRESHOLD=.5; NZTOL=1e-8

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''): h.update(block)
    return h.hexdigest()

def save(d,name): d.to_csv(RES/f'CF40_{name}.tsv',sep='\t',index=False)

def metrics(y,p,threshold=THRESHOLD):
    tn,fp,fn,tp=confusion_matrix(y,p>=threshold,labels=[0,1]).ravel()
    div=lambda a,b:float(a/b) if b else np.nan
    return {'AUROC':roc_auc_score(y,p),'PR_AUC':average_precision_score(y,p),'sensitivity':div(tp,tp+fn),
            'specificity':div(tn,tn+fp),'PPV':div(tp,tp+fp),'NPV':div(tn,tn+fn),'accuracy':div(tp+tn,len(y)),
            'TN':int(tn),'FP':int(fp),'FN':int(fn),'TP':int(tp)}

def main():
    started=time.perf_counter()
    # Protect all existing CF18/CF39 results as well as the model and training matrix.
    protected=[MODEL,MATRIX]+sorted(p for p in CF18.rglob('*') if p.is_file())+sorted(p for p in CF39.rglob('*') if p.is_file())
    before={str(p.relative_to(ROOT)):sha(p) for p in protected}
    bundle=joblib.load(MODEL)
    core=pd.read_csv(CF18/'CF18_stable_core_signature.tsv',sep='\t')
    final=pd.read_csv(CF18/'CF18_final_ElasticNet_features.tsv',sep='\t')
    panel=pd.read_csv(CF39/'CF39_recommended_gene_panel.tsv',sep='\t').sort_values('CF39_rank')
    ranking=pd.read_csv(CF39/'CF39_gene_ranking.tsv',sep='\t').sort_values('CF39_rank')
    genes=panel.gene_symbol.astype(str).tolist()
    assert len(genes)==20 and len(set(genes))==20 and set(genes)==set(core.gene_symbol)
    assert genes==ranking.gene_symbol.tolist()
    hparams=pd.read_csv(CF39/'CF39_selected_hyperparameters.tsv',sep='\t')
    counts=hparams[hparams.panel=='Top 20'].groupby(['C','l1_ratio']).size().reset_index(name='outer_fits')
    counts=counts.sort_values(['outer_fits','C','l1_ratio'],ascending=[False,True,True])
    C=float(counts.iloc[0].C); l1=float(counts.iloc[0].l1_ratio)
    assert C==.1 and l1==.25
    save(counts,'CF39_parameter_provenance')
    z=np.load(MATRIX,allow_pickle=True)
    universe=z['gene_symbols'].astype(str); ids=z['patient_ids'].astype(str); y=z['y'].astype(int)
    assert len(y)==938 and int(y.sum())==182 and len(set(ids))==938
    assert np.array_equal(universe,np.asarray(bundle['feature_universe_gene_symbols']).astype(str))
    lookup={g:i for i,g in enumerate(universe)}
    X=z['X'][:,[lookup[g] for g in genes]].astype(float)
    assert np.isfinite(X).all()
    original_oof=pd.read_csv(CF18/'CF18_TCGA_OOF_calibrated_predictions.tsv',sep='\t').set_index('patient_id').loc[ids]
    assert np.array_equal(original_oof.y_true.to_numpy(),y)
    oldpred=pd.read_csv(CF39/'CF39_patient_OOF_predictions.tsv',sep='\t')
    for name,g in oldpred.groupby('model'):
        assert np.array_equal(g.set_index('patient_id').loc[ids,'y_true'].to_numpy(),y)
    save(pd.DataFrame({'patient_id':ids,'y_true':y}),'TCGA_cohort')
    save(panel[['CF39_rank','gene_symbol','selection_frequency','nonzero_frequency','standardized_ElasticNet_coefficient']],'fixed_20_gene_panel')
    protocol={'written_before_bootstrapping_utc':datetime.now(timezone.utc).isoformat(),
              'bootstrap_iterations':B,'seed':SEED,'sampling':'ordinary patient bootstrap, n=938 draws with replacement, no stratification',
              'evaluation':'unique out-of-bag patients only; never in-bag predictions',
              'fixed_genes':genes,'model':'Elastic-Net logistic regression','C':C,'l1_ratio':l1,
              'parameter_source':f'modal joint setting in {int(counts.iloc[0].outer_fits)}/15 CF39 Top 20 outer fits; no new search',
              'class_weight':'balanced','solver':'saga','max_iter':10000,'tol':1e-4,'threshold':THRESHOLD,
              'preprocessing':'reuse fixed CF15 within-sample ranks; fit StandardScaler on bootstrap rows including multiplicity',
              'selection_definition':'absolute standardized coefficient > 1e-8; all 20 genes supplied to every fit',
              'descriptive_stability_cutoffs':'nonzero in >=80% of bootstraps AND sign consistency among nonzero >=80%; no panel changes',
              'interval_definition':'2.5th and 97.5th percentiles of bootstrap distributions; not confidence intervals for the mean',
              'external_cohort_data_used':False,'new_hyperparameter_search':False,'threshold_optimization':False,
              'limitation':'CF18/CF39 selected these genes using TCGA; OOB evaluation does not remove prior feature-selection leakage'}
    (RES/'CF40_frozen_protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    rng=np.random.default_rng(SEED); n=len(y)
    coefs=np.empty((B,20)); means=np.empty((B,20)); scales=np.empty((B,20)); intercept=np.empty(B)
    multiplicities=np.empty((B,n),dtype=np.uint16)
    probabilities=np.full((B,n),np.nan,dtype=np.float64)
    rows=[]
    print(f'Running {B} ordinary patient bootstraps: C={C}, l1_ratio={l1}, threshold={THRESHOLD}',flush=True)
    for b in range(B):
        sampled=rng.integers(0,n,size=n); cnt=np.bincount(sampled,minlength=n)
        oob=np.flatnonzero(cnt==0)
        assert len(np.unique(y[sampled]))==2 and len(np.unique(y[oob]))==2
        scaler=StandardScaler(); train=scaler.fit_transform(X[sampled]); test=scaler.transform(X[oob])
        model=LogisticRegression(penalty='elasticnet',solver='saga',C=C,l1_ratio=l1,class_weight='balanced',max_iter=10000,tol=1e-4,random_state=SEED)
        with warnings.catch_warnings():
            warnings.simplefilter('error',ConvergenceWarning)
            model.fit(train,y[sampled])
        p=model.predict_proba(test)[:,1]
        coefs[b]=model.coef_.ravel(); means[b]=scaler.mean_; scales[b]=scaler.scale_; intercept[b]=model.intercept_[0]
        multiplicities[b]=cnt; probabilities[b,oob]=p
        rows.append({'iteration':b+1,'n_draws':n,'n_unique_train':int((cnt>0).sum()),'n_train_positive_draws':int(y[sampled].sum()),
                     'n_oob':len(oob),'n_oob_positive':int(y[oob].sum()),'n_nonzero_coefficients':int((abs(coefs[b])>NZTOL).sum()),
                     'solver_iterations':int(model.n_iter_[0]),**metrics(y[oob],p)})
        if (b+1)%50==0: print(f'{b+1}/{B} complete ({time.perf_counter()-started:.1f}s)',flush=True)
    assert np.isfinite(probabilities[multiplicities==0]).all()
    assert np.isnan(probabilities[multiplicities>0]).all()
    perf=pd.DataFrame(rows); save(perf,'bootstrap_OOB_metrics')
    # Complete numerical audit trail; no serialized replacement model.
    np.savez_compressed(RES/'CF40_bootstrap_audit_arrays.npz',patient_ids=ids,y=y,genes=np.array(genes),X_rank=X,
                        multiplicities=multiplicities,standardized_coefficients=coefs,scaler_mean=means,scaler_scale=scales,
                        intercept=intercept,OOB_probabilities=probabilities)
    bi,pi=np.where(multiplicities==0)
    pd.DataFrame({'iteration':bi+1,'patient_id':ids[pi],'y_true':y[pi],'OOB_probability':probabilities[bi,pi],
                  'prediction':(probabilities[bi,pi]>=THRESHOLD).astype(int),'threshold':THRESHOLD}).to_csv(RES/'CF40_OOB_predictions.tsv.gz',sep='\t',index=False,compression='gzip')
    selected=abs(coefs)>NZTOL
    long=pd.DataFrame({'iteration':np.repeat(np.arange(1,B+1),20),'gene_symbol':np.tile(genes,B),'selected_nonzero':selected.ravel(),
                       'standardized_coefficient':coefs.ravel(),'coefficient_per_rank_unit':(coefs/scales).ravel()})
    save(long,'bootstrap_gene_coefficients')
    nonzero=selected.sum(axis=0); positive=(coefs>NZTOL).sum(axis=0); negative=(coefs < -NZTOL).sum(axis=0)
    stability=pd.DataFrame({'Gene':genes,'Selection_frequency_percent':100*selected.mean(axis=0),
                            'Mean_coefficient':coefs.mean(axis=0),'SD':coefs.std(axis=0,ddof=1),
                            'Coefficient_CI_lower_95':np.quantile(coefs,.025,axis=0),'Coefficient_CI_upper_95':np.quantile(coefs,.975,axis=0),
                            'Mean_absolute_coefficient':abs(coefs).mean(axis=0),'Positive_nonzero_iterations':positive,'Negative_nonzero_iterations':negative,
                            'Sign_consistency_nonzero':np.divide(np.maximum(positive,negative),nonzero,out=np.full(20,np.nan),where=nonzero>0),
                            'Offered_to_model_percent':100.,'CF39_rank':np.arange(1,21)})
    stability['Meets_descriptive_stability_rule']=(stability.Selection_frequency_percent>=80)&(stability.Sign_consistency_nonzero>=.8)
    stability=stability.sort_values(['Selection_frequency_percent','Mean_absolute_coefficient','Gene'],ascending=[False,False,True]).reset_index(drop=True)
    stability['Rank']=np.arange(1,21)
    save(stability,'gene_stability')
    metric_names=['AUROC','PR_AUC','sensitivity','specificity','PPV','NPV','accuracy']
    summary=pd.DataFrame([{'metric':m,'mean':perf[m].mean(),'median':perf[m].median(),'SD':perf[m].std(ddof=1),
                           'CI_lower_95':perf[m].quantile(.025),'CI_upper_95':perf[m].quantile(.975),
                           'valid_iterations':int(perf[m].notna().sum()),'undefined_iterations':int(perf[m].isna().sum()),
                           'interval_type':'central 95% bootstrap OOB distribution, not CI of mean'} for m in metric_names])
    save(summary,'performance_stability')
    coverage=(multiplicities==0).sum(axis=0)
    save(pd.DataFrame({'patient_id':ids,'y_true':y,'n_OOB_evaluations':coverage,'mean_OOB_probability':np.nanmean(probabilities,axis=0),
                       'SD_OOB_probability':np.nanstd(probabilities,axis=0,ddof=1)}),'patient_prediction_stability')
    # Comparisons reuse prior TCGA results only; no smaller-panel refits.
    historical=pd.read_csv(CF39/'CF39_performance.tsv',sep='\t')
    comparisons=[]
    for name,k in [('CF18 full',86),('Top 20',20),('Top 15',15),('Top 10',10),('Top 5',5)]:
        tab=historical[historical.model==name].set_index('metric')
        old=oldpred[oldpred.model==name]
        label='CF18 original (historical OOF)' if name=='CF18 full' else f'CF39 {name}'
        comparisons.append({'Model':label,'Number_of_genes':k,'Evaluation':'patient-averaged repeated TCGA OOF',
                            'Threshold':float(tab.threshold.iloc[0]),**{m:float(tab.loc[m,'estimate']) for m in metric_names if m!='accuracy'},
                            'accuracy':float((old.y_true==old.prediction).mean())})
    comparisons.append({'Model':'CF40 fixed 20-gene bootstrap','Number_of_genes':20,'Evaluation':'mean over 1000 varying OOB sets',
                        'Threshold':THRESHOLD,**{m:float(perf[m].mean()) for m in metric_names}})
    comparison=pd.DataFrame(comparisons); save(comparison,'model_comparison')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.dpi':400})
    blue='#0072B2'; orange='#D55E00'
    def finish(fig,name):
        fig.tight_layout()
        for ext in ['png','pdf']:fig.savefig(FIG/f'CF40_{name}.{ext}',bbox_inches='tight')
        plt.close(fig)
    ss=stability.sort_values('CF39_rank')
    fig,ax=plt.subplots(figsize=(11,4.8))
    ax.bar(ss.Gene,ss.Selection_frequency_percent,color=[blue if q else orange for q in ss.Meets_descriptive_stability_rule])
    ax.axhline(80,color='0.35',ls='--',label='80% descriptive cutoff')
    ax.set(xlabel='Fixed signature genes (CF39 order)',ylabel='Nonzero coefficient frequency (%)',ylim=(0,105),title='CF40 | Gene selection across 1,000 bootstrap refits')
    ax.tick_params(axis='x',rotation=60); ax.legend(fontsize=9); finish(fig,'Figure1_gene_selection_stability')
    fig,ax=plt.subplots(figsize=(8,7))
    rr=ss.iloc[::-1]
    for i,r in enumerate(rr.itertuples()):
        color=blue if r.Mean_coefficient>=0 else orange
        ax.hlines(i,r.Coefficient_CI_lower_95,r.Coefficient_CI_upper_95,color=color,lw=2)
        ax.plot(r.Mean_coefficient,i,'o',color=color,ms=4)
    ax.axvline(0,ls='--',color='0.5'); ax.set(yticks=range(20),yticklabels=rr.Gene,xlabel='Standardized coefficient: mean and central 95% bootstrap interval',title='CF40 | Coefficient stability'); finish(fig,'Figure2_coefficient_stability')
    fig,axes=plt.subplots(1,2,figsize=(10,4.3))
    for ax,m in zip(axes,['AUROC','PR_AUC']):
        s=summary.set_index('metric').loc[m]
        ax.hist(perf[m],bins=30,color=blue,alpha=.8,edgecolor='white')
        ax.axvline(s['mean'],color=orange,lw=2,label=f"Mean {s['mean']:.3f}")
        for v in [s.CI_lower_95,s.CI_upper_95]:ax.axvline(v,color='0.35',ls='--')
        ax.set(xlabel=m.replace('_','-'),ylabel='Bootstrap iterations',title=f'{m.replace("_","-")} | out-of-bag');ax.legend()
    fig.suptitle('CF40 | Performance across 1,000 bootstrap refits'); finish(fig,'Figure3_performance_distributions')
    fig,axes=plt.subplots(2,2,figsize=(11,8))
    ax=axes[0,0];ax.axis('off')
    stable_n=int(stability.Meets_descriptive_stability_rule.sum())
    ax.text(.02,.95,f'Fixed 20-gene HER2 panel\n\n938 TCGA patients (182 HER2+)\n1,000 patient bootstrap refits\nOOB evaluation only\nC = {C}; l1 ratio = {l1}\nThreshold = 0.5; no optimization\n\n{stable_n}/20 genes meet descriptive\nnonzero-frequency + sign rule',va='top',fontsize=13,linespacing=1.5)
    ax=axes[0,1];ax.hist(perf.n_nonzero_coefficients,bins=np.arange(0,22)-.5,color=blue,edgecolor='white');ax.set(xlabel='Nonzero coefficients per refit',ylabel='Bootstrap iterations',title='All 20 genes always supplied',xlim=(0,21))
    ax=axes[1,0]
    for i,m in enumerate(metric_names):
        r=summary.set_index('metric').loc[m]
        ax.hlines(i,r.CI_lower_95,r.CI_upper_95,color=blue,lw=2);ax.plot(r['mean'],i,'o',color=blue)
    ax.set(yticks=range(7),yticklabels=[m.replace('_','-') for m in metric_names],xlim=(0,1),xlabel='Mean and central 95% OOB interval',title='Performance stability');ax.invert_yaxis()
    ax=axes[1,1];ax.hist(coverage,bins=20,color=blue,edgecolor='white');ax.set(xlabel='OOB evaluations per patient',ylabel='Patients',title='Repeated held-out coverage')
    fig.suptitle('CF40 | Robustness summary — conditional on TCGA-selected genes',fontsize=13)
    finish(fig,'Figure4_robustness_summary')
    assert all(sha(ROOT/p)==h for p,h in before.items())
    provenance={'completed_utc':datetime.now(timezone.utc).isoformat(),'input_sha256':before,'protected_input_hashes_unchanged':True,
                'script_sha256':sha(Path(__file__)),'runtime_parser_sha256':sha(Path(__file__).parent/'_runtime/_strptime.py'),
                'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__,
                'bootstrap_iterations_completed':B,'runtime_seconds':time.perf_counter()-started,'external_data_used':False,
                'convergence_warnings':0,'stable_gene_count':stable_n,'minimum_patient_OOB_count':int(coverage.min()),
                'maximum_patient_OOB_count':int(coverage.max())}
    (RES/'CF40_provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
    stxt='\n'.join(f'| {r.Gene} | {r.Selection_frequency_percent:.1f} | {r.Mean_coefficient:.4f} | {r.SD:.4f} | {r.Coefficient_CI_lower_95:.4f} to {r.Coefficient_CI_upper_95:.4f} | {r.Rank} |' for r in stability.itertuples())
    ptxt='\n'.join(f'| {r.metric} | {r.mean:.4f} | {r.median:.4f} | {r.CI_lower_95:.4f} to {r.CI_upper_95:.4f} |' for r in summary.itertuples())
    ctxt='\n'.join(f'| {r.Model} | {r.Number_of_genes} | {r.AUROC:.4f} | {r.PR_AUC:.4f} | {r.sensitivity:.4f} | {r.specificity:.4f} |' for r in comparison.itertuples())
    less_stable=', '.join(stability.loc[~stability.Meets_descriptive_stability_rule,'Gene']) or 'None'
    avg=summary.set_index('metric')
    conclusion=(f'The fixed panel retains predictive signal under resampling (mean OOB AUROC {avg.loc["AUROC","mean"]:.4f}, PR-AUC {avg.loc["PR_AUC","mean"]:.4f}), but gene-level stability is heterogeneous: {stable_n}/20 genes meet the descriptive stability rule. It is suitable as a fixed research candidate for further independent external validation; the evidence does not establish that every gene is consistently selected, that the panel is independently reproducible, or that it is ready for clinical use.' if stable_n<20 else f'All 20 genes meet the descriptive stability rule and the panel retains predictive signal (mean OOB AUROC {avg.loc["AUROC","mean"]:.4f}, PR-AUC {avg.loc["PR_AUC","mean"]:.4f}). These conditional internal results support further independent external validation, not clinical readiness or proven independent reproducibility.')
    report=f'''# CF40: Robustness and Stability Validation of the 20-Gene HER2 Signature

## 1. Objective

Are the 20 selected HER2 signature genes consistently selected and predictive under repeated resampling and model evaluation?

{conclusion}

## 2. Input data and frozen panel

Use the locked CF15 TCGA matrix (`CF15_TCGA_HER2_rank_matrix.npz`), containing 938 unique patients: 182 HER2-positive and 756 negative. Labels and order were verified against archived CF18 and CF39 OOF predictions. The CF18 stable core, final coefficients, model bundle, calibration information, and CF39 recommended panel/ranking, hyperparameter records, and performance outputs were inspected. CF18 remains the original 86-nonzero-gene locked model; CF39 recommended this 20-gene core but did not serialize a final fitted 20-gene estimator.

Fixed genes, in CF39 order: **{', '.join(genes)}**.

CF18 and CF39 gene sets agree exactly. No external expression, clinical data, external-validation predictions, or external-performance results were loaded or used. Original results and the locked model remain unchanged; before/after SHA-256 hashes cover all files under the CF18 and CF39 results directories plus the locked model and TCGA matrix.

## 3. Methods

Use the same CF39 model family: class-balanced Elastic-Net logistic regression with saga, max_iter=10000, tol=1e-4. Fix C={C} and l1_ratio={l1}, the modal joint setting in {int(counts.iloc[0].outer_fits)}/15 existing CF39 20-gene outer fits. This is a conditional robustness specification inherited from prior training, not a new hyperparameter search or new prediction framework. CF39 previously tuned parameters within outer training folds, whereas CF40 fixes them; comparisons are descriptive rather than exact replications of that tuning procedure.

Reuse CF15 within-sample percentile ranks over the original 22,106-gene universe and subset the existing 20 features afterward. Fit StandardScaler separately on each bootstrap training sample, including duplicate-patient multiplicities. The corresponding out-of-bag patients use only that fitted scaler. Balanced class weights are calculated from bootstrap training labels. No imputation, batch correction, gene search, feature expansion, calibration, or threshold optimization is performed. The CF39 reduced-model decision threshold remains **0.5**. These class-balanced scores are not calibrated disease risks.

## 4. Bootstrap procedure

Perform **1,000 ordinary patient bootstraps**, seed {SEED}. Each replicate draws 938 patients with replacement, fits only the 20 genes, and evaluates only unique patients never drawn in that replicate. No in-bag/resubstitution performance is reported. Every replicate has both classes in its training and OOB sets and converges without warnings. OOB sample sizes range from {perf.n_oob.min()} to {perf.n_oob.max()}, and each patient is evaluated OOB {coverage.min()}–{coverage.max()} times.

Selection means absolute standardized coefficient >1e-8. Inclusion in the input panel is 100% by design and is not presented as selection stability. Penalization can make coefficients zero without changing the supplied 20-gene panel. All coefficients, including zeros, contribute to means, SDs (ddof=1), and empirical percentile intervals. Coefficients are per one bootstrap-training SD of the rank feature; scaler parameters and coefficients per raw rank unit are also saved for reproducibility.

Performance is calculated per OOB replicate: AUROC, average precision (reported as PR-AUC), sensitivity, specificity, PPV, NPV, accuracy, and confusion counts. Summaries give equally weighted mean and median across replicates, with 2.5th–97.5th empirical percentiles. These are **central 95% bootstrap variability intervals**, not confidence intervals for the mean, not independent test-cohort intervals, and not evidence from 1,000 independent cohorts. The PR-AUC prevalence reference for the complete TCGA cohort is {y.mean():.4f}; individual OOB prevalences vary. Undefined ratios are recorded as NaN and valid/undefined counts are supplied rather than replaced with zero.

## 5. Gene stability results

| Gene | Selection frequency (%) | Mean coefficient | SD | Bootstrap coefficient 95% interval | Rank |
|---|---:|---:|---:|---:|---:|
{stxt}

Rank orders genes by nonzero frequency, then mean absolute coefficient, with symbol resolving ties. CF39 order is retained separately. A descriptive rule, fixed before bootstrapping, requires >=80% nonzero frequency and >=80% sign consistency among nonzero fits, reflecting the original 12/15 stability frequency. **{stable_n}/20 genes meet this rule.** Genes not meeting it: **{less_stable}**. This is a diagnostic description, not a gene-removal rule. All 20 genes remain in the panel.

Across refits, the number of nonzero coefficients ranges from {perf.n_nonzero_coefficients.min()} to {perf.n_nonzero_coefficients.max()} (median {perf.n_nonzero_coefficients.median():.1f}). Correlated predictors can exchange coefficients under Elastic-Net; variable individual selection does not by itself imply loss of panel-level prediction. Conversely, high selection does not establish biological causality or assay reliability.

## 6. Performance stability results

| Metric | Mean | Median | Central 95% bootstrap OOB interval |
|---|---:|---:|---:|
{ptxt}

The uncertainty includes changes in sampled training patients, fitted coefficients, and OOB test composition, conditional on the previously chosen features and fixed hyperparameters. It does not include the original discovery/selection uncertainty. Repeated predictions of a patient are correlated; they are never treated as independent patients for inferential tests. The patient-level prediction-stability table describes coverage and score variability, not a newly trained ensemble model.

## 7. Comparison with previous models

| Model | Number of genes | AUROC | PR-AUC | Sensitivity | Specificity |
|---|---:|---:|---:|---:|---:|
{ctxt}

CF18/CF39 numbers are reused historical patient-averaged repeated OOF estimates on 938 TCGA patients. CF40 numbers are means over varying OOB sets; a bootstrap sample contains fewer unique training patients than the full cohort. No smaller signatures or CF18 models were refit. CF18 retains its own calibrated threshold {float(bundle['classification_threshold']):.10f}; CF39/CF40 reduced models use 0.5 without calibration. Different estimands, training sizes, hyperparameter policies, and operating policies preclude interpreting these differences as superiority or deterioration caused solely by resampling. The full comparison file also includes PPV, NPV, accuracy, thresholds, and evaluation types.

## 8. Interpretation

{conclusion}

CF40 supplies a reproducible numerical audit of fixed-panel robustness. The strongest claim is conditional internal robustness, not independent reproducibility of the original gene-discovery process. The fixed 20-gene panel is retained exactly, irrespective of individual stability diagnostics. No deployment estimator or alternative signature is generated.

## 9. Limitations

- CF18 and CF39 used TCGA to select and rank these genes. OOB exclusion during refitting does not undo this prior selection leakage; predictive estimates can remain optimistic.
- Hyperparameters are fixed to the prior CF39 modal setting. This is not uncertainty analysis over alternate model specifications and does not reproduce CF39 nested tuning on every bootstrap.
- Highly correlated genes, regularization, and bootstrap-dependent scaling affect individual coefficient selection and sign. Intervals are descriptive conditional bootstrap intervals, not post-selection inferential guarantees.
- Sensitivity, specificity, PPV, NPV, and accuracy depend on the unoptimized operating threshold; PPV and NPV also depend on prevalence.
- Transcriptome-wide ranks remain necessary. A panel-only laboratory assay, including measurement of MIR4728, is not established by this analysis.
- No external cohort is examined here, so cross-platform transfer, population transportability, and clinical utility are not established.

## Deliverables and reproducibility

Figures 1–4 cover gene selection frequencies, coefficient intervals, AUROC/PR-AUC distributions, and the combined robustness summary, in 400-dpi PNG and PDF. Results include the frozen protocol, gene-level coefficient records, bootstrap OOB metrics, compressed per-replicate OOB predictions, input/parameter provenance, and numerical arrays containing all sample multiplicities, fitted scaler/model parameters, and OOB probabilities. These arrays reconstruct every bootstrap prediction without refitting.

Run from the project root: `.venv/Scripts/python.exe CF40_Robustness_Stability_Validation_20Gene_Signature/scripts/CF40_bootstrap.py`. The CF40-local official CPython 3.10.11 `_strptime.py` copy bypasses the existing corrupted system module without altering the environment. Software versions, seed, hashes, and runtime are recorded in `CF40_provenance.json`.
'''
    (REPORT/'CF40_report.md').write_text(report,encoding='utf-8')
    print(summary.to_string(index=False),flush=True)
    print(f'COMPLETE: {stable_n}/20 genes meet descriptive stability rule.',flush=True)

if __name__=='__main__':main()
