from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit, logit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_curve,
    roc_auc_score,
    roc_curve,
)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


ROOT = Path(__file__).resolve().parents[2]
CF33 = ROOT / "CF33_second_external_validation"
INPUT_DIR = CF33 / "input"
RESULTS_DIR = CF33 / "results"
FIGURES_DIR = CF33 / "figures"
METADATA_DIR = CF33 / "metadata"
LOGS_DIR = CF33 / "logs"

METABRIC_DIR = ROOT / "data" / "external_validation" / "metabric" / "brca_metabric"
METABRIC_ARCHIVE = ROOT / "data" / "external_validation" / "metabric" / "brca_metabric.tar.gz"
METABRIC_EXPRESSION = METABRIC_DIR / "data_mrna_illumina_microarray.txt"
METABRIC_SAMPLE = METABRIC_DIR / "data_clinical_sample.txt"
METABRIC_PATIENT = METABRIC_DIR / "data_clinical_patient.txt"
METABRIC_META_EXPRESSION = METABRIC_DIR / "meta_mrna_illumina_microarray.txt"
TCGA_RANK_MATRIX = ROOT / "data" / "processed" / "ml_ready" / "CF15_TCGA_HER2_rank_matrix.npz"
CF32_FINAL_SIGNATURE = ROOT / "CF32_minimal_HER2_signature_development" / "results" / "CF32_final_minimal_signature.tsv"
CF32_PERFORMANCE = ROOT / "CF32_minimal_HER2_signature_development" / "results" / "CF32_signature_performance_comparison.tsv"

FINAL_GENES = ["STARD3", "PGAP3", "MIEN1", "PSMD3", "MED1", "CDK12", "MIR4728", "GSDMB", "FBXL20", "FCGBP"]
LOCKED_THRESHOLD = 0.4345288894526921
BOOTSTRAP_ITERATIONS = 10000
SEED = 20260815
DOWNLOAD_DATE = "2026-09-15"


def ensure_dirs() -> None:
    for directory in [INPUT_DIR, RESULTS_DIR, FIGURES_DIR, METADATA_DIR, LOGS_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


def read_tsv(path: Path, **kwargs) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path, sep="\t", **kwargs)


def load_final_genes() -> list[str]:
    final = read_tsv(CF32_FINAL_SIGNATURE)
    genes = final["Gene"].astype(str).tolist()
    if genes != FINAL_GENES:
        raise RuntimeError("CF32 final signature differs from the expected 10-gene panel.")
    return genes


def load_tcga_training(genes: list[str]) -> tuple[pd.DataFrame, pd.Series, np.ndarray]:
    matrix = np.load(TCGA_RANK_MATRIX, allow_pickle=True)
    all_genes = matrix["gene_symbols"].astype(str)
    gene_index = {gene: idx for idx, gene in enumerate(all_genes)}
    missing = sorted(set(genes) - set(gene_index))
    if missing:
        raise RuntimeError(f"Final genes missing from locked TCGA rank matrix: {missing}")
    indices = [gene_index[gene] for gene in genes]
    x = pd.DataFrame(matrix["X"][:, indices], index=matrix["sample_ids"].astype(str), columns=genes)
    y = pd.Series(matrix["y"].astype(int), index=x.index, name="HER2")
    return x, y, all_genes


def make_model() -> object:
    return make_pipeline(
        StandardScaler(),
        LogisticRegression(
            penalty="elasticnet",
            solver="saga",
            l1_ratio=0.25,
            C=0.01,
            class_weight="balanced",
            max_iter=5000,
            tol=0.001,
            random_state=SEED,
        ),
    )


def read_cbio_table(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t", comment="#")


def load_metabric(genes: list[str], locked_universe: np.ndarray) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    expression = read_tsv(METABRIC_EXPRESSION)
    expression["Hugo_Symbol"] = expression["Hugo_Symbol"].astype(str)
    expression = expression.drop(columns=[col for col in ["Entrez_Gene_Id"] if col in expression.columns])
    expression = expression.groupby("Hugo_Symbol", as_index=True).mean(numeric_only=True)

    available = [gene for gene in genes if gene in expression.index]
    missing = [gene for gene in genes if gene not in expression.index]
    locked = pd.DataFrame(0.0, index=locked_universe, columns=expression.columns, dtype=np.float32)
    overlap = sorted(set(locked_universe).intersection(expression.index.astype(str)))
    locked.loc[overlap] = expression.loc[overlap].astype(np.float32)
    ranked = locked.rank(axis=0, pct=True).astype(np.float32)
    x = ranked.loc[genes].T
    x.index.name = "sample_id"

    sample = read_cbio_table(METABRIC_SAMPLE)
    patient = read_cbio_table(METABRIC_PATIENT)
    clinical = sample.merge(patient, on="PATIENT_ID", how="left", suffixes=("_sample", "_patient"))
    clinical = clinical[clinical["HER2_STATUS"].isin(["Positive", "Negative"])].copy()
    clinical["HER2"] = (clinical["HER2_STATUS"] == "Positive").astype(int)
    common = x.index.intersection(clinical["SAMPLE_ID"].astype(str))
    x = x.loc[common].copy()
    clinical = clinical.set_index("SAMPLE_ID").loc[common].reset_index()
    clinical = clinical.rename(columns={"index": "SAMPLE_ID"})
    if "SAMPLE_ID" not in clinical.columns:
        clinical = clinical.rename(columns={clinical.columns[0]: "SAMPLE_ID"})

    mapping = pd.DataFrame(
        [
            {
                "Gene": gene,
                "Available": gene in available,
                "Identifier": gene if gene in available else "NA",
                "Notes": "Present in METABRIC Illumina expression matrix." if gene in available else "Missing from METABRIC microarray expression; not replaced, zero-filled only as locked-universe missing feature.",
            }
            for gene in genes
        ]
    )
    mapping.to_csv(RESULTS_DIR / "CF33_gene_mapping.tsv", sep="\t", index=False)
    return x, clinical, mapping


def calculate_metrics(y_true: np.ndarray, probability: np.ndarray, threshold: float) -> dict[str, float]:
    y_pred = (probability >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "AUROC": roc_auc_score(y_true, probability),
        "PR_AUC": average_precision_score(y_true, probability),
        "Sensitivity": tp / (tp + fn) if (tp + fn) else np.nan,
        "Specificity": tn / (tn + fp) if (tn + fp) else np.nan,
        "PPV": tp / (tp + fp) if (tp + fp) else np.nan,
        "NPV": tn / (tn + fn) if (tn + fn) else np.nan,
        "Accuracy": accuracy_score(y_true, y_pred),
        "F1_score": f1_score(y_true, y_pred, zero_division=0),
        "MCC": matthews_corrcoef(y_true, y_pred),
    }


def calibration_metrics(y_true: np.ndarray, probability: np.ndarray) -> dict[str, float]:
    clipped = np.clip(probability, 1e-6, 1 - 1e-6)
    x = logit(clipped)

    def objective(params: np.ndarray) -> float:
        intercept, slope = params
        p = np.clip(expit(intercept + slope * x), 1e-9, 1 - 1e-9)
        return -float(np.sum(y_true * np.log(p) + (1 - y_true) * np.log(1 - p)))

    result = minimize(objective, x0=np.array([0.0, 1.0]), method="BFGS")
    intercept, slope = result.x if result.success else (np.nan, np.nan)
    return {
        "Brier_score": brier_score_loss(y_true, probability),
        "Calibration_slope": float(slope),
        "Calibration_intercept": float(intercept),
    }


def bootstrap_ci(y_true: np.ndarray, probability: np.ndarray, threshold: float) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    rows = []
    n = len(y_true)
    for iteration in range(1, BOOTSTRAP_ITERATIONS + 1):
        indices = rng.integers(0, n, size=n)
        yi = y_true[indices]
        pi = probability[indices]
        if len(np.unique(yi)) < 2:
            continue
        metrics = calculate_metrics(yi, pi, threshold)
        rows.append(
            {
                "Iteration": iteration,
                "AUROC": metrics["AUROC"],
                "PR_AUC": metrics["PR_AUC"],
                "Sensitivity": metrics["Sensitivity"],
                "Specificity": metrics["Specificity"],
            }
        )
    boot = pd.DataFrame(rows)
    boot.to_csv(RESULTS_DIR / "CF33_bootstrap_iterations.tsv", sep="\t", index=False)
    summary = []
    for metric in ["AUROC", "PR_AUC", "Sensitivity", "Specificity"]:
        values = boot[metric].dropna().to_numpy()
        summary.append(
            {
                "Metric": metric,
                "Estimate": calculate_metrics(y_true, probability, threshold)[metric],
                "CI_lower_2_5": np.percentile(values, 2.5),
                "CI_upper_97_5": np.percentile(values, 97.5),
                "Bootstrap_iterations_requested": BOOTSTRAP_ITERATIONS,
                "Bootstrap_iterations_used": len(values),
            }
        )
    ci = pd.DataFrame(summary)
    ci.to_csv(RESULTS_DIR / "CF33_bootstrap_CI.tsv", sep="\t", index=False)
    return ci


def write_selection_and_manifest(clinical: pd.DataFrame, mapping: pd.DataFrame) -> None:
    cohort = pd.DataFrame(
        [
            {
                "Dataset": "METABRIC",
                "Source": "cBioPortal DataHub public study archive brca_metabric.tar.gz",
                "Sample size": len(clinical),
                "HER2 labels available": True,
                "Expression platform": "Illumina HT-12 v3 microarray log2 intensity",
                "Reason selected": "Preferred independent cohort was available with mRNA expression and explicit HER2_STATUS labels; APOLLO-BRCA1 was present locally but lacked documented HER2 labels.",
            },
            {
                "Dataset": "APOLLO-BRCA1",
                "Source": "Local project data/raw/apollo_brca1",
                "Sample size": 68,
                "HER2 labels available": False,
                "Expression platform": "RNA-seq UQ-normalized log2",
                "Reason selected": "Not selected because project clinical inventory did not provide HER2 status labels.",
            },
        ]
    )
    cohort.to_csv(RESULTS_DIR / "CF33_cohort_selection_report.tsv", sep="\t", index=False)

    manifest = pd.DataFrame(
        [
            {
                "filename": METABRIC_ARCHIVE.name,
                "path": str(METABRIC_ARCHIVE),
                "dataset": "METABRIC",
                "sample_count": len(clinical),
                "feature_count": "NA",
                "description": f"Downloaded public cBioPortal/DataHub METABRIC archive on {DOWNLOAD_DATE}.",
            },
            {
                "filename": METABRIC_EXPRESSION.name,
                "path": str(METABRIC_EXPRESSION),
                "dataset": "METABRIC",
                "sample_count": len(clinical),
                "feature_count": "all available genes; 10 signature genes queried",
                "description": "Illumina HT-12 v3 microarray log2 expression matrix.",
            },
            {
                "filename": METABRIC_SAMPLE.name,
                "path": str(METABRIC_SAMPLE),
                "dataset": "METABRIC",
                "sample_count": len(clinical),
                "feature_count": "HER2_STATUS; ER_STATUS; PR_STATUS; TUMOR_STAGE",
                "description": "Clinical sample data containing HER2 labels.",
            },
            {
                "filename": METABRIC_PATIENT.name,
                "path": str(METABRIC_PATIENT),
                "dataset": "METABRIC",
                "sample_count": len(clinical),
                "feature_count": "CLAUDIN_SUBTYPE; ER_IHC; HER2_SNP6; clinical covariates",
                "description": "Clinical patient data used for optional subgroup analysis.",
            },
            {
                "filename": CF32_FINAL_SIGNATURE.name,
                "path": str(CF32_FINAL_SIGNATURE),
                "dataset": "CF32",
                "sample_count": 10,
                "feature_count": len(mapping),
                "description": "Final 10-gene minimal HER2 signature, used unchanged.",
            },
        ]
    )
    manifest.to_csv(INPUT_DIR / "CF33_input_manifest.tsv", sep="\t", index=False)


def write_dataset_summary(clinical: pd.DataFrame, mapping: pd.DataFrame) -> None:
    summary = pd.DataFrame(
        [
            {
                "Dataset": "METABRIC",
                "N": len(clinical),
                "HER2_positive": int(clinical["HER2"].sum()),
                "HER2_negative": int((1 - clinical["HER2"]).sum()),
                "Available_signature_genes": int(mapping["Available"].sum()),
                "Missing_signature_genes": int((~mapping["Available"]).sum()),
                "Processing": "Expression aligned to locked CF18/CF32 gene universe, missing genes zero-filled without replacement, then within-sample percentile-ranked.",
            }
        ]
    )
    summary.to_csv(RESULTS_DIR / "CF33_dataset_summary.tsv", sep="\t", index=False)


def write_cross_cohort(metrics: dict[str, float]) -> pd.DataFrame:
    cf32 = read_tsv(CF32_PERFORMANCE)
    minimal = cf32[cf32["Signature_name"] == "10_CORE_STABLE"].iloc[0]
    rows = [
        {
            "Cohort": "TCGA",
            "N": 938,
            "AUROC": minimal.TCGA_AUROC,
            "PR_AUC": minimal.TCGA_PR_AUC,
            "Sensitivity": np.nan,
            "Specificity": np.nan,
            "PPV": np.nan,
            "NPV": np.nan,
        },
        {
            "Cohort": "SCAN-B",
            "N": 3151,
            "AUROC": minimal.SCANB_AUROC,
            "PR_AUC": minimal.SCANB_PR_AUC,
            "Sensitivity": minimal.Sensitivity,
            "Specificity": minimal.Specificity,
            "PPV": minimal.PPV,
            "NPV": minimal.NPV,
        },
        {
            "Cohort": "METABRIC",
            "N": int(metrics["N"]),
            "AUROC": metrics["AUROC"],
            "PR_AUC": metrics["PR_AUC"],
            "Sensitivity": metrics["Sensitivity"],
            "Specificity": metrics["Specificity"],
            "PPV": metrics["PPV"],
            "NPV": metrics["NPV"],
        },
    ]
    comparison = pd.DataFrame(rows)
    comparison.to_csv(RESULTS_DIR / "CF33_cross_cohort_comparison.tsv", sep="\t", index=False)
    return comparison


def subgroup_analysis(clinical: pd.DataFrame, probability: np.ndarray) -> pd.DataFrame:
    frame = clinical.copy()
    frame["probability"] = probability
    candidates = {
        "ER_status": "ER_STATUS",
        "PR_status": "PR_STATUS",
        "Molecular_subtype": "CLAUDIN_SUBTYPE",
        "Stage": "TUMOR_STAGE",
    }
    rows = []
    for subgroup_type, column in candidates.items():
        if column not in frame.columns:
            continue
        for value, group in frame.dropna(subset=[column]).groupby(column):
            if len(group) < 50 or group["HER2"].nunique() < 2 or group["HER2"].sum() < 5:
                continue
            metrics = calculate_metrics(group["HER2"].to_numpy(), group["probability"].to_numpy(), LOCKED_THRESHOLD)
            rows.append(
                {
                    "Subgroup_type": subgroup_type,
                    "Subgroup": value,
                    "N": len(group),
                    "HER2_positive": int(group["HER2"].sum()),
                    "HER2_negative": int((1 - group["HER2"]).sum()),
                    **metrics,
                }
            )
    subgroups = pd.DataFrame(rows)
    subgroups.to_csv(RESULTS_DIR / "CF33_subgroup_performance.tsv", sep="\t", index=False)
    return subgroups


def plot_outputs(clinical: pd.DataFrame, probability: np.ndarray, cross_cohort: pd.DataFrame) -> None:
    y = clinical["HER2"].to_numpy()
    fpr, tpr, _ = roc_curve(y, probability)
    precision, recall, _ = precision_recall_curve(y, probability)

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.plot(fpr, tpr, color="#4c78a8", linewidth=2, label=f"METABRIC AUROC={roc_auc_score(y, probability):.3f}")
    ax.plot([0, 1], [0, 1], color="#888888", linestyle="--", linewidth=1)
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_title("CF33 METABRIC ROC curve")
    ax.legend(frameon=False)
    ax.grid(color="#dddddd", linewidth=0.6)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF33_ROC_curve.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.plot(recall, precision, color="#59a14f", linewidth=2, label=f"METABRIC PR-AUC={average_precision_score(y, probability):.3f}")
    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_title("CF33 METABRIC PR curve")
    ax.legend(frameon=False)
    ax.grid(color="#dddddd", linewidth=0.6)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF33_PR_curve.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 6))
    bins = np.linspace(0, 1, 11)
    cal = pd.DataFrame({"y": y, "p": probability})
    cal["bin"] = pd.cut(cal["p"], bins=bins, include_lowest=True)
    grouped = cal.groupby("bin", observed=True).agg(mean_pred=("p", "mean"), observed=("y", "mean"), n=("y", "size"))
    grouped = grouped[grouped["n"] >= 5]
    ax.plot(grouped["mean_pred"], grouped["observed"], marker="o", color="#4c78a8", linewidth=2)
    ax.plot([0, 1], [0, 1], color="#888888", linestyle="--", linewidth=1)
    ax.set_xlabel("Mean predicted probability")
    ax.set_ylabel("Observed HER2-positive fraction")
    ax.set_title("CF33 METABRIC calibration")
    ax.grid(color="#dddddd", linewidth=0.6)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF33_calibration_plot.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    x = np.arange(len(cross_cohort))
    width = 0.35
    ax.bar(x - width / 2, cross_cohort["AUROC"], width, label="AUROC", color="#4c78a8")
    ax.bar(x + width / 2, cross_cohort["PR_AUC"], width, label="PR-AUC", color="#59a14f")
    ax.set_xticks(x)
    ax.set_xticklabels(cross_cohort["Cohort"])
    ax.set_ylim(0, 1)
    ax.set_ylabel("Metric value")
    ax.set_title("CF33 cross-cohort 10-gene performance")
    ax.legend(frameon=False)
    ax.grid(axis="y", color="#dddddd", linewidth=0.6)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF33_cross_cohort_performance.png", dpi=300)
    plt.close(fig)


def write_qc(mapping: pd.DataFrame) -> pd.DataFrame:
    qc = pd.DataFrame(
        [
            {
                "QC_check": "Final 10 genes unchanged",
                "Status": "PASS" if mapping["Gene"].tolist() == FINAL_GENES else "FAIL",
                "Details": "CF32 final 10-gene panel was used in the same order without adding or replacing genes.",
            },
            {
                "QC_check": "No external cohort training",
                "Status": "PASS",
                "Details": "Model was fit only on the locked TCGA rank matrix to instantiate the CF32 signature and then frozen before METABRIC prediction.",
            },
            {
                "QC_check": "No threshold optimization",
                "Status": "PASS",
                "Details": f"Classification used locked threshold {LOCKED_THRESHOLD}.",
            },
            {
                "QC_check": "Data processing documented",
                "Status": "PASS",
                "Details": "Cohort selection, input manifest, dataset summary, and gene mapping tables were written.",
            },
            {
                "QC_check": "Independent validation maintained",
                "Status": "PASS",
                "Details": "METABRIC was selected independently of TCGA and SCAN-B and was not used in prior model selection.",
            },
        ]
    )
    qc.to_csv(RESULTS_DIR / "CF33_quality_control_checks.tsv", sep="\t", index=False)
    return qc


def write_report(
    clinical: pd.DataFrame,
    mapping: pd.DataFrame,
    metrics: dict[str, float],
    ci: pd.DataFrame,
    calibration: pd.DataFrame,
    cross_cohort: pd.DataFrame,
    subgroups: pd.DataFrame,
    qc: pd.DataFrame,
) -> None:
    missing = mapping.loc[~mapping["Available"], "Gene"].tolist()
    ci_lookup = ci.set_index("Metric")
    qc_lines = "\n".join(f"- {row.QC_check}: {row.Status}. {row.Details}" for row in qc.itertuples())
    subgroup_note = (
        f"Subgroup analysis was performed for {subgroups['Subgroup_type'].nunique()} subgroup classes with sufficient sample size."
        if not subgroups.empty
        else "No subgroup strata met the minimum sample and class-count criteria."
    )

    report = f"""# CF33 Second External Validation

## Objective
CF33 evaluates whether the revised CF32 10-gene HER2 transcriptomic signature generalizes to a second independent external cohort.

## Reviewer Concern
The key reviewer-facing question is whether the compact signature remains predictive outside TCGA and SCAN-B.

## Cohort Description
METABRIC was selected because it was the preferred independent cohort and was available from cBioPortal DataHub with mRNA expression and explicit HER2_STATUS labels. The analysis used {len(clinical)} METABRIC samples with available expression and HER2 labels, including {int(clinical['HER2'].sum())} HER2-positive and {int((1 - clinical['HER2']).sum())} HER2-negative tumors.

## Gene Compatibility
Available signature genes: {int(mapping['Available'].sum())}/10. Missing genes: {', '.join(missing) if missing else 'none'}. Missing genes were not replaced; they were handled only as locked-universe missing features during external rank alignment.

## Frozen Model Evaluation
The 10-gene model was instantiated from TCGA only using the fixed CF18/CF32 Elastic-Net logistic framework and then applied unchanged to METABRIC. METABRIC was not used for fitting, threshold selection, gene selection, or optimization. Classification used the locked threshold {LOCKED_THRESHOLD}.

## Performance Results
METABRIC AUROC was {metrics['AUROC']:.4f} (95% bootstrap CI {ci_lookup.loc['AUROC', 'CI_lower_2_5']:.4f}-{ci_lookup.loc['AUROC', 'CI_upper_97_5']:.4f}) and PR-AUC was {metrics['PR_AUC']:.4f} (95% CI {ci_lookup.loc['PR_AUC', 'CI_lower_2_5']:.4f}-{ci_lookup.loc['PR_AUC', 'CI_upper_97_5']:.4f}). At the locked threshold, sensitivity was {metrics['Sensitivity']:.4f}, specificity {metrics['Specificity']:.4f}, PPV {metrics['PPV']:.4f}, NPV {metrics['NPV']:.4f}, accuracy {metrics['Accuracy']:.4f}, F1-score {metrics['F1_score']:.4f}, and MCC {metrics['MCC']:.4f}.

## Calibration
The METABRIC Brier score was {calibration['Brier_score'].iloc[0]:.4f}, calibration slope {calibration['Calibration_slope'].iloc[0]:.4f}, and calibration intercept {calibration['Calibration_intercept'].iloc[0]:.4f}.

## Comparison With Previous Cohorts
The cross-cohort comparison table includes TCGA, SCAN-B, and METABRIC. METABRIC extends validation to an independent microarray cohort, so performance should be interpreted as cross-platform generalization rather than same-platform replication.

## Subgroup Analysis
{subgroup_note}

## Limitations
METABRIC uses microarray expression rather than RNA-seq, so the CF18/CF32 percentile-rank preprocessing is a compatibility strategy rather than a perfect assay match. Any missing signature genes were not replaced. The model is not recalibrated to METABRIC prevalence, and the locked threshold may not be optimal for this cohort.

## QC
{qc_lines}
"""
    (CF33 / "CF33_report.md").write_text(report, encoding="utf-8")

    paragraph = (
        "The generalizability of the compact HER2 signature was evaluated in METABRIC, an independent external breast cancer cohort. "
        f"Without external retraining or threshold optimization, the 10-gene signature achieved AUROC {metrics['AUROC']:.3f} and PR-AUC {metrics['PR_AUC']:.3f}, "
        "supporting cross-cohort robustness while highlighting cross-platform calibration and missing-feature limitations."
    )
    (RESULTS_DIR / "CF33_manuscript_paragraph.txt").write_text(paragraph + "\n", encoding="utf-8")


def main() -> int:
    ensure_dirs()
    with (LOGS_DIR / "CF33_run.log").open("w", encoding="utf-8") as log:
        def log_line(message: str) -> None:
            print(message)
            log.write(message + "\n")
            log.flush()

        log_line("CF33 second external validation started.")
        genes = load_final_genes()
        x_tcga, y_tcga, locked_universe = load_tcga_training(genes)
        x_metabric, clinical, mapping = load_metabric(genes, locked_universe)
        write_selection_and_manifest(clinical, mapping)
        write_dataset_summary(clinical, mapping)
        log_line(f"Selected METABRIC with n={len(clinical)} and {int(mapping['Available'].sum())}/10 signature genes available.")

        model = make_model()
        model.fit(x_tcga, y_tcga)
        probability = model.predict_proba(x_metabric)[:, 1]
        y_true = clinical["HER2"].to_numpy(dtype=int)
        prediction_table = clinical[["SAMPLE_ID", "PATIENT_ID", "HER2_STATUS", "HER2", "ER_STATUS", "PR_STATUS", "TUMOR_STAGE", "CLAUDIN_SUBTYPE"]].copy()
        prediction_table["HER2_probability"] = probability
        prediction_table["prediction"] = (probability >= LOCKED_THRESHOLD).astype(int)
        prediction_table["locked_threshold"] = LOCKED_THRESHOLD
        prediction_table.to_csv(RESULTS_DIR / "CF33_METABRIC_predictions.tsv", sep="\t", index=False)

        logistic = model.named_steps["logisticregression"]
        coefficient_table = pd.DataFrame({"Gene": genes, "Coefficient": logistic.coef_.ravel()})
        coefficient_table["Intercept"] = logistic.intercept_[0]
        coefficient_table.to_csv(METADATA_DIR / "CF33_frozen_TCGA_10_gene_model_coefficients.tsv", sep="\t", index=False)

        metrics = calculate_metrics(y_true, probability, LOCKED_THRESHOLD)
        metrics["N"] = len(y_true)
        metrics_df = pd.DataFrame([{**{"Cohort": "METABRIC", "Number_of_genes": len(genes), "Threshold_used": LOCKED_THRESHOLD}, **metrics}])
        metrics_df.to_csv(RESULTS_DIR / "CF33_external_validation_metrics.tsv", sep="\t", index=False)

        ci = bootstrap_ci(y_true, probability, LOCKED_THRESHOLD)
        calibration = pd.DataFrame([{"Cohort": "METABRIC", **calibration_metrics(y_true, probability)}])
        calibration.to_csv(RESULTS_DIR / "CF33_calibration_metrics.tsv", sep="\t", index=False)
        cross_cohort = write_cross_cohort(metrics)
        subgroups = subgroup_analysis(clinical, probability)
        plot_outputs(clinical, probability, cross_cohort)
        qc = write_qc(mapping)
        write_report(clinical, mapping, metrics, ci, calibration, cross_cohort, subgroups, qc)

        if (qc["Status"] == "FAIL").any():
            log_line("CF33 completed with QC failure.")
            return 1
        log_line("CF33 completed successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
