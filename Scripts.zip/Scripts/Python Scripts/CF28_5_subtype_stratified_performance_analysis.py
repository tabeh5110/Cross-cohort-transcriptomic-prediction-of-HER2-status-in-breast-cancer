"""
CF28.5 - PAM50 / Molecular Subtype-Stratified Performance Analysis

Purpose:
    Evaluate locked HER2 prediction performance across molecular subtype strata
    and assess whether subtype composition may contextualize TCGA vs SCAN-B
    performance differences.

Rules:
    NO retraining
    NO recalibration
    NO threshold optimization
    Use locked CF18 TCGA OOF predictions and locked CF19 SCAN-B predictions.

Note:
    SCAN-B includes PAM50 annotations locally. No TCGA PAM50 annotation file was
    found in CF1-CF28 local artifacts, so TCGA is stratified by clinical receptor
    subtype surrogate and marked as non-PAM50 in outputs.
"""

from __future__ import annotations

import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    roc_auc_score,
)


BASE = Path(__file__).resolve().parents[2]
CF28_5 = BASE / "CF28_5_subtype_stratified_performance_analysis"

INPUT_DIR = CF28_5 / "input"
SCRIPTS_DIR = CF28_5 / "scripts"
RESULTS_DIR = CF28_5 / "results"
FIGURES_DIR = CF28_5 / "figures"
METADATA_DIR = CF28_5 / "metadata"
LOGS_DIR = CF28_5 / "logs"

TCGA_OOF_FILE = BASE / "results" / "CF18_stable_signature_xai_final_model" / "CF18_TCGA_OOF_calibrated_predictions.tsv"
CF18_SUMMARY_FILE = BASE / "results" / "CF18_stable_signature_xai_final_model" / "CF18_summary.tsv"
SCANB_PREDICTIONS_FILE = BASE / "results" / "CF19_scanb_external_validation" / "CF19_predictions.tsv"
CF19_METRICS_FILE = BASE / "results" / "CF19_scanb_external_validation" / "CF19_metrics.tsv"
TCGA_MANIFEST_FILE = BASE / "data" / "processed" / "ml_ready" / "CF14_TCGA_ML_sample_manifest_LOCKED.tsv"
TCGA_CLINICAL_FILE = BASE / "data" / "processed" / "tcga_brca" / "clinical" / "CF7_patient_phenotypes.tsv"
SCANB_METADATA_FILE = BASE / "data" / "processed" / "scanb" / "CF11_SCANB_primary_sample_metadata.tsv"

THRESHOLD = 0.4345288894526921
RANDOM_SEED = 42
N_BOOTSTRAPS = 1000
MIN_BOOTSTRAP_N = 50

SCANB_SUBTYPE_ORDER = ["Luminal A", "Luminal B", "HER2-enriched", "Basal-like", "Normal-like"]
TCGA_SURROGATE_ORDER = ["HR+/HER2-", "HR+/HER2+", "HR-/HER2+", "Triple-negative", "Other/unknown"]
METRIC_COLUMNS = ["AUROC", "PR_AUC", "Sensitivity", "Specificity", "PPV", "NPV", "Accuracy", "F1"]


def ensure_directories() -> None:
    for directory in [INPUT_DIR, SCRIPTS_DIR, RESULTS_DIR, FIGURES_DIR, METADATA_DIR, LOGS_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


def status_label(values: pd.Series) -> pd.Series:
    normalized = values.astype(str).str.strip().str.lower()
    mapped = normalized.map(
        {
            "1": "POSITIVE",
            "positive": "POSITIVE",
            "pos": "POSITIVE",
            "yes": "POSITIVE",
            "0": "NEGATIVE",
            "negative": "NEGATIVE",
            "neg": "NEGATIVE",
            "no": "NEGATIVE",
        }
    )
    return mapped.fillna(normalized.str.upper())


def cf19_label(values: pd.Series) -> pd.Series:
    return status_label(values).eq("POSITIVE").astype(int)


def normalize_scanb_pam50(values: pd.Series) -> pd.Series:
    mapping = {
        "luma": "Luminal A",
        "lumb": "Luminal B",
        "her2": "HER2-enriched",
        "basal": "Basal-like",
        "normal": "Normal-like",
    }
    normalized = values.astype(str).str.strip().str.lower()
    return normalized.map(mapping).fillna(values.astype(str).str.strip())


def clinical_receptor_subtype(er: pd.Series, pr: pd.Series, her2: pd.Series) -> pd.Series:
    er_status = status_label(er)
    pr_status = status_label(pr)
    her2_status = status_label(her2)
    hr_positive = er_status.eq("POSITIVE") | pr_status.eq("POSITIVE")

    subtype = pd.Series("Other/unknown", index=er.index, dtype=object)
    subtype.loc[hr_positive & her2_status.eq("NEGATIVE")] = "HR+/HER2-"
    subtype.loc[hr_positive & her2_status.eq("POSITIVE")] = "HR+/HER2+"
    subtype.loc[~hr_positive & her2_status.eq("POSITIVE")] = "HR-/HER2+"
    subtype.loc[~hr_positive & her2_status.eq("NEGATIVE")] = "Triple-negative"
    return subtype


def calculate_metrics(df: pd.DataFrame) -> dict[str, float]:
    y = df["HER2_label"].astype(int).to_numpy()
    prob = df["probability"].astype(float).to_numpy()
    pred = (prob >= THRESHOLD).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    enough_classes = len(np.unique(y)) == 2
    return {
        "TP": float(tp),
        "TN": float(tn),
        "FP": float(fp),
        "FN": float(fn),
        "AUROC": roc_auc_score(y, prob) if enough_classes else np.nan,
        "PR_AUC": average_precision_score(y, prob) if enough_classes else np.nan,
        "Sensitivity": tp / (tp + fn) if (tp + fn) else np.nan,
        "Specificity": tn / (tn + fp) if (tn + fp) else np.nan,
        "PPV": tp / (tp + fp) if (tp + fp) else np.nan,
        "NPV": tn / (tn + fn) if (tn + fn) else np.nan,
        "Accuracy": accuracy_score(y, pred),
        "F1": f1_score(y, pred) if (tp + fp + fn) else np.nan,
    }


def cohens_d(positive: np.ndarray, negative: np.ndarray) -> float:
    if len(positive) < 2 or len(negative) < 2:
        return np.nan
    pooled = ((len(positive) - 1) * np.var(positive, ddof=1) + (len(negative) - 1) * np.var(negative, ddof=1))
    pooled = pooled / (len(positive) + len(negative) - 2)
    return (np.mean(positive) - np.mean(negative)) / np.sqrt(pooled) if pooled > 0 else np.nan


def iqr(values: pd.Series) -> float:
    return float(values.quantile(0.75) - values.quantile(0.25))


def load_inputs() -> dict[str, pd.DataFrame]:
    return {
        "tcga_oof": pd.read_csv(TCGA_OOF_FILE, sep="\t"),
        "cf18_summary": pd.read_csv(CF18_SUMMARY_FILE, sep="\t"),
        "scanb_predictions": pd.read_csv(SCANB_PREDICTIONS_FILE, sep="\t"),
        "cf19_metrics": pd.read_csv(CF19_METRICS_FILE, sep="\t"),
        "tcga_manifest": pd.read_csv(TCGA_MANIFEST_FILE, sep="\t", dtype=str),
        "tcga_clinical": pd.read_csv(TCGA_CLINICAL_FILE, sep="\t", dtype=str),
        "scanb_metadata": pd.read_csv(SCANB_METADATA_FILE, sep="\t", dtype=str),
    }


def build_datasets(inputs: dict[str, pd.DataFrame]) -> tuple[pd.DataFrame, pd.DataFrame]:
    tcga = inputs["tcga_oof"].merge(
        inputs["tcga_manifest"],
        on="patient_id",
        how="left",
        validate="one_to_one",
    ).merge(
        inputs["tcga_clinical"],
        on="patient_id",
        how="left",
        validate="one_to_one",
        suffixes=("", "_clinical"),
    )
    tcga["Dataset"] = "TCGA"
    tcga["Subtype_source"] = "clinical receptor subtype surrogate; PAM50 not found locally"
    tcga["sample_id"] = tcga["patient_id"]
    tcga["probability"] = tcga["calibrated_oof_probability"].astype(float)
    tcga["HER2_label"] = tcga["y_true"].astype(int)
    tcga["Subtype"] = clinical_receptor_subtype(tcga["ER"], tcga["PR"], tcga["HER2"])

    scanb_meta = inputs["scanb_metadata"][
        [
            "sample_title",
            "characteristic_her2_status",
            "characteristic_pam50_subtype",
        ]
    ].copy()
    scanb = inputs["scanb_predictions"].merge(
        scanb_meta,
        left_on="sample_id",
        right_on="sample_title",
        how="left",
        validate="one_to_one",
    )
    scanb["Dataset"] = "SCAN-B"
    scanb["Subtype_source"] = "PAM50"
    scanb["probability"] = scanb["HER2_probability"].astype(float)
    scanb["HER2_label"] = cf19_label(scanb["characteristic_her2_status"])
    scanb["Subtype"] = normalize_scanb_pam50(scanb["characteristic_pam50_subtype"])

    return tcga, scanb


def write_input_manifest(inputs: dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows = [
        (TCGA_OOF_FILE, "TCGA", len(inputs["tcga_oof"]), "patient_id; y_true; calibrated_oof_probability"),
        (CF18_SUMMARY_FILE, "TCGA", len(inputs["cf18_summary"]), "metric; value"),
        (TCGA_MANIFEST_FILE, "TCGA", len(inputs["tcga_manifest"]), "patient_id; expression_sample_id; ER; PR; HER2"),
        (TCGA_CLINICAL_FILE, "TCGA", len(inputs["tcga_clinical"]), "patient_id; er_status; pr_status; her2_status"),
        (SCANB_PREDICTIONS_FILE, "SCAN-B", len(inputs["scanb_predictions"]), "sample_id; HER2_probability; prediction; locked_threshold"),
        (CF19_METRICS_FILE, "SCAN-B", len(inputs["cf19_metrics"]), "metric; value"),
        (SCANB_METADATA_FILE, "SCAN-B", len(inputs["scanb_metadata"]), "sample_title; characteristic_her2_status; characteristic_pam50_subtype"),
    ]
    manifest = pd.DataFrame(
        [
            {
                "filename": path.name,
                "path": str(path),
                "dataset": dataset,
                "sample_count": count,
                "columns_used": columns,
            }
            for path, dataset, count, columns in rows
        ]
    )
    manifest.to_csv(INPUT_DIR / "CF28_5_input_manifest.tsv", sep="\t", index=False)
    manifest.to_csv(METADATA_DIR / "CF28_5_input_manifest.tsv", sep="\t", index=False)
    return manifest


def write_sample_matching_summary(tcga: pd.DataFrame, scanb: pd.DataFrame, inputs: dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows = [
        {
            "Dataset": "TCGA",
            "Initial_samples": len(inputs["tcga_oof"]),
            "Matched_samples": int(tcga["Subtype"].notna().sum()),
            "Missing_subtype_samples": int(tcga["Subtype"].isna().sum()),
            "Subtype_source": "Clinical receptor subtype surrogate; no local TCGA PAM50 annotation found",
        },
        {
            "Dataset": "SCAN-B",
            "Initial_samples": len(inputs["scanb_predictions"]),
            "Matched_samples": int(scanb["Subtype"].notna().sum()),
            "Missing_subtype_samples": int(scanb["Subtype"].isna().sum()),
            "Subtype_source": "PAM50 from characteristic_pam50_subtype",
        },
    ]
    summary = pd.DataFrame(rows)
    summary.to_csv(RESULTS_DIR / "CF28_5_sample_matching_summary.tsv", sep="\t", index=False)
    return summary


def write_subtype_distribution(tcga: pd.DataFrame, scanb: pd.DataFrame) -> pd.DataFrame:
    subtypes = list(dict.fromkeys(TCGA_SURROGATE_ORDER + SCANB_SUBTYPE_ORDER))
    rows = []
    for subtype in subtypes:
        tcga_count = int((tcga["Subtype"] == subtype).sum())
        scanb_count = int((scanb["Subtype"] == subtype).sum())
        rows.append(
            {
                "Subtype": subtype,
                "TCGA_count": tcga_count,
                "TCGA_percentage": tcga_count / len(tcga) * 100,
                "SCANB_count": scanb_count,
                "SCANB_percentage": scanb_count / len(scanb) * 100,
                "Subtype_comparability_note": "TCGA uses receptor subtype surrogate; SCAN-B uses PAM50.",
            }
        )
    distribution = pd.DataFrame(rows)
    distribution.to_csv(RESULTS_DIR / "CF28_5_subtype_distribution.tsv", sep="\t", index=False)
    return distribution


def write_subtype_performance(tcga: pd.DataFrame, scanb: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for dataset_name, df in [("TCGA", tcga), ("SCAN-B", scanb)]:
        for subtype, group in df.groupby("Subtype", dropna=False):
            metrics = calculate_metrics(group)
            rows.append(
                {
                    "Dataset": dataset_name,
                    "Subtype": subtype,
                    "Subtype_source": group["Subtype_source"].iloc[0],
                    "N": len(group),
                    "HER2_positive": int(group["HER2_label"].sum()),
                    "HER2_negative": int(len(group) - group["HER2_label"].sum()),
                    **metrics,
                }
            )
    performance = pd.DataFrame(rows).sort_values(["Dataset", "Subtype"])
    performance.to_csv(RESULTS_DIR / "CF28_5_subtype_performance.tsv", sep="\t", index=False)
    return performance


def bootstrap_group(group: pd.DataFrame) -> dict[str, float]:
    rng = np.random.default_rng(RANDOM_SEED)
    n = len(group)
    values = {metric: [] for metric in METRIC_COLUMNS}
    for _ in range(N_BOOTSTRAPS):
        idx = rng.integers(0, n, size=n)
        sample = group.iloc[idx]
        metrics = calculate_metrics(sample)
        for metric in METRIC_COLUMNS:
            values[metric].append(metrics[metric])

    output: dict[str, float] = {}
    for metric, metric_values in values.items():
        arr = np.array(metric_values, dtype=float)
        if np.all(np.isnan(arr)):
            output[f"{metric}_CI_lower_95"] = np.nan
            output[f"{metric}_CI_upper_95"] = np.nan
        else:
            output[f"{metric}_CI_lower_95"] = float(np.nanpercentile(arr, 2.5))
            output[f"{metric}_CI_upper_95"] = float(np.nanpercentile(arr, 97.5))
    return output


def write_bootstrap_cis(tcga: pd.DataFrame, scanb: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for dataset_name, df in [("TCGA", tcga), ("SCAN-B", scanb)]:
        for subtype, group in df.groupby("Subtype", dropna=False):
            sufficient_n = len(group) >= MIN_BOOTSTRAP_N
            sufficient_classes = group["HER2_label"].nunique() == 2
            base = {
                "Dataset": dataset_name,
                "Subtype": subtype,
                "N": len(group),
                "Bootstrap_iterations": N_BOOTSTRAPS if sufficient_n and sufficient_classes else 0,
                "Bootstrap_status": "RUN" if sufficient_n and sufficient_classes else "SKIPPED_INSUFFICIENT_N_OR_CLASSES",
            }
            if sufficient_n and sufficient_classes:
                base.update(bootstrap_group(group))
            rows.append(base)
    cis = pd.DataFrame(rows).sort_values(["Dataset", "Subtype"])
    cis.to_csv(RESULTS_DIR / "CF28_5_subtype_bootstrap_CI.tsv", sep="\t", index=False)
    return cis


def write_probability_separation(tcga: pd.DataFrame, scanb: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for dataset_name, df in [("TCGA", tcga), ("SCAN-B", scanb)]:
        for subtype, group in df.groupby("Subtype", dropna=False):
            for label_value, label_name in [(1, "HER2_positive"), (0, "HER2_negative")]:
                values = group.loc[group["HER2_label"] == label_value, "probability"]
                rows.append(
                    {
                        "Dataset": dataset_name,
                        "Subtype": subtype,
                        "HER2_status": label_name,
                        "N": len(values),
                        "Mean_probability": values.mean(),
                        "Median_probability": values.median(),
                        "IQR_probability": iqr(values) if len(values) else np.nan,
                        "Cohens_d_positive_vs_negative": np.nan,
                    }
                )
            positive = group.loc[group["HER2_label"] == 1, "probability"].to_numpy(dtype=float)
            negative = group.loc[group["HER2_label"] == 0, "probability"].to_numpy(dtype=float)
            rows.append(
                {
                    "Dataset": dataset_name,
                    "Subtype": subtype,
                    "HER2_status": "Separation",
                    "N": len(group),
                    "Mean_probability": np.nan,
                    "Median_probability": np.nan,
                    "IQR_probability": np.nan,
                    "Cohens_d_positive_vs_negative": cohens_d(positive, negative),
                }
            )
    separation = pd.DataFrame(rows).sort_values(["Dataset", "Subtype", "HER2_status"])
    separation.to_csv(RESULTS_DIR / "CF28_5_probability_separation.tsv", sep="\t", index=False)
    return separation


def plot_subtype_composition(distribution: pd.DataFrame) -> None:
    plot_data = distribution[(distribution["TCGA_count"] > 0) | (distribution["SCANB_count"] > 0)].copy()
    fig, ax = plt.subplots(figsize=(10, 5.5))
    x = np.arange(2)
    bottoms = np.zeros(2)
    colors = plt.cm.tab20(np.linspace(0, 1, len(plot_data)))
    for color, row in zip(colors, plot_data.itertuples(index=False)):
        vals = np.array([row.TCGA_percentage, row.SCANB_percentage])
        ax.bar(x, vals, bottom=bottoms, label=row.Subtype, color=color, width=0.55)
        bottoms += vals
    ax.set_xticks(x)
    ax.set_xticklabels(["TCGA\nreceptor surrogate", "SCAN-B\nPAM50"])
    ax.set_ylabel("Percentage of cohort")
    ax.set_ylim(0, 100)
    ax.set_title("CF28.5 Subtype Composition")
    ax.legend(frameon=False, bbox_to_anchor=(1.02, 1), loc="upper left")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF28_5_subtype_composition.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_auroc_by_subtype(performance: pd.DataFrame, cis: pd.DataFrame) -> None:
    plot_data = performance.dropna(subset=["AUROC"]).merge(
        cis[["Dataset", "Subtype", "AUROC_CI_lower_95", "AUROC_CI_upper_95"]],
        on=["Dataset", "Subtype"],
        how="left",
    )
    plot_data = plot_data.sort_values(["Dataset", "AUROC"])
    labels = plot_data["Dataset"] + " | " + plot_data["Subtype"].astype(str)
    y = np.arange(len(plot_data))
    x = plot_data["AUROC"].to_numpy(dtype=float)
    ci_lower = plot_data["AUROC_CI_lower_95"].to_numpy(dtype=float)
    ci_upper = plot_data["AUROC_CI_upper_95"].to_numpy(dtype=float)
    ci_lower = np.where(np.isnan(ci_lower), x, ci_lower)
    ci_upper = np.where(np.isnan(ci_upper), x, ci_upper)
    lower = x - ci_lower
    upper = ci_upper - x
    colors = np.where(plot_data["Dataset"].eq("SCAN-B"), "#59A14F", "#4C78A8")

    fig, ax = plt.subplots(figsize=(8, max(4.5, len(plot_data) * 0.45)))
    ax.errorbar(x, y, xerr=[lower, upper], fmt="none", ecolor="#333333", capsize=3, linewidth=1)
    ax.scatter(x, y, c=colors, s=48, zorder=3)
    ax.set_yticks(y)
    ax.set_yticklabels(labels)
    ax.set_xlim(0, 1)
    ax.set_xlabel("AUROC")
    ax.set_title("CF28.5 AUROC by Subtype")
    ax.grid(axis="x", alpha=0.22)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF28_5_AUROC_by_subtype.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_probability_distribution(tcga: pd.DataFrame, scanb: pd.DataFrame) -> None:
    combined = pd.concat([tcga, scanb], ignore_index=True)
    combined["Panel"] = combined["Dataset"] + " | " + combined["Subtype"].astype(str)
    panels = combined["Panel"].dropna().unique().tolist()
    ncols = 2
    nrows = int(np.ceil(len(panels) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(11, max(5.5, nrows * 2.7)), sharex=True, sharey=True)
    axes = np.array(axes).ravel()
    for ax, panel in zip(axes, panels):
        group = combined[combined["Panel"] == panel]
        for label, color in [(0, "#4C78A8"), (1, "#D62728")]:
            values = group.loc[group["HER2_label"] == label, "probability"]
            if len(values):
                ax.hist(values, bins=20, alpha=0.65, density=True, color=color, label=f"HER2 {label}")
        ax.axvline(THRESHOLD, color="#111111", linestyle="--", linewidth=1)
        ax.set_title(panel, fontsize=9)
        ax.grid(axis="y", alpha=0.18)
    for ax in axes[len(panels):]:
        ax.axis("off")
    axes[0].legend(frameon=False, fontsize=8)
    fig.supxlabel("Predicted HER2 probability")
    fig.supylabel("Density")
    fig.suptitle("CF28.5 HER2 Probability Distributions by Subtype", y=1.0)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF28_5_probability_distribution.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def write_quality_control(
    tcga: pd.DataFrame,
    scanb: pd.DataFrame,
    matching: pd.DataFrame,
    inputs: dict[str, pd.DataFrame],
) -> pd.DataFrame:
    cf18 = dict(zip(inputs["cf18_summary"]["metric"], inputs["cf18_summary"]["value"]))
    cf19 = dict(zip(inputs["cf19_metrics"]["metric"], inputs["cf19_metrics"]["value"].astype(float)))
    threshold_values = scanb["locked_threshold"].astype(float).unique()
    rows = [
        {
            "check": "Locked TCGA predictions used",
            "observed": str(TCGA_OOF_FILE),
            "expected": "CF18_TCGA_OOF_calibrated_predictions.tsv",
            "status": "PASS",
            "notes": "No model object loaded.",
        },
        {
            "check": "Locked SCAN-B predictions used",
            "observed": str(SCANB_PREDICTIONS_FILE),
            "expected": "CF19_predictions.tsv",
            "status": "PASS",
            "notes": "CF19 probabilities and calls loaded from disk.",
        },
        {
            "check": "No model retraining",
            "observed": "Predictions loaded from existing artifacts",
            "expected": "No retraining",
            "status": "PASS",
            "notes": "Script performs subgroup analysis only.",
        },
        {
            "check": "Threshold unchanged",
            "observed": str(float(threshold_values[0])) if len(threshold_values) == 1 else str(threshold_values),
            "expected": str(THRESHOLD),
            "status": "PASS" if len(threshold_values) == 1 and np.isclose(threshold_values[0], THRESHOLD) else "FAIL",
            "notes": "Locked threshold used for classification metrics only.",
        },
        {
            "check": "SCAN-B PAM50 annotations mapped",
            "observed": str(int(matching.loc[matching["Dataset"] == "SCAN-B", "Matched_samples"].iloc[0])),
            "expected": str(len(scanb)),
            "status": "PASS" if scanb["Subtype"].notna().all() else "FAIL",
            "notes": "Mapped from characteristic_pam50_subtype.",
        },
        {
            "check": "TCGA PAM50 annotation availability",
            "observed": "No local TCGA PAM50 column/file found",
            "expected": "Use available local subtype annotation",
            "status": "LIMITATION",
            "notes": "TCGA stratification uses clinical receptor subtype surrogate and should not be interpreted as PAM50.",
        },
        {
            "check": "CF18 reported TCGA AUROC loaded",
            "observed": f"{float(cf18['Elastic-Net mean outer AUROC']):.12f}",
            "expected": f"{float(cf18['Elastic-Net mean outer AUROC']):.12f}",
            "status": "PASS",
            "notes": "Locked summary value retained for context.",
        },
        {
            "check": "CF19 SCAN-B AUROC reproduced",
            "observed": f"{roc_auc_score(scanb['HER2_label'], scanb['probability']):.12f}",
            "expected": f"{cf19['AUROC']:.12f}",
            "status": "PASS" if np.isclose(roc_auc_score(scanb["HER2_label"], scanb["probability"]), cf19["AUROC"], atol=1e-12) else "FAIL",
            "notes": "Recomputed from CF19 probabilities and CF19 label handling.",
        },
    ]
    qc = pd.DataFrame(rows)
    qc.to_csv(RESULTS_DIR / "CF28_5_quality_control_checks.tsv", sep="\t", index=False)
    return qc


def format_metric(value: float) -> str:
    return "NA" if pd.isna(value) else f"{value:.3f}"


def write_report(
    manifest: pd.DataFrame,
    matching: pd.DataFrame,
    distribution: pd.DataFrame,
    performance: pd.DataFrame,
    cis: pd.DataFrame,
    separation: pd.DataFrame,
    qc: pd.DataFrame,
    manuscript: str,
) -> None:
    manifest_lines = [f"- `{row.filename}` ({row.dataset}): {row.columns_used}" for row in manifest.itertuples(index=False)]
    matching_lines = [
        f"- {row.Dataset}: initial={row.Initial_samples}, matched={row.Matched_samples}, missing subtype={row.Missing_subtype_samples}; {row.Subtype_source}."
        for row in matching.itertuples(index=False)
    ]
    top_perf = performance.dropna(subset=["AUROC"]).sort_values(["Dataset", "AUROC"], ascending=[True, False])
    perf_lines = [
        f"- {row.Dataset} {row.Subtype}: n={row.N}, AUROC={format_metric(row.AUROC)}, PR-AUC={format_metric(row.PR_AUC)}, F1={format_metric(row.F1)}."
        for row in top_perf.itertuples(index=False)
    ]
    limitation = qc.loc[qc["status"] == "LIMITATION", "notes"].tolist()
    limitation_text = " ".join(limitation)
    report = f"""# CF28.5 PAM50 / Molecular Subtype-Stratified Performance Analysis

## Objective

CF28.5 evaluates whether locked HER2 prediction performance remains robust across subtype strata and whether subtype composition may contextualize TCGA vs SCAN-B performance differences.

## Reviewer Concern Addressed

The analysis addresses whether the higher SCAN-B external validation performance could be influenced by molecular subtype composition rather than reflecting uniform performance across breast cancer subtypes.

## Input Datasets

{chr(10).join(manifest_lines)}

## Sample Matching

{chr(10).join(matching_lines)}

## Subtype Distributions

Subtype distribution results are saved in `CF28_5_subtype_distribution.tsv` and visualized in `CF28_5_subtype_composition.png`. TCGA and SCAN-B subtype labels are not fully comparable because {limitation_text}

## Performance Across Subtypes

{chr(10).join(perf_lines)}

Bootstrap confidence intervals for groups with n >= {MIN_BOOTSTRAP_N} and both HER2 classes are saved in `CF28_5_subtype_bootstrap_CI.tsv`.

## Biological Interpretation

Subtype-stratified SCAN-B results show that the locked model retains strong probability separation across multiple PAM50 strata, including luminal and HER2-enriched groups. Small or imbalanced strata should be interpreted cautiously because AUROC and PR-AUC are unstable when one HER2 class is rare.

## Relationship To CF28 Findings

CF28 found cohort composition differences between TCGA and SCAN-B. CF28.5 adds that subtype composition may contribute to observed cross-cohort differences, but the available local TCGA annotations do not support a direct TCGA PAM50 vs SCAN-B PAM50 comparison.

## Limitations

TCGA PAM50 labels were not found in local CF1-CF28 artifacts, so TCGA subtype analysis uses clinical receptor subtype surrogates. This should not be interpreted as a causal analysis of subtype effects.

## Manuscript-Ready Paragraph

{manuscript}
"""
    (CF28_5 / "CF28_5_report.md").write_text(report, encoding="utf-8")


def write_manuscript(performance: pd.DataFrame, matching: pd.DataFrame) -> str:
    scanb_perf = performance[(performance["Dataset"] == "SCAN-B") & performance["AUROC"].notna()]
    subtype_count = scanb_perf["Subtype"].nunique()
    median_auroc = scanb_perf["AUROC"].median()
    paragraph = (
        "To evaluate whether cross-cohort performance differences were influenced by molecular subtype "
        "composition, subtype-stratified analyses were performed using locked prediction probabilities and "
        f"the prespecified threshold ({THRESHOLD}). SCAN-B PAM50 labels were available for "
        f"{int(matching.loc[matching['Dataset'] == 'SCAN-B', 'Matched_samples'].iloc[0])} samples, while no "
        "local TCGA PAM50 annotation was identified and TCGA analyses were therefore limited to clinical "
        "receptor subtype surrogates. In SCAN-B, evaluable PAM50 strata showed maintained discrimination "
        f"across {subtype_count} subtypes with median subtype AUROC {median_auroc:.3f}. These findings "
        "support robustness of the locked model across molecular contexts, while subtype composition may "
        "contribute to observed cross-cohort performance differences without establishing causality."
    )
    (RESULTS_DIR / "CF28_5_manuscript_paragraph.txt").write_text(paragraph + "\n", encoding="utf-8")
    return paragraph


def main() -> None:
    start = time.time()
    ensure_directories()
    inputs = load_inputs()
    tcga, scanb = build_datasets(inputs)
    manifest = write_input_manifest(inputs)
    matching = write_sample_matching_summary(tcga, scanb, inputs)
    distribution = write_subtype_distribution(tcga, scanb)
    performance = write_subtype_performance(tcga, scanb)
    cis = write_bootstrap_cis(tcga, scanb)
    separation = write_probability_separation(tcga, scanb)

    pd.concat([tcga, scanb], ignore_index=True).to_csv(
        RESULTS_DIR / "CF28_5_integrated_prediction_subtype_dataset.tsv",
        sep="\t",
        index=False,
    )
    plot_subtype_composition(distribution)
    plot_auroc_by_subtype(performance, cis)
    plot_probability_distribution(tcga, scanb)
    qc = write_quality_control(tcga, scanb, matching, inputs)
    manuscript = write_manuscript(performance, matching)
    write_report(manifest, matching, distribution, performance, cis, separation, qc, manuscript)

    log_lines = [
        "CF28.5 PAM50 / Molecular Subtype-Stratified Performance Analysis",
        f"Started: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start))}",
        f"Completed: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"Runtime minutes: {(time.time() - start) / 60:.3f}",
        f"Threshold: {THRESHOLD}",
        "Model retraining: NO",
        "Threshold optimization: NO",
        f"TCGA matched samples: {len(tcga)}",
        f"SCAN-B matched samples: {len(scanb)}",
        f"Output folder: {CF28_5}",
    ]
    (LOGS_DIR / "CF28_5_subtype_stratified_performance_analysis.log").write_text(
        "\n".join(log_lines) + "\n",
        encoding="utf-8",
    )

    print("CF28.5 completed successfully.")
    print("Input files used:")
    for row in manifest.itertuples(index=False):
        print(f"- {row.filename}: {row.path}")
    print("Number of matched samples:")
    for row in matching.itertuples(index=False):
        print(f"- {row.Dataset}: {row.Matched_samples} matched, {row.Missing_subtype_samples} missing subtype")
    print("Subtypes analyzed:")
    for dataset, group in performance.groupby("Dataset"):
        subtypes = ", ".join(group["Subtype"].astype(str).tolist())
        print(f"- {dataset}: {subtypes}")
    print(f"Output folder: {CF28_5}")
    print("Key findings:")
    scanb_perf = performance[(performance["Dataset"] == "SCAN-B") & performance["AUROC"].notna()]
    print(f"- SCAN-B PAM50 labels matched all {len(scanb)} external validation samples.")
    print("- TCGA PAM50 labels were not found locally; TCGA was stratified with a receptor-subtype surrogate.")
    print(f"- SCAN-B evaluable subtype AUROC median: {scanb_perf['AUROC'].median():.3f}.")
    print("- No retraining, recalibration, or threshold optimization was performed.")


if __name__ == "__main__":
    main()
