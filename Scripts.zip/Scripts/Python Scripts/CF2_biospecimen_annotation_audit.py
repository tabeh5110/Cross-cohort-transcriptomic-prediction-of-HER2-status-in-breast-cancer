from __future__ import annotations

"""
CF2 - TCGA-BRCA Biospecimen and Annotation Quality Audit

Purpose
-------
Interrogate official GDC metadata for the 27 duplicate-review records identified
by CF1, without downloading RNA-seq expression files and without selecting or
removing any sample.

Inputs
------
results/CF1_duplicate_resolution_audit/CF1_duplicate_review_table.tsv

Outputs
-------
results/CF2_biospecimen_annotation_audit/
    CF2_case_biospecimen_raw.json
    CF2_annotations_raw.json
    CF2_biospecimen_aliquot_table.tsv
    CF2_annotations.tsv
    CF2_duplicate_qc_review.tsv
    CF2_unmatched_cf1_records.tsv
    CF2_annotation_category_summary.tsv
    CF2_summary.tsv
    CF2_provenance.tsv

logs/
    CF2_biospecimen_annotation_audit.log

Important
---------
- Uses only GDC metadata endpoints (cases, annotations, status).
- Does NOT download RNA-seq expression files.
- Does NOT remove or choose samples.
- Network requests use retry/backoff and extended timeouts.
"""

import hashlib
import json
import logging
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# ============================================================
# 0. Configuration
# ============================================================

CF_ID = "CF2"
SCRIPT_NAME = "CF2_biospecimen_annotation_audit.py"
SCRIPT_VERSION = "1.0.0"
PROJECT_ID = "TCGA-BRCA"
REFERENCE_GENOME = "GRCh38/hg38"
GDC_DATA_RELEASE = "46.0"

GDC_BASE_URL = "https://api.gdc.cancer.gov"
GDC_STATUS_URL = f"{GDC_BASE_URL}/status"
GDC_CASES_URL = f"{GDC_BASE_URL}/cases"
GDC_ANNOTATIONS_URL = f"{GDC_BASE_URL}/annotations"

INPUT_FILE = Path(
    "results/CF1_duplicate_resolution_audit/CF1_duplicate_review_table.tsv"
)

OUTPUT_DIR = Path("results/CF2_biospecimen_annotation_audit")
LOG_DIR = Path("logs")
LOG_FILE = LOG_DIR / "CF2_biospecimen_annotation_audit.log"

EXPECTED_CF1_RECORDS = 27


# ============================================================
# 1. Utility functions
# ============================================================


def configure_logging() -> logging.Logger:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger(CF_ID)
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    formatter = logging.Formatter("%(message)s")

    file_handler = logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8")
    file_handler.setFormatter(formatter)

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    return logger


def md5_file(path: Path) -> str:
    digest = hashlib.md5()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_session() -> requests.Session:
    """Create a resilient HTTP session for temporary GDC/network failures."""
    retry = Retry(
        total=6,
        connect=6,
        read=6,
        status=6,
        backoff_factor=2.0,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset({"GET"}),
        raise_on_status=False,
    )

    adapter = HTTPAdapter(max_retries=retry)
    session = requests.Session()
    session.mount("https://", adapter)
    session.headers.update(
        {
            "Accept": "application/json",
            "User-Agent": "TCGA-BRCA-Research-CF2/1.0",
        }
    )
    return session


def gdc_get_json(
    session: requests.Session,
    url: str,
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """GET JSON from GDC with long read timeout and clear error messages."""
    response = session.get(
        url,
        params=params,
        timeout=(20, 180),
    )

    if not response.ok:
        preview = response.text[:1000]
        raise RuntimeError(
            f"GDC request failed: HTTP {response.status_code}\n"
            f"URL: {response.url}\n"
            f"Response preview: {preview}"
        )

    try:
        return response.json()
    except ValueError as exc:
        raise RuntimeError(
            f"GDC returned non-JSON content for URL: {response.url}"
        ) from exc


def write_json(data: Any, path: Path) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)


def scalar(value: Any) -> Any:
    """Return values suitable for a flat TSV cell."""
    if value is None:
        return pd.NA
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return value


def annotation_signature(annotation: dict[str, Any]) -> str:
    fields = [
        annotation.get("entity_type"),
        annotation.get("category"),
        annotation.get("classification"),
        annotation.get("status"),
        annotation.get("notes"),
    ]
    return " | ".join(str(x) for x in fields if x not in (None, ""))


def collapse_annotations(items: Iterable[dict[str, Any]]) -> str:
    signatures = sorted(
        {
            annotation_signature(item)
            for item in items
            if annotation_signature(item)
        }
    )
    return " || ".join(signatures)


def numeric_values(slides: list[dict[str, Any]], field: str) -> list[float]:
    values: list[float] = []
    for slide in slides:
        value = slide.get(field)
        if value is None:
            continue
        try:
            values.append(float(value))
        except (TypeError, ValueError):
            continue
    return values


def max_or_na(values: list[float]) -> Any:
    return max(values) if values else pd.NA


def median_or_na(values: list[float]) -> Any:
    if not values:
        return pd.NA
    return float(pd.Series(values).median())


# ============================================================
# 2. Flatten nested GDC biospecimen response
# ============================================================


def flatten_biospecimen_cases(case_hits: list[dict[str, Any]]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []

    for case in case_hits:
        case_annotations = case.get("annotations") or []

        for sample in case.get("samples") or []:
            sample_annotations = sample.get("annotations") or []

            for portion in sample.get("portions") or []:
                portion_annotations = portion.get("annotations") or []
                slides = portion.get("slides") or []

                tumor_cells = numeric_values(slides, "percent_tumor_cells")
                tumor_nuclei = numeric_values(slides, "percent_tumor_nuclei")
                normal_cells = numeric_values(slides, "percent_normal_cells")
                necrosis = numeric_values(slides, "percent_necrosis")
                stromal_cells = numeric_values(slides, "percent_stromal_cells")

                for analyte in portion.get("analytes") or []:
                    analyte_annotations = analyte.get("annotations") or []

                    for aliquot in analyte.get("aliquots") or []:
                        aliquot_annotations = aliquot.get("annotations") or []

                        rows.append(
                            {
                                "patient_id": case.get("submitter_id"),
                                "case_uuid": case.get("case_id") or case.get("id"),
                                "sample_id": sample.get("submitter_id"),
                                "sample_uuid": sample.get("sample_id"),
                                "sample_type": sample.get("sample_type"),
                                "specimen_type": sample.get("specimen_type"),
                                "tumor_descriptor": sample.get("tumor_descriptor"),
                                "tissue_type": sample.get("tissue_type"),
                                "sample_ordinal": sample.get("sample_ordinal"),
                                "sample_initial_weight": sample.get("initial_weight"),
                                "sample_current_weight": sample.get("current_weight"),
                                "sample_preservation_method": sample.get("preservation_method"),
                                "sample_freezing_method": sample.get("freezing_method"),
                                "time_excision_to_freezing": sample.get(
                                    "time_between_excision_and_freezing"
                                ),
                                "time_clamping_to_freezing": sample.get(
                                    "time_between_clamping_and_freezing"
                                ),
                                "portion_id": portion.get("submitter_id"),
                                "portion_uuid": portion.get("portion_id"),
                                "portion_number": portion.get("portion_number"),
                                "portion_weight": portion.get("weight"),
                                "portion_is_ffpe": portion.get("is_ffpe"),
                                "analyte_id": analyte.get("submitter_id"),
                                "analyte_uuid": analyte.get("analyte_id"),
                                "analyte_type": analyte.get("analyte_type"),
                                "a260_a280_ratio": analyte.get("a260_a280_ratio"),
                                "rna_integrity_number": analyte.get(
                                    "rna_integrity_number"
                                ),
                                "ribosomal_rna_28s_18s_ratio": analyte.get(
                                    "ribosomal_rna_28s_18s_ratio"
                                ),
                                "analyte_concentration": analyte.get("concentration"),
                                "analyte_amount": analyte.get("amount"),
                                "analyte_quantity": analyte.get("analyte_quantity"),
                                "analyte_volume": analyte.get("analyte_volume"),
                                "normal_tumor_genotype_snp_match": analyte.get(
                                    "normal_tumor_genotype_snp_match"
                                ),
                                "aliquot_barcode": aliquot.get("submitter_id"),
                                "aliquot_uuid": aliquot.get("aliquot_id"),
                                "aliquot_analyte_type": aliquot.get("analyte_type"),
                                "aliquot_concentration": aliquot.get("concentration"),
                                "aliquot_amount": aliquot.get("amount"),
                                "aliquot_quantity": aliquot.get("aliquot_quantity"),
                                "aliquot_volume": aliquot.get("aliquot_volume"),
                                "aliquot_source_center": aliquot.get("source_center"),
                                "aliquot_state": aliquot.get("state"),
                                "slide_count_for_portion": len(slides),
                                "max_percent_tumor_cells": max_or_na(tumor_cells),
                                "median_percent_tumor_cells": median_or_na(tumor_cells),
                                "max_percent_tumor_nuclei": max_or_na(tumor_nuclei),
                                "median_percent_tumor_nuclei": median_or_na(tumor_nuclei),
                                "min_percent_normal_cells": (
                                    min(normal_cells) if normal_cells else pd.NA
                                ),
                                "median_percent_normal_cells": median_or_na(normal_cells),
                                "min_percent_necrosis": (
                                    min(necrosis) if necrosis else pd.NA
                                ),
                                "median_percent_necrosis": median_or_na(necrosis),
                                "median_percent_stromal_cells": median_or_na(
                                    stromal_cells
                                ),
                                "case_annotation_count": len(case_annotations),
                                "sample_annotation_count": len(sample_annotations),
                                "portion_annotation_count": len(portion_annotations),
                                "analyte_annotation_count": len(analyte_annotations),
                                "aliquot_annotation_count": len(aliquot_annotations),
                                "case_annotations": collapse_annotations(case_annotations),
                                "sample_annotations": collapse_annotations(
                                    sample_annotations
                                ),
                                "portion_annotations": collapse_annotations(
                                    portion_annotations
                                ),
                                "analyte_annotations": collapse_annotations(
                                    analyte_annotations
                                ),
                                "aliquot_annotations": collapse_annotations(
                                    aliquot_annotations
                                ),
                            }
                        )

    return pd.DataFrame(rows)


def annotations_to_table(annotation_hits: list[dict[str, Any]]) -> pd.DataFrame:
    columns = [
        "annotation_id",
        "case_id",
        "case_submitter_id",
        "entity_id",
        "entity_submitter_id",
        "entity_type",
        "category",
        "classification",
        "status",
        "notes",
        "state",
        "submitter_id",
        "created_datetime",
        "updated_datetime",
    ]

    rows = []
    for hit in annotation_hits:
        row = {column: scalar(hit.get(column)) for column in columns}
        rows.append(row)

    return pd.DataFrame(rows, columns=columns)


def related_annotation_summary(
    row: pd.Series,
    annotation_df: pd.DataFrame,
) -> pd.Series:
    if annotation_df.empty:
        return pd.Series(
            {
                "direct_case_annotations": 0,
                "direct_sample_annotations": 0,
                "direct_aliquot_annotations": 0,
                "direct_file_annotations": 0,
                "direct_annotation_total": 0,
                "direct_annotation_categories": "",
                "direct_annotation_details": "",
            }
        )

    patient_id = row.get("patient_id")
    sample_id = row.get("sample_id")
    aliquot_barcode = row.get("aliquot_barcode")
    file_id = row.get("file_id")

    case_mask = (
        annotation_df["entity_type"].astype(str).str.lower().eq("case")
        & annotation_df["case_submitter_id"].eq(patient_id)
    )

    sample_mask = annotation_df["entity_submitter_id"].eq(sample_id)
    aliquot_mask = annotation_df["entity_submitter_id"].eq(aliquot_barcode)
    file_mask = annotation_df["entity_id"].eq(file_id)

    related_mask = case_mask | sample_mask | aliquot_mask | file_mask
    related = annotation_df.loc[related_mask].copy()

    categories = sorted(
        {
            str(value)
            for value in related["category"].dropna().tolist()
            if str(value).strip()
        }
    )

    details = []
    for _, ann in related.iterrows():
        pieces = [
            ann.get("entity_type"),
            ann.get("category"),
            ann.get("classification"),
            ann.get("status"),
            ann.get("notes"),
        ]
        text = " | ".join(
            str(piece) for piece in pieces if pd.notna(piece) and str(piece).strip()
        )
        if text:
            details.append(text)

    details = sorted(set(details))

    return pd.Series(
        {
            "direct_case_annotations": int(case_mask.sum()),
            "direct_sample_annotations": int(sample_mask.sum()),
            "direct_aliquot_annotations": int(aliquot_mask.sum()),
            "direct_file_annotations": int(file_mask.sum()),
            "direct_annotation_total": int(related_mask.sum()),
            "direct_annotation_categories": " || ".join(categories),
            "direct_annotation_details": " || ".join(details),
        }
    )


# ============================================================
# 3. Main CF2 workflow
# ============================================================


def main() -> int:
    logger = configure_logging()

    logger.info("")
    logger.info("============================================================")
    logger.info(" CF2 - TCGA-BRCA BIOSPECIMEN + ANNOTATION QUALITY AUDIT")
    logger.info("============================================================")
    logger.info("")

    # --------------------------------------------------------
    # Step 1: Validate CF1 input
    # --------------------------------------------------------
    logger.info("[1/9] Validating CF1 duplicate-review input...")
    logger.info("")

    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"Required CF1 input not found: {INPUT_FILE}")

    input_md5 = md5_file(INPUT_FILE)
    cf1 = pd.read_csv(INPUT_FILE, sep="\t", dtype=str)

    required_columns = {
        "patient_id",
        "sample_id",
        "aliquot_barcode",
        "sample_type",
        "file_id",
        "file_name",
        "duplicate_reason",
    }
    missing = sorted(required_columns - set(cf1.columns))
    if missing:
        raise RuntimeError(
            "CF1 input is missing required columns: " + ", ".join(missing)
        )

    logger.info(f"CF1 records loaded: {len(cf1)}")
    logger.info(f"CF1 input MD5: {input_md5}")
    logger.info(f"Unique duplicate-review patients: {cf1['patient_id'].nunique()}")

    if len(cf1) != EXPECTED_CF1_RECORDS:
        logger.warning(
            f"WARNING: Expected {EXPECTED_CF1_RECORDS} CF1 review records, "
            f"but found {len(cf1)}."
        )

    patient_ids = sorted(cf1["patient_id"].dropna().unique().tolist())

    # --------------------------------------------------------
    # Step 2: Create resilient GDC session and capture status
    # --------------------------------------------------------
    logger.info("")
    logger.info("[2/9] Checking GDC API status...")
    logger.info("")

    session = build_session()
    status_json = gdc_get_json(session, GDC_STATUS_URL)

    logger.info("GDC API connection successful.")
    logger.info(f"GDC status payload: {json.dumps(status_json, sort_keys=True)}")

    # --------------------------------------------------------
    # Step 3: Query nested biospecimen metadata for 11 cases
    # --------------------------------------------------------
    logger.info("")
    logger.info("[3/9] Querying nested GDC biospecimen metadata...")
    logger.info("")

    case_filter = {
        "op": "in",
        "content": {
            "field": "submitter_id",
            "value": patient_ids,
        },
    }

    case_expand = ",".join(
        [
            "annotations",
            "samples",
            "samples.annotations",
            "samples.portions",
            "samples.portions.annotations",
            "samples.portions.analytes",
            "samples.portions.analytes.annotations",
            "samples.portions.analytes.aliquots",
            "samples.portions.analytes.aliquots.annotations",
            "samples.portions.analytes.aliquots.center",
            "samples.portions.slides",
            "samples.portions.slides.annotations",
        ]
    )

    case_params = {
        "filters": json.dumps(case_filter, separators=(",", ":")),
        "expand": case_expand,
        "size": 100,
        "pretty": "false",
    }

    case_json = gdc_get_json(session, GDC_CASES_URL, case_params)
    write_json(case_json, OUTPUT_DIR / "CF2_case_biospecimen_raw.json")

    case_hits = case_json.get("data", {}).get("hits", [])
    logger.info(f"GDC cases returned: {len(case_hits)}")

    returned_patients = {
        hit.get("submitter_id") for hit in case_hits if hit.get("submitter_id")
    }
    missing_patients = sorted(set(patient_ids) - returned_patients)
    if missing_patients:
        logger.warning(
            "WARNING: GDC case response did not include: " + ", ".join(missing_patients)
        )

    # --------------------------------------------------------
    # Step 4: Flatten biospecimen tree
    # --------------------------------------------------------
    logger.info("")
    logger.info("[4/9] Flattening sample/portion/analyte/aliquot metadata...")
    logger.info("")

    biospecimen_df = flatten_biospecimen_cases(case_hits)
    biospecimen_path = OUTPUT_DIR / "CF2_biospecimen_aliquot_table.tsv"
    biospecimen_df.to_csv(biospecimen_path, sep="\t", index=False)

    logger.info(f"Flattened biospecimen aliquot rows: {len(biospecimen_df)}")

    # --------------------------------------------------------
    # Step 5: Query all GDC annotations for the 11 cases
    # --------------------------------------------------------
    logger.info("")
    logger.info("[5/9] Querying GDC annotations for duplicate-review cases...")
    logger.info("")

    annotation_filter = {
        "op": "in",
        "content": {
            "field": "case_submitter_id",
            "value": patient_ids,
        },
    }

    annotation_fields = [
        "annotation_id",
        "case_id",
        "case_submitter_id",
        "entity_id",
        "entity_submitter_id",
        "entity_type",
        "category",
        "classification",
        "status",
        "notes",
        "state",
        "submitter_id",
        "created_datetime",
        "updated_datetime",
    ]

    annotation_params = {
        "filters": json.dumps(annotation_filter, separators=(",", ":")),
        "fields": ",".join(annotation_fields),
        "size": 1000,
        "pretty": "false",
    }

    annotation_json = gdc_get_json(
        session,
        GDC_ANNOTATIONS_URL,
        annotation_params,
    )
    write_json(annotation_json, OUTPUT_DIR / "CF2_annotations_raw.json")

    annotation_hits = annotation_json.get("data", {}).get("hits", [])
    annotation_df = annotations_to_table(annotation_hits)
    annotation_df.to_csv(
        OUTPUT_DIR / "CF2_annotations.tsv",
        sep="\t",
        index=False,
    )

    logger.info(f"GDC annotations returned: {len(annotation_df)}")

    # --------------------------------------------------------
    # Step 6: Match CF1 records to biospecimen aliquots
    # --------------------------------------------------------
    logger.info("")
    logger.info("[6/9] Matching the 27 CF1 records to GDC biospecimens...")
    logger.info("")

    if biospecimen_df.empty:
        merged = cf1.copy()
        merged["biospecimen_match"] = False
    else:
        # An aliquot submitter barcode should uniquely identify the nested aliquot.
        duplicate_aliquot_rows = biospecimen_df[
            biospecimen_df.duplicated("aliquot_barcode", keep=False)
        ]
        if not duplicate_aliquot_rows.empty:
            logger.warning(
                "WARNING: Nested GDC response contains repeated aliquot barcodes. "
                "All matches will be preserved for review."
            )

        merged = cf1.merge(
            biospecimen_df,
            on=["patient_id", "sample_id", "aliquot_barcode"],
            how="left",
            suffixes=("_cf1", "_gdc"),
            indicator=True,
        )
        merged["biospecimen_match"] = merged["_merge"].eq("both")
        merged = merged.drop(columns=["_merge"])

    matched_cf1_keys = set(
        merged.loc[merged["biospecimen_match"], "aliquot_barcode"].dropna()
    )
    expected_cf1_keys = set(cf1["aliquot_barcode"].dropna())
    unmatched_keys = sorted(expected_cf1_keys - matched_cf1_keys)

    logger.info(
        f"CF1 aliquot barcodes matched: "
        f"{len(expected_cf1_keys) - len(unmatched_keys)}/{len(expected_cf1_keys)}"
    )

    # --------------------------------------------------------
    # Step 7: Add direct annotation evidence to every CF1 record
    # --------------------------------------------------------
    logger.info("")
    logger.info("[7/9] Linking direct GDC annotations to CF1 records...")
    logger.info("")

    annotation_summary = merged.apply(
        lambda row: related_annotation_summary(row, annotation_df),
        axis=1,
    )
    review_df = pd.concat(
        [merged.reset_index(drop=True), annotation_summary.reset_index(drop=True)],
        axis=1,
    )

    # Availability flags are descriptive only; they are NOT selection rules.
    for source_col, flag_col in [
        ("rna_integrity_number", "has_rin"),
        ("a260_a280_ratio", "has_a260_a280"),
        ("max_percent_tumor_cells", "has_tumor_cell_percent"),
        ("max_percent_tumor_nuclei", "has_tumor_nuclei_percent"),
    ]:
        if source_col in review_df.columns:
            review_df[flag_col] = review_df[source_col].notna()
        else:
            review_df[flag_col] = False

    review_df["has_any_direct_annotation"] = (
        pd.to_numeric(review_df["direct_annotation_total"], errors="coerce")
        .fillna(0)
        .gt(0)
    )

    # No keep/drop recommendation is made in CF2.
    review_df["CF2_selection_status"] = "REVIEW_ONLY_NO_SELECTION"

    review_df.to_csv(
        OUTPUT_DIR / "CF2_duplicate_qc_review.tsv",
        sep="\t",
        index=False,
    )

    unmatched_df = review_df.loc[~review_df["biospecimen_match"]].copy()
    unmatched_df.to_csv(
        OUTPUT_DIR / "CF2_unmatched_cf1_records.tsv",
        sep="\t",
        index=False,
    )

    # --------------------------------------------------------
    # Step 8: Summaries and provenance
    # --------------------------------------------------------
    logger.info("")
    logger.info("[8/9] Building CF2 summary and provenance...")
    logger.info("")

    if annotation_df.empty:
        annotation_category_summary = pd.DataFrame(
            columns=["category", "classification", "status", "n_annotations"]
        )
    else:
        annotation_category_summary = (
            annotation_df.groupby(
                ["category", "classification", "status"],
                dropna=False,
            )
            .size()
            .reset_index(name="n_annotations")
            .sort_values("n_annotations", ascending=False)
        )

    annotation_category_summary.to_csv(
        OUTPUT_DIR / "CF2_annotation_category_summary.tsv",
        sep="\t",
        index=False,
    )

    matched_count = int(review_df["biospecimen_match"].sum())
    records_with_annotations = int(review_df["has_any_direct_annotation"].sum())
    records_with_rin = int(review_df["has_rin"].sum())
    records_with_a260 = int(review_df["has_a260_a280"].sum())
    records_with_tumor_cells = int(review_df["has_tumor_cell_percent"].sum())
    records_with_tumor_nuclei = int(review_df["has_tumor_nuclei_percent"].sum())

    summary_rows = [
        ("CF1 duplicate-review records", len(cf1)),
        ("Unique duplicate-review patients", len(patient_ids)),
        ("GDC cases returned", len(case_hits)),
        ("Flattened biospecimen aliquot rows", len(biospecimen_df)),
        ("CF1 records matched to GDC biospecimens", matched_count),
        ("CF1 records unmatched", len(review_df) - matched_count),
        ("GDC annotations returned for 11 cases", len(annotation_df)),
        ("CF1 records with direct annotation evidence", records_with_annotations),
        ("CF1 records with RIN available", records_with_rin),
        ("CF1 records with A260/A280 available", records_with_a260),
        ("CF1 records with tumor-cell percentage available", records_with_tumor_cells),
        ("CF1 records with tumor-nuclei percentage available", records_with_tumor_nuclei),
    ]

    summary_df = pd.DataFrame(summary_rows, columns=["metric", "value"])
    summary_df.to_csv(
        OUTPUT_DIR / "CF2_summary.tsv",
        sep="\t",
        index=False,
    )

    status_data = status_json.get("data", status_json)
    provenance_rows = [
        ("code_file", SCRIPT_NAME),
        ("script_version", SCRIPT_VERSION),
        ("input_file", str(INPUT_FILE)),
        ("input_md5", input_md5),
        ("input_records", len(cf1)),
        ("project", PROJECT_ID),
        ("reference_genome", REFERENCE_GENOME),
        ("gdc_data_release_target", GDC_DATA_RELEASE),
        ("gdc_api_base_url", GDC_BASE_URL),
        ("gdc_status", json.dumps(status_data, sort_keys=True)),
        ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
        ("python_version", sys.version.replace("\n", " ")),
        ("platform", platform.platform()),
        ("pandas_version", pd.__version__),
        ("requests_version", requests.__version__),
    ]

    provenance_df = pd.DataFrame(provenance_rows, columns=["field", "value"])
    provenance_df.to_csv(
        OUTPUT_DIR / "CF2_provenance.tsv",
        sep="\t",
        index=False,
    )

    # --------------------------------------------------------
    # Step 9: Final report
    # --------------------------------------------------------
    logger.info("")
    logger.info("[9/9] CF2 audit complete.")
    logger.info("")
    logger.info("============================================================")
    logger.info(" CF2 COMPLETE")
    logger.info("============================================================")
    logger.info("")

    for metric, value in summary_rows:
        logger.info(f"{metric}: {value}")

    logger.info("")
    logger.info(f"Results saved to: {OUTPUT_DIR}")
    logger.info("")
    logger.info("CF2 generated:")
    logger.info("  CF2_case_biospecimen_raw.json")
    logger.info("  CF2_annotations_raw.json")
    logger.info("  CF2_biospecimen_aliquot_table.tsv")
    logger.info("  CF2_annotations.tsv")
    logger.info("  CF2_duplicate_qc_review.tsv")
    logger.info("  CF2_unmatched_cf1_records.tsv")
    logger.info("  CF2_annotation_category_summary.tsv")
    logger.info("  CF2_summary.tsv")
    logger.info("  CF2_provenance.tsv")
    logger.info("  CF2_biospecimen_annotation_audit.log")
    logger.info("")
    logger.info("IMPORTANT:")
    logger.info("No RNA-seq expression files were downloaded.")
    logger.info("No duplicate sample was selected or removed.")
    logger.info("CF2 only adds official GDC biospecimen/QC/annotation evidence.")

    if unmatched_keys:
        logger.info("")
        logger.warning("WARNING: Some CF1 aliquots were not matched:")
        for barcode in unmatched_keys:
            logger.warning(f"  {barcode}")
        logger.warning(
            "Do not proceed to cohort selection until unmatched records are resolved."
        )
        return 2

    logger.info("")
    logger.info("All CF1 duplicate-review aliquots matched the GDC biospecimen tree.")
    logger.info("CF2 is ready for scientific interpretation before CF3 selection.")
    logger.info("============================================================")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\nCF2 interrupted by user.", file=sys.stderr)
        raise SystemExit(130)
    except Exception as exc:
        print("\n============================================================", file=sys.stderr)
        print(" CF2 FAILED", file=sys.stderr)
        print("============================================================", file=sys.stderr)
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        print(
            "No cohort-selection decision should be made from an incomplete CF2 run.",
            file=sys.stderr,
        )
        raise