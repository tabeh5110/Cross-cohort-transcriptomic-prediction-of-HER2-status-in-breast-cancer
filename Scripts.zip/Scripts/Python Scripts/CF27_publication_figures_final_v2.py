"""
============================================================
CF27 v2 - PUBLICATION FIGURE REFINEMENT
============================================================

Purpose:
    Create professional manuscript-style figures.

Changes:
    - Redesigned Figure 1 workflow
    - Redesigned Figure 2 leakage-control schematic
    - Keeps combined figures
    - Also exports individual panel figures
    - Adds consistent publication formatting

NO ML
NO RETRAINING
NO DATA CHANGES

============================================================
"""

import os
import matplotlib.pyplot as plt
from PIL import Image


BASE = r"D:\Masters\Research\TCGA_BRCA"

FIG_DIR = os.path.join(
    BASE,
    "results",
    "CF25_manuscript_package",
    "FIGURES_FINAL"
)

CF26_DIR = os.path.join(
    BASE,
    "results",
    "CF26_publication_enhancement"
)

OUT = os.path.join(
    BASE,
    "results",
    "FINAL_PUBLICATION_FIGURES_V2"
)

os.makedirs(OUT, exist_ok=True)


def load_image(folder, filename):

    path = os.path.join(folder, filename)

    if os.path.exists(path):
        return Image.open(path).convert("RGB")

    print("Missing:", path)
    return None



def save_panel(images, titles, filename, cols=2):

    valid=[]

    for img,title in zip(images,titles):
        if img:
            valid.append((img,title))


    if not valid:
        return


    rows=(len(valid)+cols-1)//cols

    fig,axes=plt.subplots(
        rows,
        cols,
        figsize=(14,6*rows)
    )

    if rows==1:
        axes=[axes] if cols==1 else axes

    else:
        axes=axes.flatten()


    for i,(img,title) in enumerate(valid):

        axes[i].imshow(img)
        axes[i].set_title(
            title,
            fontsize=13,
            weight="bold"
        )
        axes[i].axis("off")


    for ax in axes[len(valid):]:
        ax.axis("off")


    plt.tight_layout()

    plt.savefig(
        os.path.join(OUT,filename),
        dpi=600,
        bbox_inches="tight"
    )

    plt.close()



def create_workflow():

    fig,ax=plt.subplots(
        figsize=(8,12)
    )

    ax.axis("off")


    boxes=[
        ("TCGA-BRCA\nDiscovery Cohort",0.92),
        ("RNA preprocessing\nQC + normalization",0.80),
        ("Biological analysis\nDEG + pathways",0.68),
        ("Machine learning\nNested CV",0.56),
        ("Feature selection\nModel comparison",0.44),
        ("Elastic-Net\nFinal model lock",0.32),
        ("SCAN-B\nExternal validation",0.20),
        ("APOLLO\nMulti-omics confirmation",0.08)
    ]


    for text,y in boxes:

        ax.text(
            0.5,
            y,
            text,
            ha="center",
            va="center",
            fontsize=13,
            weight="bold",
            bbox=dict(
                boxstyle="round,pad=0.8",
                linewidth=1.5
            )
        )


    for i in range(len(boxes)-1):

        ax.annotate(
            "",
            xy=(0.5,boxes[i+1][1]+0.05),
            xytext=(0.5,boxes[i][1]-0.05),
            arrowprops=dict(
                arrowstyle="->",
                linewidth=1.5
            )
        )


    ax.text(
        0.5,
        0.98,
        "Figure 1. Integrated computational workflow",
        ha="center",
        fontsize=15,
        weight="bold"
    )


    plt.savefig(
        os.path.join(
            OUT,
            "Figure1_Workflow_v2.png"
        ),
        dpi=600,
        bbox_inches="tight"
    )

    plt.close()



def create_leakage_control():

    fig,ax=plt.subplots(
        figsize=(10,8)
    )

    ax.axis("off")


    dev=[
        "TCGA-BRCA",
        "Preprocessing",
        "Nested CV\nFeature selection",
        "Model training",
        "Elastic-Net lock"
    ]


    test=[
        "SCAN-B\nExternal validation",
        "APOLLO\nMulti-omics confirmation"
    ]


    y=0.85

    for item in dev:

        ax.text(
            0.35,
            y,
            item,
            ha="center",
            fontsize=12,
            weight="bold",
            bbox=dict(
                boxstyle="round"
            )
        )

        y-=0.15


    y=0.55

    for item in test:

        ax.text(
            0.75,
            y,
            item,
            ha="center",
            fontsize=12,
            weight="bold",
            bbox=dict(
                boxstyle="round"
            )
        )

        y-=0.25


    ax.annotate(
        "",
        xy=(0.75,0.35),
        xytext=(0.45,0.25),
        arrowprops=dict(
            arrowstyle="->",
            linewidth=2
        )
    )


    ax.text(
        0.55,
        0.15,
        "External datasets accessed only after model locking\n(NO retraining / NO feature optimization)",
        ha="center",
        fontsize=11
    )


    ax.text(
        0.5,
        0.97,
        "Figure 2. Leakage-controlled machine learning design",
        ha="center",
        fontsize=15,
        weight="bold"
    )


    plt.savefig(
        os.path.join(
            OUT,
            "Figure2_ML_Leakage_Control_v2.png"
        ),
        dpi=600,
        bbox_inches="tight"
    )

    plt.close()



def main():

    print("""
============================================================
CF27 v2 - PUBLICATION FIGURE REFINEMENT
============================================================
""")


    create_workflow()

    create_leakage_control()


    # Individual figures
    individual = {

        "Figure3_AUROC_Model_Comparison.png":
        "CF17_AUROC_model_comparison.png",

        "Figure3_PR_AUC_Model_Comparison.png":
        "CF17_PR_AUC_model_comparison.png",

        "Figure4_SCANB_ROC.png":
        "CF19_ROC.png",

        "Figure4_SCANB_PR.png":
        "CF19_PR_curve.png",

        "Figure5_Coefficients.png":
        "CF18_final_ElasticNet_coefficients.png",

        "Figure5_Gene_Importance.png":
        "CF20_gene_importance.png",

        "Figure6_APOLLO.png":
        "CF21v3_evidence_barplot.png"

    }


    for out,name in individual.items():

        img=load_image(
            FIG_DIR,
            name
        )

        if img:
            img.save(
                os.path.join(OUT,out),
                dpi=(600,600)
            )


    # Combined figures

    save_panel(
        [
            load_image(FIG_DIR,"CF17_AUROC_model_comparison.png"),
            load_image(FIG_DIR,"CF17_PR_AUC_model_comparison.png"),
            load_image(CF26_DIR,"CF26_SCANB_calibration_curve.png")
        ],
        [
            "AUROC comparison",
            "PR-AUC comparison",
            "Calibration"
        ],
        "Figure3_Model_Performance_v2.png",
        cols=3
    )


    save_panel(
        [
            load_image(FIG_DIR,"CF19_ROC.png"),
            load_image(FIG_DIR,"CF19_PR_curve.png"),
            load_image(CF26_DIR,"CF26_threshold_curve.png")
        ],
        [
            "SCAN-B ROC",
            "SCAN-B PR curve",
            "Threshold analysis"
        ],
        "Figure4_SCANB_Validation_v2.png",
        cols=3
    )


    save_panel(
        [
            load_image(FIG_DIR,"CF18_final_ElasticNet_coefficients.png"),
            load_image(FIG_DIR,"CF20_gene_importance.png"),
            load_image(FIG_DIR,"CF22_Hallmark_Pathways.png"),
            load_image(FIG_DIR,"CF22_Reactome_Pathways.png")
        ],
        [
            "Elastic-Net coefficients",
            "Gene importance",
            "Hallmark pathways",
            "Reactome pathways"
        ],
        "Figure5_Gene_Signature_Biology_v2.png",
        cols=2
    )


    img=load_image(
        FIG_DIR,
        "CF21v3_evidence_barplot.png"
    )

    if img:
        img.save(
            os.path.join(
                OUT,
                "Figure6_APOLLO_Multiomics_v2.png"
            ),
            dpi=(600,600)
        )


    print("""
============================================================
CF27 v2 COMPLETE
============================================================

Output:
FINAL_PUBLICATION_FIGURES_V2

============================================================
""")


if __name__=="__main__":
    main()
