#!/usr/bin/env python
"""
CF14 - HARD MANUAL PRE-ML AUDIT

Purpose
-------
Create the final pre-ML evidence package without training any model.

This script:
1) verifies CF13 is frozen with PASS;
2) constructs the exact TCGA Primary Tumor ML sample manifest;
3) validates SCAN-B external sample/label alignment;
4) audits ER, PR, HER2 and TNBC class balance in discovery/external cohorts;
5) verifies the leakage-safe TCGA∩SCAN-B feature universe;
6) writes a protocol draft and leakage checklist;
7) stops with AUDIT_COMPLETE_NOT_LOCKED.

NO ML is performed and no final endpoint is auto-selected.
The user must manually review CF14 output before the protocol is locked.
"""

from __future__ import annotations

import gzip
import hashlib
import logging
import platform
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


ROOT = Path.cwd()

# ------------------------------
# Upstream inputs
# ------------------------------
CF13_RESULTS = ROOT / "results" / "CF13_cross_cohort_harmonization"
CF13_SUMMARY = CF13_RESULTS / "CF13_summary.tsv"
CF13_ENDPOINT_AUDIT = CF13_RESULTS / "CF13_endpoint_coverage_audit.tsv"
CF13_SCALE_PROTOCOL = CF13_RESULTS / "CF13_expression_scale_protocol.tsv"
CF13_LEAKAGE_RULES = CF13_RESULTS / "CF13_leakage_prevention_rules.tsv"

CROSS_DIR = ROOT / "data" / "processed" / "cross_cohort"
CF13_CROSSWALK = CROSS_DIR / "CF13_transcriptomic_feature_crosswalk.tsv"
CF13_TCGA_ENDPOINT = CROSS_DIR / "CF13_TCGA_endpoint_manifest.tsv"
CF13_SCANB_ENDPOINT = CROSS_DIR / "CF13_SCANB_endpoint_manifest.tsv"

TCGA_DIR = ROOT / "data" / "processed" / "tcga_brca" / "expression"
TCGA_MANIFEST = TCGA_DIR / "CF6_final_sample_manifest.tsv"
TCGA_TPM = TCGA_DIR / "CF6_tpm.tsv.gz"

SCANB_EXPRESSION = ROOT / "data" / "processed" / "scanb" / "CF11_SCANB_primary_expression.tsv.gz"

CF8_COHORT = ROOT / "data" / "processed" / "tcga_brca" / "qc" / "CF8_final_analytical_cohort.tsv"

# ------------------------------
# Outputs
# ------------------------------
RESULTS = ROOT / "results" / "CF14_pre_ml_manual_audit"
PROCESSED = ROOT / "data" / "processed" / "ml_ready"
LOG_DIR = ROOT / "logs"
LOG_FILE = LOG_DIR / "CF14_pre_ml_manual_audit.log"

TCGA_ML_MANIFEST = PROCESSED / "CF14_TCGA_ML_sample_manifest_DRAFT.tsv"
SCANB_ML_MANIFEST = PROCESSED / "CF14_SCANB_external_sample_manifest_DRAFT.tsv"

EXPECTED_TCGA_TUMOR_PATIENTS = 1094
EXPECTED_SCANB_PRIMARY = 3273
EXPECTED_EXTERNAL_FEATURE_UNIVERSE = 22106


def setup_logging() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    PROCESSED.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def norm_col(x: str) -> str:
    s = str(x).strip().lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    return s.strip("_")


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(block_size), b""):
            h.update(block)
    return h.hexdigest()


def read_metric_value(path: Path, metric: str) -> str:
    df = pd.read_csv(path, sep="\t", dtype=str)
    if not {"metric", "value"}.issubset(df.columns):
        raise RuntimeError(f"Expected metric/value columns in {path}")
    d = dict(zip(df["metric"], df["value"]))
    return str(d.get(metric, ""))


def gzip_header(path: Path) -> List[str]:
    return list(pd.read_csv(path, sep="\t", compression="gzip", nrows=0).columns)


def find_col(df: pd.DataFrame, names: Sequence[str]) -> Optional[str]:
    norm_to_raw = {norm_col(c): c for c in df.columns}
    for name in names:
        if norm_col(name) in norm_to_raw:
            return norm_to_raw[norm_col(name)]
    return None


def resolve_tcga_manifest_columns(
    manifest: pd.DataFrame,
    expression_sample_ids: set,
) -> Tuple[str, str, str]:
    """
    Resolve patient ID, sample ID and sample type in CF6 manifest.

    Sample-ID selection is evidence-based: among plausible columns, choose the
    one with the largest exact overlap with the frozen TCGA TPM header.
    """
    patient_candidates = [
        "patient_id", "case_submitter_id", "case_id", "patient_barcode",
    ]
    type_candidates = [
        "sample_type", "gdc_sample_type",
    ]

    patient_col = find_col(manifest, patient_candidates)
    sample_type_col = find_col(manifest, type_candidates)

    if patient_col is None:
        raise RuntimeError(
            f"Could not resolve TCGA patient ID column. Columns={list(manifest.columns)}"
        )
    if sample_type_col is None:
        raise RuntimeError(
            f"Could not resolve TCGA sample type column. Columns={list(manifest.columns)}"
        )

    plausible_sample_cols = []
    for c in manifest.columns:
        n = norm_col(c)
        if any(tok in n for tok in ["sample", "submitter", "barcode"]):
            if c != patient_col and c != sample_type_col:
                plausible_sample_cols.append(c)

    scored = []
    for c in plausible_sample_cols:
        vals = set(manifest[c].dropna().astype(str))
        overlap = len(vals & expression_sample_ids)
        scored.append((overlap, c))

    scored.sort(reverse=True)

    if not scored or scored[0][0] == 0:
        raise RuntimeError(
            "Could not identify a CF6 sample-ID column matching TCGA TPM columns."
        )

    best_overlap, sample_col = scored[0]
    return patient_col, sample_col, sample_type_col


def endpoint_balance(
    df: pd.DataFrame,
    cohort: str,
    endpoint: str,
) -> Dict[str, object]:
    s = df[endpoint]

    if endpoint == "TNBC":
        positive_label = "TNBC"
        negative_label = "NON_TNBC"
    else:
        positive_label = "POSITIVE"
        negative_label = "NEGATIVE"

    known = s.isin([positive_label, negative_label])
    pos = int((s == positive_label).sum())
    neg = int((s == negative_label).sum())
    n = pos + neg

    return {
        "cohort": cohort,
        "endpoint": endpoint,
        "known_n": n,
        "positive_n": pos,
        "negative_n": neg,
        "positive_fraction": round(pos / n, 4) if n else np.nan,
        "minority_n": min(pos, neg),
        "minority_fraction": round(min(pos, neg) / n, 4) if n else np.nan,
        "missing_n": int(len(df) - n),
        "coverage_fraction": round(n / len(df), 4) if len(df) else np.nan,
    }


def main() -> None:
    setup_logging()
    start = time.time()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF14 - HARD MANUAL PRE-ML AUDIT")
    logging.info("============================================================")
    logging.info("")
    logging.info("Estimated runtime: ~1-5 minutes")
    logging.info("Likely bottleneck: reading headers and compact audit tables")
    logging.info("Long silent periods are NOT expected.")
    logging.info("NO ML WILL RUN.")
    logging.info("")

    required = [
        CF13_SUMMARY,
        CF13_ENDPOINT_AUDIT,
        CF13_SCALE_PROTOCOL,
        CF13_LEAKAGE_RULES,
        CF13_CROSSWALK,
        CF13_TCGA_ENDPOINT,
        CF13_SCANB_ENDPOINT,
        TCGA_MANIFEST,
        TCGA_TPM,
        SCANB_EXPRESSION,
    ]
    for p in required:
        if not p.exists():
            raise FileNotFoundError(f"Required CF14 input missing: {p}")

    # --------------------------------------------------------
    # 1. Freeze upstream gate
    # --------------------------------------------------------
    logging.info("[1/7] Validating CF13 gate and upstream evidence...")
    logging.info("")

    cf13_gate = read_metric_value(CF13_SUMMARY, "CF13 stage gate")
    if not cf13_gate.upper().startswith("PASS"):
        raise RuntimeError(f"CF13 gate is not PASS: {cf13_gate}")

    common_features_reported = int(
        float(
            read_metric_value(
                CF13_SUMMARY,
                "TCGA-SCANB common one-to-one symbols",
            )
        )
    )
    apollo_overlap = int(
        float(
            read_metric_value(
                CF13_SUMMARY,
                "APOLLO samples present in case+RNA+protein+phospho",
            )
        )
    )

    if common_features_reported != EXPECTED_EXTERNAL_FEATURE_UNIVERSE:
        raise RuntimeError(
            f"CF13 common feature universe={common_features_reported}; "
            f"expected {EXPECTED_EXTERNAL_FEATURE_UNIVERSE}."
        )
    if apollo_overlap != 68:
        raise RuntimeError(
            f"CF13 APOLLO complete multi-omics overlap={apollo_overlap}; expected 68."
        )

    logging.info("CF13 stage gate: PASS")
    logging.info(f"TCGA-SCANB common genes: {common_features_reported}")
    logging.info(f"APOLLO complete multi-omics cases: {apollo_overlap}")
    logging.info("")

    # --------------------------------------------------------
    # 2. Build exact TCGA tumor ML sample manifest
    # --------------------------------------------------------
    logging.info("[2/7] Building exact TCGA Primary Tumor ML sample manifest...")
    logging.info("")

    tcga_manifest = pd.read_csv(TCGA_MANIFEST, sep="\t", dtype=str)
    tcga_header = gzip_header(TCGA_TPM)
    tcga_expr_samples = set(map(str, tcga_header[1:]))

    patient_col, sample_col, sample_type_col = resolve_tcga_manifest_columns(
        tcga_manifest,
        tcga_expr_samples,
    )

    tumor_mask = (
        tcga_manifest[sample_type_col]
        .astype(str)
        .str.strip()
        .str.lower()
        .eq("primary tumor")
    )
    tumor_manifest = tcga_manifest.loc[tumor_mask].copy()

    if len(tumor_manifest) != EXPECTED_TCGA_TUMOR_PATIENTS:
        raise RuntimeError(
            f"TCGA tumor rows={len(tumor_manifest)}; "
            f"expected {EXPECTED_TCGA_TUMOR_PATIENTS}."
        )

    if tumor_manifest[patient_col].duplicated().any():
        raise RuntimeError("TCGA tumor manifest is not one-row-per-patient.")
    if tumor_manifest[sample_col].duplicated().any():
        raise RuntimeError("TCGA tumor manifest contains duplicate expression sample IDs.")

    missing_expr = sorted(
        set(tumor_manifest[sample_col].astype(str)) - tcga_expr_samples
    )
    if missing_expr:
        raise RuntimeError(
            f"{len(missing_expr)} TCGA tumor sample IDs are absent from TPM header."
        )

    tcga_ep = pd.read_csv(CF13_TCGA_ENDPOINT, sep="\t", dtype=str)
    if "source_id" not in tcga_ep.columns:
        raise RuntimeError("CF13 TCGA endpoint manifest lacks source_id.")
    if tcga_ep["source_id"].duplicated().any():
        raise RuntimeError("CF13 TCGA endpoint manifest has duplicate source_id values.")

    tumor_core = tumor_manifest[[patient_col, sample_col, sample_type_col]].copy()
    tumor_core = tumor_core.rename(
        columns={
            patient_col: "patient_id",
            sample_col: "expression_sample_id",
            sample_type_col: "sample_type",
        }
    )

    tcga_ml = tumor_core.merge(
        tcga_ep[
            ["source_id", "ER", "PR", "HER2", "TNBC"]
        ],
        left_on="patient_id",
        right_on="source_id",
        how="left",
        validate="one_to_one",
    ).drop(columns=["source_id"])

    if len(tcga_ml) != EXPECTED_TCGA_TUMOR_PATIENTS:
        raise RuntimeError("TCGA ML manifest changed row count after endpoint join.")

    if tcga_ml[["ER", "PR", "HER2", "TNBC"]].isna().all(axis=1).any():
        logging.info(
            "NOTE: Some tumors have no classifiable receptor endpoint; "
            "they remain in the cohort manifest but will be excluded per endpoint."
        )

    tcga_ml.to_csv(TCGA_ML_MANIFEST, sep="\t", index=False)

    logging.info(f"TCGA discovery tumors: {len(tcga_ml)}")
    logging.info(f"TCGA sample-ID field: {sample_col}")
    logging.info(f"TCGA patient-ID field: {patient_col}")
    logging.info("Normal samples in ML manifest: 0")
    logging.info("")

    # --------------------------------------------------------
    # 3. Validate SCAN-B external sample alignment
    # --------------------------------------------------------
    logging.info("[3/7] Validating SCAN-B external expression/endpoint alignment...")
    logging.info("")

    scanb_ep = pd.read_csv(CF13_SCANB_ENDPOINT, sep="\t", dtype=str)
    scanb_header = gzip_header(SCANB_EXPRESSION)
    scanb_expr_samples = list(map(str, scanb_header[1:]))
    scanb_expr_set = set(scanb_expr_samples)

    if len(scanb_expr_samples) != EXPECTED_SCANB_PRIMARY:
        raise RuntimeError(
            f"SCAN-B expression columns={len(scanb_expr_samples)}; expected 3273."
        )
    if len(scanb_ep) != EXPECTED_SCANB_PRIMARY:
        raise RuntimeError(
            f"SCAN-B endpoint rows={len(scanb_ep)}; expected 3273."
        )
    if scanb_ep["source_id"].duplicated().any():
        raise RuntimeError("SCAN-B endpoint source IDs are duplicated.")

    scanb_ep_set = set(scanb_ep["source_id"].astype(str))
    if scanb_ep_set != scanb_expr_set:
        missing_labels = sorted(scanb_expr_set - scanb_ep_set)
        missing_expr = sorted(scanb_ep_set - scanb_expr_set)
        raise RuntimeError(
            "SCAN-B expression/endpoint IDs do not match exactly. "
            f"expression_without_endpoint={len(missing_labels)}, "
            f"endpoint_without_expression={len(missing_expr)}"
        )

    order = pd.DataFrame({"source_id": scanb_expr_samples})
    scanb_ml = order.merge(
        scanb_ep[["source_id", "ER", "PR", "HER2", "TNBC"]],
        on="source_id",
        how="left",
        validate="one_to_one",
    )
    scanb_ml = scanb_ml.rename(columns={"source_id": "expression_sample_id"})
    scanb_ml.to_csv(SCANB_ML_MANIFEST, sep="\t", index=False)

    logging.info("SCAN-B expression/endpoint alignment: EXACT 3273/3273")
    logging.info("SCAN-B remains external and untouched by training/tuning.")
    logging.info("")

    # --------------------------------------------------------
    # 4. Candidate endpoint balance
    # --------------------------------------------------------
    logging.info("[4/7] Auditing candidate endpoint coverage and class balance...")
    logging.info("")

    balance_rows = []
    for endpoint in ["ER", "PR", "HER2", "TNBC"]:
        balance_rows.append(endpoint_balance(tcga_ml, "TCGA", endpoint))
        balance_rows.append(endpoint_balance(scanb_ml, "SCANB", endpoint))

    balance = pd.DataFrame(balance_rows)
    balance.to_csv(
        RESULTS / "CF14_candidate_endpoint_balance.tsv",
        sep="\t",
        index=False,
    )

    for endpoint in ["ER", "PR", "HER2", "TNBC"]:
        logging.info(f"{endpoint}:")
        for cohort in ["TCGA", "SCANB"]:
            r = balance.loc[
                (balance["endpoint"] == endpoint)
                & (balance["cohort"] == cohort)
            ].iloc[0]
            logging.info(
                f"  {cohort}: known={int(r['known_n'])}, "
                f"positive={int(r['positive_n'])}, "
                f"negative={int(r['negative_n'])}, "
                f"minority={float(r['minority_fraction']):.3f}"
            )
    logging.info("")

    # --------------------------------------------------------
    # 5. Verify leakage-safe gene universe
    # --------------------------------------------------------
    logging.info("[5/7] Verifying leakage-safe external-validation gene universe...")
    logging.info("")

    crosswalk = pd.read_csv(CF13_CROSSWALK, sep="\t", dtype=str)

    if crosswalk["gene_symbol"].duplicated().any():
        raise RuntimeError("CF13 feature crosswalk contains duplicate gene symbols.")

    eligible = (
        crosswalk["eligible_TCGA_SCANB_external_validation"]
        .astype(str)
        .str.lower()
        .isin(["true", "1", "yes"])
    )
    n_eligible = int(eligible.sum())

    if n_eligible != EXPECTED_EXTERNAL_FEATURE_UNIVERSE:
        raise RuntimeError(
            f"Eligible external-validation genes={n_eligible}; expected 22106."
        )

    if "APOLLO_RNA_one_to_one" in crosswalk.columns:
        # Verify APOLLO is not silently required for ML eligibility.
        eligible_without_apollo = int(
            (
                eligible
                & ~crosswalk["APOLLO_RNA_one_to_one"]
                .astype(str)
                .str.lower()
                .isin(["true", "1", "yes"])
            ).sum()
        )
    else:
        eligible_without_apollo = -1

    pd.DataFrame(
        {
            "gene_symbol": crosswalk.loc[eligible, "gene_symbol"].astype(str)
        }
    ).to_csv(
        PROCESSED / "CF14_external_validation_gene_universe_DRAFT.tsv",
        sep="\t",
        index=False,
    )

    logging.info(f"Eligible TCGA∩SCAN-B genes: {n_eligible}")
    logging.info(
        "Eligible genes not requiring APOLLO RNA presence: "
        f"{eligible_without_apollo}"
    )
    logging.info("APOLLO is not used to define the ML feature universe.")
    logging.info("")

    # --------------------------------------------------------
    # 6. Write protocol draft + leakage checklist
    # --------------------------------------------------------
    logging.info("[6/7] Writing pre-ML protocol draft and leakage checklist...")
    logging.info("")

    protocol = pd.DataFrame(
        [
            (
                "Discovery cohort",
                "TCGA-BRCA Primary Tumor only",
                "READY",
                "1094 resolved tumor patients; normal samples excluded",
            ),
            (
                "External validation cohort",
                "SCAN-B GSE96058",
                "READY",
                "3273 GEO-designated primary tumors; never used for tuning",
            ),
            (
                "Cross-omics confirmation cohort",
                "APOLLO-BRCA-1",
                "READY",
                "68 cases with RNA+protein+phosphoprotein overlap",
            ),
            (
                "ML feature availability universe",
                "Exact one-to-one TCGA∩SCAN-B symbols",
                "READY",
                "22106 genes; APOLLO presence not required",
            ),
            (
                "Primary prediction endpoint",
                "PENDING MANUAL SELECTION",
                "REVIEW_REQUIRED",
                "Choose among measured/pathology ER, PR, HER2, TNBC after balance review",
            ),
            (
                "TCGA expression transform",
                "PENDING MANUAL LOCK",
                "REVIEW_REQUIRED",
                "Candidate: log2(TPM+1), then training-fold-only scaling",
            ),
            (
                "SCAN-B scale handling",
                "PENDING MANUAL LOCK",
                "REVIEW_REQUIRED",
                "Must preserve external validation; no label-informed harmonization",
            ),
            (
                "Cross-cohort ComBat",
                "FORBIDDEN",
                "LOCKED",
                "Would mix discovery and external cohort distributions",
            ),
            (
                "Pooled quantile normalization",
                "FORBIDDEN",
                "LOCKED",
                "External validation must remain independent",
            ),
            (
                "Feature selection",
                "Inside training folds only",
                "LOCKED",
                "No global DEG or whole-dataset feature selection",
            ),
            (
                "CF9 stable DEG list",
                "Biology evidence only",
                "LOCKED",
                "Not a globally preselected ML feature set",
            ),
            (
                "SCAN-B labels",
                "External evaluation only",
                "LOCKED",
                "Never used for tuning, feature selection or model choice",
            ),
            (
                "APOLLO",
                "Cross-omics confirmation only",
                "LOCKED",
                "Not ML performance validation",
            ),
            (
                "Model families",
                "PENDING MANUAL LOCK",
                "REVIEW_REQUIRED",
                "Proposed: Elastic Net logistic + linear SVM + one nonlinear boosted-tree model",
            ),
            (
                "Nested CV",
                "PENDING MANUAL LOCK",
                "REVIEW_REQUIRED",
                "Proposed: stratified outer CV with all preprocessing/tuning inside training data",
            ),
            (
                "Primary metric",
                "PENDING MANUAL LOCK",
                "REVIEW_REQUIRED",
                "Proposed: AUROC plus PR-AUC/MCC/balanced accuracy and calibration",
            ),
        ],
        columns=["protocol_item", "draft_decision", "status", "rationale"],
    )
    protocol.to_csv(
        RESULTS / "CF14_protocol_draft.tsv",
        sep="\t",
        index=False,
    )

    leakage = pd.DataFrame(
        [
            ("Normal tissue excluded from TCGA ML population", True),
            ("One TCGA tumor row per patient", len(tcga_ml) == tcga_ml["patient_id"].nunique()),
            ("SCAN-B sample IDs exactly aligned", set(scanb_ml["expression_sample_id"]) == scanb_expr_set),
            ("SCAN-B excluded from tuning", True),
            ("APOLLO excluded from model performance validation", True),
            ("APOLLO not required for ML feature universe", True),
            ("Global CF9 DEG preselection forbidden", True),
            ("Cross-cohort ComBat forbidden", True),
            ("Pooled cross-cohort quantile normalization forbidden", True),
            ("ML executed in CF14", False),
        ],
        columns=["check", "value"],
    )
    leakage.to_csv(
        RESULTS / "CF14_leakage_audit.tsv",
        sep="\t",
        index=False,
    )

    logging.info("Protocol draft written.")
    logging.info("Primary endpoint remains intentionally UNLOCKED.")
    logging.info("Preprocessing/model/CV choices remain intentionally UNLOCKED.")
    logging.info("")

    # --------------------------------------------------------
    # 7. Summary + provenance
    # --------------------------------------------------------
    logging.info("[7/7] Writing CF14 audit summary and provenance...")
    logging.info("")

    runtime = (time.time() - start) / 60.0

    summary = pd.DataFrame(
        [
            ("TCGA discovery tumors", len(tcga_ml)),
            ("SCAN-B external tumors", len(scanb_ml)),
            ("External-validation feature universe", n_eligible),
            ("APOLLO complete multi-omics cases", apollo_overlap),
            ("Candidate endpoints audited", 4),
            ("ML performed", "NO"),
            ("Primary endpoint locked", "NO"),
            ("Preprocessing locked", "NO"),
            ("Model families locked", "NO"),
            ("Nested CV locked", "NO"),
            ("CF14 runtime minutes", round(runtime, 2)),
            ("CF14 status", "AUDIT_COMPLETE_NOT_LOCKED"),
        ],
        columns=["metric", "value"],
    )
    summary.to_csv(
        RESULTS / "CF14_summary.tsv",
        sep="\t",
        index=False,
    )

    provenance = pd.DataFrame(
        [
            ("code_file", "CF14_pre_ml_manual_audit.py"),
            ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
            ("CF13_summary_sha256", sha256_file(CF13_SUMMARY)),
            ("CF13_crosswalk_sha256", sha256_file(CF13_CROSSWALK)),
            ("CF13_TCGA_endpoint_sha256", sha256_file(CF13_TCGA_ENDPOINT)),
            ("CF13_SCANB_endpoint_sha256", sha256_file(CF13_SCANB_ENDPOINT)),
            ("TCGA_CF6_manifest_sha256", sha256_file(TCGA_MANIFEST)),
            ("TCGA_TPM_header_sample_count", len(tcga_header) - 1),
            ("SCANB_expression_header_sample_count", len(scanb_header) - 1),
            (
                "manual_gate_rule",
                "No CF15/ML execution until CF14 candidate endpoint balance and "
                "protocol draft are manually reviewed and explicitly locked",
            ),
            ("python_version", sys.version.replace("\n", " ")),
            ("pandas_version", pd.__version__),
            ("numpy_version", np.__version__),
            ("platform", platform.platform()),
        ],
        columns=["field", "value"],
    )
    provenance.to_csv(
        RESULTS / "CF14_provenance.tsv",
        sep="\t",
        index=False,
    )

    sentinel = RESULTS / "CF14_MANUAL_APPROVAL_REQUIRED.txt"
    sentinel.write_text(
        "CF14 audit is complete, but the ML protocol is NOT locked.\n"
        "Review CF14_candidate_endpoint_balance.tsv and CF14_protocol_draft.tsv.\n"
        "Do not begin CF15 until explicit manual approval is recorded.\n",
        encoding="utf-8",
    )

    logging.info("============================================================")
    logging.info(" CF14 AUDIT COMPLETE - MANUAL PROTOCOL LOCK REQUIRED")
    logging.info("============================================================")
    logging.info("")
    logging.info(f"TCGA discovery tumors: {len(tcga_ml)}")
    logging.info(f"SCAN-B external tumors: {len(scanb_ml)}")
    logging.info(f"External-validation gene universe: {n_eligible}")
    logging.info(f"APOLLO complete multi-omics cases: {apollo_overlap}")
    logging.info(f"CF14 runtime: {runtime:.1f} min")
    logging.info("")
    logging.info("STATUS: AUDIT_COMPLETE_NOT_LOCKED")
    logging.info("NO ML was performed.")
    logging.info("")
    logging.info("SEND THE FULL TERMINAL OUTPUT FOR MANUAL REVIEW.")
    logging.info("Do not start CF15 yet.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF14 ERROR: {exc}")
        sys.exit(1)
