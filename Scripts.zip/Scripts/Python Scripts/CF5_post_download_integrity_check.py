#!/usr/bin/env python
"""
CF5 - TCGA-BRCA Post-Download Integrity Check

Purpose
-------
Validate the RNA-seq STAR-count files downloaded from the NCI GDC against the
frozen CF4 manifest before any expression matrix is constructed.

This script performs NO data transformation and NO statistical analysis.

Critical checks
---------------
1. Every CF4 manifest UUID/file is present exactly once.
2. Downloaded byte size exactly matches the official GDC manifest.
3. Downloaded MD5 exactly matches the official GDC manifest.
4. Every expected file has the augmented STAR-count TSV structure expected
   for this project.
5. No incomplete/partial transfer files remain.
6. The total validated byte count matches the frozen acquisition plan.

Outputs
-------
All outputs begin with CF5_ according to the project naming convention.
"""

from __future__ import annotations

import csv
import hashlib
import json
import logging
import os
import platform
import re
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd


# ============================================================
# CF5 CONFIGURATION
# ============================================================

PROJECT_ROOT = Path.cwd()

CF4_DIR = PROJECT_ROOT / "results" / "CF4_gdc_acquisition_preparation"
MANIFEST_FILE = CF4_DIR / "CF4_gdc_manifest.txt"
CF4_SUMMARY_FILE = CF4_DIR / "CF4_summary.tsv"
CF4_PROVENANCE_FILE = CF4_DIR / "CF4_provenance.tsv"

DOWNLOAD_DIR = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "tcga_brca"
    / "star_counts"
)

OUTPUT_DIR = (
    PROJECT_ROOT
    / "results"
    / "CF5_post_download_integrity_check"
)

LOG_DIR = PROJECT_ROOT / "logs"
LOG_FILE = LOG_DIR / "CF5_post_download_integrity_check.log"

# MD5 is I/O bound here. Four workers is deliberately conservative for
# ordinary workstation disks and avoids excessive random disk I/O.
HASH_WORKERS = min(4, max(1, os.cpu_count() or 1))
HASH_CHUNK_SIZE = 8 * 1024 * 1024  # 8 MiB

EXPECTED_FILENAME_SUFFIX = ".rna_seq.augmented_star_gene_counts.tsv"

# Official GDC mRNA STAR output contains gene ID plus unstranded/stranded raw
# counts. GDC's augmented files also contain TPM, FPKM, and FPKM-UQ.
REQUIRED_STAR_COLUMNS = {
    "gene_id",
    "unstranded",
    "stranded_first",
    "stranded_second",
    "tpm_unstranded",
    "fpkm_unstranded",
    "fpkm_uq_unstranded",
}

GENCODE_ID_PATTERN = re.compile(r"^ENSG\d+(?:\.\d+)?$")

PARTIAL_FILE_PATTERNS = (
    ".partial",
    ".part",
    ".tmp",
    ".download",
)


# ============================================================
# UTILITIES
# ============================================================

def md5_file(path: Path) -> str:
    """Return the hexadecimal MD5 checksum of a file."""
    digest = hashlib.md5()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(HASH_CHUNK_SIZE), b""):
            digest.update(chunk)
    return digest.hexdigest()


def human_bytes(value: int) -> str:
    """Human-readable binary byte size."""
    value = int(value)
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    size = float(value)
    for unit in units:
        if size < 1024.0 or unit == units[-1]:
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{value} B"


def safe_int(value) -> Optional[int]:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def setup_logging() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def load_metric_table(path: Path) -> Dict[str, str]:
    """Read a two-column metric/value or field/value TSV as a dictionary."""
    if not path.exists():
        return {}

    df = pd.read_csv(path, sep="\t", dtype=str)

    if {"metric", "value"}.issubset(df.columns):
        key_col = "metric"
    elif {"field", "value"}.issubset(df.columns):
        key_col = "field"
    else:
        return {}

    return dict(zip(df[key_col].astype(str), df["value"].astype(str)))


def empty_dataframe(columns: List[str]) -> pd.DataFrame:
    return pd.DataFrame(columns=columns)


# ============================================================
# FILE DISCOVERY
# ============================================================

def index_downloaded_files(download_dir: Path) -> Tuple[List[Path], Dict[str, List[Path]]]:
    """
    Recursively index every file in the GDC download directory by basename.
    """
    all_files = [p for p in download_dir.rglob("*") if p.is_file()]

    by_name: Dict[str, List[Path]] = {}
    for path in all_files:
        by_name.setdefault(path.name, []).append(path)

    return all_files, by_name


def resolve_expected_path(
    file_uuid: str,
    filename: str,
    download_dir: Path,
    by_name: Dict[str, List[Path]],
) -> Tuple[Optional[Path], str, int]:
    """
    Resolve one expected GDC file.

    Preferred layout:
        download_dir / <file_uuid> / <filename>

    A recursive basename fallback is allowed because GDC client layouts can
    differ across versions/settings. Multiple matches are treated as an error.
    """
    canonical = download_dir / file_uuid / filename

    if canonical.is_file():
        matches = by_name.get(filename, [])
        return canonical, "canonical_uuid_path", len(matches)

    matches = by_name.get(filename, [])

    if len(matches) == 1:
        return matches[0], "unique_recursive_filename_match", 1

    if len(matches) == 0:
        return None, "missing", 0

    return None, "multiple_recursive_matches", len(matches)


# ============================================================
# STAR-COUNTS FORMAT CHECK
# ============================================================

def inspect_star_counts_format(path: Path) -> Dict[str, object]:
    """
    Perform a lightweight structural validation of an augmented GDC STAR-count
    TSV. Full-file corruption is assessed independently by byte size + MD5.

    The function searches the first 250 text lines for the gene_id header and
    confirms required STAR/raw-count and normalized-expression columns.
    It also confirms that at least one GENCODE ENSG identifier appears shortly
    after the header.
    """
    result = {
        "format_readable": False,
        "expected_filename_suffix": path.name.endswith(EXPECTED_FILENAME_SUFFIX),
        "header_found": False,
        "header_line_number": None,
        "column_count": None,
        "required_columns_present": False,
        "missing_required_columns": "",
        "gencode_gene_seen": False,
        "format_pass": False,
        "format_error": "",
    }

    try:
        lines: List[str] = []
        with path.open("r", encoding="utf-8-sig", errors="strict", newline="") as handle:
            for idx, line in enumerate(handle, start=1):
                lines.append(line.rstrip("\r\n"))
                if idx >= 250:
                    break

        result["format_readable"] = True

        header_idx = None
        header_columns: List[str] = []

        for i, line in enumerate(lines):
            parts = line.split("\t")
            if parts and parts[0].strip() == "gene_id":
                header_idx = i
                header_columns = [x.strip() for x in parts]
                break

        if header_idx is None:
            result["format_error"] = "gene_id header not found in first 250 lines"
            return result

        result["header_found"] = True
        result["header_line_number"] = header_idx + 1
        result["column_count"] = len(header_columns)

        missing = sorted(REQUIRED_STAR_COLUMNS.difference(header_columns))
        result["missing_required_columns"] = ";".join(missing)
        result["required_columns_present"] = len(missing) == 0

        # Look for at least one GENCODE gene ID after the header.
        for line in lines[header_idx + 1 :]:
            if not line:
                continue
            first_field = line.split("\t", 1)[0].strip()
            if GENCODE_ID_PATTERN.match(first_field):
                result["gencode_gene_seen"] = True
                break

        result["format_pass"] = bool(
            result["format_readable"]
            and result["expected_filename_suffix"]
            and result["header_found"]
            and result["required_columns_present"]
            and result["gencode_gene_seen"]
        )

        if not result["format_pass"] and not result["format_error"]:
            problems = []
            if not result["expected_filename_suffix"]:
                problems.append("unexpected filename suffix")
            if not result["required_columns_present"]:
                problems.append("required columns missing")
            if not result["gencode_gene_seen"]:
                problems.append("no ENSG identifier detected near header")
            result["format_error"] = "; ".join(problems)

    except UnicodeDecodeError as exc:
        result["format_error"] = f"UTF-8 decode error: {exc}"
    except OSError as exc:
        result["format_error"] = f"file read error: {exc}"
    except Exception as exc:  # keep QC table informative instead of crashing
        result["format_error"] = f"unexpected format-check error: {exc}"

    return result


# ============================================================
# PER-FILE VALIDATION
# ============================================================

def validate_one_file(task: Dict[str, object]) -> Dict[str, object]:
    """Validate size, MD5, and STAR-count structure for one resolved file."""
    path: Optional[Path] = task["resolved_path"]  # type: ignore[assignment]

    record = dict(task)
    record.pop("resolved_path", None)

    if path is None:
        record.update(
            {
                "actual_path": "",
                "actual_size": None,
                "size_match": False,
                "actual_md5": "",
                "md5_match": False,
                "integrity_pass": False,
            }
        )
        record.update(
            {
                "format_readable": False,
                "expected_filename_suffix": False,
                "header_found": False,
                "header_line_number": None,
                "column_count": None,
                "required_columns_present": False,
                "missing_required_columns": "",
                "gencode_gene_seen": False,
                "format_pass": False,
                "format_error": "file not uniquely resolved",
            }
        )
        return record

    actual_size = path.stat().st_size
    expected_size = int(task["expected_size"])
    actual_md5 = md5_file(path)

    record.update(
        {
            "actual_path": str(path.resolve()),
            "actual_size": actual_size,
            "size_match": actual_size == expected_size,
            "actual_md5": actual_md5,
            "md5_match": actual_md5.lower() == str(task["expected_md5"]).lower(),
        }
    )

    format_result = inspect_star_counts_format(path)
    record.update(format_result)

    record["integrity_pass"] = bool(
        record["size_match"]
        and record["md5_match"]
        and record["format_pass"]
        and int(record["recursive_match_count"]) == 1
    )

    return record


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    setup_logging()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF5 - POST-DOWNLOAD INTEGRITY + STAR-COUNTS FORMAT CHECK")
    logging.info("============================================================")
    logging.info("")

    # --------------------------------------------------------
    # 1. Validate frozen CF4 inputs
    # --------------------------------------------------------
    logging.info("[1/8] Validating frozen CF4 acquisition manifest...")
    logging.info("")

    if not MANIFEST_FILE.exists():
        raise FileNotFoundError(f"CF4 manifest not found: {MANIFEST_FILE}")

    if not CF4_SUMMARY_FILE.exists():
        raise FileNotFoundError(f"CF4 summary not found: {CF4_SUMMARY_FILE}")

    if not DOWNLOAD_DIR.exists():
        raise FileNotFoundError(
            f"Download directory not found: {DOWNLOAD_DIR}\n"
            "Run the frozen GDC download command before CF5."
        )

    manifest_md5 = md5_file(MANIFEST_FILE)
    manifest = pd.read_csv(
        MANIFEST_FILE,
        sep="\t",
        dtype={
            "id": str,
            "filename": str,
            "md5": str,
            "size": "Int64",
            "state": str,
        },
    )

    required_manifest_columns = {"id", "filename", "md5", "size", "state"}
    missing_manifest_columns = required_manifest_columns.difference(manifest.columns)
    if missing_manifest_columns:
        raise RuntimeError(
            "CF4 GDC manifest is missing required columns: "
            + ", ".join(sorted(missing_manifest_columns))
        )

    if manifest["id"].duplicated().any():
        raise RuntimeError("CF4 manifest contains duplicate GDC file UUIDs.")

    if manifest["filename"].duplicated().any():
        raise RuntimeError("CF4 manifest contains duplicate filenames.")

    cf4_summary = load_metric_table(CF4_SUMMARY_FILE)
    cf4_provenance = load_metric_table(CF4_PROVENANCE_FILE)

    expected_manifest_count = safe_int(
        cf4_summary.get("Official GDC manifest files")
    )
    expected_total_bytes = safe_int(
        cf4_summary.get("Expected bytes")
    )

    if expected_manifest_count is not None and len(manifest) != expected_manifest_count:
        raise RuntimeError(
            f"Manifest row count changed since CF4: "
            f"{len(manifest)} vs expected {expected_manifest_count}"
        )

    manifest_total_bytes = int(manifest["size"].sum())

    if expected_total_bytes is not None and manifest_total_bytes != expected_total_bytes:
        raise RuntimeError(
            "Manifest total bytes changed since CF4: "
            f"{manifest_total_bytes:,} vs expected {expected_total_bytes:,}"
        )

    logging.info(f"CF4 manifest records: {len(manifest)}")
    logging.info(f"CF4 manifest MD5: {manifest_md5}")
    logging.info(
        f"Expected download volume: {manifest_total_bytes:,} "
        f"({human_bytes(manifest_total_bytes)})"
    )
    if "GDC release" in cf4_summary:
        logging.info(f"Frozen GDC release: {cf4_summary['GDC release']}")
    logging.info("")

    # --------------------------------------------------------
    # 2. Index downloaded files
    # --------------------------------------------------------
    logging.info("[2/8] Indexing GDC download directory...")
    logging.info("")

    all_downloaded_files, by_name = index_downloaded_files(DOWNLOAD_DIR)

    logging.info(f"Files physically present under download tree: {len(all_downloaded_files)}")
    logging.info(f"Download root: {DOWNLOAD_DIR.resolve()}")
    logging.info("")

    # --------------------------------------------------------
    # 3. Resolve expected files
    # --------------------------------------------------------
    logging.info("[3/8] Resolving all manifest files against local paths...")
    logging.info("")

    tasks: List[Dict[str, object]] = []

    for row in manifest.itertuples(index=False):
        resolved_path, resolution_method, match_count = resolve_expected_path(
            file_uuid=str(row.id),
            filename=str(row.filename),
            download_dir=DOWNLOAD_DIR,
            by_name=by_name,
        )

        tasks.append(
            {
                "file_id": str(row.id),
                "filename": str(row.filename),
                "expected_md5": str(row.md5).lower(),
                "expected_size": int(row.size),
                "manifest_state": str(row.state),
                "resolution_method": resolution_method,
                "recursive_match_count": match_count,
                "resolved_path": resolved_path,
            }
        )

    missing_before_hash = sum(1 for x in tasks if x["resolved_path"] is None)
    ambiguous_before_hash = sum(
        1 for x in tasks if x["resolution_method"] == "multiple_recursive_matches"
    )

    logging.info(f"Manifest files uniquely resolved: {len(tasks) - missing_before_hash}/{len(tasks)}")
    logging.info(f"Missing manifest files: {missing_before_hash}")
    logging.info(f"Ambiguous duplicate local matches: {ambiguous_before_hash}")
    logging.info("")

    # --------------------------------------------------------
    # 4. Validate MD5, size, and format
    # --------------------------------------------------------
    logging.info("[4/8] Checking file size, MD5, and STAR-count structure...")
    logging.info(
        f"MD5 worker threads: {HASH_WORKERS} "
        f"(total data ~{human_bytes(manifest_total_bytes)})"
    )
    logging.info("")

    # executor.map preserves task order, producing deterministic output tables.
    results: List[Dict[str, object]] = []
    with ThreadPoolExecutor(max_workers=HASH_WORKERS) as executor:
        for idx, result in enumerate(executor.map(validate_one_file, tasks), start=1):
            results.append(result)
            if idx % 100 == 0 or idx == len(tasks):
                logging.info(f"Validated {idx}/{len(tasks)} files...")

    result_df = pd.DataFrame(results)

    # --------------------------------------------------------
    # 5. Detect unexpected / partial files
    # --------------------------------------------------------
    logging.info("")
    logging.info("[5/8] Checking for unexpected and incomplete transfer files...")
    logging.info("")

    expected_names = set(manifest["filename"].astype(str))
    expected_ids = set(manifest["id"].astype(str))

    gdc_support_rows = []
    unexpected_rows = []

    for path in all_downloaded_files:
        name = path.name
        if name in expected_names:
            continue

        lower_name = name.lower()
        partial_indicator = any(
            token in lower_name for token in PARTIAL_FILE_PATTERNS
        )

        # Official GDC Data Transfer Tool layout places transfer state files
        # inside <file_uuid>/logs/. These are client support/provenance files,
        # not analytical RNA-seq data and therefore must not be classified as
        # unexpected scientific files.
        is_gdc_log_state_file = path.parent.name.lower() == "logs"

        row = {
            "path": str(path.resolve()),
            "filename": name,
            "size": path.stat().st_size,
            "partial_or_incomplete_indicator": partial_indicator,
        }

        if is_gdc_log_state_file:
            row["classification"] = "GDC_CLIENT_SUPPORT_STATE_FILE"
            gdc_support_rows.append(row)
        else:
            row["classification"] = "UNEXPECTED_NON_MANIFEST_FILE"
            unexpected_rows.append(row)

    gdc_support_df = pd.DataFrame(
        gdc_support_rows,
        columns=[
            "path",
            "filename",
            "size",
            "partial_or_incomplete_indicator",
            "classification",
        ],
    )

    unexpected_df = pd.DataFrame(
        unexpected_rows,
        columns=[
            "path",
            "filename",
            "size",
            "partial_or_incomplete_indicator",
            "classification",
        ],
    )

    # Count incomplete-transfer indicators across BOTH scientific and GDC
    # support/state files. A .partial anywhere in the raw download tree blocks
    # the integrity gate.
    partial_file_count = 0
    if not gdc_support_df.empty:
        partial_file_count += int(
            gdc_support_df["partial_or_incomplete_indicator"].sum()
        )
    if not unexpected_df.empty:
        partial_file_count += int(
            unexpected_df["partial_or_incomplete_indicator"].sum()
        )

    logging.info(f"GDC client support/state files: {len(gdc_support_df)}")
    logging.info(f"Truly unexpected non-manifest files: {len(unexpected_df)}")
    logging.info(f"Partial/incomplete-transfer indicators: {partial_file_count}")
    logging.info("")

    # --------------------------------------------------------
    # 6. Build pass/fail tables
    # --------------------------------------------------------
    logging.info("[6/8] Building CF5 integrity results...")
    logging.info("")

    missing_df = result_df[
        (result_df["resolution_method"] == "missing")
        | (result_df["resolution_method"] == "multiple_recursive_matches")
    ].copy()

    failed_df = result_df[~result_df["integrity_pass"].astype(bool)].copy()

    format_columns = [
        "file_id",
        "filename",
        "actual_path",
        "format_readable",
        "expected_filename_suffix",
        "header_found",
        "header_line_number",
        "column_count",
        "required_columns_present",
        "missing_required_columns",
        "gencode_gene_seen",
        "format_pass",
        "format_error",
    ]
    format_df = result_df[format_columns].copy()

    size_match_count = int(result_df["size_match"].fillna(False).sum())
    md5_match_count = int(result_df["md5_match"].fillna(False).sum())
    format_pass_count = int(result_df["format_pass"].fillna(False).sum())
    integrity_pass_count = int(result_df["integrity_pass"].fillna(False).sum())

    actual_validated_bytes = int(
        pd.to_numeric(
            result_df.loc[
                result_df["integrity_pass"].astype(bool),
                "actual_size",
            ],
            errors="coerce",
        ).fillna(0).sum()
    )

    critical_failure_count = (
        len(failed_df)
        + len(unexpected_df)
        + partial_file_count
    )

    overall_pass = (
        len(result_df) == len(manifest)
        and len(failed_df) == 0
        and len(unexpected_df) == 0
        and partial_file_count == 0
        and actual_validated_bytes == manifest_total_bytes
    )

    logging.info(f"Size matches: {size_match_count}/{len(manifest)}")
    logging.info(f"MD5 matches: {md5_match_count}/{len(manifest)}")
    logging.info(f"STAR-count format passes: {format_pass_count}/{len(manifest)}")
    logging.info(f"Fully validated files: {integrity_pass_count}/{len(manifest)}")
    logging.info(
        f"Validated bytes: {actual_validated_bytes:,} "
        f"({human_bytes(actual_validated_bytes)})"
    )
    logging.info("")

    # --------------------------------------------------------
    # 7. Save outputs + provenance
    # --------------------------------------------------------
    logging.info("[7/8] Saving CF5 results and provenance...")
    logging.info("")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    result_df.to_csv(
        OUTPUT_DIR / "CF5_file_integrity_results.tsv",
        sep="\t",
        index=False,
    )

    format_df.to_csv(
        OUTPUT_DIR / "CF5_star_counts_format_qc.tsv",
        sep="\t",
        index=False,
    )

    missing_df.to_csv(
        OUTPUT_DIR / "CF5_missing_or_ambiguous_files.tsv",
        sep="\t",
        index=False,
    )

    failed_df.to_csv(
        OUTPUT_DIR / "CF5_failed_integrity_files.tsv",
        sep="\t",
        index=False,
    )

    gdc_support_df.to_csv(
        OUTPUT_DIR / "CF5_gdc_client_support_files.tsv",
        sep="\t",
        index=False,
    )

    unexpected_df.to_csv(
        OUTPUT_DIR / "CF5_unexpected_files.tsv",
        sep="\t",
        index=False,
    )

    summary_rows = [
        ("Expected manifest files", len(manifest)),
        ("Files uniquely resolved", int((result_df["recursive_match_count"] == 1).sum())),
        ("Missing or ambiguous files", len(missing_df)),
        ("Exact file-size matches", size_match_count),
        ("Exact MD5 matches", md5_match_count),
        ("STAR-count format passes", format_pass_count),
        ("Fully validated files", integrity_pass_count),
        ("Expected bytes", manifest_total_bytes),
        ("Fully validated bytes", actual_validated_bytes),
        ("Physical files under download tree", len(all_downloaded_files)),
        ("GDC client support/state files", len(gdc_support_df)),
        ("Truly unexpected non-manifest files", len(unexpected_df)),
        ("Partial/incomplete transfer files", partial_file_count),
        ("Critical failure count", critical_failure_count),
        ("CF5 integrity gate", "PASS" if overall_pass else "FAIL"),
    ]

    summary_df = pd.DataFrame(summary_rows, columns=["metric", "value"])
    summary_df.to_csv(
        OUTPUT_DIR / "CF5_summary.tsv",
        sep="\t",
        index=False,
    )

    provenance_rows = [
        ("code_file", "CF5_post_download_integrity_check.py"),
        ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
        ("project_root", str(PROJECT_ROOT.resolve())),
        ("download_directory", str(DOWNLOAD_DIR.resolve())),
        ("cf4_manifest", str(MANIFEST_FILE.resolve())),
        ("cf4_manifest_md5", manifest_md5),
        ("cf4_manifest_records", len(manifest)),
        ("cf4_expected_bytes", manifest_total_bytes),
        ("cf4_gdc_release", cf4_summary.get("GDC release", "")),
        ("cf4_gdc_client_version", cf4_summary.get("GDC client version", "")),
        ("cf4_provenance_file_md5", md5_file(CF4_PROVENANCE_FILE) if CF4_PROVENANCE_FILE.exists() else ""),
        ("hash_algorithm", "MD5"),
        ("hash_workers", HASH_WORKERS),
        ("python_version", sys.version.replace("\n", " ")),
        ("platform", platform.platform()),
        ("integrity_gate", "PASS" if overall_pass else "FAIL"),
    ]

    provenance_df = pd.DataFrame(provenance_rows, columns=["field", "value"])
    provenance_df.to_csv(
        OUTPUT_DIR / "CF5_provenance.tsv",
        sep="\t",
        index=False,
    )

    readiness_file = OUTPUT_DIR / "CF5_READY_FOR_EXPRESSION_PROCESSING.txt"

    if overall_pass:
        readiness_file.write_text(
            "CF5 INTEGRITY GATE: PASS\n"
            f"Validated files: {integrity_pass_count}/{len(manifest)}\n"
            f"Validated bytes: {actual_validated_bytes}\n"
            f"CF4 manifest MD5: {manifest_md5}\n"
            "The frozen TCGA-BRCA STAR-count acquisition is ready for "
            "expression-matrix construction.\n",
            encoding="utf-8",
        )
    elif readiness_file.exists():
        readiness_file.unlink()

    # --------------------------------------------------------
    # 8. Final stage gate
    # --------------------------------------------------------
    logging.info("[8/8] Final CF5 stage gate...")
    logging.info("")
    logging.info("============================================================")

    if overall_pass:
        logging.info(" CF5 COMPLETE - INTEGRITY GATE PASSED")
    else:
        logging.info(" CF5 FAILED - INTEGRITY GATE DID NOT PASS")

    logging.info("============================================================")
    logging.info("")
    logging.info(f"Expected files: {len(manifest)}")
    logging.info(f"Fully validated files: {integrity_pass_count}")
    logging.info(f"Exact MD5 matches: {md5_match_count}")
    logging.info(f"Exact size matches: {size_match_count}")
    logging.info(f"STAR-count format passes: {format_pass_count}")
    logging.info(f"Missing/ambiguous expected files: {len(missing_df)}")
    logging.info(f"GDC client support/state files: {len(gdc_support_df)}")
    logging.info(f"Truly unexpected non-manifest files: {len(unexpected_df)}")
    logging.info(f"Partial/incomplete transfer files: {partial_file_count}")
    logging.info(
        f"Expected / validated bytes: "
        f"{manifest_total_bytes:,} / {actual_validated_bytes:,}"
    )
    logging.info("")
    logging.info(f"Results saved to: {OUTPUT_DIR}")
    logging.info("")
    logging.info("CF5 generated:")
    logging.info("  CF5_file_integrity_results.tsv")
    logging.info("  CF5_star_counts_format_qc.tsv")
    logging.info("  CF5_missing_or_ambiguous_files.tsv")
    logging.info("  CF5_failed_integrity_files.tsv")
    logging.info("  CF5_gdc_client_support_files.tsv")
    logging.info("  CF5_unexpected_files.tsv")
    logging.info("  CF5_summary.tsv")
    logging.info("  CF5_provenance.tsv")
    if overall_pass:
        logging.info("  CF5_READY_FOR_EXPRESSION_PROCESSING.txt")
    logging.info("  CF5_post_download_integrity_check.log")
    logging.info("")

    if overall_pass:
        logging.info("IMPORTANT:")
        logging.info("No expression values were transformed by CF5.")
        logging.info("No sample was removed by CF5.")
        logging.info("All expected files match the frozen official GDC manifest.")
        logging.info("CF5 is ready to be frozen before expression-matrix construction.")
        logging.info("")
        return

    logging.error("IMPORTANT:")
    logging.error("Do NOT start expression-matrix construction.")
    logging.error(
        "Inspect CF5_failed_integrity_files.tsv, "
        "CF5_missing_or_ambiguous_files.tsv, "
        "CF5_unexpected_files.tsv, and "
        "CF5_gdc_client_support_files.tsv."
    )
    logging.error(
        "If downloads are incomplete, rerun the exact frozen GDC download command "
        "from CF4 and then rerun CF5."
    )
    logging.error("")

    raise RuntimeError(
        "CF5 integrity gate failed. Expression processing is blocked."
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF5 ERROR: {exc}")
        sys.exit(1)