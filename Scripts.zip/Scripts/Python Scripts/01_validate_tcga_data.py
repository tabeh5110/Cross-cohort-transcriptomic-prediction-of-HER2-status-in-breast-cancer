#!/usr/bin/env python3
"""Independent, chunked validation of the TCGA-BRCA acquisition outputs.

This is deliberately separate from the R downloader so that the first Python
stage confirms that the exported matrix and metadata are internally consistent
before any preprocessing, differential expression, or machine learning begins.
"""

from __future__ import annotations

import gzip
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed" / "tcga_brca"
QC_DIR = PROCESSED / "qc"
COUNTS = PROCESSED / "tcga_brca_raw_counts.tsv.gz"
SAMPLE_META = PROCESSED / "tcga_brca_sample_metadata.tsv"
GENE_META = PROCESSED / "tcga_brca_gene_annotation.tsv"
CLINICAL = PROCESSED / "tcga_brca_clinical.tsv"
BIOSPECIMEN = PROCESSED / "tcga_brca_biospecimen.tsv"


def sample_group(barcode: str) -> str:
    parts = str(barcode).split("-")
    if len(parts) < 4:
        return "Other/Unknown"
    code = parts[3][:2]
    return {"01": "Primary Tumor", "11": "Solid Tissue Normal"}.get(code, "Other/Unknown")


def first_header(path: Path) -> list[str]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        return handle.readline().rstrip("\n").split("\t")


def validate_counts(path: Path, chunksize: int = 500) -> dict[str, object]:
    header = first_header(path)
    if not header or header[0] != "gene_id":
        raise ValueError("Counts matrix must begin with a 'gene_id' column.")

    samples = header[1:]
    duplicate_sample_columns = len(samples) - len(set(samples))
    groups = pd.Series([sample_group(x) for x in samples], dtype="string")

    n_genes = 0
    negative_values = 0
    missing_values = 0
    non_numeric_values = 0
    duplicated_gene_ids = 0
    seen_genes: set[str] = set()
    gene_id_order: list[str] = []

    for chunk in pd.read_csv(path, sep="\t", compression="gzip", chunksize=chunksize, dtype={"gene_id": "string"}):
        gene_ids = chunk.pop("gene_id").astype("string")
        duplicated_gene_ids += int(gene_ids.isin(seen_genes).sum())
        duplicated_gene_ids += int(gene_ids.duplicated().sum())
        current_gene_ids = gene_ids.dropna().tolist()
        gene_id_order.extend(current_gene_ids)
        seen_genes.update(current_gene_ids)
        n_genes += len(gene_ids)

        numeric = chunk.apply(pd.to_numeric, errors="coerce")
        # Values that existed but became NaN are non-numeric.
        non_numeric_values += int((numeric.isna() & chunk.notna()).to_numpy().sum())
        missing_values += int(numeric.isna().to_numpy().sum())
        negative_values += int((numeric < 0).to_numpy().sum())

    return {
        "n_genes": n_genes,
        "n_samples": len(samples),
        "duplicate_sample_columns": duplicate_sample_columns,
        "duplicated_gene_ids": duplicated_gene_ids,
        "negative_values": negative_values,
        "missing_values": missing_values,
        "non_numeric_values": non_numeric_values,
        "primary_tumor_samples": int((groups == "Primary Tumor").sum()),
        "solid_tissue_normal_samples": int((groups == "Solid Tissue Normal").sum()),
        "other_unknown_samples": int((groups == "Other/Unknown").sum()),
        "sample_columns": samples,
        "gene_id_order": gene_id_order,
    }


def main() -> int:
    QC_DIR.mkdir(parents=True, exist_ok=True)

    required = [COUNTS, SAMPLE_META, GENE_META, CLINICAL, BIOSPECIMEN]
    missing = [p for p in required if not p.exists()]
    if missing:
        print("ERROR: Step 1 outputs are missing:")
        for p in missing:
            print(f"  - {p.relative_to(ROOT)}")
        print("Run: Rscript scripts/01_download_tcga_data.R")
        return 2

    print("Validating exported raw-count matrix in chunks...")
    count_info = validate_counts(COUNTS)

    sample_meta = pd.read_csv(SAMPLE_META, sep="\t", dtype="string")
    gene_meta = pd.read_csv(GENE_META, sep="\t", dtype="string")
    clinical = pd.read_csv(CLINICAL, sep="\t", dtype="string")
    biospecimen = pd.read_csv(BIOSPECIMEN, sep="\t", dtype="string")

    sample_columns_match = (
        "expression_column" in sample_meta.columns
        and sample_meta["expression_column"].tolist() == count_info["sample_columns"]
    )
    gene_ids_match = (
        "matrix_gene_id" in gene_meta.columns
        and gene_meta["matrix_gene_id"].dropna().tolist() == count_info["gene_id_order"]
    )

    checks = [
        ("matrix_has_genes", count_info["n_genes"] > 0, count_info["n_genes"]),
        ("matrix_has_samples", count_info["n_samples"] > 0, count_info["n_samples"]),
        ("unique_sample_columns", count_info["duplicate_sample_columns"] == 0, count_info["duplicate_sample_columns"]),
        ("unique_gene_ids", count_info["duplicated_gene_ids"] == 0, count_info["duplicated_gene_ids"]),
        ("counts_are_non_negative", count_info["negative_values"] == 0, count_info["negative_values"]),
        ("counts_are_numeric", count_info["non_numeric_values"] == 0, count_info["non_numeric_values"]),
        ("counts_have_no_missing_values", count_info["missing_values"] == 0, count_info["missing_values"]),
        ("contains_primary_tumor", count_info["primary_tumor_samples"] > 0, count_info["primary_tumor_samples"]),
        ("contains_solid_tissue_normal", count_info["solid_tissue_normal_samples"] > 0, count_info["solid_tissue_normal_samples"]),
        ("sample_metadata_row_count_matches", len(sample_meta) == count_info["n_samples"], len(sample_meta)),
        ("sample_metadata_columns_match_matrix", sample_columns_match, sample_columns_match),
        ("gene_metadata_row_count_matches", len(gene_meta) == count_info["n_genes"], len(gene_meta)),
        ("gene_metadata_ids_match_matrix", gene_ids_match, gene_ids_match),
        ("clinical_table_nonempty", len(clinical) > 0, len(clinical)),
        ("biospecimen_table_nonempty", len(biospecimen) > 0, len(biospecimen)),
    ]

    qc = pd.DataFrame(checks, columns=["check", "passed", "observed"])
    qc.to_csv(QC_DIR / "python_validation_checks.tsv", sep="\t", index=False)

    summary = pd.DataFrame(
        {
            "metric": [
                "genes",
                "expression_samples",
                "primary_tumor_samples",
                "solid_tissue_normal_samples",
                "other_unknown_samples",
                "clinical_rows",
                "biospecimen_rows",
            ],
            "value": [
                count_info["n_genes"],
                count_info["n_samples"],
                count_info["primary_tumor_samples"],
                count_info["solid_tissue_normal_samples"],
                count_info["other_unknown_samples"],
                len(clinical),
                len(biospecimen),
            ],
        }
    )
    summary.to_csv(QC_DIR / "python_acquisition_summary.tsv", sep="\t", index=False)

    print("\nTCGA-BRCA acquisition summary")
    print(summary.to_string(index=False))

    failed = qc.loc[~qc["passed"].astype(bool)]
    if not failed.empty:
        print("\nFAILED CHECKS")
        print(failed.to_string(index=False))
        return 1

    print("\nAll acquisition checks PASSED.")
    print(f"QC report: {QC_DIR / 'python_validation_checks.tsv'}")
    print("The dataset is ready for Step 2: cohort curation and exploratory QC.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
