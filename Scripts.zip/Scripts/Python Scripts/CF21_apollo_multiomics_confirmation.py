"""
============================================================
CF21 - APOLLO MULTI-OMICS CONFIRMATION
============================================================

Purpose:
    Confirm CF18 Elastic-Net predictive genes using APOLLO-BRCA-1
    RNA, protein, and phosphoprotein evidence.

Rules:
    - NO model retraining
    - NO feature selection
    - NO ML modification
    - APOLLO is confirmation only

============================================================
"""

import os
import time
import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

START = time.time()

BASE = r"D:\Masters\Research\TCGA_BRCA"

MODEL_FILE = os.path.join(
    BASE,
    "data",
    "processed",
    "ml_ready",
    "CF18_final_model",
    "CF18_final_ElasticNet_model_bundle.joblib"
)

APOLLO_DIR = os.path.join(
    BASE,
    "data",
    "raw",
    "apollo_brca1",
    "open"
)

RNA_FILE = os.path.join(
    APOLLO_DIR,
    "apollo-brca1.rnaseq.expressed_genes.level3.UQnorm_log2.txt"
)

PROTEIN_FILE = os.path.join(
    APOLLO_DIR,
    "apollo-brca1.globalproteomics_level3_unimputed.txt"
)

PHOSPHO_FILE = os.path.join(
    APOLLO_DIR,
    "apollo-brca1.phosphoproteomics_level3_adjusted_by_global_unimputed.txt"
)

OUT = os.path.join(
    BASE,
    "results",
    "CF21_apollo_multiomics_confirmation"
)

os.makedirs(OUT, exist_ok=True)


def load_predictive_genes():

    print("[1/6] Loading CF18 model bundle...")

    bundle = joblib.load(MODEL_FILE)

    all_genes = np.array(
        bundle["feature_universe_gene_symbols"]
    )

    selector = bundle["select_k_best"]

    selected_mask = selector.get_support()

    selected_genes = all_genes[selected_mask]

    model = bundle["elasticnet_model"]

    coefficients = model.coef_.flatten()

    if len(selected_genes) != len(coefficients):
        raise RuntimeError(
            f"Mismatch: selected genes={len(selected_genes)}, "
            f"coefficients={len(coefficients)}"
        )

    coef_table = pd.DataFrame(
        {
            "gene": selected_genes,
            "coefficient": coefficients
        }
    )

    coef_table = coef_table[
        coef_table["coefficient"] != 0
    ].copy()

    coef_table["abs_coefficient"] = (
        coef_table["coefficient"]
        .abs()
    )

    coef_table = coef_table.sort_values(
        "abs_coefficient",
        ascending=False
    )

    print(
        "Selected genes:",
        len(selected_genes)
    )

    print(
        "Non-zero predictive genes:",
        len(coef_table)
    )

    return coef_table


def extract_gene_column(path):
    df = pd.read_csv(
        path,
        sep="\t",
        nrows=5,
        low_memory=False
    )

    return df.columns[0]


def check_gene_presence(path, genes, label):
    print(f"Checking {label}...")

    gene_col = extract_gene_column(path)

    df = pd.read_csv(
        path,
        sep="\t",
        usecols=[gene_col],
        low_memory=False
    )

    values = set(
        df[gene_col]
        .astype(str)
        .str.upper()
    )

    result = genes.copy()

    result[label] = (
        result["gene"]
        .str.upper()
        .isin(values)
    )

    print(
        label,
        "supported:",
        int(result[label].sum()),
        "/",
        len(result)
    )

    return result


def main():

    print("""
============================================================
 CF21 - APOLLO MULTI-OMICS CONFIRMATION
============================================================
NO MODEL TRAINING
NO FEATURE SELECTION
NO MODEL CHANGE
============================================================
""")

    genes = load_predictive_genes()

    print("\n[2/6] Checking APOLLO RNA evidence...")
    result = check_gene_presence(
        RNA_FILE,
        genes,
        "RNA_support"
    )

    print("\n[3/6] Checking APOLLO protein evidence...")
    result = check_gene_presence(
        PROTEIN_FILE,
        result,
        "Protein_support"
    )

    print("\n[4/6] Checking APOLLO phosphoprotein evidence...")
    result = check_gene_presence(
        PHOSPHO_FILE,
        result,
        "Phospho_support"
    )

    def category(row):
        if row.RNA_support and row.Protein_support and row.Phospho_support:
            return "RNA+Protein+Phospho"
        elif row.RNA_support and row.Protein_support:
            return "RNA+Protein"
        elif row.RNA_support:
            return "RNA_only"
        else:
            return "No_APOLLO_match"

    result["evidence_level"] = result.apply(category, axis=1)

    result.to_csv(
        os.path.join(
            OUT,
            "CF21_predictive_gene_multiomics_table.tsv"
        ),
        sep="\t",
        index=False
    )

    summary = (
        result["evidence_level"]
        .value_counts()
        .reset_index()
    )

    summary.columns = [
        "evidence_level",
        "gene_count"
    ]

    summary.to_csv(
        os.path.join(
            OUT,
            "CF21_multiomics_summary.tsv"
        ),
        sep="\t",
        index=False
    )

    print("\n[5/6] Generating evidence figure...")

    plt.figure(figsize=(7,4))
    summary.plot(
        x="evidence_level",
        y="gene_count",
        kind="bar",
        legend=False
    )
    plt.ylabel("Number of genes")
    plt.xlabel("Evidence level")
    plt.title("CF21 APOLLO Multi-Omics Support")
    plt.tight_layout()

    plt.savefig(
        os.path.join(
            OUT,
            "CF21_evidence_barplot.png"
        ),
        dpi=300
    )

    plt.close()

    pd.DataFrame({
        "item": [
            "Predictive genes",
            "APOLLO RNA file",
            "APOLLO protein file",
            "APOLLO phosphoprotein file"
        ],
        "value": [
            len(result),
            os.path.basename(RNA_FILE),
            os.path.basename(PROTEIN_FILE),
            os.path.basename(PHOSPHO_FILE)
        ]
    }).to_csv(
        os.path.join(
            OUT,
            "CF21_provenance.tsv"
        ),
        sep="\t",
        index=False
    )

    print("\n[6/6] Final gate")

    print("""
============================================================
 CF21 COMPLETE - APOLLO MULTI-OMICS CONFIRMATION PASSED
============================================================
""")

    print("Genes evaluated:", len(result))
    print("Runtime:", round((time.time()-START)/60,2), "min")
    print("STATUS: READY_FOR_REVIEW")


if __name__ == "__main__":
    main()
