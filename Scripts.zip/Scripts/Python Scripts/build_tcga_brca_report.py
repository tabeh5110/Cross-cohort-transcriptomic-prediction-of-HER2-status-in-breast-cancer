from __future__ import annotations

import math
import os
from pathlib import Path

import pandas as pd
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


BASE = Path(r"D:\Masters\Research\TCGA_BRCA")
OUT = BASE / "reports" / "TCGA_BRCA_ML_Project_Report_Final.docx"
REPORTS = BASE / "reports"
FIG_QA = REPORTS / "report_generated_assets"
FINAL_FIG = BASE / "results" / "FINAL_PUBLICATION_FIGURES_V2"


TITLE = (
    "Development and External Validation of a Leakage-Controlled "
    "Transcriptomic Machine Learning Framework for HER2 Prediction in "
    "Breast Cancer Using TCGA-BRCA and SCAN-B with APOLLO Multi-Omics "
    "Evidence Support"
)


def read_tsv(rel: str) -> pd.DataFrame:
    return pd.read_csv(BASE / rel, sep="\t")


def read_tsv_str(rel: str) -> pd.DataFrame:
    return pd.read_csv(BASE / rel, sep="\t", dtype=str)


def summary_dict(rel: str, key_col: str | None = None, val_col: str | None = None) -> dict[str, str]:
    df = read_tsv(rel)
    if key_col is None:
        key_col = df.columns[0]
    if val_col is None:
        val_col = df.columns[1]
    return {str(k): str(v) for k, v in zip(df[key_col], df[val_col])}


def fmt_num(value: float | str, digits: int = 4) -> str:
    try:
        return f"{float(value):.{digits}f}"
    except Exception:
        return str(value)


def fmt_pct(value: float | str, digits: int = 1) -> str:
    try:
        return f"{100 * float(value):.{digits}f}%"
    except Exception:
        return str(value)


def add_field(paragraph, instr: str):
    run = paragraph.add_run()
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = instr
    fld_sep = OxmlElement("w:fldChar")
    fld_sep.set(qn("w:fldCharType"), "separate")
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_begin, instr_text, fld_sep, fld_end])


def set_cell_shading(cell, fill: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_text(cell, text: str, size: float = 8.5, bold: bool = False):
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    r = p.add_run("" if pd.isna(text) else str(text))
    r.font.name = "Times New Roman"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    r.font.size = Pt(size)
    r.bold = bold


def style_table(table, font_size: float = 8.5):
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    for row_idx, row in enumerate(table.rows):
        for cell in row.cells:
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(0)
                for r in p.runs:
                    r.font.name = "Times New Roman"
                    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
                    r.font.size = Pt(font_size)
            if row_idx == 0:
                set_cell_shading(cell, "E8EEF5")
                for p in cell.paragraphs:
                    for r in p.runs:
                        r.bold = True


def add_caption(doc: Document, label: str, number: int, caption: str):
    p = doc.add_paragraph()
    p.style = doc.styles["Caption"]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(f"{label} {number}. {caption}")
    r.font.name = "Times New Roman"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    r.font.size = Pt(9)
    r.italic = True
    return p


def add_body(doc: Document, text: str):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.15
    r = p.add_run(text)
    r.font.name = "Times New Roman"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    r.font.size = Pt(11)
    return p


def add_heading(doc: Document, text: str, level: int = 1):
    p = doc.add_heading(text, level=level)
    for r in p.runs:
        r.font.name = "Times New Roman"
        r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
        r.font.color.rgb = RGBColor(0, 0, 0)
        r.bold = True
        r.font.size = Pt(14 if level == 1 else 12)
    p.paragraph_format.space_before = Pt(12 if level == 1 else 8)
    p.paragraph_format.space_after = Pt(6 if level == 1 else 4)
    return p


def add_bullets(doc: Document, items: list[str]):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(item)
        r.font.name = "Times New Roman"
        r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
        r.font.size = Pt(11)


def add_table_from_rows(doc: Document, headers: list[str], rows: list[list[str]], caption: str, table_no: int, font_size: float = 8.5):
    add_caption(doc, "Table", table_no, caption)
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    hdr = table.rows[0].cells
    for i, h in enumerate(headers):
        set_cell_text(hdr[i], h, size=font_size, bold=True)
    for row in rows:
        cells = table.add_row().cells
        for i, val in enumerate(row):
            set_cell_text(cells[i], val, size=font_size)
    style_table(table, font_size=font_size)
    doc.add_paragraph()
    return table


def add_image(doc: Document, path: Path, caption: str, fig_no: int, width: float = 6.3):
    if not path.exists():
        print(f"WARNING: Figure missing, skipped: {path}")
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(path), width=Inches(width))
    add_caption(doc, "Figure", fig_no, caption)


def create_workflow_figure():
    FIG_QA.mkdir(parents=True, exist_ok=True)
    out = FIG_QA / "Figure1_CF1_CF25_workflow.png"
    groups = [
        ("CF1-CF5", "TCGA acquisition\nand integrity"),
        ("CF6-CF8", "RNA matrix,\nclinical harmonization,\nQC"),
        ("CF9-CF10", "Differential expression\nand pathway biology"),
        ("CF11-CF14", "SCAN-B/APOLLO\nharmonization and\npre-ML lock"),
        ("CF15-CF18", "Leakage-controlled ML,\nnested CV, final\nmodel lock"),
        ("CF19", "SCAN-B untouched\nexternal validation"),
        ("CF20-CF22", "Interpretation,\nAPOLLO evidence,\nsignature biology"),
        ("CF23-CF25", "Publication package,\nfinal archive,\nmanuscript package"),
    ]
    width, height = 2860, 760
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("arial.ttf", 34)
        font_bold = ImageFont.truetype("arialbd.ttf", 36)
        note_font = ImageFont.truetype("arial.ttf", 28)
    except Exception:
        font = ImageFont.load_default()
        font_bold = font
        note_font = font

    box_w, box_h = 285, 230
    left, gap, y = 40, 70, 210
    blue = "#1F4D78"
    fill = "#E8EEF5"
    for i, (cf, label) in enumerate(groups):
        x = left + i * (box_w + gap)
        draw.rounded_rectangle([x, y, x + box_w, y + box_h], radius=28, fill=fill, outline=blue, width=5)
        cf_bbox = draw.textbbox((0, 0), cf, font=font_bold)
        draw.text((x + (box_w - (cf_bbox[2] - cf_bbox[0])) / 2, y + 20), cf, fill="black", font=font_bold)
        lines = label.split("\n")
        line_y = y + 75
        for line in lines:
            bbox = draw.textbbox((0, 0), line, font=font)
            draw.text((x + (box_w - (bbox[2] - bbox[0])) / 2, line_y), line, fill="black", font=font)
            line_y += 40
        if i < len(groups) - 1:
            x1 = x + box_w + 8
            x2 = x + box_w + gap - 12
            yy = y + box_h // 2
            draw.line([x1, yy, x2, yy], fill=blue, width=6)
            draw.polygon([(x2, yy), (x2 - 22, yy - 14), (x2 - 22, yy + 14)], fill=blue)

    note = "No SCAN-B or APOLLO labels were accessed during TCGA model development; external data were reserved for locked validation/evidence mapping."
    bbox = draw.textbbox((0, 0), note, font=note_font)
    draw.text(((width - (bbox[2] - bbox[0])) / 2, 560), note, fill="#333333", font=note_font)
    img.save(out)
    return out


def make_panel_figure(items: list[tuple[Path, str]], out_name: str, cols: int = 2, cell_w: int = 1250, cell_h: int = 900):
    FIG_QA.mkdir(parents=True, exist_ok=True)
    rows = math.ceil(len(items) / cols)
    pad = 55
    title_h = 80
    out = FIG_QA / out_name
    canvas = Image.new("RGB", (cols * cell_w + (cols + 1) * pad, rows * cell_h + (rows + 1) * pad), "white")
    draw = ImageDraw.Draw(canvas)
    try:
        label_font = ImageFont.truetype("arialbd.ttf", 42)
    except Exception:
        label_font = ImageFont.load_default()
    for idx, (path, label) in enumerate(items):
        row, col = divmod(idx, cols)
        x0 = pad + col * (cell_w + pad)
        y0 = pad + row * (cell_h + pad)
        draw.text((x0, y0), label, fill="black", font=label_font)
        if not path.exists():
            draw.text((x0, y0 + title_h), f"Missing figure: {path.name}", fill="black", font=label_font)
            continue

        im = Image.open(path).convert("RGB")
        im.thumbnail((cell_w, cell_h - title_h), Image.LANCZOS)
        x = x0 + (cell_w - im.width) // 2
        y = y0 + title_h + (cell_h - title_h - im.height) // 2
        canvas.paste(im, (x, y))
    canvas.save(out)
    return out


def make_doc():
    REPORTS.mkdir(parents=True, exist_ok=True)
    workflow = FINAL_FIG / "Figure_1_Integrated_Computational_Workflow.png"
    if not workflow.exists():
        workflow = create_workflow_figure()
    bio_panel = make_panel_figure(
        [
            (FINAL_FIG / "Figure5_Gene_Signature_Biology_v2.png", "Figure 5. Gene signature biology"),
        ],
        "Figure2_biological_discovery_panel.png",
        cols=2,
        cell_w=1300,
        cell_h=940,
    )
    model_panel = make_panel_figure(
        [
            (FINAL_FIG / "Figure3_Model_Performance_v2.png", "Figure 3. Model performance"),
        ],
        "Figure3_model_comparison_panel.png",
        cols=2,
        cell_w=1350,
        cell_h=850,
    )
    signature_panel = make_panel_figure(
        [
            (FINAL_FIG / "Figure5_Coefficients.png", "A. Model coefficients"),
            (FINAL_FIG / "Figure5_Gene_Importance.png", "B. Gene importance"),
        ],
        "Figure4_signature_xai_panel.png",
        cols=2,
        cell_w=1250,
        cell_h=920,
    )
    scanb_panel = make_panel_figure(
        [
            (FINAL_FIG / "Figure4_SCANB_Validation_v2.png", "Figure 4. SCAN-B external validation"),
        ],
        "Figure5_scanb_validation_panel.png",
        cols=2,
        cell_w=1050,
        cell_h=900,
    )

    cf1 = summary_dict("results/CF1_duplicate_resolution_audit/CF1_summary.tsv")
    cf3 = summary_dict("results/CF3_tcga_cohort_resolution/CF3_cohort_summary.tsv")
    cf4 = summary_dict("results/CF4_gdc_acquisition_preparation/CF4_summary.tsv")
    cf5 = summary_dict("results/CF5_post_download_integrity_check/CF5_summary.tsv")
    cf6 = summary_dict("results/CF6_expression_matrix_construction/CF6_summary.tsv")
    cf7 = summary_dict("results/CF7_clinical_harmonization/CF7_summary.tsv")
    cf8 = summary_dict("results/CF8_rnaseq_quality_control/CF8_finalization_summary.tsv")
    cf9 = summary_dict("results/CF9_differential_expression/CF9_summary.tsv")
    cf10 = summary_dict("results/CF10_pathway_biology/CF10_summary.tsv")
    cf11 = summary_dict("results/CF11_scanb_acquisition_qc/CF11_summary.tsv")
    cf12 = summary_dict("results/CF12_apollo_brca1_acquisition_qc/CF12_summary.tsv")
    cf13 = summary_dict("results/CF13_cross_cohort_harmonization/CF13_summary.tsv")
    cf14 = summary_dict("results/CF14_pre_ml_manual_audit/CF14_LOCKED_summary.tsv")
    cf15 = summary_dict("results/CF15_ml_experiment_design/CF15_summary.tsv")
    cf16 = summary_dict("results/CF16_nested_cv_training/CF16_summary.tsv")
    cf16b = summary_dict("results/CF16B_exploratory_model_extension/CF16B_summary.tsv")
    cf17 = summary_dict("results/CF17_combined_model_evaluation/CF17_summary.tsv")
    cf17lock = summary_dict("results/CF17_combined_model_evaluation/CF17_LOCKED_summary.tsv")
    cf18 = summary_dict("results/CF18_stable_signature_xai_final_model/CF18_summary.tsv")
    cf19m = summary_dict("results/CF19_scanb_external_validation/CF19_metrics.tsv")
    cf19s = summary_dict("results/CF19_scanb_external_validation/CF19_summary.tsv", "item", "value")
    cf21pub = read_tsv("results/CF23_publication_package/CF23_APOLLO_confirmation_summary.tsv")
    cf22 = summary_dict("results/CF22_signature_biology/CF22_summary.tsv", "Item", "Value")

    model_perf = read_tsv("results/CF17_combined_model_evaluation/CF17_combined_model_performance.tsv")
    sig = read_tsv("results/CF18_stable_signature_xai_final_model/CF18_final_ElasticNet_features.tsv")
    sig86 = sig[sig["final_model_nonzero"] == True].copy().sort_values("final_model_importance_rank")
    apollo = read_tsv("results/CF21_apollo_multiomics_confirmation_v3/CF21v3_predictive_gene_multiomics_table.tsv")
    sig86 = sig86.merge(apollo[["gene", "Evidence_level", "RNA_support", "Protein_support", "Phospho_support"]], left_on="gene_symbol", right_on="gene", how="left")
    hallmark = read_tsv("results/CF22_signature_biology/CF22_Hallmark_enrichment.tsv")
    reactome = read_tsv("results/CF22_signature_biology/CF22_Reactome_enrichment.tsv")
    scanb_pred = read_tsv("results/CF19_scanb_external_validation/CF19_predictions.tsv")
    scanb_meta = read_tsv_str("data/processed/scanb/CF11_SCANB_primary_sample_metadata.tsv")
    scanb_y = (
        scanb_meta["characteristic_her2_status"]
        .astype(str)
        .str.lower()
        .isin(["positive", "pos", "her2 positive", "her2_positive", "1", "1.0", "yes"])
        .astype(int)
    )
    scanb_call = scanb_pred["prediction"].astype(int)
    scanb_tp = int(((scanb_y == 1) & (scanb_call == 1)).sum())
    scanb_fp = int(((scanb_y == 0) & (scanb_call == 1)).sum())
    scanb_tn = int(((scanb_y == 0) & (scanb_call == 0)).sum())
    scanb_fn = int(((scanb_y == 1) & (scanb_call == 0)).sum())
    scanb_ppv = scanb_tp / (scanb_tp + scanb_fp)
    scanb_npv = scanb_tn / (scanb_tn + scanb_fn)
    cf22_hallmark_fdr_sig = int((pd.to_numeric(hallmark["Adjusted P-value"], errors="coerce") <= 0.05).sum())
    cf22_reactome_fdr_sig = int((pd.to_numeric(reactome["Adjusted P-value"], errors="coerce") <= 0.05).sum())

    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(1)
    sec.bottom_margin = Inches(1)
    sec.left_margin = Inches(1)
    sec.right_margin = Inches(1)
    sec.header_distance = Inches(0.49)
    sec.footer_distance = Inches(0.49)

    styles = doc.styles
    styles["Normal"].font.name = "Times New Roman"
    styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    styles["Normal"].font.size = Pt(11)
    styles["Normal"].paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    styles["Normal"].paragraph_format.line_spacing = 1.15
    styles["Normal"].paragraph_format.space_after = Pt(6)
    for style_name, size in [("Heading 1", 14), ("Heading 2", 12), ("Heading 3", 12)]:
        st = styles[style_name]
        st.font.name = "Times New Roman"
        st._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
        st.font.size = Pt(size)
        st.font.bold = True
        st.font.color.rgb = RGBColor(0, 0, 0)
    styles["Caption"].font.name = "Times New Roman"
    styles["Caption"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    styles["Caption"].font.size = Pt(9)
    styles["Caption"].font.italic = True

    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("Page ")
    add_field(footer, "PAGE")

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(14)
    r = p.add_run(TITLE)
    r.font.name = "Times New Roman"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    r.font.size = Pt(14)
    r.bold = True
    add_body(doc, "Professional research report prepared for supervisor/manuscript review.")
    add_body(doc, "Project: TCGA-BRCA HER2 transcriptomic machine learning, SCAN-B external validation, and APOLLO-BRCA-1 orthogonal multi-omics evidence mapping.")
    add_body(doc, "Author/project information: Computational biology research report generated from the completed CF1-CF25 project artifacts.")
    doc.add_paragraph()
    add_heading(doc, "Table of Contents", 1)
    p = doc.add_paragraph()
    add_field(p, r'TOC \o "1-2" \h \z \u')
    doc.add_page_break()

    fig_no = 1
    table_no = 1

    add_heading(doc, "1. Executive Summary", 1)
    add_body(doc, f"This project developed and validated a transcriptomics-based HER2 prediction framework for breast cancer using TCGA-BRCA as the model-development cohort, SCAN-B/GSE96058 as an independent external validation cohort, and APOLLO-BRCA-1 as an orthogonal multi-omics evidence resource. The central objective was to build a robust gene-expression model while avoiding machine-learning leakage and then test whether the locked model generalized outside TCGA.")
    add_body(doc, f"The final leakage-controlled model was an Elastic-Net logistic regression trained on {cf18['TCGA final training samples']} TCGA tumors with definitive HER2 labels. A common one-to-one TCGA-SCAN-B gene universe of {cf15['Locked genes']} genes was transformed to within-sample percentile ranks, {cf18['Final model selected k']} genes were selected for the locked final model, and {cf18['Final model nonzero coefficients']} genes retained non-zero Elastic-Net coefficients.")
    add_body(doc, f"External validation was performed in SCAN-B without retraining or threshold optimization. The locked CF18 model achieved AUROC {fmt_num(cf19m['AUROC'])} and PR-AUC {fmt_num(cf19m['PR_AUC'])} in {cf19s['Samples']} SCAN-B samples. At the locked threshold, sensitivity was {fmt_pct(cf19m['Sensitivity'])}, specificity was {fmt_pct(cf19m['Specificity'])}, PPV was {fmt_pct(scanb_ppv)}, and NPV was {fmt_pct(scanb_npv)}.")
    add_body(doc, f"APOLLO evidence mapping supported {cf21pub.loc[cf21pub.Evidence_layer == 'RNA', 'Supported_predictive_genes'].iloc[0]} genes at RNA level, {cf21pub.loc[cf21pub.Evidence_layer == 'Protein', 'Supported_predictive_genes'].iloc[0]} at protein level, and {cf21pub.loc[cf21pub.Evidence_layer == 'Phosphoprotein', 'Supported_predictive_genes'].iloc[0]} at phosphoprotein level. The study therefore supports a biologically plausible and externally validated expression-based HER2 prediction signature, while APOLLO evidence should not be interpreted as independent predictive validation.")

    add_heading(doc, "2. Introduction", 1)
    add_body(doc, "Breast cancer is a heterogeneous disease in which molecular subtype and receptor status shape prognosis, systemic treatment selection, and clinical trial stratification. HER2 status is especially important because ERBB2/HER2 amplification or over-expression identifies tumors that may benefit from HER2-targeted therapy. Standard clinical assessment relies on immunohistochemistry and in situ hybridization, which remain essential but may be affected by tissue quality, sampling, scoring ambiguity, and inter-laboratory variation.")
    add_body(doc, "Transcriptomic profiling provides a complementary view of tumor biology. Because HER2 status is embedded in broader ERBB2 amplicon, proliferation, immune, metabolic, and signaling patterns, RNA-seq can support computational prediction and biological interpretation. However, transcriptomics-based classifiers can overstate performance if feature selection, preprocessing, thresholding, or model comparison leaks information across training and validation boundaries.")
    add_body(doc, "This project addresses those risks by separating TCGA model development from SCAN-B external validation and APOLLO multi-omics evidence mapping. The result is a multi-stage computational study that links differential expression, pathway enrichment, supervised machine learning, model interpretation, and orthogonal biological evidence.")

    add_heading(doc, "3. Research Objectives", 1)
    add_body(doc, "The primary objective was to develop and validate a robust gene-expression-based HER2 prediction model for breast cancer using TCGA-BRCA RNA-seq data and independent external validation.")
    add_bullets(doc, [
        "Identify predictive gene signatures associated with HER2 status.",
        "Avoid machine-learning leakage by locking endpoint, gene universe, preprocessing, nested cross-validation design, model roles, and final threshold before external validation.",
        "Externally validate the locked model in SCAN-B/GSE96058 without retraining or external threshold optimization.",
        "Assess biological relevance using APOLLO-BRCA-1 RNA, protein, and phosphoproteomic data.",
        "Interpret predictive biology through differential expression, Hallmark enrichment, Reactome enrichment, and model coefficients.",
    ])

    add_heading(doc, "4. Overall Computational Workflow", 1)
    add_body(doc, "The workflow was organized as auditable computational frames (CF1-CF25), beginning with TCGA acquisition and QC, progressing through biological analysis and leakage-controlled ML, and ending with SCAN-B external validation, APOLLO evidence assessment, and manuscript curation.")
    add_image(doc, workflow, "Study workflow from TCGA acquisition to leakage-controlled model development, external validation, and multi-omics interpretation.", fig_no, width=6.5)
    fig_no += 1

    leakage_fig = FINAL_FIG / "Figure_2_Leakage_Controlled_ML_Design.png"
    if leakage_fig.exists():
        add_image(doc, leakage_fig, "Leakage-controlled machine learning development framework showing training isolation, model locking, and independent SCAN-B/APOLLO evaluation.", fig_no, width=6.5)
        fig_no += 1

    add_heading(doc, "5. Dataset Description", 1)
    rows = [
        ["TCGA-BRCA", "Discovery and model development", f"{cf6['Final biological samples']} RNA-seq samples; {cf6['Final Primary Tumor samples']} primary tumors; {cf6['Final Solid Tissue Normal samples']} normals; {cf14['TCGA HER2 classifiable']} HER2-classifiable tumors", "STAR-count RNA-seq, TPM, clinical receptor labels", "DE biology, ML training, nested CV, final model locking"],
        ["SCAN-B / GSE96058", "Untouched external validation", f"{cf11['Primary biological samples']} primary biological samples; CF19 evaluated {cf19s['HER2 positives']} HER2-positive, {cf19s['HER2 negatives']} non-positive/negative-coded samples, including 122 metadata-missing HER2 records treated as non-positive by the CF19 script", "Processed gene-level RNA expression and HER2 metadata", "Independent validation of locked CF18 model"],
        ["APOLLO-BRCA-1", "Orthogonal biological evidence assessment", f"{cf12['Expected invasive breast tumor cases']} cases; {cf13['APOLLO samples present in case+RNA+protein+phospho']} complete RNA+protein+phosphoprotein cases", "RNA, protein, phosphoproteomics", "Multi-omics evidence for predictive genes; not used for ML training"],
    ]
    add_table_from_rows(doc, ["Dataset", "Purpose", "Sample number", "Data layers", "Role in study"], rows, "Dataset summary and study role.", table_no, font_size=8.5)
    table_no += 1

    add_heading(doc, "6. Computational Pipeline (CF1-CF25)", 1)
    add_body(doc, "The CF design produced a reproducible audit trail. Early CF stages defined eligible samples and data integrity; middle stages locked biological and ML design choices; later stages performed external validation, multi-omics evidence mapping, and final reporting.")
    pipeline_rows = [
        ["CF1", "Duplicate resolution audit", "Raw GDC RNA-seq manifest", "Barcode decomposition and duplicate review", f"{cf1['Records requiring duplicate review']} records reviewed", "Prevented duplicate samples from distorting downstream counts"],
        ["CF2", "Biospecimen annotation audit", "CF1 duplicate-review records", "GDC case and aliquot annotation retrieval", "Annotations and quality fields mapped to duplicate records", "Used biospecimen evidence to support selection decisions"],
        ["CF3", "TCGA cohort resolution", "CF1-CF2 audit outputs", "Eligibility rules and duplicate biological sample selection", f"{cf3['Final selected biological samples']} selected biological samples", "Defined a clean acquisition cohort"],
        ["CF4", "GDC acquisition preparation", "CF3 candidate manifest", "Manifest cross-check, disk-space and GDC release audit", f"{cf4['Official GDC manifest files']} files; {cf4['GDC release']}", "Made acquisition reproducible and versioned"],
        ["CF5", "Post-download integrity check", "Downloaded STAR-count files", "MD5, file-size, and STAR-count format validation", f"{cf5['Fully validated files']} validated files", "Established raw data integrity before expression processing"],
        ["CF6", "Expression matrix construction", "Validated STAR-count files", "Replicate resolution and matrix assembly", f"{cf6['Raw-count matrix rows']} genes x {cf6['Raw-count matrix columns']} samples", "Produced raw-count and TPM matrices"],
        ["CF7", "Clinical harmonization", "Clinical/BCR XML and CF6 samples", "Receptor conflict audit and endpoint availability analysis", f"{cf7['HER2 definitive patients']} HER2-definitive patients", "Identified HER2 as a sufficiently usable endpoint"],
        ["CF8", "RNA-seq QC", "CF6 matrices and CF7 phenotypes", "QC metrics, PCA, manual review finalization", f"{cf8['Samples retained']} samples retained", "Froze the analytical cohort without supervised feature selection"],
        ["CF9", "Differential expression", "Raw counts and tumor/normal labels", "DESeq2 primary and paired edgeR sensitivity analysis", f"{cf9['Stable cross-analysis DEGs']} stable DEGs", "Established breast-cancer transcriptomic discovery biology"],
        ["CF10", "Pathway biology", "CF9 ranked genes", "MSigDB Hallmark and Reactome GSEA", f"{cf10['Total stable cross-analysis pathways']} stable pathways", "Connected DEGs to coherent cancer pathways"],
        ["CF11", "SCAN-B acquisition/QC", "GSE96058 files", "Metadata harmonization and expression QC", f"{cf11['Primary biological samples']} primary SCAN-B samples", "Reserved independent cohort for validation"],
        ["CF12", "APOLLO acquisition/QC", "APOLLO-BRCA-1 open data", "File, MD5, and layer inventory validation", f"{cf12['Primary APOLLO evidence layers']} evidence layers", "Prepared orthogonal proteogenomic evidence data"],
        ["CF13", "Cross-cohort harmonization", "TCGA, SCAN-B, APOLLO gene maps", "One-to-one symbol crosswalk and assay-case mapping", f"{cf13['TCGA-SCANB common one-to-one symbols']} TCGA-SCAN-B genes", "Defined common feature space while avoiding batch correction leakage"],
        ["CF14", "Pre-ML manual audit", "Cohort manifests and endpoints", "Protocol lock and SHA256 manifest freezing", f"{cf14['External-validation genes']} locked genes", "Locked endpoint, samples, and external gene universe"],
        ["CF15", "ML experiment design", "Locked TCGA manifest and gene universe", "Within-sample rank matrix and nested CV setup", f"{cf15['Outer CV splits']} outer splits, {cf15['Inner CV folds']} inner folds", "Created leakage-controlled model design"],
        ["CF16", "Nested CV training", "CF15 rank matrix", "Outer/inner CV for pre-specified model families", f"{cf16['Completed outer/model jobs']} jobs", "Estimated model performance without using external data"],
        ["CF16B", "Exploratory extension", "CF15/CF16 framework", "Post-hoc exploratory model families", f"{cf16b['Completed outer/model jobs']} jobs", "Explored challengers without changing primary analysis"],
        ["CF17", "Combined model evaluation", "CF16 and CF16B outputs", "Bootstrap CIs, model ranking, role lock", f"Elastic-Net locked; LightGBM AUROC gain {cf17['Exploratory-best AUROC gain over pre-specified-best']}", "Prioritized pre-specified model despite small exploratory gain"],
        ["CF18", "Final model/signature lock", "Locked model role", "Final Elastic-Net refit, coefficient extraction, threshold calibration", f"{cf18['Final model nonzero coefficients']} non-zero genes; threshold {fmt_num(cf18['Locked calibrated probability threshold'])}", "Finalized the model before SCAN-B testing"],
        ["CF19", "SCAN-B validation", "Locked CF18 model and SCAN-B data", "No retraining; fixed threshold evaluation", f"AUROC {fmt_num(cf19m['AUROC'])}; PR-AUC {fmt_num(cf19m['PR_AUC'])}", "Tested real external generalization"],
        ["CF20", "Model interpretation", "CF18 coefficients", "Coefficient ranking and sign interpretation", "Top positive and negative predictive genes", "Made the model biologically interpretable"],
        ["CF21", "APOLLO evidence mapping", "CF18 gene list and APOLLO layers", "RNA/protein/phosphoprotein evidence mapping", "RNA 66/86, protein 39/86, phosphoprotein 15/86", "Provided orthogonal multi-omics biological support"],
        ["CF22", "Signature biology", "86-gene model signature", "Hallmark and Reactome over-representation analysis", f"{cf22['Hallmark pathways']} Hallmark; {cf22['Reactome pathways']} Reactome pathways", "Interpreted predictive genes in pathway context"],
        ["CF23", "Publication package", "CF1-CF22 final outputs", "Curated figures and summary tables", "Ready-for-manuscript package", "Consolidated report-ready evidence"],
        ["CF24", "Final archive", "Important results and figures", "Artifact consolidation", "Final archive manifest", "Preserved key results for reproducibility"],
        ["CF25", "Manuscript package", "Final archive and selected outputs", "Final figure/result selection", "FIGURES_FINAL and RESULTS_FINAL folders", "Prepared supervisor/manuscript deliverables"],
    ]
    add_table_from_rows(doc, ["CF", "Purpose", "Input", "Method", "Output", "Scientific importance"], pipeline_rows, "Computational pipeline summary across CF1-CF25.", table_no, font_size=8.0)
    table_no += 1

    add_heading(doc, "7. Biological Discovery Analysis", 1)
    add_body(doc, f"Biological discovery used tumor-versus-normal differential expression rather than making tumor-versus-normal classification the main ML claim. CF9 analyzed {cf9['Primary Tumor samples']} primary tumors and {cf9['Solid Tissue Normal samples']} solid tissue normals using DESeq2, with a paired edgeR sensitivity analysis in {cf9['Paired patients']} paired patients. At FDR {cf9['FDR threshold']} and absolute log2 fold-change {cf9['Absolute log2FC threshold']}, the primary analysis identified {cf9['Primary upregulated DEGs']} upregulated and {cf9['Primary downregulated DEGs']} downregulated genes; {cf9['Stable cross-analysis DEGs']} genes were stable across primary and paired analyses.")
    add_body(doc, f"Pathway analysis in CF10 tested {cf10['Hallmark pathways tested primary']} Hallmark and {cf10['Reactome pathways tested primary']} Reactome gene sets. The Hallmark NES correlation between primary and paired analyses was {fmt_num(cf10['Hallmark NES Spearman correlation'])}, and the Reactome NES correlation was {fmt_num(cf10['Reactome NES Spearman correlation'])}, supporting reproducible pathway-level effects.")
    add_image(doc, bio_panel, "Biological discovery and pathway analysis: CF9 primary DESeq2 tumor-versus-normal differential expression and CF10 stable Hallmark GSEA pathways.", fig_no, width=6.4)
    fig_no += 1

    add_heading(doc, "8. Machine Learning Development", 1)
    add_body(doc, f"The supervised learning task was HER2 prediction among {cf15['TCGA HER2 classifiable']} TCGA tumors with definitive HER2 labels ({cf15['TCGA HER2 positive']} positive and {cf15['TCGA HER2 negative']} negative). The feature universe was the locked TCGA-SCAN-B common one-to-one gene set of {cf15['Locked genes']} genes. Expression values were represented as within-sample percentile ranks, a design intended to reduce cross-cohort scale dependence while preserving the relative expression profile within each tumor.")
    add_body(doc, f"Nested cross-validation used {cf15['Outer CV repeats']} repeats and {cf15['Outer CV splits']} total outer evaluations, with {cf15['Inner CV folds']} inner folds for hyperparameter search. CF16 evaluated Elastic-Net logistic regression, XGBoost, and linear SVM as pre-specified primary analyses. CF16B added LightGBM, Extra Trees, ridge logistic regression, and RBF SVM as post-hoc exploratory extensions without altering the original CF16 analysis.")
    add_body(doc, "Feature selection was performed inside the model-development workflow rather than on the full external validation cohort. CF15 locked the eligible gene universe before model training. During CF16 nested cross-validation, SelectKBest feature filtering and model hyperparameters were estimated within training data for each outer evaluation, and SCAN-B/APOLLO data were not read. CF18 then refit the locked Elastic-Net workflow on the full TCGA HER2-training cohort, selected 500 genes, and produced 86 non-zero model coefficients before SCAN-B was accessed.")
    add_body(doc, "Leakage prevention was explicit: SCAN-B and APOLLO were not accessed during CF15-CF18 model development, the final model family was locked in CF17, and the final model/threshold were locked in CF18 before CF19 validation.")
    perf_rows = []
    role_map = {
        "ElasticNet_Logistic": "Primary final model",
        "XGBoost": "Pre-specified comparator",
        "Linear_SVM": "Pre-specified comparator",
        "LightGBM": "Exploratory challenger",
        "RBF_SVM": "Exploratory comparator",
        "Ridge_Logistic": "Exploratory comparator",
        "Extra_Trees": "Exploratory comparator",
    }
    for _, row in model_perf.sort_values("AUROC_rank_all7").iterrows():
        if row["model"] in ["ElasticNet_Logistic", "XGBoost", "LightGBM", "Linear_SVM", "RBF_SVM", "Ridge_Logistic"]:
            perf_rows.append([row["model"].replace("_", " "), fmt_num(row["mean_AUROC"]), fmt_num(row["mean_PR_AUC"]), role_map.get(row["model"], row["analysis_status"])])
    add_table_from_rows(doc, ["Model", "AUROC", "PR-AUC", "Role"], perf_rows, "Nested cross-validation model performance comparison from CF17.", table_no, font_size=8.5)
    table_no += 1
    add_image(doc, model_panel, "CF17 nested cross-validation model comparison across AUROC and PR-AUC.", fig_no, width=6.4)
    fig_no += 1

    add_heading(doc, "9. Final Model and Gene Signature", 1)
    add_body(doc, f"CF17 locked Elastic-Net logistic regression as the primary final model because it was the best pre-specified model by mean AUROC and had nearly identical AUROC to the best exploratory LightGBM challenger. LightGBM improved mean AUROC by only {cf17lock['LightGBM minus Elastic-Net AUROC']}, with a 95% CI of {cf17lock['LightGBM minus Elastic-Net AUROC 95% CI']}. The final CF18 model used {cf18['Final model selected k']} selected genes and retained {cf18['Final model nonzero coefficients']} non-zero coefficients.")
    add_body(doc, f"Compared with an ERBB2-only benchmark, the Elastic-Net model increased mean outer AUROC from {fmt_num(cf18['ERBB2-only mean outer AUROC'])} to {fmt_num(cf18['Elastic-Net mean outer AUROC'])}. The bootstrap AUROC difference was {fmt_num(cf18['ElasticNet minus ERBB2 AUROC bootstrap difference'])} with 95% CI {cf18['ElasticNet minus ERBB2 AUROC 95% CI']}. This supports a broader HER2-associated expression signature while also showing that the improvement over ERBB2 alone should be interpreted with uncertainty.")
    add_image(doc, signature_panel, "CF18 final Elastic-Net signature interpretation: largest standardized coefficients and feature-stability evidence.", fig_no, width=6.4)
    fig_no += 1
    sig_rows = []
    for _, row in sig86.iterrows():
        sig_rows.append([
            str(int(row["final_model_importance_rank"])),
            row["gene_symbol"],
            fmt_num(row["standardized_ElasticNet_coefficient"], 4),
            row["dominant_coefficient_sign"],
            row["stability_tier"],
            "" if pd.isna(row["Evidence_level"]) else row["Evidence_level"],
        ])
    add_table_from_rows(doc, ["Rank", "Gene", "Coefficient", "Sign", "Stability tier", "APOLLO evidence"], sig_rows, "Final 86-gene Elastic-Net predictive signature from CF18 with APOLLO evidence labels from CF21v3.", table_no, font_size=8.0)
    table_no += 1

    add_heading(doc, "10. External Validation Using SCAN-B", 1)
    add_body(doc, f"CF19 evaluated the locked CF18 Elastic-Net model in SCAN-B/GSE96058. The external validation protocol did not retrain the model, did not reselect genes, and did not optimize the threshold on SCAN-B labels. The locked calibrated probability threshold was {cf19s['Threshold']}.")
    add_body(doc, f"The CF19 evaluation table included {cf19s['Samples']} samples ({cf19s['HER2 positives']} HER2-positive and {cf19s['HER2 negatives']} non-positive/negative-coded samples). The source SCAN-B metadata contained 420 positive, 2,731 negative, and 122 missing HER2 records; the CF19 binarization treated non-positive and missing labels as class 0. This implementation detail is important when interpreting specificity and PPV.")
    add_body(doc, f"The locked model achieved AUROC {fmt_num(cf19m['AUROC'])} and PR-AUC {fmt_num(cf19m['PR_AUC'])}. At the locked threshold, sensitivity was {fmt_pct(cf19m['Sensitivity'])}, specificity was {fmt_pct(cf19m['Specificity'])}, PPV was {fmt_pct(scanb_ppv)}, and NPV was {fmt_pct(scanb_npv)}.")
    val_rows = [[
        "SCAN-B / GSE96058",
        cf19s["Samples"],
        cf19s["HER2 positives"],
        cf19s["HER2 negatives"],
        f"TP {scanb_tp}; FP {scanb_fp}; TN {scanb_tn}; FN {scanb_fn}",
        fmt_num(cf19m["AUROC"]),
        fmt_num(cf19m["PR_AUC"]),
        fmt_pct(cf19m["Sensitivity"]),
        fmt_pct(cf19m["Specificity"]),
        fmt_pct(scanb_ppv),
        fmt_pct(scanb_npv),
    ]]
    add_table_from_rows(doc, ["Cohort", "N", "HER2+", "HER2- coded", "Confusion matrix", "AUROC", "PR-AUC", "Sensitivity", "Specificity", "PPV", "NPV"], val_rows, "SCAN-B external validation performance from CF19 using the locked threshold.", table_no, font_size=7.6)
    table_no += 1
    add_image(doc, scanb_panel, "CF19 external SCAN-B validation curves for the locked CF18 Elastic-Net model.", fig_no, width=6.2)
    fig_no += 1

    add_heading(doc, "11. APOLLO Multi-Omics Evidence Analysis", 1)
    add_body(doc, "APOLLO-BRCA-1 was used as an orthogonal biological evidence resource, not as a machine-learning training or tuning dataset and not as an independent predictive validation cohort. CF21 mapped the 86 predictive genes to RNA, protein, and phosphoproteomic evidence layers.")
    add_body(doc, "The final publication package summarized support for 66/86 genes at RNA level, 39/86 at protein level, and 15/86 at phosphoprotein level. In the CF21v3 evidence categories, 27 genes were RNA-only, 24 had RNA plus protein support, 15 had RNA plus protein plus phosphoprotein support, and 20 had no APOLLO match.")
    ev_rows = [[r.Evidence_layer, r.Supported_predictive_genes] for r in cf21pub.itertuples(index=False)]
    add_table_from_rows(doc, ["Evidence layer", "Supported predictive genes"], ev_rows, "APOLLO multi-omics evidence mapped to the 86-gene signature.", table_no, font_size=8.5)
    table_no += 1
    apollo_fig = FINAL_FIG / "Figure6_APOLLO_Multiomics_v2.png"
    if apollo_fig.exists():
        add_image(doc, apollo_fig, "CF21v3 APOLLO evidence categories for the final 86 predictive genes.", fig_no, width=5.2)
        fig_no += 1
    fig_no += 1

    add_heading(doc, "12. Biological Interpretation", 1)
    add_body(doc, "The final signature contained canonical ERBB2-region and HER2-associated genes, including STARD3, MIEN1, PGAP3, GRB7, ERBB2, GSDMB, CDK12, PSMD3, and MED1, together with genes carrying negative coefficients such as FCGBP, IFNLR1, ZNF862, DCAKD, and LDLR. The coefficient pattern suggests that HER2 prediction was not driven by ERBB2 alone but by a broader expression program spanning the ERBB2 amplicon, immune/interferon-associated genes, metabolic pathways, and signaling regulators.")
    top_hallmark = "; ".join(hallmark["Term"].head(8).tolist())
    top_reactome = "; ".join(reactome["Term"].head(8).tolist())
    add_body(doc, f"CF22 returned {cf22['Hallmark pathways']} Hallmark and {cf22['Reactome pathways']} Reactome over-representation results among predictive genes; none reached FDR <= 0.05 after multiple-testing adjustment ({cf22_hallmark_fdr_sig} Hallmark and {cf22_reactome_fdr_sig} Reactome terms). Top nominal Hallmark terms included {top_hallmark}. Top nominal Reactome terms included {top_reactome}. The directly HER2-relevant Reactome signals included GRB7 events in ERBB2 signaling and signaling by ERBB2, consistent with the known biological neighborhood of HER2-amplified breast cancer, but these should be interpreted descriptively.")
    add_heading(doc, "13. Integrated Findings", 1)
    integrated_rows = [
        ["Machine learning", "Elastic-Net logistic regression locked in CF17-CF18", f"Mean outer AUROC {fmt_num(cf18['Elastic-Net mean outer AUROC'])}; PR-AUC {fmt_num(cf18['Elastic-Net mean outer PR-AUC'])}", "Model learned a reproducible HER2 expression pattern in TCGA"],
        ["External validation", "SCAN-B/GSE96058", f"AUROC {fmt_num(cf19m['AUROC'])}; PR-AUC {fmt_num(cf19m['PR_AUC'])}", "Locked model generalized to an independent cohort"],
        ["RNA evidence", "APOLLO-BRCA-1 RNA", "66/86 predictive genes", "Most model genes had transcriptomic support in APOLLO"],
        ["Protein evidence", "APOLLO-BRCA-1 proteomics", "39/86 predictive genes", "Nearly half of the signature had protein-level support"],
        ["Phosphoprotein evidence", "APOLLO-BRCA-1 phosphoproteomics", "15/86 predictive genes", "Subset linked to signaling-level evidence"],
        ["Pathway biology", "Hallmark and Reactome enrichment", f"{cf22['Hallmark pathways']} Hallmark; {cf22['Reactome pathways']} Reactome", "Biological interpretation aligned with HER2/ERBB2 and cancer signaling"],
    ]
    add_table_from_rows(doc, ["Evidence layer", "Source", "Result", "Interpretation"], integrated_rows, "Integrated evidence summary across ML validation, multi-omics evidence mapping, and pathway biology.", table_no, font_size=8.2)
    table_no += 1

    add_heading(doc, "14. Discussion", 1)
    add_body(doc, "This project is stronger than a typical single-cohort ML study because it maintained a staged audit trail from data acquisition through external validation. The ML design explicitly separated endpoint definition, feature-universe locking, rank-based preprocessing, nested cross-validation, final model selection, and threshold locking before SCAN-B evaluation. This substantially reduces the risk that external performance reflects tuning to the validation set.")
    add_body(doc, "The model choice is also scientifically conservative. Although LightGBM had the highest mean AUROC among all seven compared models, its AUROC gain over Elastic-Net was only 0.002577 and its confidence interval crossed zero. The final choice of Elastic-Net preserved the pre-specified primary-analysis framework and offered a more interpretable coefficient-based signature.")
    add_body(doc, "The external SCAN-B AUROC of 0.9186 and PR-AUC of 0.8145 support generalization despite cohort and platform differences. APOLLO evidence mapping adds biological plausibility by showing that many predictive genes are observable beyond the TCGA RNA layer, including protein and phosphoprotein evidence for subsets of the signature.")

    add_heading(doc, "15. Limitations", 1)
    add_bullets(doc, [
        "The analysis used retrospective public datasets, so prospective clinical performance remains untested.",
        "HER2 labels depend on harmonized clinical metadata and may inherit variability from source testing and reporting.",
        "SCAN-B validation was independent, but additional external cohorts would better characterize population and platform robustness.",
        "The CF19 SCAN-B endpoint implementation treated missing HER2 metadata as non-positive, which affects specificity and PPV interpretation.",
        "The locked threshold produced high sensitivity but modest specificity in SCAN-B, so clinical deployment would require calibration and decision-curve analysis for a defined use case.",
        "APOLLO evidence mapping was orthogonal and biologically valuable, but the APOLLO cohort size was limited compared with TCGA and SCAN-B.",
        "No prospective clinical testing, pathology integration, or implementation study was performed.",
    ])

    add_heading(doc, "16. Data and Code Availability", 1)
    add_body(doc, "The study used publicly available data sources: TCGA-BRCA RNA-seq and clinical data from the NCI Genomic Data Commons; SCAN-B/GSE96058 processed gene-expression and sample metadata from GEO; and APOLLO-BRCA-1 open-access proteogenomic publication files from the NCI GDC. Controlled-access APOLLO files were intentionally excluded.")
    add_body(doc, f"The final computational archive was curated in CF24 and CF25. The CF25 manuscript package contains selected final tables and figures, and all reported values in this document were derived from the CF1-CF25 result files. Reproducibility metadata include GDC Data Release 46.0, manifest checksums, protocol SHA256 hashes, stage-level provenance tables, software environment files, and model artifacts under the processed machine-learning outputs.")

    add_heading(doc, "17. Future Directions", 1)
    add_bullets(doc, [
        "Prospectively test the locked model in a clinically annotated breast cancer cohort with standardized HER2 IHC/ISH results.",
        "Evaluate decision-curve utility and threshold selection for specific clinical scenarios such as reflex testing, QC flagging, or molecular triage.",
        "Integrate transcriptomic prediction with digital pathology, copy-number features, and clinical covariates.",
        "Assess model calibration and subgroup performance by ER status, tumor subtype, treatment context, and sample-processing protocol.",
        "Develop a deployment study with locked preprocessing, versioned model artifacts, audit logging, and clinical governance review.",
    ])

    add_heading(doc, "18. Conclusion", 1)
    add_body(doc, "The TCGA-BRCA project produced a complete multi-stage, leakage-controlled, externally validated, and biologically interpreted HER2 prediction framework. The final Elastic-Net model used a locked 22,106-gene rank-based feature universe, selected 500 genes, retained 86 non-zero predictors, and achieved strong independent SCAN-B validation performance. APOLLO multi-omics evidence mapping and pathway interpretation supported the biological plausibility of the predictive signature. Overall, the work is suitable as a professional research report and provides a defensible foundation for manuscript preparation or prospective validation planning.")

    add_heading(doc, "References", 1)
    references = [
        "Slamon DJ et al. Human breast cancer: correlation of relapse and survival with amplification of the HER-2/neu oncogene. Science. 1987.",
        "Wolff AC et al. Human epidermal growth factor receptor 2 testing in breast cancer: ASCO/CAP clinical practice guideline focused update. Journal of Clinical Oncology. 2018.",
        "The Cancer Genome Atlas Network. Comprehensive molecular portraits of human breast tumours. Nature. 2012.",
        "Saal LH et al. The Sweden Cancerome Analysis Network - Breast (SCAN-B) Initiative. Genome Medicine. 2015.",
        "Brueffer C et al. Clinical value of RNA sequencing-based classifiers for prediction of the five conventional breast cancer biomarkers: a report from the population-based multicenter Sweden Cancerome Analysis Network - Breast Initiative. JCO Precision Oncology. 2018.",
        "Subramanian A et al. Gene set enrichment analysis: a knowledge-based approach for interpreting genome-wide expression profiles. Proceedings of the National Academy of Sciences. 2005.",
        "Liberzon A et al. The Molecular Signatures Database Hallmark Gene Set Collection. Cell Systems. 2015.",
        "Fabregat A et al. Reactome pathway knowledgebase. Nucleic Acids Research. 2018.",
        "Love MI, Huber W, Anders S. Moderated estimation of fold change and dispersion for RNA-seq data with DESeq2. Genome Biology. 2014.",
        "Robinson MD, McCarthy DJ, Smyth GK. edgeR: a Bioconductor package for differential expression analysis of digital gene expression data. Bioinformatics. 2010.",
        "Friedman J, Hastie T, Tibshirani R. Regularization paths for generalized linear models via coordinate descent. Journal of Statistical Software. 2010.",
        "Chen T, Guestrin C. XGBoost: A scalable tree boosting system. Proceedings of KDD. 2016.",
    ]
    for ref in references:
        p = doc.add_paragraph(style="List Number")
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(ref)
        r.font.name = "Times New Roman"
        r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
        r.font.size = Pt(10)

    # Core properties and final font pass.
    doc.core_properties.title = TITLE
    doc.core_properties.subject = "TCGA-BRCA HER2 machine learning and multi-omics project report"
    doc.core_properties.author = "Codex"
    for p in doc.paragraphs:
        for r in p.runs:
            r.font.name = "Times New Roman"
            r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    doc.save(OUT)
    return OUT


if __name__ == "__main__":
    path = make_doc()
    print(path)