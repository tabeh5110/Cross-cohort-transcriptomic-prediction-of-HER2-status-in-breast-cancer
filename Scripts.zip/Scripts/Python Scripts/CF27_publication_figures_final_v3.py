"""
CF27_publication_figures_final_v3.py

Publication-quality figure refinement.
Only redesigns Figure 1 and Figure 2.
Keeps existing Figure 3-6 from previous package.

No ML.
No retraining.
No data modification.
"""

import os
import matplotlib.pyplot as plt
from PIL import Image


BASE = r"D:\Masters\Research\TCGA_BRCA"

SRC = os.path.join(
    BASE,
    "results",
    "FINAL_PUBLICATION_FIGURES_V2"
)

OUT = os.path.join(
    BASE,
    "results",
    "FINAL_PUBLICATION_FIGURES_V3"
)

os.makedirs(OUT, exist_ok=True)


def make_box(ax, x, y, text, width=0.22, height=0.10):
    ax.text(
        x, y, text,
        ha="center",
        va="center",
        fontsize=11,
        weight="bold",
        bbox=dict(
            boxstyle="round,pad=0.5",
            linewidth=1.2
        )
    )


def arrow(ax, x1, y1, x2, y2):
    ax.annotate(
        "",
        xy=(x2, y2),
        xytext=(x1, y1),
        arrowprops=dict(
            arrowstyle="->",
            linewidth=1.5
        )
    )


def figure1():

    fig, ax = plt.subplots(figsize=(14, 6))
    ax.axis("off")

    ax.text(
        0.5, 0.95,
        "Integrated computational framework for HER2 prediction and multi-omics validation",
        ha="center",
        fontsize=15,
        weight="bold"
    )

    # phase titles
    ax.text(
        0.17, 0.82,
        "Phase I\nDiscovery & Biology",
        ha="center",
        fontsize=12,
        weight="bold"
    )

    ax.text(
        0.50, 0.82,
        "Phase II\nMachine Learning Development",
        ha="center",
        fontsize=12,
        weight="bold"
    )

    ax.text(
        0.83, 0.82,
        "Phase III\nIndependent Validation",
        ha="center",
        fontsize=12,
        weight="bold"
    )

    phase1=[
        "TCGA-BRCA\ncohort",
        "RNA\npreprocessing",
        "DEG +\npathway analysis"
    ]

    ys=[0.65,0.48,0.31]

    for t,y in zip(phase1,ys):
        make_box(ax,0.17,y,t)

    arrow(ax,0.17,0.57,0.17,0.54)
    arrow(ax,0.17,0.40,0.17,0.37)

    phase2=[
        "Nested\ncross-validation",
        "Feature\nselection",
        "Elastic-Net\nmodel lock"
    ]

    for t,y in zip(phase2,ys):
        make_box(ax,0.50,y,t)

    arrow(ax,0.50,0.57,0.50,0.54)
    arrow(ax,0.50,0.40,0.50,0.37)

    phase3=[
        "SCAN-B\nexternal validation",
        "APOLLO\nmulti-omics"
    ]

    for t,y in zip(phase3,[0.55,0.35]):
        make_box(ax,0.83,y,t)

    arrow(ax,0.27,0.48,0.39,0.48)
    arrow(ax,0.61,0.48,0.72,0.48)

    plt.savefig(
        os.path.join(OUT,"Figure1_Workflow_v3.png"),
        dpi=600,
        bbox_inches="tight"
    )
    plt.close()


def figure2():

    fig, ax = plt.subplots(figsize=(12,6))
    ax.axis("off")

    ax.text(
        0.5,0.93,
        "Leakage-controlled machine learning framework",
        ha="center",
        fontsize=15,
        weight="bold"
    )

    ax.text(
        0.28,0.80,
        "MODEL DEVELOPMENT\n(TCGA ONLY)",
        ha="center",
        fontsize=12,
        weight="bold"
    )

    left=[
        "Expression matrix",
        "Preprocessing",
        "Nested CV",
        "Feature selection",
        "Model comparison",
        "Elastic-Net\nlock"
    ]

    ys=[0.68,0.58,0.48,0.38,0.28,0.18]

    for t,y in zip(left,ys):
        make_box(ax,0.28,y,t)

    for a,b in zip(ys[:-1],ys[1:]):
        arrow(ax,0.28,a-0.05,0.28,b+0.05)

    ax.text(
        0.52,0.45,
        "MODEL\nLOCK\n\nNO INFORMATION FLOW",
        ha="center",
        va="center",
        fontsize=12,
        weight="bold",
        bbox=dict(
            boxstyle="round",
            linewidth=2
        )
    )

    make_box(
        ax,
        0.78,
        0.55,
        "SCAN-B\nExternal validation\n\nNO retraining"
    )

    make_box(
        ax,
        0.78,
        0.32,
        "APOLLO\nMulti-omics confirmation\n\nNO model change"
    )

    arrow(ax,0.38,0.18,0.68,0.55)
    arrow(ax,0.38,0.18,0.68,0.32)

    plt.savefig(
        os.path.join(OUT,"Figure2_Leakage_Control_v3.png"),
        dpi=600,
        bbox_inches="tight"
    )
    plt.close()


def copy_existing():

    names=[
        "Figure3_Model_Performance_v2.png",
        "Figure4_SCANB_Validation_v2.png",
        "Figure5_Gene_Signature_Biology_v2.png",
        "Figure6_APOLLO_Multiomics_v2.png"
    ]

    for n in names:
        src=os.path.join(SRC,n)
        if os.path.exists(src):
            Image.open(src).save(
                os.path.join(OUT,n),
                dpi=(600,600)
            )


def main():

    print("Creating CF27 v3 publication figures")

    figure1()
    figure2()
    copy_existing()

    print("Complete:")
    print(OUT)


if __name__=="__main__":
    main()
