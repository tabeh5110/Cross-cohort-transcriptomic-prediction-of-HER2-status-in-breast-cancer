from __future__ import annotations

import json
import warnings
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from scipy import stats
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_selection import SelectKBest, VarianceThreshold, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler


ROOT = Path(__file__).resolve().parents[2]
CF31 = ROOT / "CF31_gene_stability_analysis"
INPUT_DIR = CF31 / "input"
RESULTS_DIR = CF31 / "results"
FIGURES_DIR = CF31 / "figures"
METADATA_DIR = CF31 / "metadata"
LOGS_DIR = CF31 / "logs"

RANK_MATRIX = ROOT / "data" / "processed" / "ml_ready" / "CF15_TCGA_HER2_rank_matrix.npz"
MODEL_BUNDLE = ROOT / "data" / "processed" / "ml_ready" / "CF18_final_model" / "CF18_final_ElasticNet_model_bundle.joblib"
CF18_FEATURES = ROOT / "results" / "CF18_stable_signature_xai_final_model" / "CF18_final_ElasticNet_features.tsv"
CF20_COEFFICIENTS = ROOT / "results" / "CF20_model_interpretation" / "CF20_all_selected_coefficients.tsv"
CF18_SUMMARY = ROOT / "results" / "CF18_stable_signature_xai_final_model" / "CF18_summary.tsv"

N_BOOTSTRAPS = 1000
N_RANDOM_SETS = 1000
SEED = 42
N_JOBS = 4


def ensure_dirs() -> None:
    for directory in [INPUT_DIR, RESULTS_DIR, FIGURES_DIR, METADATA_DIR, LOGS_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


def read_tsv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path, sep="\t")


def count_rows(path: Path) -> int | str:
    if not path.exists():
        return "MISSING"
    if path.suffix == ".npz":
        matrix = np.load(path, allow_pickle=True)
        return int(matrix["X"].shape[0])
    try:
        return len(read_tsv(path))
    except Exception:
        return "NA"


def feature_count(path: Path) -> int | str:
    if not path.exists():
        return "MISSING"
    if path.suffix == ".npz":
        matrix = np.load(path, allow_pickle=True)
        return int(matrix["X"].shape[1])
    try:
        df = read_tsv(path)
        for column in ["gene", "gene_symbol", "Gene"]:
            if column in df.columns:
                return int(df[column].nunique())
        return int(df.shape[1])
    except Exception:
        return "NA"


def write_manifest() -> pd.DataFrame:
    rows = [
        {
            "filename": RANK_MATRIX.name,
            "path": str(RANK_MATRIX),
            "sample_count": count_rows(RANK_MATRIX),
            "feature_count": feature_count(RANK_MATRIX),
            "description": "Original locked TCGA HER2 within-sample percentile-rank training matrix used by CF18.",
        },
        {
            "filename": MODEL_BUNDLE.name,
            "path": str(MODEL_BUNDLE),
            "sample_count": "NA",
            "feature_count": feature_count(RANK_MATRIX),
            "description": "Locked CF18 model bundle used to recover preprocessing order and Elastic-Net hyperparameters.",
        },
        {
            "filename": CF18_FEATURES.name,
            "path": str(CF18_FEATURES),
            "sample_count": "NA",
            "feature_count": feature_count(CF18_FEATURES),
            "description": "Final CF18 Elastic-Net feature table with locked coefficients and original stability fields.",
        },
        {
            "filename": CF20_COEFFICIENTS.name,
            "path": str(CF20_COEFFICIENTS),
            "sample_count": "NA",
            "feature_count": feature_count(CF20_COEFFICIENTS),
            "description": "Locked CF20 coefficient table; nonzero rows define the original 86-gene signature.",
        },
        {
            "filename": CF18_SUMMARY.name,
            "path": str(CF18_SUMMARY),
            "sample_count": "NA",
            "feature_count": "NA",
            "description": "CF18 summary used for reference counts and lock-status provenance.",
        },
    ]
    manifest = pd.DataFrame(rows)
    manifest.to_csv(INPUT_DIR / "CF31_input_manifest.tsv", sep="\t", index=False)
    return manifest


def load_inputs() -> tuple[np.ndarray, np.ndarray, np.ndarray, pd.DataFrame, dict]:
    matrix = np.load(RANK_MATRIX, allow_pickle=True)
    x = matrix["X"].astype(np.float32)
    y = matrix["y"].astype(np.int8)
    genes = matrix["gene_symbols"].astype(str)
    cf20 = read_tsv(CF20_COEFFICIENTS)
    cf20["coefficient"] = pd.to_numeric(cf20["coefficient"], errors="coerce").fillna(0.0)
    bundle = joblib.load(MODEL_BUNDLE)
    return x, y, genes, cf20, bundle


def write_model_reproducibility(bundle: dict) -> pd.DataFrame:
    hyper = bundle["final_hyperparameters"]
    rows = [
        {"Setting": "Algorithm", "Value": bundle["primary_model_family"], "Source": str(MODEL_BUNDLE)},
        {"Setting": "Rank representation", "Value": bundle["rank_representation"], "Source": str(MODEL_BUNDLE)},
        {"Setting": "Variance filter", "Value": "VarianceThreshold(threshold=0)", "Source": str(MODEL_BUNDLE)},
        {"Setting": "Scaler", "Value": "StandardScaler fitted within each bootstrap resample", "Source": str(MODEL_BUNDLE)},
        {"Setting": "Feature selection", "Value": f"SelectKBest(f_classif, k={hyper['k']})", "Source": str(MODEL_BUNDLE)},
        {"Setting": "Regularization C", "Value": hyper["C"], "Source": str(MODEL_BUNDLE)},
        {"Setting": "Elastic-Net l1_ratio", "Value": hyper["l1_ratio"], "Source": str(MODEL_BUNDLE)},
        {"Setting": "Class weighting", "Value": "balanced", "Source": str(MODEL_BUNDLE)},
        {"Setting": "Solver", "Value": "saga", "Source": str(MODEL_BUNDLE)},
        {"Setting": "Max iterations", "Value": 5000, "Source": str(MODEL_BUNDLE)},
        {"Setting": "Tolerance", "Value": 0.001, "Source": str(MODEL_BUNDLE)},
        {"Setting": "Bootstrap iterations", "Value": N_BOOTSTRAPS, "Source": "CF31 protocol"},
        {"Setting": "External cohorts used", "Value": "None", "Source": "CF31 protocol"},
        {"Setting": "Threshold optimization", "Value": "None", "Source": "CF31 protocol"},
    ]
    reproducibility = pd.DataFrame(rows)
    reproducibility.to_csv(METADATA_DIR / "CF31_model_reproducibility.tsv", sep="\t", index=False)
    reproducibility.to_csv(RESULTS_DIR / "CF31_model_reproducibility.tsv", sep="\t", index=False)
    return reproducibility


def bootstrap_fit(
    iteration: int,
    x: np.ndarray,
    y: np.ndarray,
    genes: np.ndarray,
    k: int,
    c_value: float,
    l1_ratio: float,
) -> tuple[int, np.ndarray, bool]:
    rng = np.random.default_rng(SEED + iteration)
    sample_idx = rng.choice(x.shape[0], size=x.shape[0], replace=True)
    xb = x[sample_idx]
    yb = y[sample_idx]

    variance = VarianceThreshold(threshold=0)
    xb_var = variance.fit_transform(xb)
    var_support = variance.get_support()

    scaler = StandardScaler()
    xb_scaled = scaler.fit_transform(xb_var)

    selector = SelectKBest(score_func=f_classif, k=min(k, xb_scaled.shape[1]))
    xb_selected = selector.fit_transform(xb_scaled, yb)
    selected_after_var = np.flatnonzero(var_support)[selector.get_support()]

    model = LogisticRegression(
        penalty="elasticnet",
        solver="saga",
        l1_ratio=l1_ratio,
        C=c_value,
        class_weight="balanced",
        max_iter=5000,
        tol=0.001,
        random_state=20260815 + iteration,
    )
    converged = True
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", ConvergenceWarning)
        model.fit(xb_selected, yb)
        if any(issubclass(w.category, ConvergenceWarning) for w in caught):
            converged = False

    full_coef = np.zeros(len(genes), dtype=np.float32)
    full_coef[selected_after_var] = model.coef_.ravel().astype(np.float32)
    return iteration, full_coef, converged


def run_bootstraps(x: np.ndarray, y: np.ndarray, genes: np.ndarray, bundle: dict) -> tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    coef_path = RESULTS_DIR / "CF31_bootstrap_gene_coefficient_matrix.tsv"
    sel_path = RESULTS_DIR / "CF31_bootstrap_gene_selection_matrix.tsv"
    summary_path = RESULTS_DIR / "CF31_bootstrap_iteration_summary.tsv"
    if coef_path.exists() and sel_path.exists() and summary_path.exists():
        coefficients = pd.read_csv(coef_path, sep="\t").drop(columns=["Gene"]).to_numpy(dtype=np.float32)
        selections = pd.read_csv(sel_path, sep="\t").drop(columns=["Gene"]).to_numpy(dtype=np.int8)
        summary = pd.read_csv(summary_path, sep="\t")
        return coefficients, selections, summary

    hyper = bundle["final_hyperparameters"]
    tasks = Parallel(n_jobs=N_JOBS, backend="loky", verbose=10, max_nbytes="20M", temp_folder=str(LOGS_DIR))(
        delayed(bootstrap_fit)(
            i,
            x,
            y,
            genes,
            int(hyper["k"]),
            float(hyper["C"]),
            float(hyper["l1_ratio"]),
        )
        for i in range(1, N_BOOTSTRAPS + 1)
    )
    tasks = sorted(tasks, key=lambda item: item[0])
    coefficients = np.column_stack([item[1] for item in tasks]).astype(np.float32)
    selections = (np.abs(coefficients) > 1e-9).astype(np.int8)
    summary = pd.DataFrame(
        {
            "Bootstrap": [item[0] for item in tasks],
            "Selected_nonzero_genes": selections.sum(axis=0),
            "Converged_without_warning": [item[2] for item in tasks],
        }
    )

    columns = [f"Bootstrap_{i}" for i in range(1, N_BOOTSTRAPS + 1)]
    pd.DataFrame(selections, columns=columns).insert(0, "Gene", genes)
    selection_df = pd.DataFrame(selections, columns=columns)
    selection_df.insert(0, "Gene", genes)
    selection_df.to_csv(sel_path, sep="\t", index=False)

    coef_df = pd.DataFrame(coefficients, columns=columns)
    coef_df.insert(0, "Gene", genes)
    coef_df.to_csv(coef_path, sep="\t", index=False, float_format="%.7g")
    summary.to_csv(summary_path, sep="\t", index=False)
    return coefficients, selections, summary


def direction_consistency(row: np.ndarray) -> tuple[str, float]:
    nonzero = row[np.abs(row) > 1e-9]
    if len(nonzero) == 0:
        return "Not_selected", 0.0
    pos = int((nonzero > 0).sum())
    neg = int((nonzero < 0).sum())
    if pos >= neg:
        return "Positive", pos / len(nonzero)
    return "Negative", neg / len(nonzero)


def calculate_stability(genes: np.ndarray, coefficients: np.ndarray, selections: np.ndarray) -> pd.DataFrame:
    selection_frequency = selections.mean(axis=1)
    mean_coefficient = coefficients.mean(axis=1)
    coefficient_sd = coefficients.std(axis=1, ddof=1)
    directions = []
    consistencies = []
    for row in coefficients:
        label, consistency = direction_consistency(row)
        directions.append(label)
        consistencies.append(consistency)
    stability = pd.DataFrame(
        {
            "Gene": genes,
            "Selection_frequency": selection_frequency,
            "Mean_coefficient": mean_coefficient,
            "Coefficient_SD": coefficient_sd,
            "Direction": directions,
            "Direction_consistency": consistencies,
        }
    ).sort_values(["Selection_frequency", "Mean_coefficient", "Gene"], ascending=[False, False, True])
    stability.to_csv(RESULTS_DIR / "CF31_gene_stability.tsv", sep="\t", index=False)
    return stability


def category(freq: float) -> str:
    if freq >= 0.90:
        return "CORE_STABLE"
    if freq >= 0.50:
        return "CONSISTENT"
    return "VARIABLE"


def write_categories(stability: pd.DataFrame) -> pd.DataFrame:
    categories = stability[["Gene", "Selection_frequency"]].copy()
    categories["Category"] = categories["Selection_frequency"].map(category)
    categories.to_csv(RESULTS_DIR / "CF31_stability_categories.tsv", sep="\t", index=False)
    return categories


def original_signature_genes(cf20: pd.DataFrame) -> list[str]:
    return cf20.loc[pd.to_numeric(cf20["coefficient"], errors="coerce").fillna(0.0) != 0, "gene"].astype(str).tolist()


def write_signature_overlap(stability: pd.DataFrame, categories: pd.DataFrame, cf20: pd.DataFrame) -> pd.DataFrame:
    original = set(original_signature_genes(cf20))
    overlap = stability[["Gene", "Selection_frequency"]].merge(categories[["Gene", "Category"]], on="Gene", how="left")
    overlap["Original_signature"] = overlap["Gene"].isin(original)
    overlap = overlap[["Gene", "Original_signature", "Selection_frequency", "Category"]]
    overlap.to_csv(RESULTS_DIR / "CF31_signature_overlap.tsv", sep="\t", index=False)

    retained = int(((overlap["Original_signature"]) & (overlap["Category"] != "VARIABLE")).sum())
    unstable_removed = int(((overlap["Original_signature"]) & (overlap["Category"] == "VARIABLE")).sum())
    summary = pd.DataFrame(
        [
            {"Metric": "Original_signature_genes", "Value": len(original)},
            {"Metric": "Original_genes_retained_CORE_or_CONSISTENT", "Value": retained},
            {"Metric": "Original_unstable_VARIABLE_genes", "Value": unstable_removed},
            {"Metric": "Original_CORE_STABLE_genes", "Value": int(((overlap["Original_signature"]) & (overlap["Category"] == "CORE_STABLE")).sum())},
        ]
    )
    summary.to_csv(RESULTS_DIR / "CF31_signature_overlap_summary.tsv", sep="\t", index=False)
    return overlap


def write_core_and_top(stability: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    core = stability[stability["Selection_frequency"] >= 0.90].copy()
    core.to_csv(RESULTS_DIR / "CF31_core_stable_signature.tsv", sep="\t", index=False)

    top = stability.copy()
    top["Stability_x_abs_coefficient"] = top["Selection_frequency"] * top["Mean_coefficient"].abs()
    top = top.sort_values(["Stability_x_abs_coefficient", "Selection_frequency"], ascending=[False, False]).head(20)
    top.to_csv(RESULTS_DIR / "CF31_top_stable_genes.tsv", sep="\t", index=False)
    return core, top


def random_comparison(stability: pd.DataFrame, original_genes: list[str]) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    freq = stability.set_index("Gene")["Selection_frequency"]
    genes = freq.index.to_numpy()
    observed = float(freq.loc[original_genes].mean())
    random_values = []
    for i in range(N_RANDOM_SETS):
        sampled = rng.choice(genes, size=len(original_genes), replace=False)
        random_values.append(float(freq.loc[sampled].mean()))
    random_values = np.array(random_values)
    comparison = pd.DataFrame(
        [
            {
                "Metric": "Mean_selection_frequency",
                "Observed_original_signature": observed,
                "Random_mean": random_values.mean(),
                "Random_SD": random_values.std(ddof=1),
                "Observed_percentile": stats.percentileofscore(random_values, observed, kind="weak"),
                "Empirical_p_value_random_ge_observed": (int((random_values >= observed).sum()) + 1) / (N_RANDOM_SETS + 1),
                "Random_sets": N_RANDOM_SETS,
            }
        ]
    )
    comparison.to_csv(RESULTS_DIR / "CF31_random_stability_comparison.tsv", sep="\t", index=False)
    pd.DataFrame({"Random_set": np.arange(1, N_RANDOM_SETS + 1), "Mean_selection_frequency": random_values}).to_csv(
        RESULTS_DIR / "CF31_random_stability_distribution.tsv", sep="\t", index=False
    )
    return comparison


def make_figures(stability: pd.DataFrame, categories: pd.DataFrame, original_genes: list[str]) -> None:
    signature = stability[stability["Gene"].isin(original_genes)].copy()
    signature = signature.sort_values("Selection_frequency", ascending=False)
    colors = signature["Selection_frequency"].map(lambda x: "#b13f3f" if x >= 0.90 else ("#d08c27" if x >= 0.50 else "#6f8fb3"))
    fig, ax = plt.subplots(figsize=(13, 6))
    ax.bar(np.arange(len(signature)), signature["Selection_frequency"], color=colors)
    ax.axhline(0.90, color="#444444", linestyle="--", linewidth=1)
    ax.axhline(0.50, color="#777777", linestyle=":", linewidth=1)
    ax.set_xticks(np.arange(len(signature)))
    ax.set_xticklabels(signature["Gene"], rotation=90, fontsize=7)
    ax.set_ylabel("Selection frequency")
    ax.set_title("CF31 bootstrap selection frequency across original 86-gene signature")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF31_gene_selection_frequency.png", dpi=300)
    plt.close(fig)

    counts = categories[categories["Gene"].isin(original_genes)]["Category"].value_counts().reindex(
        ["CORE_STABLE", "CONSISTENT", "VARIABLE"], fill_value=0
    )
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.bar(counts.index, counts.values, color=["#b13f3f", "#d08c27", "#6f8fb3"])
    ax.set_ylabel("Original signature genes")
    ax.set_title("CF31 stability category distribution")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF31_stability_category_distribution.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 6))
    plot_df = stability[stability["Gene"].isin(original_genes)].copy()
    ax.scatter(plot_df["Mean_coefficient"], plot_df["Selection_frequency"], c="#4c78a8", alpha=0.8, edgecolor="white")
    for row in plot_df.sort_values("Selection_frequency", ascending=False).head(20).itertuples(index=False):
        ax.text(row.Mean_coefficient, row.Selection_frequency, row.Gene, fontsize=7)
    ax.axhline(0.90, color="#444444", linestyle="--", linewidth=1)
    ax.axhline(0.50, color="#777777", linestyle=":", linewidth=1)
    ax.axvline(0, color="#999999", linewidth=0.8)
    ax.set_xlabel("Mean bootstrap coefficient")
    ax.set_ylabel("Selection frequency")
    ax.set_title("CF31 coefficient stability")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF31_coefficient_stability.png", dpi=300)
    plt.close(fig)


def write_report(
    reproducibility: pd.DataFrame,
    stability: pd.DataFrame,
    categories: pd.DataFrame,
    overlap: pd.DataFrame,
    core: pd.DataFrame,
    top: pd.DataFrame,
    random_stats: pd.DataFrame,
    iteration_summary: pd.DataFrame,
) -> None:
    original = overlap[overlap["Original_signature"]].copy()
    original_core = original[original["Category"] == "CORE_STABLE"]
    original_consistent = original[original["Category"] == "CONSISTENT"]
    original_variable = original[original["Category"] == "VARIABLE"]
    convergence_rate = float(iteration_summary["Converged_without_warning"].mean())
    core_names = "; ".join(original_core.sort_values("Selection_frequency", ascending=False)["Gene"].tolist())
    top_names = "; ".join(top["Gene"].head(20).tolist())

    report = f"""# CF31 Formal Gene Stability Analysis of the HER2 Predictive Signature

## Objective
CF31 quantifies feature selection stability and coefficient reproducibility for the locked HER2 Elastic-Net model. The locked CF18 model remains unchanged; CF31 evaluates feature reliability only.

## Reviewer Concern
The analysis addresses whether the 86-gene predictive signature is consistently selected across different TCGA training samples or whether genes may be artifacts of one fitting instance.

## Model Settings
The bootstrap framework reproduced the saved CF18 settings: within-sample percentile-rank TCGA matrix, `VarianceThreshold(0)`, `StandardScaler`, `SelectKBest(f_classif, k=500)`, Elastic-Net logistic regression with `C=0.01`, `l1_ratio=0.25`, `class_weight='balanced'`, `solver='saga'`, `max_iter=5000`, and `tol=0.001`. Full settings are saved in `metadata/CF31_model_reproducibility.tsv`.

## Bootstrap Procedure
CF31 performed {N_BOOTSTRAPS} TCGA-only bootstrap iterations. Each iteration sampled the 938 TCGA training patients with replacement, refit preprocessing and Elastic-Net model components, and recorded nonzero model coefficients as selected genes. No external cohort, SCAN-B data, threshold optimization, or model-performance tuning was used.

## Stability Results
Across all genes, {len(core)} met the CORE_STABLE threshold of selection frequency >= 0.90. Within the original 86-gene signature, {len(original_core)} were CORE_STABLE, {len(original_consistent)} were CONSISTENT, and {len(original_variable)} were VARIABLE. Bootstrap convergence without warning occurred in {convergence_rate:.1%} of iterations.

## Core Genes Identified
Original-signature CORE_STABLE genes: {core_names}

Top stability-weighted genes: {top_names}

## Comparison With Original Signature
The original signature remains the reference model. CF31 does not remove genes from the locked model; it identifies reproducible components for interpretation and for downstream CF32-style compact-panel refinement.

## Random Stability Comparison
The original 86-gene signature mean selection frequency was {random_stats['Observed_original_signature'].iloc[0]:.4f}, compared with a random-set mean of {random_stats['Random_mean'].iloc[0]:.4f} across {N_RANDOM_SETS} equal-size random gene sets. Empirical p-value for random >= observed was {random_stats['Empirical_p_value_random_ge_observed'].iloc[0]:.4g}.

## Implications for CF32
CF32 should treat CF31 stability as evidence of reproducibility, not mechanism. Stable genes can prioritize reduced signatures only when combined with model contribution, biological/network evidence, and performance retention.
"""
    (CF31 / "CF31_report.md").write_text(report, encoding="utf-8")

    paragraph = (
        "To evaluate robustness of the identified transcriptomic signature, bootstrap-based feature stability analysis "
        f"was performed using {N_BOOTSTRAPS} repeated Elastic-Net model fits on TCGA training resamples. "
        f"{len(original_core)} of the original 86 genes demonstrated CORE_STABLE selection frequency (>=0.90), "
        "identifying a high-confidence reproducible subset for subsequent signature refinement. Stability was interpreted "
        "as evidence of reproducible feature selection rather than biological mechanism."
    )
    (RESULTS_DIR / "CF31_manuscript_paragraph.txt").write_text(paragraph + "\n", encoding="utf-8")


def write_qc(iteration_summary: pd.DataFrame) -> pd.DataFrame:
    required_outputs = [
        "CF31_bootstrap_gene_selection_matrix.tsv",
        "CF31_bootstrap_gene_coefficient_matrix.tsv",
        "CF31_gene_stability.tsv",
        "CF31_stability_categories.tsv",
        "CF31_signature_overlap.tsv",
        "CF31_core_stable_signature.tsv",
        "CF31_top_stable_genes.tsv",
        "CF31_random_stability_comparison.tsv",
    ]
    rows = [
        {
            "QC_check": "Same CF18 model framework used",
            "Status": "PASS",
            "Details": "CF31 uses the locked CF15 rank matrix and CF18 hyperparameters/preprocessing order.",
        },
        {
            "QC_check": "No external cohort used",
            "Status": "PASS",
            "Details": "Only TCGA rank matrix and locked model metadata are used for bootstrap fitting.",
        },
        {
            "QC_check": "No SCAN-B tuning",
            "Status": "PASS",
            "Details": "No SCAN-B files are read by the CF31 script.",
        },
        {
            "QC_check": "No threshold optimization",
            "Status": "PASS",
            "Details": "CF31 estimates gene stability and does not calculate classification thresholds.",
        },
        {
            "QC_check": "Bootstrap iterations completed",
            "Status": "PASS" if len(iteration_summary) == N_BOOTSTRAPS else "FAIL",
            "Details": f"{len(iteration_summary)}/{N_BOOTSTRAPS} bootstrap iterations recorded.",
        },
        {
            "QC_check": "All intermediate and final outputs saved",
            "Status": "PASS" if all((RESULTS_DIR / name).exists() for name in required_outputs) else "FAIL",
            "Details": "; ".join(required_outputs),
        },
    ]
    qc = pd.DataFrame(rows)
    qc.to_csv(RESULTS_DIR / "CF31_quality_control_checks.tsv", sep="\t", index=False)
    return qc


def main() -> int:
    ensure_dirs()
    log_path = LOGS_DIR / "CF31_run.log"
    with log_path.open("w", encoding="utf-8") as log:
        def log_line(message: str) -> None:
            print(message)
            log.write(message + "\n")
            log.flush()

        log_line("CF31 gene stability analysis started.")
        manifest = write_manifest()
        x, y, genes, cf20, bundle = load_inputs()
        reproducibility = write_model_reproducibility(bundle)
        log_line(f"Loaded TCGA rank matrix: {x.shape[0]} samples x {x.shape[1]} genes.")
        log_line(f"Running {N_BOOTSTRAPS} bootstrap Elastic-Net fits with {N_JOBS} workers.")
        coefficients, selections, iteration_summary = run_bootstraps(x, y, genes, bundle)
        log_line("Bootstrap fitting complete.")

        stability = calculate_stability(genes, coefficients, selections)
        categories = write_categories(stability)
        overlap = write_signature_overlap(stability, categories, cf20)
        core, top = write_core_and_top(stability)
        random_stats = random_comparison(stability, original_signature_genes(cf20))
        make_figures(stability, categories, original_signature_genes(cf20))
        qc = write_qc(iteration_summary)
        write_report(reproducibility, stability, categories, overlap, core, top, random_stats, iteration_summary)

        if (qc["Status"] == "FAIL").any():
            log_line("CF31 completed with QC failure.")
            return 1
        log_line("CF31 completed successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
