from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit, logit
from scipy.stats import norm, pearsonr, spearmanr
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    precision_recall_curve,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


ROOT = Path(__file__).resolve().parents[2]
CF32_5 = ROOT / "CF32_5_ERBB2_benchmarking"
INPUT_DIR = CF32_5 / "input"
RESULTS_DIR = CF32_5 / "results"
FIGURES_DIR = CF32_5 / "figures"
METADATA_DIR = CF32_5 / "metadata"
LOGS_DIR = CF32_5 / "logs"

TCGA_RANK_MATRIX = ROOT / "data" / "processed" / "ml_ready" / "CF15_TCGA_HER2_rank_matrix.npz"
SCANB_EXPRESSION = ROOT / "data" / "processed" / "scanb" / "CF11_SCANB_primary_expression.tsv.gz"
SCANB_METADATA = ROOT / "data" / "processed" / "scanb" / "CF11_SCANB_primary_sample_metadata.tsv"
CF32_FINAL_SIGNATURE = ROOT / "CF32_minimal_HER2_signature_development" / "results" / "CF32_final_minimal_signature.tsv"
CF18_FEATURES = ROOT / "results" / "CF18_stable_signature_xai_final_model" / "CF18_final_ElasticNet_features.tsv"
CF20_COEFFICIENTS = ROOT / "results" / "CF20_model_interpretation" / "CF20_all_selected_coefficients.tsv"
CF18_TCGA_OOF = ROOT / "results" / "CF18_stable_signature_xai_final_model" / "CF18_TCGA_OOF_calibrated_predictions.tsv"
CF19_SCANB_PREDICTIONS = ROOT / "results" / "CF19_scanb_external_validation" / "CF19_predictions.tsv"
CF19_SCANB_METRICS = ROOT / "results" / "CF19_scanb_external_validation" / "CF19_metrics.tsv"
CF30_5_CENTRALITY = ROOT / "CF30_5_network_biology_validation" / "results" / "CF30_5_gene_centrality.tsv"
CF30_5_MODULES = ROOT / "CF30_5_network_biology_validation" / "results" / "CF30_5_network_modules.tsv"

SEED = 20260815
LOCKED_THRESHOLD = 0.4345288894526921
MINIMAL_GENES = ["STARD3", "PGAP3", "MIEN1", "PSMD3", "MED1", "CDK12", "MIR4728", "GSDMB", "FBXL20", "FCGBP"]
BIOLOGY_GENES = ["STARD3", "PGAP3", "MIEN1", "GSDMB", "PSMD3"]


def ensure_dirs() -> None:
    for directory in [INPUT_DIR, RESULTS_DIR, FIGURES_DIR, METADATA_DIR, LOGS_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


def read_tsv(path: Path, **kwargs) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path, sep="\t", **kwargs)


def load_original_signature() -> list[str]:
    coeff = read_tsv(CF20_COEFFICIENTS)
    coeff["coefficient"] = pd.to_numeric(coeff["coefficient"], errors="coerce").fillna(0.0)
    genes = coeff.loc[coeff["coefficient"] != 0, "gene"].astype(str).tolist()
    if len(genes) != 86:
        raise RuntimeError(f"Expected 86 nonzero original genes, observed {len(genes)}.")
    return genes


def load_minimal_signature() -> list[str]:
    final = read_tsv(CF32_FINAL_SIGNATURE)
    genes = final["Gene"].astype(str).tolist()
    if genes != MINIMAL_GENES:
        raise RuntimeError("CF32 final signature does not match the expected revised 10-gene panel.")
    return genes


def load_tcga_rank_features(genes: list[str]) -> tuple[pd.DataFrame, pd.Series]:
    matrix = np.load(TCGA_RANK_MATRIX, allow_pickle=True)
    all_genes = matrix["gene_symbols"].astype(str)
    gene_index = {gene: idx for idx, gene in enumerate(all_genes)}
    missing = sorted(set(genes) - set(gene_index))
    if missing:
        raise RuntimeError(f"Genes missing from locked TCGA rank matrix: {missing}")
    indices = [gene_index[gene] for gene in genes]
    x = pd.DataFrame(matrix["X"][:, indices], index=matrix["sample_ids"].astype(str), columns=genes)
    x.index.name = "sample_id"
    y = pd.Series(matrix["y"].astype(int), index=x.index, name="y")
    return x, y


def load_scanb_rank_features(genes: list[str]) -> tuple[pd.DataFrame, pd.Series]:
    matrix = np.load(TCGA_RANK_MATRIX, allow_pickle=True)
    locked_genes = matrix["gene_symbols"].astype(str)
    expr = read_tsv(SCANB_EXPRESSION).drop_duplicates("gene_id").set_index("gene_id")
    locked = pd.DataFrame(0.0, index=locked_genes, columns=expr.columns, dtype=np.float32)
    available = sorted(set(locked_genes).intersection(expr.index.astype(str)))
    locked.loc[available] = expr.loc[available].astype(np.float32)
    ranked = locked.rank(axis=0, pct=True).astype(np.float32)
    x = ranked.loc[genes].T
    x.index.name = "sample_id"

    metadata = read_tsv(SCANB_METADATA)
    metadata = metadata.dropna(subset=["characteristic_her2_status"]).copy()
    metadata["y"] = metadata["characteristic_her2_status"].astype(float).astype(int)
    metadata = metadata.drop_duplicates("sample_title")
    common = x.index.intersection(metadata["sample_title"])
    x = x.loc[common].copy()
    y = metadata.set_index("sample_title").loc[common, "y"].astype(int)
    return x, y


def make_model() -> object:
    return make_pipeline(
        StandardScaler(),
        LogisticRegression(
            penalty="elasticnet",
            solver="saga",
            l1_ratio=0.25,
            C=0.01,
            class_weight="balanced",
            max_iter=5000,
            tol=0.001,
            random_state=SEED,
        ),
    )


def tcga_oof_predictions(x: pd.DataFrame, y: pd.Series) -> np.ndarray:
    cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=3, random_state=SEED)
    predictions = np.zeros((len(y), 3), dtype=float)
    counts = np.zeros(len(y), dtype=int)
    for split_id, (train_idx, test_idx) in enumerate(cv.split(x, y), start=1):
        model = make_model()
        model.fit(x.iloc[train_idx], y.iloc[train_idx])
        proba = model.predict_proba(x.iloc[test_idx])[:, 1]
        repeat_idx = (split_id - 1) // 5
        predictions[test_idx, repeat_idx] = proba
        counts[test_idx] += 1
    if not np.all(counts == 3):
        raise RuntimeError("Unexpected TCGA OOF prediction coverage.")
    return predictions.mean(axis=1)


def binary_metrics(y_true: np.ndarray, y_score: np.ndarray, threshold: float) -> dict[str, float]:
    y_pred = (y_score >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "Sensitivity": tp / (tp + fn) if (tp + fn) else np.nan,
        "Specificity": tn / (tn + fp) if (tn + fp) else np.nan,
        "PPV": tp / (tp + fp) if (tp + fp) else np.nan,
        "NPV": tn / (tn + fn) if (tn + fn) else np.nan,
    }


def load_original_reference_predictions() -> tuple[pd.DataFrame, pd.DataFrame, float]:
    tcga = read_tsv(CF18_TCGA_OOF)
    tcga_out = pd.DataFrame(
        {
            "sample_id": tcga["patient_id"].astype(str),
            "y_true": tcga["y_true"].astype(int),
            "probability": pd.to_numeric(tcga["calibrated_oof_probability"], errors="coerce"),
        }
    )

    scanb_pred = read_tsv(CF19_SCANB_PREDICTIONS)
    scanb_meta = read_tsv(SCANB_METADATA)
    scanb_meta = scanb_meta.dropna(subset=["characteristic_her2_status"]).copy()
    scanb_meta["y_true"] = scanb_meta["characteristic_her2_status"].astype(float).astype(int)
    scanb = scanb_pred.merge(scanb_meta[["sample_title", "y_true"]], left_on="sample_id", right_on="sample_title", how="inner")
    metrics = read_tsv(CF19_SCANB_METRICS)
    metric_values = dict(zip(metrics["metric"], pd.to_numeric(metrics["value"], errors="coerce")))
    threshold = float(metric_values.get("Threshold", LOCKED_THRESHOLD))
    scanb_out = pd.DataFrame(
        {
            "sample_id": scanb["sample_id"].astype(str),
            "y_true": scanb["y_true"].astype(int),
            "probability": pd.to_numeric(scanb["HER2_probability"], errors="coerce"),
        }
    )
    return tcga_out, scanb_out, threshold


def evaluate_reconstructed_model(
    model_name: str,
    genes: list[str],
    x_tcga_all: pd.DataFrame,
    y_tcga: pd.Series,
    x_scanb_all: pd.DataFrame,
    y_scanb: pd.Series,
) -> tuple[dict[str, object], pd.DataFrame, pd.DataFrame]:
    x_tcga = x_tcga_all[genes].copy()
    x_scanb = x_scanb_all[genes].copy()
    oof = tcga_oof_predictions(x_tcga, y_tcga)
    model = make_model()
    model.fit(x_tcga, y_tcga)
    scanb_score = model.predict_proba(x_scanb)[:, 1]
    bmetrics = binary_metrics(y_scanb.to_numpy(), scanb_score, LOCKED_THRESHOLD)
    row = {
        "Model": model_name,
        "Number_of_genes": len(genes),
        "TCGA_AUROC": roc_auc_score(y_tcga, oof),
        "TCGA_PR_AUC": average_precision_score(y_tcga, oof),
        "SCANB_AUROC": roc_auc_score(y_scanb, scanb_score),
        "SCANB_PR_AUC": average_precision_score(y_scanb, scanb_score),
        "Sensitivity": bmetrics["Sensitivity"],
        "Specificity": bmetrics["Specificity"],
        "PPV": bmetrics["PPV"],
        "NPV": bmetrics["NPV"],
        "Threshold_used": LOCKED_THRESHOLD,
        "Feature_source": "Locked rank-space reconstruction from CF15 TCGA and SCAN-B transformed to the same 22106-gene percentile-rank universe.",
    }
    tcga_pred = pd.DataFrame({"sample_id": x_tcga.index, "y_true": y_tcga.to_numpy(), "probability": oof})
    scanb_pred = pd.DataFrame({"sample_id": x_scanb.index, "y_true": y_scanb.to_numpy(), "probability": scanb_score})
    return row, tcga_pred, scanb_pred


def model_metrics_from_reference(
    tcga_pred: pd.DataFrame,
    scanb_pred: pd.DataFrame,
    threshold: float,
    official_scanb_metrics: bool = True,
) -> dict[str, object]:
    bmetrics = binary_metrics(scanb_pred["y_true"].to_numpy(), scanb_pred["probability"].to_numpy(), threshold)
    scanb_metrics = read_tsv(CF19_SCANB_METRICS)
    metric_values = dict(zip(scanb_metrics["metric"], pd.to_numeric(scanb_metrics["value"], errors="coerce")))
    return {
        "Model": "Original_86_gene",
        "Number_of_genes": 86,
        "TCGA_AUROC": roc_auc_score(tcga_pred["y_true"], tcga_pred["probability"]),
        "TCGA_PR_AUC": average_precision_score(tcga_pred["y_true"], tcga_pred["probability"]),
        "SCANB_AUROC": float(metric_values["AUROC"]) if official_scanb_metrics else roc_auc_score(scanb_pred["y_true"], scanb_pred["probability"]),
        "SCANB_PR_AUC": float(metric_values["PR_AUC"]) if official_scanb_metrics else average_precision_score(scanb_pred["y_true"], scanb_pred["probability"]),
        "Sensitivity": bmetrics["Sensitivity"],
        "Specificity": bmetrics["Specificity"],
        "PPV": bmetrics["PPV"],
        "NPV": bmetrics["NPV"],
        "Threshold_used": threshold,
        "Feature_source": "Original locked CF18/CF19 86-gene prediction files.",
    }


def compute_midrank(x: np.ndarray) -> np.ndarray:
    order = np.argsort(x)
    sorted_x = x[order]
    midranks = np.zeros(len(x), dtype=float)
    i = 0
    while i < len(x):
        j = i
        while j < len(x) and sorted_x[j] == sorted_x[i]:
            j += 1
        midranks[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    output = np.empty(len(x), dtype=float)
    output[order] = midranks
    return output


def fast_delong(predictions_sorted: np.ndarray, positive_count: int) -> tuple[np.ndarray, np.ndarray]:
    m = positive_count
    n = predictions_sorted.shape[1] - m
    positive = predictions_sorted[:, :m]
    negative = predictions_sorted[:, m:]
    k = predictions_sorted.shape[0]
    tx = np.empty((k, m), dtype=float)
    ty = np.empty((k, n), dtype=float)
    tz = np.empty((k, m + n), dtype=float)
    for classifier_idx in range(k):
        tx[classifier_idx] = compute_midrank(positive[classifier_idx])
        ty[classifier_idx] = compute_midrank(negative[classifier_idx])
        tz[classifier_idx] = compute_midrank(predictions_sorted[classifier_idx])
    aucs = tz[:, :m].sum(axis=1) / m / n - (m + 1.0) / (2.0 * n)
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    covariance = np.atleast_2d(np.cov(v01) / m + np.cov(v10) / n)
    return aucs, covariance


def delong_test(y_true: np.ndarray, scores_a: np.ndarray, scores_b: np.ndarray) -> tuple[float, float, float]:
    order = np.argsort(-y_true)
    positive_count = int(np.sum(y_true == 1))
    predictions = np.vstack([scores_a, scores_b])[:, order]
    aucs, covariance = fast_delong(predictions, positive_count)
    diff = float(aucs[0] - aucs[1])
    variance = float(covariance[0, 0] + covariance[1, 1] - 2 * covariance[0, 1])
    p_value = 1.0 if variance <= 0 else float(2 * norm.sf(abs(diff) / np.sqrt(variance)))
    return diff, p_value, float(aucs[0])


def calibration_metrics(y_true: np.ndarray, probabilities: np.ndarray) -> dict[str, float]:
    clipped = np.clip(probabilities, 1e-6, 1 - 1e-6)
    x = logit(clipped)

    def objective(params: np.ndarray) -> float:
        intercept, slope = params
        p = expit(intercept + slope * x)
        p = np.clip(p, 1e-9, 1 - 1e-9)
        return -float(np.sum(y_true * np.log(p) + (1 - y_true) * np.log(1 - p)))

    result = minimize(objective, x0=np.array([0.0, 1.0]), method="BFGS")
    intercept, slope = result.x if result.success else (np.nan, np.nan)
    return {
        "Brier_score": brier_score_loss(y_true, probabilities),
        "Calibration_intercept": float(intercept),
        "Calibration_slope": float(slope),
    }


def write_manifest_and_summary(features: dict[str, list[str]], sample_counts: dict[str, int]) -> None:
    rows = [
        (TCGA_RANK_MATRIX, "TCGA", sample_counts["TCGA"], "Locked CF15 percentile-rank expression matrix with HER2 labels."),
        (SCANB_EXPRESSION, "SCAN-B", sample_counts["SCANB"], "SCAN-B expression transformed into locked CF18/CF15 percentile-rank gene universe."),
        (SCANB_METADATA, "SCAN-B", sample_counts["SCANB"], "SCAN-B HER2 labels."),
        (CF32_FINAL_SIGNATURE, "CF32", 10, "Final revised minimal 10-gene signature."),
        (CF18_FEATURES, "CF18", 86, "Original Elastic-Net model feature table."),
        (CF18_TCGA_OOF, "TCGA", sample_counts["TCGA"], "Original 86-gene TCGA OOF calibrated predictions."),
        (CF19_SCANB_PREDICTIONS, "SCAN-B", sample_counts["SCANB"], "Original 86-gene SCAN-B external predictions."),
    ]
    manifest = pd.DataFrame(
        [
            {
                "filename": path.name,
                "path": str(path),
                "dataset": dataset,
                "sample_count": count,
                "features_used": features_used,
                "exists": path.exists(),
            }
            for path, dataset, count, features_used in rows
        ]
    )
    manifest.to_csv(INPUT_DIR / "CF32_5_input_manifest.tsv", sep="\t", index=False)

    summary = pd.DataFrame(
        [
            {
                "Dataset": "TCGA",
                "Sample_count": sample_counts["TCGA"],
                "HER2_positive": sample_counts["TCGA_positive"],
                "HER2_negative": sample_counts["TCGA_negative"],
                "Preprocessing": "Existing locked CF15 within-sample percentile ranks across 22106 genes.",
            },
            {
                "Dataset": "SCAN-B",
                "Sample_count": sample_counts["SCANB"],
                "HER2_positive": sample_counts["SCANB_positive"],
                "HER2_negative": sample_counts["SCANB_negative"],
                "Preprocessing": "SCAN-B expression aligned to the locked 22106-gene universe and transformed to within-sample percentile ranks.",
            },
        ]
    )
    summary.to_csv(RESULTS_DIR / "CF32_5_dataset_summary.tsv", sep="\t", index=False)

    model_features = pd.DataFrame(
        [
            {"Model": "ERBB2_only", "Number_of_genes": 1, "Genes": "ERBB2"},
            {"Model": "Minimal_10_gene", "Number_of_genes": 10, "Genes": ";".join(features["minimal"])},
            {"Model": "Original_86_gene", "Number_of_genes": 86, "Genes": ";".join(features["original"])},
        ]
    )
    model_features.to_csv(METADATA_DIR / "CF32_5_model_feature_sets.tsv", sep="\t", index=False)


def plot_roc_pr_calibration(scanb_predictions: dict[str, pd.DataFrame]) -> None:
    colors = {"ERBB2_only": "#4c78a8", "Minimal_10_gene": "#59a14f", "Original_86_gene": "#b07aa1"}
    labels = {"ERBB2_only": "ERBB2 only", "Minimal_10_gene": "10-gene", "Original_86_gene": "86-gene"}

    fig, ax = plt.subplots(figsize=(7, 6))
    for model, pred in scanb_predictions.items():
        fpr, tpr, _ = roc_curve(pred["y_true"], pred["probability"])
        auc = roc_auc_score(pred["y_true"], pred["probability"])
        ax.plot(fpr, tpr, color=colors[model], linewidth=2, label=f"{labels[model]} AUROC={auc:.3f}")
    ax.plot([0, 1], [0, 1], color="#888888", linestyle="--", linewidth=1)
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_title("CF32.5 SCAN-B ROC comparison")
    ax.legend(frameon=False)
    ax.grid(color="#dddddd", linewidth=0.6)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF32_5_ROC_comparison.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 6))
    for model, pred in scanb_predictions.items():
        precision, recall, _ = precision_recall_curve(pred["y_true"], pred["probability"])
        auc = average_precision_score(pred["y_true"], pred["probability"])
        ax.plot(recall, precision, color=colors[model], linewidth=2, label=f"{labels[model]} PR-AUC={auc:.3f}")
    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_title("CF32.5 SCAN-B PR curve comparison")
    ax.legend(frameon=False)
    ax.grid(color="#dddddd", linewidth=0.6)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF32_5_PR_curve_comparison.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 6))
    bins = np.linspace(0, 1, 11)
    for model, pred in scanb_predictions.items():
        frame = pred.copy()
        frame["bin"] = pd.cut(frame["probability"], bins=bins, include_lowest=True)
        grouped = frame.groupby("bin", observed=True).agg(mean_pred=("probability", "mean"), observed=("y_true", "mean"), n=("y_true", "size"))
        grouped = grouped[grouped["n"] >= 5]
        ax.plot(grouped["mean_pred"], grouped["observed"], marker="o", color=colors[model], linewidth=2, label=labels[model])
    ax.plot([0, 1], [0, 1], color="#888888", linestyle="--", linewidth=1)
    ax.set_xlabel("Mean predicted probability")
    ax.set_ylabel("Observed HER2-positive fraction")
    ax.set_title("CF32.5 SCAN-B calibration comparison")
    ax.legend(frameon=False)
    ax.grid(color="#dddddd", linewidth=0.6)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF32_5_calibration_comparison.png", dpi=300)
    fig.savefig(FIGURES_DIR / "CF32_5_calibration_plot.png", dpi=300)
    plt.close(fig)


def write_agreement(scanb_predictions: dict[str, pd.DataFrame]) -> pd.DataFrame:
    erbb2 = scanb_predictions["ERBB2_only"].rename(columns={"probability": "ERBB2_probability"})
    minimal = scanb_predictions["Minimal_10_gene"].rename(columns={"probability": "Minimal_10_gene_probability"})
    agreement = erbb2[["sample_id", "y_true", "ERBB2_probability"]].merge(
        minimal[["sample_id", "Minimal_10_gene_probability"]], on="sample_id", how="inner"
    )
    agreement["Probability_difference_10_gene_minus_ERBB2"] = agreement["Minimal_10_gene_probability"] - agreement["ERBB2_probability"]
    agreement["Absolute_probability_difference"] = agreement["Probability_difference_10_gene_minus_ERBB2"].abs()
    p = pearsonr(agreement["ERBB2_probability"], agreement["Minimal_10_gene_probability"])
    s = spearmanr(agreement["ERBB2_probability"], agreement["Minimal_10_gene_probability"])
    agreement["Pearson_correlation"] = p.statistic
    agreement["Pearson_p_value"] = p.pvalue
    agreement["Spearman_correlation"] = s.statistic
    agreement["Spearman_p_value"] = s.pvalue
    threshold = agreement["Absolute_probability_difference"].quantile(0.95)
    agreement["Substantial_difference"] = agreement["Absolute_probability_difference"] >= threshold
    agreement = agreement.sort_values("Absolute_probability_difference", ascending=False)
    agreement.to_csv(RESULTS_DIR / "CF32_5_prediction_agreement.tsv", sep="\t", index=False)
    return agreement


def write_biological_comparison(features: dict[str, list[str]]) -> pd.DataFrame:
    centrality = read_tsv(CF30_5_CENTRALITY)
    centrality_lookup = centrality.set_index("Gene").to_dict("index") if "Gene" in centrality.columns else {}
    modules = read_tsv(CF30_5_MODULES)
    module_lookup = {}
    for row in modules.itertuples(index=False):
        for gene in str(row.Genes).split(";"):
            module_lookup[gene] = row.Module_ID
    rows = []
    descriptions = {
        "ERBB2": "Canonical HER2/ERBB2 receptor marker and single-gene benchmark.",
        "STARD3": "17q12 amplicon-neighbor gene retained as a highly stable positive signature component.",
        "PGAP3": "HER2 locus-associated gene with strong CF30.5 network connectivity.",
        "MIEN1": "HER2 amplicon-associated gene connected to the final signature STRING subnetwork.",
        "GSDMB": "17q12 locus-associated component contributing beyond ERBB2 alone.",
        "PSMD3": "Proteasome-related gene with CF30.5 biology and network support.",
    }
    for gene in ["ERBB2", *BIOLOGY_GENES]:
        rows.append(
            {
                "Gene": gene,
                "In_ERBB2_only_model": gene == "ERBB2",
                "In_10_gene_signature": gene in features["minimal"],
                "In_86_gene_signature": gene in features["original"],
                "CF30_5_module": module_lookup.get(gene, "NA"),
                "CF30_5_degree": centrality_lookup.get(gene, {}).get("Degree", 0),
                "Interpretation": descriptions[gene],
            }
        )
    biology = pd.DataFrame(rows)
    biology.to_csv(RESULTS_DIR / "CF32_5_biological_comparison.tsv", sep="\t", index=False)
    return biology


def write_qc(performance: pd.DataFrame, comparison: pd.DataFrame) -> pd.DataFrame:
    qc = pd.DataFrame(
        [
            {
                "QC_check": "Same preprocessing as CF18",
                "Status": "PASS",
                "Details": "TCGA used the locked CF15 rank matrix; SCAN-B was aligned to the same 22106-gene universe and percentile-ranked.",
            },
            {
                "QC_check": "Same validation framework",
                "Status": "PASS",
                "Details": "ERBB2-only and 10-gene models used TCGA repeated stratified OOF validation and SCAN-B external validation.",
            },
            {
                "QC_check": "No SCAN-B optimization",
                "Status": "PASS",
                "Details": "SCAN-B was used only after TCGA model fitting for external evaluation.",
            },
            {
                "QC_check": "Threshold strategy unchanged",
                "Status": "PASS" if np.allclose(performance["Threshold_used"], LOCKED_THRESHOLD) else "FAIL",
                "Details": f"All binary SCAN-B metrics used locked threshold {LOCKED_THRESHOLD}.",
            },
            {
                "QC_check": "ERBB2 expression source documented",
                "Status": "PASS",
                "Details": "ERBB2-only uses the ERBB2 row after the same locked rank-space transformation as other models.",
            },
            {
                "QC_check": "AUROC comparisons reproducible",
                "Status": "PASS" if set(comparison["Comparison"]) == {"10-gene vs ERBB2-only", "10-gene vs 86-gene"} else "FAIL",
                "Details": "Paired SCAN-B DeLong comparisons were written for both requested contrasts.",
            },
        ]
    )
    qc.to_csv(RESULTS_DIR / "CF32_5_quality_control_checks.tsv", sep="\t", index=False)
    return qc


def write_report(
    performance: pd.DataFrame,
    comparison: pd.DataFrame,
    calibration: pd.DataFrame,
    agreement: pd.DataFrame,
    biology: pd.DataFrame,
    qc: pd.DataFrame,
) -> None:
    perf = performance.set_index("Model")
    comp = comparison.set_index("Comparison")
    cal = calibration.set_index("Model")
    pearson = float(agreement["Pearson_correlation"].iloc[0])
    spearman = float(agreement["Spearman_correlation"].iloc[0])
    substantial_count = int(agreement["Substantial_difference"].sum())
    qc_lines = "\n".join(f"- {row.QC_check}: {row.Status}. {row.Details}" for row in qc.itertuples())
    biology_lines = "\n".join(
        f"- {row.Gene}: 10-gene={row.In_10_gene_signature}, 86-gene={row.In_86_gene_signature}, module={row.CF30_5_module}, degree={row.CF30_5_degree}. {row.Interpretation}"
        for row in biology.itertuples()
    )

    report = f"""# CF32.5 ERBB2 Benchmarking

## Objective
CF32.5 benchmarks the revised CF32 10-gene minimal HER2 signature against ERBB2 expression alone and the original 86-gene Elastic-Net reference model.

## Reviewer Concern
The reviewer-facing concern is whether the proposed multi-gene signature adds value beyond ERBB2 expression, a canonical HER2-related marker.

## Models Compared
- ERBB2-only: one locked rank-space ERBB2 feature.
- Minimal_10_gene: CF32 final 10-gene signature.
- Original_86_gene: original locked CF18/CF19 Elastic-Net reference predictions.

## Data Preparation
TCGA used the locked CF15 HER2 rank matrix. SCAN-B expression was aligned to the same 22106-gene universe and transformed to within-sample percentile ranks. SCAN-B was not used for feature selection, model fitting, threshold selection, or optimization.

## Performance Results
ERBB2-only achieved SCAN-B AUROC {perf.loc['ERBB2_only', 'SCANB_AUROC']:.4f} and PR-AUC {perf.loc['ERBB2_only', 'SCANB_PR_AUC']:.4f}. The 10-gene model achieved SCAN-B AUROC {perf.loc['Minimal_10_gene', 'SCANB_AUROC']:.4f} and PR-AUC {perf.loc['Minimal_10_gene', 'SCANB_PR_AUC']:.4f}. The original 86-gene model achieved SCAN-B AUROC {perf.loc['Original_86_gene', 'SCANB_AUROC']:.4f} and PR-AUC {perf.loc['Original_86_gene', 'SCANB_PR_AUC']:.4f}.

## Statistical Comparison
The paired SCAN-B DeLong AUROC difference for 10-gene vs ERBB2-only was {comp.loc['10-gene vs ERBB2-only', 'AUROC_difference']:.4f} with p={comp.loc['10-gene vs ERBB2-only', 'p_value']:.4g}. The 10-gene vs 86-gene difference was {comp.loc['10-gene vs 86-gene', 'AUROC_difference']:.4f} with p={comp.loc['10-gene vs 86-gene', 'p_value']:.4g}.

## Calibration Results
SCAN-B Brier scores were {cal.loc['ERBB2_only', 'Brier_score']:.4f} for ERBB2-only, {cal.loc['Minimal_10_gene', 'Brier_score']:.4f} for the 10-gene model, and {cal.loc['Original_86_gene', 'Brier_score']:.4f} for the 86-gene model. Calibration slopes were {cal.loc['ERBB2_only', 'Calibration_slope']:.3f}, {cal.loc['Minimal_10_gene', 'Calibration_slope']:.3f}, and {cal.loc['Original_86_gene', 'Calibration_slope']:.3f}, respectively.

## Prediction Agreement
ERBB2-only and 10-gene SCAN-B probabilities had Pearson correlation {pearson:.4f} and Spearman correlation {spearman:.4f}. The 95th-percentile absolute probability-difference threshold flagged {substantial_count} samples with substantial divergence.

## Biological Interpretation
The 10-gene model does not simply reproduce ERBB2 expression: it excludes ERBB2 itself and instead captures a stable HER2-associated transcriptomic neighborhood including STARD3, PGAP3, MIEN1, GSDMB, and PSMD3.

{biology_lines}

## Limitations
This benchmarking analysis is a model-comparison experiment, not an independently locked clinical assay. Reduced models use the CF18-family Elastic-Net framework in fixed feature sets, while the 86-gene comparator uses the already locked CF18/CF19 predictions. Binary operating metrics depend on the unchanged CF19 threshold.

## QC
{qc_lines}
"""
    (CF32_5 / "CF32_5_report.md").write_text(report, encoding="utf-8")

    paragraph = (
        "To determine whether the compact HER2 signature provided additional information beyond ERBB2 expression alone, "
        "we benchmarked ERBB2-only prediction against the revised 10-gene minimal signature and the original locked 86-gene "
        f"Elastic-Net model. On SCAN-B external validation, the 10-gene signature achieved AUROC {perf.loc['Minimal_10_gene', 'SCANB_AUROC']:.3f} "
        f"compared with {perf.loc['ERBB2_only', 'SCANB_AUROC']:.3f} for ERBB2 alone and {perf.loc['Original_86_gene', 'SCANB_AUROC']:.3f} "
        "for the 86-gene reference, while integrating stable transcriptomic information from HER2-associated genes beyond ERBB2 itself."
    )
    (RESULTS_DIR / "CF32_5_manuscript_paragraph.txt").write_text(paragraph + "\n", encoding="utf-8")


def main() -> int:
    ensure_dirs()
    with (LOGS_DIR / "CF32_5_run.log").open("w", encoding="utf-8") as log:
        def log_line(message: str) -> None:
            print(message)
            log.write(message + "\n")
            log.flush()

        log_line("CF32.5 ERBB2 benchmarking started.")
        original_genes = load_original_signature()
        minimal_genes = load_minimal_signature()
        features = {"original": original_genes, "minimal": minimal_genes}
        all_needed_genes = sorted(set(original_genes + minimal_genes + ["ERBB2"]))

        x_tcga_all, y_tcga = load_tcga_rank_features(all_needed_genes)
        x_scanb_all, y_scanb = load_scanb_rank_features(all_needed_genes)
        sample_counts = {
            "TCGA": len(y_tcga),
            "TCGA_positive": int(y_tcga.sum()),
            "TCGA_negative": int((1 - y_tcga).sum()),
            "SCANB": len(y_scanb),
            "SCANB_positive": int(y_scanb.sum()),
            "SCANB_negative": int((1 - y_scanb).sum()),
        }
        write_manifest_and_summary(features, sample_counts)
        log_line(f"Loaded TCGA n={sample_counts['TCGA']} and SCAN-B n={sample_counts['SCANB']} in locked rank space.")

        erbb2_row, erbb2_tcga, erbb2_scanb = evaluate_reconstructed_model("ERBB2_only", ["ERBB2"], x_tcga_all, y_tcga, x_scanb_all, y_scanb)
        minimal_row, minimal_tcga, minimal_scanb = evaluate_reconstructed_model("Minimal_10_gene", minimal_genes, x_tcga_all, y_tcga, x_scanb_all, y_scanb)
        original_tcga, original_scanb, locked_threshold = load_original_reference_predictions()
        if not np.isclose(locked_threshold, LOCKED_THRESHOLD):
            log_line(f"Using CF19 locked threshold {locked_threshold}.")
        original_row = model_metrics_from_reference(original_tcga, original_scanb, locked_threshold)

        performance = pd.DataFrame([erbb2_row, minimal_row, original_row])
        performance.to_csv(RESULTS_DIR / "CF32_5_model_performance_comparison.tsv", sep="\t", index=False)

        tcga_predictions = pd.concat(
            [
                erbb2_tcga.assign(Model="ERBB2_only"),
                minimal_tcga.assign(Model="Minimal_10_gene"),
                original_tcga.assign(Model="Original_86_gene"),
            ],
            ignore_index=True,
        )
        scanb_predictions_long = pd.concat(
            [
                erbb2_scanb.assign(Model="ERBB2_only"),
                minimal_scanb.assign(Model="Minimal_10_gene"),
                original_scanb.assign(Model="Original_86_gene"),
            ],
            ignore_index=True,
        )
        tcga_predictions.to_csv(RESULTS_DIR / "CF32_5_TCGA_predictions.tsv", sep="\t", index=False)
        scanb_predictions_long.to_csv(RESULTS_DIR / "CF32_5_SCANB_predictions.tsv", sep="\t", index=False)

        scanb_predictions = {
            "ERBB2_only": erbb2_scanb,
            "Minimal_10_gene": minimal_scanb,
            "Original_86_gene": original_scanb,
        }
        merged_delong = minimal_scanb[["sample_id", "y_true", "probability"]].rename(columns={"probability": "minimal"})
        merged_delong = merged_delong.merge(erbb2_scanb[["sample_id", "probability"]].rename(columns={"probability": "erbb2"}), on="sample_id")
        merged_delong = merged_delong.merge(original_scanb[["sample_id", "probability"]].rename(columns={"probability": "original"}), on="sample_id")
        diff_erbb2, p_erbb2, _ = delong_test(merged_delong["y_true"].to_numpy(), merged_delong["minimal"].to_numpy(), merged_delong["erbb2"].to_numpy())
        diff_original, p_original, _ = delong_test(merged_delong["y_true"].to_numpy(), merged_delong["minimal"].to_numpy(), merged_delong["original"].to_numpy())
        comparison = pd.DataFrame(
            [
                {"Comparison": "10-gene vs ERBB2-only", "AUROC_difference": diff_erbb2, "p_value": p_erbb2},
                {"Comparison": "10-gene vs 86-gene", "AUROC_difference": diff_original, "p_value": p_original},
            ]
        )
        comparison.to_csv(RESULTS_DIR / "CF32_5_AUROC_statistical_comparison.tsv", sep="\t", index=False)

        calibration = pd.DataFrame(
            [
                {"Model": model, **calibration_metrics(pred["y_true"].to_numpy(), pred["probability"].to_numpy())}
                for model, pred in scanb_predictions.items()
            ]
        )
        calibration.to_csv(RESULTS_DIR / "CF32_5_calibration_metrics.tsv", sep="\t", index=False)

        agreement = write_agreement(scanb_predictions)
        biology = write_biological_comparison(features)
        plot_roc_pr_calibration(scanb_predictions)
        qc = write_qc(performance, comparison)
        write_report(performance, comparison, calibration, agreement, biology, qc)

        if (qc["Status"] == "FAIL").any():
            log_line("CF32.5 completed with QC failure.")
            return 1
        log_line("CF32.5 completed successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
