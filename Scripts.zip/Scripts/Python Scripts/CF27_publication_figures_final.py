"""
============================================================
CF27 - FINAL PUBLICATION FIGURE ASSEMBLY
============================================================

Purpose:
    Create final manuscript-style figures from CF25 + CF26.

No ML.
No retraining.
No statistical modification.

Outputs:
    results/FINAL_PUBLICATION_FIGURES/

============================================================
"""

import os
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageFont


BASE = r"D:\Masters\Research\TCGA_BRCA"

CF25 = os.path.join(
    BASE,
    "results",
    "CF25_manuscript_package",
    "FIGURES_FINAL"
)

CF26 = os.path.join(
    BASE,
    "results",
    "CF26_publication_enhancement"
)

OUT = os.path.join(
    BASE,
    "results",
    "FINAL_PUBLICATION_FIGURES"
)

os.makedirs(OUT, exist_ok=True)


def load(name, folder):

    path = os.path.join(
        folder,
        name
    )

    if os.path.exists(path):
        return Image.open(path).convert("RGB")

    print("Missing:", path)
    return None



def panel(images, labels, outfile, cols=2):

    valid=[]

    for img,label in zip(images,labels):
        if img is not None:
            valid.append((img,label))


    if not valid:
        return


    rows=(len(valid)+cols-1)//cols

    fig,axes=plt.subplots(
        rows,
        cols,
        figsize=(12,5*rows)
    )

    if rows==1:
        axes=[axes] if cols==1 else axes

    else:
        axes=axes.flatten()


    for ax,(img,label) in zip(axes,valid):

        ax.imshow(img)
        ax.axis("off")
        ax.set_title(label,fontsize=10)


    for ax in axes[len(valid):]:
        ax.axis("off")


    plt.tight_layout()

    plt.savefig(
        outfile,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()



def create_captions():

    text = """

Figure 1. Study workflow.
Overview of TCGA-BRCA model development, nested validation,
external SCAN-B evaluation, and APOLLO multi-omics confirmation.

Figure 2. Machine learning development and leakage control.
Illustration of the locked analytical framework ensuring that
external datasets were not used during model development.

Figure 3. Model performance comparison.
Comparison of machine-learning models with calibration assessment.

Figure 4. External validation performance.
Independent evaluation on SCAN-B including discrimination and
threshold analysis.

Figure 5. Gene signature biology.
Functional interpretation of predictive genes using model
coefficients, importance analysis, and pathway enrichment.

Figure 6. APOLLO multi-omics confirmation.
Independent RNA, protein, and phosphoproteomic evidence for
the predictive signature.

"""

    with open(
        os.path.join(
            OUT,
            "Figure_Captions.txt"
        ),
        "w",
        encoding="utf-8"
    ) as f:
        f.write(text)



def main():

    print("""
============================================================
CF27 - FINAL PUBLICATION FIGURE ASSEMBLY
============================================================
""")


    # Figure 1
    img=load(
        "CF23_Figure1_Workflow.png",
        CF25
    )

    if img:
        img.save(
            os.path.join(
                OUT,
                "Figure1_Workflow.png"
            ),
            dpi=(300,300)
        )


    # Figure 3
    panel(
        [
            load("CF17_AUROC_model_comparison.png",CF25),
            load("CF17_PR_AUC_model_comparison.png",CF25),
            load("CF26_SCANB_calibration_curve.png",CF26)
        ],
        [
            "AUROC model comparison",
            "PR-AUC model comparison",
            "Calibration"
        ],
        os.path.join(
            OUT,
            "Figure3_Model_Performance.png"
        )
    )


    # Figure 4

    panel(
        [
            load("CF19_ROC.png",CF25),
            load("CF19_PR_curve.png",CF25),
            load("CF26_threshold_curve.png",CF26)
        ],
        [
            "SCAN-B ROC",
            "SCAN-B PR curve",
            "Threshold analysis"
        ],
        os.path.join(
            OUT,
            "Figure4_SCANB_Validation.png"
        )
    )


    # Figure 5

    panel(
        [
            load("CF18_final_ElasticNet_coefficients.png",CF25),
            load("CF20_gene_importance.png",CF25),
            load("CF22_Hallmark_Pathways.png",CF25),
            load("CF22_Reactome_Pathways.png",CF25)
        ],
        [
            "Elastic-Net coefficients",
            "Gene importance",
            "Hallmark pathways",
            "Reactome pathways"
        ],
        os.path.join(
            OUT,
            "Figure5_Gene_Signature_Biology.png"
        ),
        cols=2
    )


    # Figure 6

    img=load(
        "CF21v3_evidence_barplot.png",
        CF25
    )

    if img:

        img.save(
            os.path.join(
                OUT,
                "Figure6_APOLLO_Multiomics.png"
            ),
            dpi=(300,300)
        )


    # Figure 2 schematic

    fig,ax=plt.subplots(
        figsize=(8,10)
    )

    steps=[
        "TCGA-BRCA cohort",
        "Expression preprocessing",
        "Nested cross-validation",
        "Feature selection",
        "Model comparison",
        "Elastic-Net model lock",
        "SCAN-B validation",
        "APOLLO confirmation"
    ]

    ax.axis("off")

    for i,s in enumerate(steps):

        ax.text(
            0.5,
            1-i*0.11,
            s,
            ha="center",
            va="center",
            fontsize=12,
            bbox=dict(
                boxstyle="round"
            )
        )

    plt.savefig(
        os.path.join(
            OUT,
            "Figure2_ML_Leakage_Control.png"
        ),
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()


    create_captions()


    print("""
============================================================
CF27 COMPLETE
============================================================

Final publication figures saved:

""")

    print(OUT)



if __name__=="__main__":
    main()
