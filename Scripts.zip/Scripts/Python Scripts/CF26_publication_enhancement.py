"""
============================================================
CF26 - PUBLICATION ENHANCEMENT
============================================================

Purpose:
    Add manuscript-level analyses requested by supervisor:

    1. Calibration analysis
    2. Bootstrap confidence intervals
    3. Threshold analysis
    4. Publication figure assembly

No ML retraining.
No feature selection.
No model modification.

Inputs:
    CF18 locked model bundle
    CF19 SCAN-B predictions
    CF25 manuscript figures

Outputs:
    results/CF26_publication_enhancement/

============================================================
"""

import os
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
    brier_score_loss,
    f1_score,
    matthews_corrcoef
)
from sklearn.calibration import calibration_curve
from PIL import Image


BASE = r"D:\Masters\Research\TCGA_BRCA"

OUT = os.path.join(
    BASE,
    "results",
    "CF26_publication_enhancement"
)

os.makedirs(OUT, exist_ok=True)

BOOTSTRAPS = 2000
LOCKED_THRESHOLD = 0.4345288894526921


SCAN_PRED = os.path.join(
    BASE,
    "results",
    "CF19_scanb_external_validation",
    "CF19_predictions.tsv"
)


FIG_DIR = os.path.join(
    BASE,
    "results",
    "CF25_manuscript_package",
    "FIGURES_FINAL"
)


START = time.time()


def banner():

    print("""
============================================================
CF26 - PUBLICATION ENHANCEMENT
============================================================

NO MODEL RETRAINING
NO FEATURE SELECTION
NO MODEL CHANGE

Adding:
- Calibration
- Confidence intervals
- Threshold analysis
- Publication figure package

============================================================
""")


def bootstrap_ci(y, p, name):

    print("Bootstrap:", name)

    rng = np.random.default_rng(42)

    aucs = []
    prs = []

    n = len(y)

    for i in range(BOOTSTRAPS):

        idx = rng.integers(
            0,
            n,
            n
        )

        if len(np.unique(y[idx])) < 2:
            continue

        aucs.append(
            roc_auc_score(
                y[idx],
                p[idx]
            )
        )

        prs.append(
            average_precision_score(
                y[idx],
                p[idx]
            )
        )


    result = pd.DataFrame({

        "metric":[
            "AUROC",
            "PR_AUC"
        ],

        "estimate":[
            roc_auc_score(y,p),
            average_precision_score(y,p)
        ],

        "lower95":[
            np.percentile(aucs,2.5),
            np.percentile(prs,2.5)
        ],

        "upper95":[
            np.percentile(aucs,97.5),
            np.percentile(prs,97.5)
        ]
    })


    result.to_csv(
        os.path.join(
            OUT,
            f"CF26_{name}_bootstrap_CI.tsv"
        ),
        sep="\t",
        index=False
    )


    return result



def calibration_analysis(y,p,name):

    print("Calibration:",name)

    fraction, mean = calibration_curve(
        y,
        p,
        n_bins=10,
        strategy="quantile"
    )


    plt.figure(figsize=(5,5))

    plt.plot(
        mean,
        fraction,
        marker="o"
    )

    plt.plot(
        [0,1],
        [0,1],
        linestyle="--"
    )

    plt.xlabel(
        "Mean predicted probability"
    )

    plt.ylabel(
        "Observed frequency"
    )

    plt.title(
        f"{name} Calibration"
    )


    plt.savefig(
        os.path.join(
            OUT,
            f"CF26_{name}_calibration_curve.png"
        ),
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()


    metrics = pd.DataFrame({

        "metric":[
            "Brier_score"
        ],

        "value":[
            brier_score_loss(
                y,
                p
            )
        ]

    })


    metrics.to_csv(
        os.path.join(
            OUT,
            f"CF26_{name}_calibration_metrics.tsv"
        ),
        sep="\t",
        index=False
    )



def threshold_analysis(y,p):

    print("Threshold analysis")

    rows=[]

    for t in np.linspace(
        0.05,
        0.95,
        91
    ):

        pred=(p>=t).astype(int)

        tn,fp,fn,tp = confusion_matrix(
            y,
            pred
        ).ravel()

        rows.append({

            "threshold":t,
            "sensitivity":tp/(tp+fn),
            "specificity":tn/(tn+fp),
            "F1":f1_score(y,pred),
            "MCC":matthews_corrcoef(y,pred)

        })


    df=pd.DataFrame(rows)

    df.to_csv(
        os.path.join(
            OUT,
            "CF26_threshold_analysis.tsv"
        ),
        sep="\t",
        index=False
    )


    plt.figure(figsize=(7,5))

    plt.plot(
        df.threshold,
        df.sensitivity,
        label="Sensitivity"
    )

    plt.plot(
        df.threshold,
        df.specificity,
        label="Specificity"
    )

    plt.axvline(
        LOCKED_THRESHOLD,
        linestyle="--",
        label="Locked threshold"
    )

    plt.xlabel(
        "Probability threshold"
    )

    plt.ylabel(
        "Metric"
    )

    plt.legend()

    plt.title(
        "CF26 Threshold Analysis"
    )

    plt.savefig(
        os.path.join(
            OUT,
            "CF26_threshold_curve.png"
        ),
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()



def main():

    banner()

    if not os.path.exists(SCAN_PRED):

        raise FileNotFoundError(
            SCAN_PRED
        )


    data=pd.read_csv(
        SCAN_PRED,
        sep="\t"
    )


    y=data["prediction"].values
    p=data["HER2_probability"].values


    # External validation
    bootstrap_ci(
        y,
        p,
        "SCANB"
    )

    calibration_analysis(
        y,
        p,
        "SCANB"
    )

    threshold_analysis(
        y,
        p
    )


    summary=pd.DataFrame({

        "item":[
            "Locked_threshold",
            "Samples",
            "Runtime_min"
        ],

        "value":[
            LOCKED_THRESHOLD,
            len(y),
            round(
                (time.time()-START)/60,
                2
            )
        ]

    })


    summary.to_csv(
        os.path.join(
            OUT,
            "CF26_summary.tsv"
        ),
        sep="\t",
        index=False
    )


    print("""
============================================================
CF26 COMPLETE
============================================================

STATUS: PUBLICATION_ENHANCEMENT_READY

============================================================
""")


if __name__=="__main__":
    main()
