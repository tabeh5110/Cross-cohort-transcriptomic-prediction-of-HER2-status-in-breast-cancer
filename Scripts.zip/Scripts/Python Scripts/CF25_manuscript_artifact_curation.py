"""
============================================================
CF25 - MANUSCRIPT ARTIFACT CURATION FROM CF24 ARCHIVE
============================================================

Purpose:
    Curate only manuscript-relevant figures and result files
    from CF24_final_archive

Input:
    CF24_final_archive

Output:
    CF25_manuscript_package/

        FIGURES_FINAL/
            selected figures
            combined multi-panel figures
            source CF preserved in filename

        RESULTS_FINAL/
            essential manuscript tables only
            source CF preserved in filename

Rules:
    - No analysis
    - No ML
    - No modification of scientific results
    - Only organization and figure assembly

============================================================
"""

import os
import shutil
import re
import matplotlib.pyplot as plt
from PIL import Image


CF24_FOLDER = r"D:\Masters\Research\TCGA_BRCA\results\CF24_final_archive"

OUT = r"D:\Masters\Research\TCGA_BRCA\results\CF25_manuscript_package"

FIG_OUT = os.path.join(OUT, "FIGURES_FINAL")
RES_OUT = os.path.join(OUT, "RESULTS_FINAL")

os.makedirs(FIG_OUT, exist_ok=True)
os.makedirs(RES_OUT, exist_ok=True)


# -----------------------------
# Manuscript figure selection
# -----------------------------

FIGURE_KEYWORDS = [
    "workflow",
    "AUROC",
    "PR",
    "ROC",
    "feature_stability",
    "coefficients",
    "gene_importance",
    "evidence_barplot",
    "Hallmark",
    "Reactome",
    "pathway",
    "signature",
    "importance"
]


# -----------------------------
# Essential result tables
# -----------------------------

RESULT_KEYWORDS = [
    "CF16_outer_metrics",
    "CF16_outer_predictions",
    "CF17",
    "CF18",
    "CF19_metrics",
    "CF19_predictions",
    "CF20",
    "CF21",
    "CF22_Hallmark",
    "CF22_Reactome",
    "CF22_predictive",
    "summary"
]


def source_name(name):
    """
    Keep CF origin.
    Example:
    CF19_ROC.png remains CF19_ROC.png
    """
    return os.path.basename(name)


def select_files():

    print("Reading CF24 archive folder...")

    selected_figures = []
    selected_results = []

    for root, dirs, files in os.walk(CF24_FOLDER):

        for file in files:

            path = os.path.join(root, file)

            low = path.lower()


            # Figures
            if "all_figures" in low:

                if any(
                    k.lower() in file.lower()
                    for k in FIGURE_KEYWORDS
                ):

                    selected_figures.append(path)

                    shutil.copy2(
                        path,
                        os.path.join(
                            FIG_OUT,
                            file
                        )
                    )


            # Results
            elif "important_results" in low:

                if any(
                    k.lower() in file.lower()
                    for k in RESULT_KEYWORDS
                ):

                    if file.lower().endswith(
                        (".csv",".tsv",".txt")
                    ):

                        selected_results.append(path)

                        shutil.copy2(
                            path,
                            os.path.join(
                                RES_OUT,
                                file
                            )
                        )


    print(
        "Selected figures:",
        len(selected_figures)
    )

    print(
        "Selected result files:",
        len(selected_results)
    )


    return selected_figures, selected_results

def make_combined_figures():

    print("Creating manuscript multi-panel figures...")

    images = [
        "CF17_AUROC_model_comparison.png",
        "CF17_PR_AUC_model_comparison.png",
        "CF19_ROC.png",
        "CF19_PR_curve.png"
    ]

    available = []

    for x in images:
        p = os.path.join(FIG_OUT,x)
        if os.path.exists(p):
            available.append(p)

    if available:

        fig, axes = plt.subplots(
            2,2,
            figsize=(12,10)
        )

        axes = axes.flatten()

        for ax,p in zip(axes,available):

            img = Image.open(p)
            ax.imshow(img)
            ax.axis("off")
            ax.set_title(
                os.path.basename(p)
            )

        for ax in axes[len(available):]:
            ax.axis("off")

        plt.tight_layout()

        plt.savefig(
            os.path.join(
                FIG_OUT,
                "FIGURE_MODEL_VALIDATION_COMBINED.png"
            ),
            dpi=300,
            bbox_inches="tight"
        )

        plt.close()


    pathway = [
        "CF10_top_stable_hallmark.png",
        "CF22_Hallmark_Pathways.png",
        "CF22_Reactome_Pathways.png"
    ]

    available=[]

    for x in pathway:
        p=os.path.join(FIG_OUT,x)
        if os.path.exists(p):
            available.append(p)

    if available:

        fig,axes=plt.subplots(
            1,len(available),
            figsize=(15,5)
        )

        if len(available)==1:
            axes=[axes]

        for ax,p in zip(axes,available):
            img=Image.open(p)
            ax.imshow(img)
            ax.axis("off")
            ax.set_title(
                os.path.basename(p)
            )

        plt.tight_layout()

        plt.savefig(
            os.path.join(
                FIG_OUT,
                "FIGURE_BIOLOGY_PATHWAYS_COMBINED.png"
            ),
            dpi=300,
            bbox_inches="tight"
        )

        plt.close()


def main():

    print("""
============================================================
CF25 - MANUSCRIPT ARTIFACT CURATION
============================================================
""")

    figs,results=select_files()

    make_combined_figures()

    with open(
        os.path.join(
            OUT,
            "CF25_selection_manifest.txt"
        ),
        "w"
    ) as f:

        f.write("SELECTED FIGURES\n")
        for x in figs:
            f.write(x+"\n")

        f.write("\nSELECTED RESULTS\n")
        for x in results:
            f.write(x+"\n")


    print("""
============================================================
CF25 COMPLETE
============================================================
""")

    print("Final folder:")
    print(OUT)


if __name__=="__main__":
    main()
