"""CF39: conditional nested-CV refinement of the frozen CF18 stable core.

CF18 artifacts are read-only. All new outputs stay inside CF39.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent/'_runtime'))
import json, hashlib, warnings, platform
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import joblib, sklearn
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix, roc_curve
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=Path(__file__).resolve().parents[1]
ROOT=OUT.parent
RES=OUT/'results'; FIG=OUT/'figures'; REPORT=OUT/'report'
CF18=ROOT/'results/CF18_stable_signature_xai_final_model'
MODEL=ROOT/'data/processed/ml_ready/CF18_final_model/CF18_final_ElasticNet_model_bundle.joblib'
MATRIX=ROOT/'data/processed/ml_ready/CF15_TCGA_HER2_rank_matrix.npz'
ASSIGN=ROOT/'results/CF15_ml_experiment_design/CF15_outer_cv_test_assignments.tsv'
BIO=ROOT/'CF30_5_network_biology_validation/results/CF30_5_gene_identifier_mapping.tsv'
SEED=20260922
SIZES=[20,15,10,5]
BOOT=2000

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def save(d,name): d.to_csv(RES/f'CF39_{name}.tsv',sep='\t',index=False)

def score(y,p,cut):
    tn,fp,fn,tp=confusion_matrix(y,p>=cut,labels=[0,1]).ravel()
    div=lambda a,b: a/b if b else np.nan
    return dict(AUROC=roc_auc_score(y,p),PR_AUC=average_precision_score(y,p),
                sensitivity=div(tp,tp+fn),specificity=div(tn,tn+fp),PPV=div(tp,tp+fp),NPV=div(tn,tn+fn))

def main():
    inputs=[MODEL,MATRIX,ASSIGN,BIO,CF18/'CF18_stable_core_signature.tsv',
            CF18/'CF18_final_ElasticNet_features.tsv',CF18/'CF18_TCGA_OOF_calibrated_predictions.tsv',
            CF18/'CF18_calibration_and_threshold.tsv',CF18/'CF18_final_ElasticNet_parameters.tsv']
    before={str(p.relative_to(ROOT)):sha(p) for p in inputs}
    bundle=joblib.load(MODEL)
    core=pd.read_csv(inputs[4],sep='\t')
    final=pd.read_csv(inputs[5],sep='\t')
    assert len(core)==20 and core.gene_symbol.is_unique
    assert (core.stability_tier=='CORE_STABLE').all()
    assert int(final.final_model_nonzero.sum())==86
    ranking=core.merge(final[['gene_symbol','standardized_ElasticNet_coefficient']],on='gene_symbol',validate='one_to_one')
    ranking['final_absolute_coefficient']=ranking.standardized_ElasticNet_coefficient.abs()
    annotation=pd.read_csv(BIO,sep='\t').rename(columns={'Gene':'gene_symbol'})
    ranking=ranking.merge(annotation[['gene_symbol','Protein_name','STRING_annotation']],on='gene_symbol',how='left',validate='one_to_one')
    # Limited, explicit evidence set; zero means not curated here, not biologically irrelevant.
    amp={'ERBB2','STARD3','MIEN1','PGAP3','NEUROD2','TCAP'}
    ranking['curated_HER2_evidence']=ranking.gene_symbol.isin(amp|{'MIR4728'}).astype(int)
    ranking['biology_note']=ranking.gene_symbol.map(lambda g:'HER2 amplicon region; co-amplification does not imply causality' if g in amp else ('HER2-intronic microRNA; locus-linked marker' if g=='MIR4728' else 'Stable statistical marker; no direct HER2 mechanism assigned in this limited review'))
    ranking.loc[ranking.gene_symbol=='PAX7','biology_note']='Developmental transcription factor; direct HER2 mechanism not established here'
    ranking['biology_source']=ranking.gene_symbol.map(lambda g:'https://pmc.ncbi.nlm.nih.gov/articles/PMC2917012/' if g in amp else ('https://pubmed.ncbi.nlm.nih.gov/24828673/' if g=='MIR4728' else ('https://www.ncbi.nlm.nih.gov/gene/5081' if g=='PAX7' else str(BIO.relative_to(ROOT)))))
    ranking['tier_priority']=1
    keys=['tier_priority','selection_frequency','nonzero_frequency','mean_absolute_coefficient_all15','final_absolute_coefficient','curated_HER2_evidence','gene_symbol']
    ranking=ranking.sort_values(keys,ascending=[False]*6+[True],kind='stable').reset_index(drop=True)
    ranking['CF39_rank']=np.arange(1,21)
    ranking['Protein_name']=ranking.Protein_name.fillna('Noncoding RNA or unavailable protein annotation')
    panels={f'Top {k}':ranking.gene_symbol.head(k).tolist() for k in SIZES}
    for k in SIZES: ranking[f'in_top_{k}']=ranking.CF39_rank<=k
    save(ranking,'gene_ranking')
    save(pd.DataFrame([{'panel':name,'size':len(gg),'rank':i+1,'gene_symbol':g} for name,gg in panels.items() for i,g in enumerate(gg)]),'panel_membership')
    protocol={'created_before_evaluation_utc':datetime.now(timezone.utc).isoformat(),
              'scope':'TCGA conditional post-selection refinement; not independent validation',
              'ranking_order':keys,'ranking_biology_role':'final tie-breaker and annotation; does not override stronger statistical evidence',
              'panels':panels,'outer_cv':'original CF15 3 repeats x 5 folds',
              'inner_cv':'4-fold stratified; scaler and estimator fitted only on training partitions',
              'C_grid':[.01,.1,1,10],'l1_ratio_grid':[.25,.5,.75],
              'family':'balanced Elastic-Net logistic regression; saga, max_iter=10000, tol=1e-4',
              'inner_selection_metric':'AUROC; deterministic parameter order resolves exact ties',
              'reduced_threshold':.5,'reduced_calibration':'none; class-balanced scores are not prevalence-calibrated risk',
              'CF18_threshold':float(bundle['classification_threshold']),
              'patient_aggregation':'mean of three outer held-out probabilities; never three independent copies of a patient',
              'noninferiority_margins':{'AUROC':.02,'PR_AUC':.03},
              'recommendation_rule':'smallest reduced panel whose paired conditional 95% lower bounds exceed -0.02 AUROC and -0.03 PR-AUC vs BOTH Top 20 and historical CF18; additionally sensitivity and specificity point losses <=0.05 vs Top 20. Otherwise retain 20 provisionally.',
              'warning':'Core membership and ranking were selected on the same TCGA patients before CF39. Nested hyperparameter fitting does not remove this feature-selection leakage. Size recommendation is exploratory.'}
    (RES/'CF39_frozen_refinement_protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    z=np.load(MATRIX,allow_pickle=True)
    genes=z['gene_symbols'].astype(str); patients=z['patient_ids'].astype(str); y=z['y'].astype(int)
    assert len(y)==938 and y.sum()==182 and len(set(patients))==938
    lookup={g:i for i,g in enumerate(genes)}
    X=z['X'][:,[lookup[g] for g in ranking.gene_symbol]].astype(float)
    assert np.isfinite(X).all()
    assignments=pd.read_csv(ASSIGN,sep='\t')
    for row in assignments.itertuples():
        assert patients[row.row_index]==row.patient_id and y[row.row_index]==row.y_HER2
    assert assignments.groupby('row_index').size().eq(3).all()
    reference=pd.read_csv(CF18/'CF18_TCGA_OOF_calibrated_predictions.tsv',sep='\t').set_index('patient_id').loc[patients]
    assert np.array_equal(reference.y_true.to_numpy(),y)
    assert reference.oof_repeats.eq(3).all()
    model_names=['CF18 full']+list(panels)
    pooled={'CF18 full':reference.calibrated_oof_probability.to_numpy()}
    thresholds={'CF18 full':float(bundle['classification_threshold'])}
    outer_rows=[]; search_rows=[]; fold_rows=[]; coef_rows=[]; hyper_rows=[]
    for name,gg in panels.items():
        k=len(gg); xx=X[:,:k]
        predictions=np.full((3,len(y)),np.nan)
        for split_id, a in assignments.groupby('split_id',sort=True):
            test=a.row_index.to_numpy(int); train=np.setdiff1d(np.arange(len(y)),test)
            repeat=int(a['repeat'].iloc[0]); fold=int(a['fold'].iloc[0])
            assert not np.intersect1d(train,test).size
            pipeline=Pipeline([('scale',StandardScaler()),('model',LogisticRegression(penalty='elasticnet',solver='saga',class_weight='balanced',max_iter=10000,tol=1e-4,random_state=SEED))])
            inner=StratifiedKFold(4,shuffle=True,random_state=SEED+repeat*10+fold)
            search=GridSearchCV(pipeline,{'model__C':[.01,.1,1,10],'model__l1_ratio':[.25,.5,.75]},scoring='roc_auc',cv=inner,n_jobs=1,refit=True,error_score='raise')
            with warnings.catch_warnings():
                warnings.simplefilter('error',ConvergenceWarning)
                search.fit(xx[train],y[train])
            p=search.predict_proba(xx[test])[:,1]
            predictions[repeat-1,test]=p
            for j,idx in enumerate(test): outer_rows.append({'panel':name,'split_id':split_id,'repeat':repeat,'fold':fold,'patient_id':patients[idx],'y_true':int(y[idx]),'probability':p[j],'threshold':.5})
            fold_rows.append({'panel':name,'split_id':split_id,'n_test':len(test),**score(y[test],p,.5)})
            hyper_rows.append({'panel':name,'split_id':split_id,'C':search.best_params_['model__C'],'l1_ratio':search.best_params_['model__l1_ratio'],'best_inner_AUROC':search.best_score_,'nonzero_coefficients':int(np.sum(abs(search.best_estimator_['model'].coef_.ravel())>1e-8))})
            for j,param in enumerate(search.cv_results_['params']): search_rows.append({'panel':name,'split_id':split_id,**param,'mean_inner_AUROC':search.cv_results_['mean_test_score'][j],'rank':int(search.cv_results_['rank_test_score'][j])})
            for g,c in zip(gg,search.best_estimator_['model'].coef_.ravel()): coef_rows.append({'panel':name,'split_id':split_id,'gene_symbol':g,'standardized_coefficient':c})
            print(f'{name}: {split_id} complete; inner AUROC {search.best_score_:.4f}',flush=True)
        assert np.isfinite(predictions).all()
        pooled[name]=predictions.mean(axis=0); thresholds[name]=.5
        print(f'{name} pooled: {score(y,pooled[name],.5)}',flush=True)
    save(pd.DataFrame(outer_rows),'outer_fold_predictions')
    save(pd.DataFrame(fold_rows),'outer_fold_metrics')
    save(pd.DataFrame(search_rows),'inner_search')
    save(pd.DataFrame(hyper_rows),'selected_hyperparameters')
    save(pd.DataFrame(coef_rows),'outer_fold_coefficients')
    save(pd.DataFrame([{'patient_id':patients[i],'y_true':int(y[i]),'model':name,'mean_OOF_probability':pooled[name][i],'threshold':thresholds[name],'prediction':int(pooled[name][i]>=thresholds[name])} for name in model_names for i in range(len(y))]),'patient_OOF_predictions')
    points={name:score(y,pooled[name],thresholds[name]) for name in model_names}
    print('Computing paired patient-bootstrap intervals...',flush=True)
    rng=np.random.default_rng(SEED); pos=np.flatnonzero(y); neg=np.flatnonzero(y==0)
    metric_names=list(points[model_names[0]])
    boot=np.empty((BOOT,len(model_names),len(metric_names)))
    for iteration in range(BOOT):
        idx=np.r_[rng.choice(pos,len(pos),replace=True),rng.choice(neg,len(neg),replace=True)]
        for j,name in enumerate(model_names): boot[iteration,j]=list(score(y[idx],pooled[name][idx],thresholds[name]).values())
    performance=[]
    for j,name in enumerate(model_names):
        for q,metric in enumerate(metric_names): performance.append({'model':name,'size':86 if name=='CF18 full' else len(panels[name]),'metric':metric,'estimate':points[name][metric],'lower_95':np.nanquantile(boot[:,j,q],.025),'upper_95':np.nanquantile(boot[:,j,q],.975),'threshold':thresholds[name]})
    perf=pd.DataFrame(performance); save(perf,'performance')
    differences=[]
    for name in panels:
        for ref in ['Top 20','CF18 full']:
            if name==ref: continue
            for q,metric in enumerate(metric_names):
                dif=boot[:,model_names.index(name),q]-boot[:,model_names.index(ref),q]
                differences.append({'panel':name,'reference':ref,'metric':metric,'difference':points[name][metric]-points[ref][metric],'lower_95':np.nanquantile(dif,.025),'upper_95':np.nanquantile(dif,.975)})
    diffs=pd.DataFrame(differences); save(diffs,'paired_differences')
    decisions=[]
    for k in [5,10,15]:
        name=f'Top {k}'; meets=True
        for ref in ['Top 20','CF18 full']:
            for metric,margin in [('AUROC',.02),('PR_AUC',.03)]:
                row=diffs[(diffs.panel==name)&(diffs.reference==ref)&(diffs.metric==metric)].iloc[0]
                meets=meets and bool(row.lower_95>=-margin)
        operating=points[name]['sensitivity']>=points['Top 20']['sensitivity']-.05 and points[name]['specificity']>=points['Top 20']['specificity']-.05
        decisions.append({'size':k,'paired_discrimination_rule_pass':bool(meets),'operating_point_rule_pass':bool(operating),'eligible':bool(meets and operating)})
    decision=pd.DataFrame(decisions); save(decision,'size_recommendation')
    eligible=decision.loc[decision.eligible,'size'].tolist()
    recommended=min(eligible) if eligible else 20
    save(ranking.head(recommended),'recommended_gene_panel')
    confusion=[]
    for name in model_names:
        tn,fp,fn,tp=confusion_matrix(y,pooled[name]>=thresholds[name],labels=[0,1]).ravel()
        confusion.append({'model':name,'TN':tn,'FP':fp,'FN':fn,'TP':tp})
    save(pd.DataFrame(confusion),'confusion_matrices')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.dpi':400})
    order=['Top 5','Top 10','Top 15','Top 20','CF18 full']
    colors={'Top 5':'#D55E00','Top 10':'#0072B2','Top 15':'#009E73','Top 20':'#9467BD','CF18 full':'#333333'}
    def finish(fig,name):
        fig.tight_layout()
        for ext in ['png','pdf']: fig.savefig(FIG/f'CF39_{name}.{ext}',bbox_inches='tight')
        plt.close(fig)
    fig,axes=plt.subplots(2,3,figsize=(12,7))
    for ax,metric in zip(axes.flat,metric_names):
        for i,name in enumerate(order):
            r=perf[(perf.model==name)&(perf.metric==metric)].iloc[0]
            ax.errorbar(i,r.estimate,yerr=[[max(0,r.estimate-r.lower_95)],[max(0,r.upper_95-r.estimate)]],fmt='o',color=colors[name],capsize=3)
        ax.set(xticks=range(5),xticklabels=['5','10','15','20','CF18\n86'],ylabel=metric.replace('_','-'),xlabel='Panel size',ylim=(0,1.03)); ax.grid(axis='y',alpha=.15)
    fig.suptitle('CF39 | Conditional TCGA refinement performance\nPatient-level OOF estimates and conditional 95% bootstrap intervals',fontsize=13)
    finish(fig,'Figure1_performance_by_size')
    fig,ax=plt.subplots(figsize=(8,8))
    rr=ranking.iloc[::-1]
    cols=['#0072B2' if v>=0 else '#D55E00' for v in rr.mean_coefficient_when_selected]
    ax.barh(range(20),rr.mean_absolute_coefficient_all15,color=cols)
    ax.set(yticks=range(20),yticklabels=[f'{r.CF39_rank:02d}  {r.gene_symbol}' for r in rr.itertuples()],xlabel='Mean absolute CF18 coefficient across 15 outer fits',title='CF39 | Stable-core importance in fixed panel order')
    for i,r in enumerate(rr.itertuples()): ax.text(r.mean_absolute_coefficient_all15+.003,i,f'Selected {int(r.selected_outer_splits)}/15',va='center',fontsize=8)
    ax.set_xlim(0,ranking.mean_absolute_coefficient_all15.max()*1.4)
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color='#0072B2',label='Predominantly positive'),Patch(color='#D55E00',label='Predominantly negative')],loc='lower right',fontsize=8)
    finish(fig,'Figure2_gene_importance')
    fig,ax=plt.subplots(figsize=(6.4,5.7))
    for name in order:
        fpr,tpr,_=roc_curve(y,pooled[name]); ax.plot(fpr,tpr,color=colors[name],lw=1.7,ls='--' if name=='CF18 full' else '-',label=f"{name}: AUROC {points[name]['AUROC']:.3f}")
    ax.plot([0,1],[0,1],':',color='0.6'); ax.set(xlabel='False-positive rate',ylabel='Sensitivity',xlim=(0,1),ylim=(0,1.02),title='CF39 | Conditional TCGA OOF ROC curves'); ax.legend(loc='lower right',fontsize=9)
    finish(fig,'Figure3_ROC_curves')
    assert all(sha(ROOT/p)==h for p,h in before.items())
    provenance={'run_utc':datetime.now(timezone.utc).isoformat(),'input_sha256':before,'input_hashes_unchanged':True,
                'script_sha256':sha(Path(__file__)),'runtime_parser_sha256':sha(Path(__file__).parent/'_runtime/_strptime.py'),
                'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__,
                'n_patients':len(y),'n_positive':int(y.sum()),'n_negative':int((y==0).sum()),'recommended_size':int(recommended),
                'bootstrap_replicates':BOOT,'seed':SEED,'outer_fits':60,'inner_candidates_per_fit':12,'CF18_model_refit':False}
    (RES/'CF39_provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
    panel_text='\n'.join(f'- **{name}**: '+', '.join(gg)+'.' for name,gg in panels.items())
    perf_text='\n'.join('| '+name+' | '+' | '.join(f'{points[name][m]:.4f}' for m in metric_names)+' |' for name in model_names)
    delta_text='\n'.join(f'| {r.panel} | {r.reference} | {r.metric} | {r.difference:+.4f} | {r.lower_95:+.4f} to {r.upper_95:+.4f} |' for r in diffs.itertuples() if r.metric in ['AUROC','PR_AUC'])
    chosen=f'Top {recommended}'
    conclusion=(f'The {recommended}-gene panel is the smallest tested panel meeting the prespecified conditional performance-retention rule. It is the provisional research recommendation, not a replacement for the locked CF18 model.' if eligible else 'No reduced panel meets every prespecified retention criterion. Retain the 20-gene core as the provisional reference; the present analysis does not support a smaller final panel under this rule.')
    report=f'''# CF39: Minimal HER2 Stable Signature Development

## Scientific question and conclusion

Can the stable HER2 transcriptomic signature be simplified into a smaller biologically interpretable panel without substantial loss of predictive performance?

{conclusion} For {chosen}, AUROC is {points[chosen]['AUROC']:.4f} and PR-AUC is {points[chosen]['PR_AUC']:.4f}, compared with {points['Top 20']['AUROC']:.4f}/{points['Top 20']['PR_AUC']:.4f} for the 20-gene core and {points['CF18 full']['AUROC']:.4f}/{points['CF18 full']['PR_AUC']:.4f} for the archived CF18 patient-level OOF reference. Any performance-retention conclusion is conditional on the previously selected genes and must be confirmed in genuinely independent data.

## Rationale and locked reference

CF18 contains a 20-gene CORE_STABLE set selected in at least 12/15 outer fits, nonzero in at least 12/15 fits, with sign consistency >=0.80. It is distinct from the final CF18 86-nonzero-gene model (500 selected features, C=0.01, l1_ratio=0.25). The original bundle, features, stable core, calibration, and OOF predictions were read-only. No CF18 model was refit, pruned in place, or overwritten. CF39 fits separate research models using fixed subsets of the 20-gene core; it does not reuse the later CF32 panel.

## Fixed panel ranking and biology

All 20 genes first qualify by the same CORE_STABLE tier. The deterministic descending ranking then uses selection frequency, nonzero frequency, mean absolute coefficient across all 15 CF18 outer fits, final absolute CF18 coefficient, and curated HER2 biological relevance as a final tie-breaker; symbol resolves residual ties. Biology does not override better statistical evidence, and no coefficient ties require a biological override in this dataset. Rankings and panel membership were saved before fitting any CF39 model. Coefficient-based ranks remain conditional on the original model, not causal importance.

{panel_text}

STARD3, MIEN1, and PGAP3 have HER2-amplicon context; MIR4728 is encoded within HER2. PAX7 is a developmental transcription factor with no direct HER2 mechanism assigned here. Other genes retain existing UniProt/STRING function annotations from the project, and uncurated HER2 mechanisms are explicitly marked rather than invented. Biological co-amplification is not proof of mechanistic causality. ERBB2 need not enter the smallest panel because this is a stability-led ranking rather than a forced HER2-gene inclusion rule. A small correlated panel can read out the HER2 locus without representing multiple independent pathways.

## Cohort and preprocessing

938 TCGA primary tumors: 182 HER2-positive and 756 HER2-negative. Labels and patient order come from the locked CF15 matrix and are verified against CF18 OOF predictions and the original fold registry. No external cohort was used. CF15 ranks each sample across the frozen 22,106-gene universe; CF39 reuses those values exactly and subsets the ranked features afterward. Every scaler is learned only within its corresponding training partition. No outcome-dependent normalization, batch correction, gene replacement, or additional gene screening occurs in CF39.

**A reduced predictor is not yet a stand-alone 5/10/15/20-gene laboratory assay:** its features still require transcriptome-wide ranks. An assay measuring only the panel would require a separately developed and validated normalization scheme. MIR4728 is a noncoding feature; its gene-level RNA-seq signal is not automatically equivalent to mature-miRNA abundance or a microarray probe measurement.

## Validation strategy and its limits

Use the original CF15 repeated stratified outer folds (3 repeats x 5 folds). For each of four fixed panels and each outer training set, a four-fold inner CV tunes Elastic-Net C in {{0.01, 0.1, 1, 10}} and l1_ratio in {{0.25, 0.5, 0.75}} by mean AUROC. StandardScaler is inside the pipeline. The model uses balanced class weights, saga, max_iter=10000, tol=1e-4; convergence warnings cause failure. The best inner candidate is refit on that outer training partition and predicts its untouched outer test partition. Thus parameter fitting and tuning never use the corresponding outer test labels.

**Feature-selection leakage remains:** CF18 core membership and coefficient ranking were derived using these same TCGA patients across prior fits. Nesting CF39 hyperparameter tuning does not undo that prior selection. These are conditional, post-selection internal estimates, not unbiased nested validation of the entire discovery pipeline. The selection of a recommended size on these results introduces further selection optimism. No independent generalization claim is made.

Each patient receives one held-out prediction per repeat. The primary metrics use the mean of those three probabilities, yielding 938 unique patient records per panel. Repeats are not treated as independent patients. Fold metrics are provided as diagnostics; the primary AUROC is not the mean of 15 fold AUROCs. CF18 comparison uses its existing mean-OOF calibrated predictions, not in-sample predictions from the final bundle. Historical OOF fits are a reference for the full model-development procedure, not a new evaluation of the final fixed 86-gene fit.

Reduced models use a prespecified threshold of 0.5 on their class-balanced probability scores, with no calibration or threshold optimization. These scores are not prevalence-calibrated risks. CF18 retains its own archived calibrated probabilities and threshold {thresholds['CF18 full']:.10f}. Its OOF calibrator and operating threshold were estimated from the same archived OOF labels, so its operating-point performance has additional selection optimism. Sensitivity/specificity comparisons against CF18 therefore involve different operating policies, not pure panel-size effects. Comparisons among the four CF39 panels use the same policy.

## Performance comparison

| Model | AUROC | PR-AUC | Sensitivity | Specificity | PPV | NPV |
|---|---:|---:|---:|---:|---:|---:|
{perf_text}

PR-AUC means average precision (stepwise integration), with prevalence baseline {y.mean():.4f}. The full `CF39_performance.tsv` supplies 95% intervals for all metrics. These use 2,000 stratified paired patient bootstrap samples, seed {SEED}; all models share each bootstrap draw. Intervals condition on fitted OOF predictions and the selected genes, omit discovery/tuning/model-fitting variability, and are not confirmatory noninferiority intervals. No overlapping-fold t-tests are used.

| Panel | Reference | Metric | Panel minus reference | Conditional 95% interval |
|---|---|---|---:|---:|
{delta_text}

## Recommendation rule and interpretation

Before evaluation, substantial discrimination loss was operationalized as >0.02 absolute AUROC or >0.03 absolute PR-AUC. These are pragmatic exploratory margins, not clinically established tolerances. A reduced panel qualifies only if both paired lower 95% bounds exceed the negative margin against both the 20-gene model and CF18; it must also lose no more than 0.05 absolute sensitivity or specificity versus the 20-gene panel at the shared 0.5 threshold. The smallest qualifying size is selected. PPV and NPV are reported but not optimization targets; they depend on prevalence. Failure of a confidence-bound rule is insufficient evidence of retention, not proof of inferiority.

**Provisional recommended size: {recommended} genes.** Recommended genes: {', '.join(panels[chosen])}. {conclusion}

No final deployment model is serialized and CF18 remains the locked prediction model. A smaller panel may capture redundant amplicon signals efficiently, but reduced feature count alone neither proves mechanistic specificity nor validates an assay. External validation of the frozen candidate and appropriate assay normalization would be needed before replacement of CF18.

## Figures and files

- Figure 1: six-metric performance comparison by panel size, including the historical CF18 reference, with conditional 95% intervals.
- Figure 2: gene importance in the fixed ranking order; bars show mean absolute outer-fit coefficients, labels show selection frequency, colors show predominant coefficient sign.
- Figure 3: patient-averaged OOF ROC curves for all four panels and CF18.

All figures are supplied as 400-dpi PNG and PDF. Results include ranking and annotations, panel membership, inner searches, chosen parameters, outer coefficients and predictions, patient OOF predictions, confusion matrices, paired differences, selection-rule decisions, and the recommended gene list. Input hashes are unchanged after execution. Reproduce from the project root with `.venv/Scripts/python.exe CF39_minimal_HER2_signature/scripts/CF39_refine.py`. A CF39-local copy of the official CPython 3.10.11 `_strptime.py` is used to bypass the pre-existing corrupted system file without modifying the environment.

## Biological sources

- [Primary HER2 amplicon study](https://pmc.ncbi.nlm.nih.gov/articles/PMC2917012/): amplicon context, including historical symbols C17orf37 (MIEN1) and PERLD1 (PGAP3).
- [HER2-intronic MIR4728 and ESR1 interaction](https://pubmed.ncbi.nlm.nih.gov/24828673/).
- [NCBI PAX7 annotation](https://www.ncbi.nlm.nih.gov/gene/5081).
- Existing project `CF30_5_gene_identifier_mapping.tsv`: protein/function annotations only; no CF30.5 gene-set expansion or scoring was performed.
'''
    (REPORT/'CF39_report.md').write_text(report,encoding='utf-8')
    print('COMPLETE. Provisional recommended size: '+str(recommended),flush=True)

if __name__=='__main__': main()
