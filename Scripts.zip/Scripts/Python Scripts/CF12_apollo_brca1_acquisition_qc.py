#!/usr/bin/env python
"""
CF12 - APOLLO-BRCA-1 acquisition + multi-omics QC

Purpose
-------
Acquire and verify the nine open-access APOLLO-BRCA-1 publication data files
from the NCI GDC, capture the 68-case project metadata, audit tabular structure,
and freeze the multi-omics evidence layers for later cross-omics confirmation.

This stage DOES NOT:
- download controlled WGS/variant/CNV data;
- harmonize APOLLO with TCGA or SCAN-B (CF13);
- train or tune ML models;
- use APOLLO as a model-performance validation cohort.

Scientific role
---------------
APOLLO-BRCA-1 is an orthogonal proteogenomic confirmation cohort.
Primary confirmation layers:
  1) RNA expression (UQ-normalized log2)
  2) global proteomics, unimputed
  3) phosphoproteomics, global-adjusted unimputed
Sensitivity/support layers:
  - imputed proteomics/phosphoproteomics
  - raw phosphoproteomics
  - RPPA

Open files are frozen from the official GDC publication page by UUID and are
verified against the official NCI GDC publication manifest (UUID, filename, size, MD5).
"""

from __future__ import annotations

import csv
import hashlib
import json
import logging
import math
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path.cwd()

CF11_SUMMARY = (
    PROJECT_ROOT / "results" / "CF11_scanb_acquisition_qc" / "CF11_summary.tsv"
)

RAW_DIR = PROJECT_ROOT / "data" / "raw" / "apollo_brca1" / "open"
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed" / "apollo_brca1"
RESULTS_DIR = PROJECT_ROOT / "results" / "CF12_apollo_brca1_acquisition_qc"
LOG_DIR = PROJECT_ROOT / "logs"
LOG_FILE = LOG_DIR / "CF12_apollo_brca1_acquisition_qc.log"

GDC_API = "https://api.gdc.cancer.gov"
PROJECT_ID = "APOLLO-BRCA-1"
EXPECTED_CASES = 68

PUBLICATION_MANIFEST_URL = (
    "https://gdc.cancer.gov/system/files/public/file/"
    "APOLLO-BRCA-1_Open_Manifest.txt"
)
PUBLICATION_MANIFEST = RAW_DIR / "CF12_APOLLO-BRCA-1_Open_Manifest.txt"

HTTP_TIMEOUT = 90

# Official open-access publication files from the NCI GDC APOLLO-BRCA-1 page.
OPEN_FILES = [
    {
        "file_id": "bfb7ab3f-8332-4e16-ae75-2c690a6fad85",
        "expected_name": "apollo-brca1.rnaseq.expressed_genes.level3.UQnorm_log2.txt",
        "layer": "RNA",
        "role": "PRIMARY_TRANSCRIPTOME_CONFIRMATION",
    },
    {
        "file_id": "131703e3-1a5f-46b4-a3ba-8f748d060ce2",
        "expected_name": "apollo-brca1.globalproteomics_level3_Imputed.txt",
        "layer": "GLOBAL_PROTEOMICS_IMPUTED",
        "role": "SENSITIVITY_SUPPORT",
    },
    {
        "file_id": "7f42f1a0-d21c-408b-a23a-32dcfa7ea851",
        "expected_name": "apollo-brca1.globalproteomics_level3_unimputed.txt",
        "layer": "GLOBAL_PROTEOMICS_UNIMPUTED",
        "role": "PRIMARY_PROTEIN_CONFIRMATION",
    },
    {
        "file_id": "f527526c-bac8-494a-ac4e-56442593ef74",
        "expected_name": "apollo-brca1.phosphoproteomics_level3_raw_Imputed.txt",
        "layer": "PHOSPHO_RAW_IMPUTED",
        "role": "SENSITIVITY_SUPPORT",
    },
    {
        "file_id": "c4dd4241-cb39-4947-a5f6-c13f4c176e83",
        "expected_name": "apollo-brca1.phosphoproteomics_level3_raw_unimputed.txt",
        "layer": "PHOSPHO_RAW_UNIMPUTED",
        "role": "SENSITIVITY_SUPPORT",
    },
    {
        "file_id": "068f8466-3842-4b6c-a3c0-1ce430961018",
        "expected_name": "apollo-brca1.phosphoproteomics_level3_adjusted_by_global_Imputed.txt",
        "layer": "PHOSPHO_GLOBAL_ADJUSTED_IMPUTED",
        "role": "SENSITIVITY_SUPPORT",
    },
    {
        "file_id": "9c4b2854-5f94-491a-a69d-bc1720babe82",
        "expected_name": "apollo-brca1.phosphoproteomics_level3_adjusted_by_global_unimputed.txt",
        "layer": "PHOSPHO_GLOBAL_ADJUSTED_UNIMPUTED",
        "role": "PRIMARY_PHOSPHO_CONFIRMATION",
    },
    {
        "file_id": "b23d2e5c-c4f9-46d3-ae17-09339c36cdcd",
        "expected_name": "apollo-brca1.proteomics_phopho_Datadictionary.xlsx",
        "layer": "PROTEOMICS_DATA_DICTIONARY",
        "role": "ANNOTATION_SUPPORT",
    },
    {
        "file_id": "295c0d9e-b52a-4487-8b30-fb96d39ef3bf",
        "expected_name": "apollo-brca1.RPPA_level3_imputed.xlsx",
        "layer": "RPPA",
        "role": "ORTHOGONAL_TARGETED_PROTEIN_SUPPORT",
    },
]

# Controlled files are intentionally NOT acquired in CF12.
CONTROLLED_LAYERS_NOT_DOWNLOADED = [
    "Somatic Variant Calls (VCF)",
    "Somatic Mutation Annotation File (MAF)",
    "Copy Number Segments",
    "Gene-level Copy Number",
]


# ============================================================
# UTILITIES
# ============================================================

def setup_logging() -> None:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def make_session() -> requests.Session:
    retry = Retry(
        total=8,
        connect=8,
        read=8,
        status=8,
        backoff_factor=1.0,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET", "POST"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=8, pool_maxsize=8)
    session = requests.Session()
    session.mount("https://", adapter)
    session.headers.update({"User-Agent": "TCGA-BRCA-CF12/1.0"})
    return session


def load_metric_table(path: Path) -> Dict[str, str]:
    df = pd.read_csv(path, sep="\t", dtype=str)
    if {"metric", "value"}.issubset(df.columns):
        return dict(zip(df["metric"].astype(str), df["value"].astype(str)))
    if {"field", "value"}.issubset(df.columns):
        return dict(zip(df["field"].astype(str), df["value"].astype(str)))
    return {}


def md5_file(path: Path, chunk: int = 8 * 1024 * 1024) -> str:
    h = hashlib.md5()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def sha256_file(path: Path, chunk: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def safe_json_get(session: requests.Session, url: str, params: Optional[dict] = None) -> dict:
    r = session.get(url, params=params, timeout=HTTP_TIMEOUT)
    r.raise_for_status()
    return r.json()


def download_publication_manifest() -> None:
    """Download the official NCI GDC APOLLO-BRCA-1 open-access manifest."""
    partial = PUBLICATION_MANIFEST.with_suffix(".txt.partial")
    if partial.exists():
        partial.unlink()

    cmd = [
        "curl.exe",
        "-4",
        "-L",
        "--fail",
        "--retry", "8",
        "--retry-delay", "3",
        "--connect-timeout", "30",
        "--max-time", "300",
        PUBLICATION_MANIFEST_URL,
        "-o", str(partial),
    ]
    proc = subprocess.run(cmd)
    if proc.returncode != 0:
        raise RuntimeError(
            f"Failed to download official publication manifest "
            f"(curl exit {proc.returncode})."
        )
    if not partial.exists() or partial.stat().st_size < 100:
        raise RuntimeError("Downloaded publication manifest is missing/too small.")

    if PUBLICATION_MANIFEST.exists():
        PUBLICATION_MANIFEST.unlink()
    partial.replace(PUBLICATION_MANIFEST)


def parse_publication_manifest(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, sep="\t", dtype=str)
    required = {"id", "filename", "md5", "size"}
    if not required.issubset(df.columns):
        raise RuntimeError(
            f"Official publication manifest missing columns: "
            f"{sorted(required - set(df.columns))}"
        )

    if len(df) != 9:
        raise RuntimeError(
            f"Official APOLLO open manifest contains {len(df)} files; expected 9."
        )

    df["size"] = pd.to_numeric(df["size"], errors="raise").astype("int64")

    if df["id"].duplicated().any() or df["filename"].duplicated().any():
        raise RuntimeError("Duplicate UUID or filename in official publication manifest.")

    return df


def fetch_file_metadata(session: requests.Session, file_id: str) -> dict:
    fields = (
        "file_id,file_name,md5sum,file_size,state,access,"
        "data_category,data_type,data_format,experimental_strategy,"
        "platform,updated_datetime"
    )

    # Primary route.
    url = f"{GDC_API}/files/{file_id}"
    try:
        payload = safe_json_get(session, url, params={"fields": fields})
        data = payload.get("data")
        if isinstance(data, dict) and data.get("file_id"):
            return data
    except Exception:
        pass

    # Fallback filtered /files route.
    filters = {
        "op": "in",
        "content": {"field": "file_id", "value": [file_id]},
    }
    payload = safe_json_get(
        session,
        f"{GDC_API}/files",
        params={
            "filters": json.dumps(filters),
            "fields": fields,
            "size": 10,
        },
    )
    hits = payload.get("data", {}).get("hits", [])
    if len(hits) != 1:
        raise RuntimeError(
            f"GDC metadata query for {file_id} returned {len(hits)} records."
        )
    return hits[0]


def download_gdc_file(file_id: str, dest: Path, expected_size: int, expected_md5: str) -> str:
    """
    Download with Windows curl.exe. Valid existing files are reused.
    """
    if (
        dest.exists()
        and dest.stat().st_size == expected_size
        and md5_file(dest).lower() == expected_md5.lower()
    ):
        return "CACHED_VALID"

    partial = dest.with_suffix(dest.suffix + ".partial")
    if partial.exists():
        partial.unlink()

    url = f"{GDC_API}/data/{file_id}"
    cmd = [
        "curl.exe",
        "-4",
        "-L",
        "--fail",
        "--retry", "8",
        "--retry-delay", "5",
        "--connect-timeout", "30",
        "--max-time", "3600",
        url,
        "-o", str(partial),
    ]

    proc = subprocess.run(cmd)
    if proc.returncode != 0:
        raise RuntimeError(
            f"curl.exe failed for {dest.name} with exit code {proc.returncode}."
        )

    if not partial.exists():
        raise RuntimeError(f"Download produced no file: {dest.name}")

    size_ok = partial.stat().st_size == expected_size
    md5_ok = md5_file(partial).lower() == expected_md5.lower()

    if not size_ok or not md5_ok:
        partial.unlink(missing_ok=True)
        raise RuntimeError(
            f"Integrity failure for {dest.name}: size_ok={size_ok}, md5_ok={md5_ok}"
        )

    if dest.exists():
        dest.unlink()
    partial.replace(dest)
    return "DOWNLOADED_VALID"


def flatten_case(case: dict) -> dict:
    demo = case.get("demographic") or {}
    diagnoses = case.get("diagnoses") or []
    samples = case.get("samples") or []

    row = {
        "case_id": case.get("case_id"),
        "patient_id": case.get("submitter_id"),
        "sex": demo.get("gender") or demo.get("sex_at_birth"),
        "race": demo.get("race"),
        "ethnicity": demo.get("ethnicity"),
        "vital_status": demo.get("vital_status"),
        "age_at_index": demo.get("age_at_index"),
        "days_to_death": demo.get("days_to_death"),
        "diagnosis_record_count": len(diagnoses),
        "sample_record_count": len(samples),
        "sample_submitter_ids": ";".join(
            str(x.get("submitter_id"))
            for x in samples
            if x.get("submitter_id") is not None
        ),
        "sample_types": ";".join(
            sorted(
                set(
                    str(x.get("sample_type"))
                    for x in samples
                    if x.get("sample_type") is not None
                )
            )
        ),
    }

    # Preserve compact diagnosis evidence without arbitrary record selection.
    for field in [
        "primary_diagnosis",
        "ajcc_pathologic_stage",
        "ajcc_pathologic_t",
        "ajcc_pathologic_n",
        "ajcc_pathologic_m",
        "tumor_grade",
        "age_at_diagnosis",
        "days_to_last_follow_up",
        "progression_or_recurrence",
    ]:
        vals = []
        for d in diagnoses:
            v = d.get(field)
            if v is not None and str(v).strip() != "":
                vals.append(str(v))
        row[field] = " | ".join(sorted(set(vals)))

    return row


def fetch_project_cases(session: requests.Session) -> List[dict]:
    filters = {
        "op": "in",
        "content": {
            "field": "project.project_id",
            "value": [PROJECT_ID],
        },
    }
    params = {
        "filters": json.dumps(filters),
        "expand": "demographic,diagnoses,samples",
        "size": 500,
    }
    payload = safe_json_get(session, f"{GDC_API}/cases", params=params)
    return payload.get("data", {}).get("hits", [])


def audit_text_file(path: Path) -> dict:
    # APOLLO TXT files are tabular; parse with pandas using tab first, then
    # whitespace fallback only if necessary.
    try:
        df = pd.read_csv(path, sep="\t", low_memory=False)
        delimiter = "TAB"
        if df.shape[1] == 1:
            df = pd.read_csv(path, sep=None, engine="python")
            delimiter = "AUTO"
    except Exception as exc:
        raise RuntimeError(f"Failed to parse text file {path.name}: {exc}")

    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    total_cells = int(df.shape[0] * df.shape[1])
    missing_cells = int(df.isna().sum().sum())

    return {
        "file_name": path.name,
        "format": "TXT",
        "delimiter": delimiter,
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "first_column": str(df.columns[0]) if len(df.columns) else "",
        "numeric_columns": len(numeric_cols),
        "missing_cells": missing_cells,
        "missing_percent": (
            round(100.0 * missing_cells / total_cells, 4)
            if total_cells > 0
            else 0.0
        ),
        "duplicate_first_column_values": (
            int(df.iloc[:, 0].astype(str).duplicated().sum())
            if df.shape[1] > 0
            else 0
        ),
    }


def audit_xlsx_file(path: Path) -> List[dict]:
    try:
        import openpyxl
    except ImportError as exc:
        raise RuntimeError(
            "CF12 requires openpyxl for APOLLO XLSX audit. Install with: "
            "conda install -n hasan_2026 openpyxl"
        ) from exc

    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    rows = []
    try:
        for ws in wb.worksheets:
            first_row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), ())
            rows.append(
                {
                    "file_name": path.name,
                    "format": "XLSX",
                    "delimiter": "",
                    "sheet": ws.title,
                    "rows": int(ws.max_row),
                    "columns": int(ws.max_column),
                    "first_column": (
                        "" if not first_row or first_row[0] is None
                        else str(first_row[0])
                    ),
                    "numeric_columns": "",
                    "missing_cells": "",
                    "missing_percent": "",
                    "duplicate_first_column_values": "",
                }
            )
    finally:
        wb.close()
    return rows


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    setup_logging()
    start = time.time()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF12 - APOLLO-BRCA-1 ACQUISITION + MULTI-OMICS QC")
    logging.info("============================================================")
    logging.info("")
    logging.info("Estimated runtime: ~5-20 minutes")
    logging.info("Likely bottleneck: download + MD5 verification of 9 open files")
    logging.info("Long silent periods are NOT expected; each file is reported.")
    logging.info("")

    # --------------------------------------------------------
    # 1. Validate CF11 + GDC
    # --------------------------------------------------------
    logging.info("[1/7] Validating CF11 and GDC availability...")
    logging.info("")

    if not CF11_SUMMARY.exists():
        raise FileNotFoundError(f"CF11 summary missing: {CF11_SUMMARY}")

    cf11 = load_metric_table(CF11_SUMMARY)
    if not cf11.get("CF11 stage gate", "").upper().startswith("PASS"):
        raise RuntimeError("CF11 stage gate is not PASS.")

    session = make_session()
    status = safe_json_get(session, f"{GDC_API}/status")
    if str(status.get("status", "")).upper() != "OK":
        raise RuntimeError(f"GDC API status is not OK: {status}")

    gdc_release = (
        status.get("data_release")
        or status.get("data_release_version")
        or status.get("version")
        or ""
    )

    logging.info("CF11 stage gate: PASS")
    logging.info(f"GDC status: OK")
    logging.info(f"GDC release/status text: {gdc_release}")
    logging.info("")

    # --------------------------------------------------------
    # 2. Verify official open-file inventory against publication manifest
    # --------------------------------------------------------
    logging.info("[2/7] Verifying 9 official open-access APOLLO files...")
    logging.info("      Source of truth: NCI GDC publication open-access manifest")
    logging.info("")

    download_publication_manifest()
    manifest_df = parse_publication_manifest(PUBLICATION_MANIFEST)

    manifest_by_id = manifest_df.set_index("id", drop=False)

    inventory_rows = []

    for spec in OPEN_FILES:
        file_id = spec["file_id"]
        if file_id not in manifest_by_id.index:
            raise RuntimeError(
                f"Expected UUID not present in official publication manifest: {file_id}"
            )

        row = manifest_by_id.loc[file_id]
        observed_name = str(row["filename"])
        md5sum = str(row["md5"])
        file_size = int(row["size"])

        if observed_name != spec["expected_name"]:
            raise RuntimeError(
                f"Publication-manifest filename mismatch for {file_id}: "
                f"expected '{spec['expected_name']}', observed '{observed_name}'"
            )
        if not re.fullmatch(r"[0-9a-fA-F]{32}", md5sum):
            raise RuntimeError(
                f"Invalid/missing MD5 in publication manifest for {observed_name}"
            )
        if file_size <= 0:
            raise RuntimeError(
                f"Invalid size in publication manifest for {observed_name}"
            )

        inventory_rows.append(
            {
                "file_id": file_id,
                "file_name": observed_name,
                "layer": spec["layer"],
                "CF12_role": spec["role"],
                "access": "open",
                "file_size": file_size,
                "md5sum": md5sum,
                "inventory_source": "NCI_GDC_PUBLICATION_MANIFEST",
            }
        )

        logging.info(
            f"Verified publication manifest: {observed_name} "
            f"({file_size / (1024**2):.2f} MiB)"
        )

    expected_ids = {x["file_id"] for x in OPEN_FILES}
    manifest_ids = set(manifest_df["id"].astype(str))
    if manifest_ids != expected_ids:
        extra = sorted(manifest_ids - expected_ids)
        missing = sorted(expected_ids - manifest_ids)
        raise RuntimeError(
            "Publication manifest does not exactly match expected 9-file inventory. "
            f"Missing={missing}; extra={extra}"
        )

    inventory = pd.DataFrame(inventory_rows)
    inventory.to_csv(
        RESULTS_DIR / "CF12_open_file_inventory.tsv",
        sep="\t",
        index=False,
    )

    logging.info("")
    logging.info(f"Official open files verified: {len(inventory)}/9")
    logging.info(
        f"Publication manifest SHA256: {sha256_file(PUBLICATION_MANIFEST)}"
    )
    logging.info("")

    # --------------------------------------------------------
    # 3. Download + exact integrity
    # --------------------------------------------------------
    logging.info("[3/7] Downloading/reusing and MD5-validating open files...")
    logging.info("")

    integrity_rows = []

    for row in inventory_rows:
        dest = RAW_DIR / row["file_name"]
        logging.info(f"Processing: {row['file_name']}")

        status_download = download_gdc_file(
            row["file_id"],
            dest,
            int(row["file_size"]),
            str(row["md5sum"]),
        )

        observed_size = dest.stat().st_size
        observed_md5 = md5_file(dest)

        integrity_rows.append(
            {
                "file_id": row["file_id"],
                "file_name": row["file_name"],
                "download_status": status_download,
                "expected_size": row["file_size"],
                "observed_size": observed_size,
                "size_match": observed_size == int(row["file_size"]),
                "expected_md5": row["md5sum"],
                "observed_md5": observed_md5,
                "md5_match": observed_md5.lower() == str(row["md5sum"]).lower(),
            }
        )

    integrity = pd.DataFrame(integrity_rows)
    integrity.to_csv(
        RESULTS_DIR / "CF12_download_integrity.tsv",
        sep="\t",
        index=False,
    )

    if not integrity["size_match"].all() or not integrity["md5_match"].all():
        raise RuntimeError("One or more APOLLO files failed integrity validation.")

    logging.info("")
    logging.info("Open-file integrity: 9/9 PASS")
    logging.info("")

    # --------------------------------------------------------
    # 4. Capture project cases/clinical/sample metadata
    # --------------------------------------------------------
    logging.info("[4/7] Retrieving APOLLO project case/sample metadata...")
    logging.info("")

    cases = fetch_project_cases(session)

    raw_cases = RAW_DIR / "CF12_gdc_cases_raw.json"
    raw_cases.write_text(
        json.dumps(cases, indent=2, sort_keys=True),
        encoding="utf-8",
    )

    case_df = pd.DataFrame([flatten_case(x) for x in cases])
    case_df = case_df.sort_values("patient_id").reset_index(drop=True)
    case_df.to_csv(
        PROCESSED_DIR / "CF12_case_sample_inventory.tsv",
        sep="\t",
        index=False,
    )

    if len(case_df) != EXPECTED_CASES:
        raise RuntimeError(
            f"APOLLO-BRCA-1 GDC cases={len(case_df)}; expected {EXPECTED_CASES}."
        )
    if case_df["patient_id"].duplicated().any():
        raise RuntimeError("Duplicate APOLLO patient IDs returned by GDC.")

    logging.info(f"APOLLO cases: {len(case_df)}")
    logging.info(
        f"Cases with >=1 sample record: "
        f"{int((case_df['sample_record_count'] > 0).sum())}/{len(case_df)}"
    )
    logging.info("")

    # --------------------------------------------------------
    # 5. Structural/tabular QC
    # --------------------------------------------------------
    logging.info("[5/7] Auditing tabular structure of all open multi-omics files...")
    logging.info("")

    structure_rows = []
    for spec in OPEN_FILES:
        path = RAW_DIR / spec["expected_name"]

        if path.suffix.lower() == ".txt":
            audit = audit_text_file(path)
            audit["layer"] = spec["layer"]
            audit["CF12_role"] = spec["role"]
            structure_rows.append(audit)
        elif path.suffix.lower() == ".xlsx":
            audits = audit_xlsx_file(path)
            for audit in audits:
                audit["layer"] = spec["layer"]
                audit["CF12_role"] = spec["role"]
                structure_rows.append(audit)
        else:
            raise RuntimeError(f"Unexpected APOLLO file format: {path.name}")

        logging.info(f"Structure audited: {path.name}")

    structure = pd.DataFrame(structure_rows)
    structure.to_csv(
        RESULTS_DIR / "CF12_tabular_structure_qc.tsv",
        sep="\t",
        index=False,
    )

    logging.info("")
    logging.info(f"Tabular structures audited: {len(structure_rows)} table/sheet records")
    logging.info("")

    # --------------------------------------------------------
    # 6. Freeze intended validation-layer hierarchy
    # --------------------------------------------------------
    logging.info("[6/7] Freezing APOLLO validation-layer hierarchy...")
    logging.info("")

    roles = pd.DataFrame(
        [
            (
                "RNA",
                "PRIMARY",
                "Cross-omics transcriptomic confirmation",
                "UQ-normalized log2 RNA expression",
            ),
            (
                "GLOBAL_PROTEOMICS_UNIMPUTED",
                "PRIMARY",
                "Protein-level confirmation",
                "Prefer observed/unimputed values; missingness preserved",
            ),
            (
                "PHOSPHO_GLOBAL_ADJUSTED_UNIMPUTED",
                "PRIMARY",
                "Phosphosite-level confirmation",
                "Prefer global-protein-adjusted unimputed phosphoproteomics",
            ),
            (
                "GLOBAL_PROTEOMICS_IMPUTED",
                "SENSITIVITY",
                "Protein sensitivity analysis",
                "Imputed matrix is not primary evidence",
            ),
            (
                "PHOSPHO_RAW_UNIMPUTED",
                "SENSITIVITY",
                "Raw phosphosite sensitivity",
                "Unadjusted phosphoproteomics support",
            ),
            (
                "PHOSPHO_RAW_IMPUTED",
                "SENSITIVITY",
                "Raw phosphosite imputed sensitivity",
                "Imputed matrix is not primary evidence",
            ),
            (
                "PHOSPHO_GLOBAL_ADJUSTED_IMPUTED",
                "SENSITIVITY",
                "Adjusted phosphosite sensitivity",
                "Imputed matrix is not primary evidence",
            ),
            (
                "RPPA",
                "SUPPORT",
                "Orthogonal targeted protein support",
                "Targeted antibody-based protein measurements",
            ),
            (
                "PROTEOMICS_DATA_DICTIONARY",
                "ANNOTATION",
                "Variable/feature interpretation",
                "Dictionary only",
            ),
        ],
        columns=[
            "layer",
            "evidence_priority",
            "planned_role",
            "rationale",
        ],
    )

    roles.to_csv(
        RESULTS_DIR / "CF12_validation_layer_plan.tsv",
        sep="\t",
        index=False,
    )

    logging.info("Primary APOLLO evidence layers:")
    logging.info("  RNA")
    logging.info("  Global proteomics (unimputed)")
    logging.info("  Global-adjusted phosphoproteomics (unimputed)")
    logging.info("")

    # --------------------------------------------------------
    # 7. Summary/provenance/final gate
    # --------------------------------------------------------
    logging.info("[7/7] Writing CF12 summary and provenance...")
    logging.info("")

    total_bytes = int(inventory["file_size"].sum())
    runtime_min = (time.time() - start) / 60.0

    summary = pd.DataFrame(
        [
            ("Project", PROJECT_ID),
            ("Expected invasive breast tumor cases", EXPECTED_CASES),
            ("GDC cases retrieved", len(case_df)),
            ("Official open files expected", 9),
            ("Official open files verified", len(inventory)),
            ("Open files passing size validation", int(integrity["size_match"].sum())),
            ("Open files passing MD5 validation", int(integrity["md5_match"].sum())),
            ("Open-access bytes", total_bytes),
            ("Primary APOLLO evidence layers", 3),
            ("Controlled files downloaded", 0),
            ("Controlled layers intentionally excluded", len(CONTROLLED_LAYERS_NOT_DOWNLOADED)),
            ("APOLLO used for ML training/tuning", "NO"),
            ("APOLLO role", "ORTHOGONAL_PROTEOGENOMIC_CONFIRMATION"),
            ("CF12 runtime minutes", round(runtime_min, 2)),
            ("CF12 stage gate", "PASS"),
        ],
        columns=["metric", "value"],
    )
    summary.to_csv(
        RESULTS_DIR / "CF12_summary.tsv",
        sep="\t",
        index=False,
    )

    provenance_rows = [
        ("code_file", "CF12_apollo_brca1_acquisition_qc.py"),
        ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
        ("project_id", PROJECT_ID),
        ("GDC_API", GDC_API),
        ("GDC_release_status", str(gdc_release)),
        ("publication_manifest_url", PUBLICATION_MANIFEST_URL),
        ("publication_manifest_sha256", sha256_file(PUBLICATION_MANIFEST)),
        (
            "open_file_inventory_method",
            "Validated against the official NCI GDC APOLLO-BRCA-1 publication manifest; "
            "publication-associated UUIDs may not be indexed by the live /files endpoint",
        ),
        (
            "official_open_file_UUIDs",
            json.dumps([x["file_id"] for x in OPEN_FILES]),
        ),
        (
            "controlled_data_policy",
            "No controlled WGS/somatic/CNV data downloaded in CF12",
        ),
        (
            "primary_evidence_hierarchy",
            "RNA + global proteomics unimputed + global-adjusted phosphoproteomics unimputed",
        ),
        (
            "APOLLO_validation_role",
            "Orthogonal biological/cross-omics confirmation; not ML performance validation",
        ),
        ("python_version", sys.version.replace("\n", " ")),
        ("pandas_version", pd.__version__),
        ("numpy_version", np.__version__),
        ("requests_version", requests.__version__),
        ("platform", platform.platform()),
        ("CF12_stage_gate", "PASS"),
    ]

    # File-level SHA256 provenance.
    for row in inventory_rows:
        path = RAW_DIR / row["file_name"]
        provenance_rows.append(
            (f"sha256::{row['file_name']}", sha256_file(path))
        )

    provenance_rows.append(
        ("sha256::CF12_case_sample_inventory.tsv",
         sha256_file(PROCESSED_DIR / "CF12_case_sample_inventory.tsv"))
    )

    pd.DataFrame(
        provenance_rows,
        columns=["field", "value"],
    ).to_csv(
        RESULTS_DIR / "CF12_provenance.tsv",
        sep="\t",
        index=False,
    )

    logging.info("============================================================")
    logging.info(" CF12 COMPLETE - APOLLO-BRCA-1 ACQUISITION/QC GATE PASSED")
    logging.info("============================================================")
    logging.info("")
    logging.info(f"APOLLO cases: {len(case_df)}")
    logging.info("Open files verified/integrity-passed: 9/9")
    logging.info(
        f"Total open-access volume: {total_bytes / (1024**2):.2f} MiB"
    )
    logging.info("Primary confirmation layers: 3")
    logging.info("Controlled files downloaded: 0")
    logging.info(f"CF12 runtime: {runtime_min:.1f} min")
    logging.info("")
    logging.info("IMPORTANT:")
    logging.info("APOLLO remains an orthogonal proteogenomic confirmation cohort.")
    logging.info("It is not used for model training/tuning or performance validation.")
    logging.info("No cross-cohort gene harmonization was performed yet.")
    logging.info("CF12 is ready for review before CF13 cross-cohort harmonization.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF12 ERROR: {exc}")
        sys.exit(1)