#!/usr/bin/env python
"""
CF8 - Finalize RNA-seq QC Review

Purpose
-------
Close the CF8 QC stage without using statistical outlier flags as automatic
sample-exclusion rules.

Scientific decision
-------------------
All CF8 samples are retained unless there is an upstream integrity failure or a
catastrophic QC failure. The 28 robust statistical review candidates remain in
the analytical cohort but are explicitly tagged for later sensitivity analysis.

Why
---
TCGA breast tumors are biologically heterogeneous. PCA/correlation/library-size
outlier status alone is not sufficient evidence that a sample is technically
invalid. Removing such samples automatically could remove genuine tumor biology.

Outputs
-------
data/processed/tcga_brca/qc/
  CF8_final_analytical_cohort.tsv

results/CF8_rnaseq_quality_control/
  CF8_qc_review_resolution.tsv
  CF8_finalization_summary.tsv
  CF8_finalization_provenance.tsv

No expression matrix is modified.
"""

from __future__ import annotations

import hashlib
import logging
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path.cwd()

CF5_SUMMARY = PROJECT_ROOT / "results" / "CF5_post_download_integrity_check" / "CF5_summary.tsv"
CF6_SUMMARY = PROJECT_ROOT / "results" / "CF6_expression_matrix_construction" / "CF6_summary.tsv"
CF7_SUMMARY = PROJECT_ROOT / "results" / "CF7_clinical_harmonization" / "CF7_summary.tsv"

CF8_DIR = PROJECT_ROOT / "results" / "CF8_rnaseq_quality_control"
CF8_SUMMARY = CF8_DIR / "CF8_summary.tsv"
CF8_QC_METRICS = PROJECT_ROOT / "data" / "processed" / "tcga_brca" / "qc" / "CF8_sample_qc_metrics.tsv"
CF8_REVIEW = CF8_DIR / "CF8_sample_review_candidates.tsv"

CF6_MANIFEST = (
    PROJECT_ROOT / "data" / "processed" / "tcga_brca" / "expression"
    / "CF6_final_sample_manifest.tsv"
)

PROCESSED_DIR = PROJECT_ROOT / "data" / "processed" / "tcga_brca" / "qc"
FINAL_COHORT = PROCESSED_DIR / "CF8_final_analytical_cohort.tsv"

LOG_DIR = PROJECT_ROOT / "logs"
LOG_FILE = LOG_DIR / "CF8_finalize_qc_review.log"

EXPECTED_SAMPLES = 1206
EXPECTED_PATIENTS = 1094


def setup_logging():
    CF8_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def load_metrics(path: Path):
    df = pd.read_csv(path, sep="\t", dtype=str)
    if {"metric", "value"}.issubset(df.columns):
        return dict(zip(df["metric"], df["value"]))
    if {"field", "value"}.issubset(df.columns):
        return dict(zip(df["field"], df["value"]))
    return {}


def sha256(path: Path, chunk=8 * 1024 * 1024):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def main():
    setup_logging()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF8 - FINAL QC REVIEW RESOLUTION")
    logging.info("============================================================")
    logging.info("")

    required = [
        CF5_SUMMARY, CF6_SUMMARY, CF7_SUMMARY,
        CF8_SUMMARY, CF8_QC_METRICS, CF8_REVIEW, CF6_MANIFEST,
    ]
    for p in required:
        if not p.exists():
            raise FileNotFoundError(f"Required file missing: {p}")

    # Upstream gates.
    cf5 = load_metrics(CF5_SUMMARY)
    cf6 = load_metrics(CF6_SUMMARY)
    cf7 = load_metrics(CF7_SUMMARY)
    cf8 = load_metrics(CF8_SUMMARY)

    if cf5.get("CF5 integrity gate", "").upper() != "PASS":
        raise RuntimeError("CF5 integrity gate is not PASS.")
    if cf6.get("CF6 stage gate", "").upper() != "PASS":
        raise RuntimeError("CF6 stage gate is not PASS.")
    if cf7.get("CF7 stage gate", "").upper() != "PASS":
        raise RuntimeError("CF7 stage gate is not PASS.")
    if not cf8.get("CF8 stage gate", "").upper().startswith("PASS"):
        raise RuntimeError("CF8 QC stage did not pass.")

    qc = pd.read_csv(CF8_QC_METRICS, sep="\t", dtype=str)
    review = pd.read_csv(CF8_REVIEW, sep="\t", dtype=str)
    manifest = pd.read_csv(CF6_MANIFEST, sep="\t", dtype=str)

    if len(qc) != EXPECTED_SAMPLES:
        raise RuntimeError(f"Unexpected CF8 QC sample count: {len(qc)}")
    if qc["sample_id"].nunique() != EXPECTED_SAMPLES:
        raise RuntimeError("CF8 QC sample IDs are not unique.")
    if qc["patient_id"].nunique() != EXPECTED_PATIENTS:
        raise RuntimeError(f"Unexpected CF8 patient count: {qc['patient_id'].nunique()}")

    if set(qc["sample_id"]) != set(manifest["sample_id"]):
        raise RuntimeError("CF8 QC sample IDs differ from frozen CF6 cohort.")

    review_ids = set(review["sample_id"].astype(str))
    if not review_ids.issubset(set(qc["sample_id"].astype(str))):
        raise RuntimeError("CF8 review-candidate table contains unknown samples.")

    resolution = qc.copy()

    # No review flag is treated as proof of technical invalidity.
    resolution["CF8_final_disposition"] = "RETAIN"
    resolution["CF8_qc_review_status"] = resolution["sample_id"].map(
        lambda s: "RETAIN_WITH_QC_FLAG_FOR_SENSITIVITY"
        if s in review_ids else "RETAIN_NO_QC_FLAG"
    )
    resolution["CF8_exclusion_reason"] = ""
    resolution["CF8_sensitivity_analysis_flag"] = resolution["sample_id"].isin(review_ids)

    # Formal reason is identical for all statistical review candidates.
    resolution["CF8_resolution_rationale"] = resolution["sample_id"].map(
        lambda s:
        (
            "Retained: robust statistical QC flag(s) alone are insufficient "
            "evidence of technical invalidity; sample remains in primary cohort "
            "and is carried to later sensitivity analysis."
            if s in review_ids
            else
            "Retained: no CF8 robust statistical QC review flag."
        )
    )

    if (resolution["CF8_final_disposition"] != "RETAIN").any():
        raise RuntimeError("CF8 finalizer attempted an automatic exclusion.")

    resolution.to_csv(
        CF8_DIR / "CF8_qc_review_resolution.tsv",
        sep="\t",
        index=False,
    )

    final_cols = [
        c for c in [
            "patient_id", "sample_id", "sample_type", "file_id",
            "aliquot_barcode", "plate", "center"
        ] if c in manifest.columns
    ]
    final = manifest[final_cols].copy()
    final = final.merge(
        resolution[
            [
                "sample_id",
                "CF8_qc_review_status",
                "CF8_sensitivity_analysis_flag",
                "CF8_final_disposition",
            ]
        ],
        on="sample_id",
        how="left",
        validate="one_to_one",
    )

    if len(final) != EXPECTED_SAMPLES:
        raise RuntimeError("Final analytical cohort row count changed unexpectedly.")

    final.to_csv(FINAL_COHORT, sep="\t", index=False)

    tumor_n = int((final["sample_type"] == "Primary Tumor").sum())
    normal_n = int((final["sample_type"] == "Solid Tissue Normal").sum())

    summary = pd.DataFrame(
        [
            ("CF5 integrity gate", "PASS"),
            ("CF6 expression gate", "PASS"),
            ("CF7 clinical gate", "PASS"),
            ("CF8 QC gate", cf8.get("CF8 stage gate", "")),
            ("Input biological samples", len(qc)),
            ("QC review candidates", len(review_ids)),
            ("Samples retained", len(final)),
            ("Samples excluded", 0),
            ("Primary Tumor retained", tumor_n),
            ("Solid Tissue Normal retained", normal_n),
            ("Unique patients retained", final["patient_id"].nunique()),
            ("QC-flagged samples carried to sensitivity analysis", len(review_ids)),
            ("Final analytical cohort frozen", "YES"),
            ("CF8 finalization gate", "PASS"),
        ],
        columns=["metric", "value"],
    )
    summary.to_csv(
        CF8_DIR / "CF8_finalization_summary.tsv",
        sep="\t",
        index=False,
    )

    provenance = pd.DataFrame(
        [
            ("code_file", "CF8_finalize_qc_review.py"),
            ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
            ("cf8_qc_metrics_sha256", sha256(CF8_QC_METRICS)),
            ("cf8_review_candidates_sha256", sha256(CF8_REVIEW)),
            ("cf6_manifest_sha256", sha256(CF6_MANIFEST)),
            ("final_analytical_cohort_sha256", sha256(FINAL_COHORT)),
            ("sample_exclusion_rule",
             "No automatic exclusion from robust statistical QC flags alone."),
            ("review_candidate_policy",
             "Retain in primary cohort; carry to later sensitivity analysis."),
            ("automatic_exclusions", 0),
            ("python_version", sys.version.replace("\n", " ")),
            ("pandas_version", pd.__version__),
            ("platform", platform.platform()),
            ("cf8_finalization_gate", "PASS"),
        ],
        columns=["field", "value"],
    )
    provenance.to_csv(
        CF8_DIR / "CF8_finalization_provenance.tsv",
        sep="\t",
        index=False,
    )

    logging.info("CF8 review candidates: %d", len(review_ids))
    logging.info("Automatic exclusions: 0")
    logging.info("Samples retained: %d/%d", len(final), EXPECTED_SAMPLES)
    logging.info("Primary Tumor retained: %d", tumor_n)
    logging.info("Solid Tissue Normal retained: %d", normal_n)
    logging.info("Unique patients retained: %d", final["patient_id"].nunique())
    logging.info("")
    logging.info("============================================================")
    logging.info(" CF8 FINALIZED - ANALYTICAL COHORT FROZEN")
    logging.info("============================================================")
    logging.info("")
    logging.info("All statistical QC review candidates were retained.")
    logging.info("QC-flagged samples are preserved for later sensitivity analysis.")
    logging.info("No expression matrix was modified.")
    logging.info("CF9 differential-expression analysis is now unblocked.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF8 FINALIZATION ERROR: {exc}")
        sys.exit(1)
