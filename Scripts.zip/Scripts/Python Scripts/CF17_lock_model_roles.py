#!/usr/bin/env python
"""
CF17 - MANUAL MODEL-ROLE LOCK

Locks the model roles BEFORE CF18 and BEFORE any SCAN-B/APOLLO use.

Primary final model family:
    ElasticNet_Logistic

Secondary exploratory challenger:
    LightGBM

Rationale
---------
- AUROC was the pre-locked primary model-selection metric.
- Elastic-Net is the best PRE-SPECIFIED model by mean outer AUROC.
- LightGBM is the best POST-HOC exploratory model.
- LightGBM's AUROC gain over Elastic-Net is only ~0.0026, below the
  pre-locked 0.01 simplicity tie-zone, and the paired-bootstrap AUROC
  difference CI includes zero.
- LightGBM has a real PR-AUC advantage (~0.023; paired-bootstrap CI > 0),
  so it is retained as a SECONDARY EXPLORATORY CHALLENGER rather than discarded.
- This preserves the pre-specified primary analysis while transparently carrying
  the strongest exploratory nonlinear model forward as a secondary comparator.

This script does not train models and does not access SCAN-B or APOLLO.
"""

from __future__ import annotations

import hashlib
import platform
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


ROOT = Path.cwd()

CF17_DIR = ROOT / "results" / "CF17_combined_model_evaluation"
SUMMARY = CF17_DIR / "CF17_summary.tsv"
DECISION = CF17_DIR / "CF17_model_selection_decision_evidence.tsv"
PERFORMANCE = CF17_DIR / "CF17_combined_model_performance.tsv"
PAIRWISE = CF17_DIR / "CF17_paired_model_differences.tsv"

LOCK_OUT = CF17_DIR / "CF17_LOCKED_model_roles.tsv"
LOCK_SUMMARY = CF17_DIR / "CF17_LOCKED_summary.tsv"
LOCK_PROVENANCE = CF17_DIR / "CF17_LOCKED_provenance.tsv"
LOCK_MARKER = CF17_DIR / "CF17_MODEL_ROLES_LOCKED.txt"

PRIMARY_MODEL = "ElasticNet_Logistic"
SECONDARY_EXPLORATORY_MODEL = "LightGBM"

EXPECTED_STAGE_GATE = "EVALUATION_COMPLETE_MANUAL_MODEL_LOCK_REQUIRED"
EXPECTED_AUROC_TIE_ZONE = 0.01


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(block_size), b""):
            h.update(block)
    return h.hexdigest()


def metric_dict(path: Path) -> dict:
    df = pd.read_csv(path, sep="\t", dtype=str)
    return dict(zip(df["metric"].astype(str), df["value"].astype(str)))


def decision_dict(path: Path) -> dict:
    df = pd.read_csv(path, sep="\t", dtype=str)
    return dict(zip(df["decision_item"].astype(str), df["value"].astype(str)))


def main() -> None:
    print("")
    print("============================================================")
    print(" CF17 - MANUAL MODEL-ROLE LOCK")
    print("============================================================")
    print("")
    print("Estimated runtime: <1 minute")
    print("Bottleneck: none")
    print("Model retraining: NO")
    print("SCAN-B accessed: NO")
    print("APOLLO accessed: NO")
    print("")

    for p in [SUMMARY, DECISION, PERFORMANCE, PAIRWISE]:
        if not p.exists():
            raise FileNotFoundError(f"Required CF17 file missing: {p}")

    summary = metric_dict(SUMMARY)
    decision = decision_dict(DECISION)
    perf = pd.read_csv(PERFORMANCE, sep="\t")
    pair = pd.read_csv(PAIRWISE, sep="\t")

    if summary.get("CF17 stage gate") != EXPECTED_STAGE_GATE:
        raise RuntimeError(
            f"Unexpected CF17 stage gate: {summary.get('CF17 stage gate')}"
        )

    best_pre = decision.get(
        "Best pre-specified model by locked primary metric"
    )
    best_exp = decision.get(
        "Best exploratory model by locked primary metric"
    )

    if best_pre != PRIMARY_MODEL:
        raise RuntimeError(
            f"Best pre-specified model changed: {best_pre}"
        )
    if best_exp != SECONDARY_EXPLORATORY_MODEL:
        raise RuntimeError(
            f"Best exploratory model changed: {best_exp}"
        )

    auc_gain = float(
        decision["Exploratory minus pre-specified best AUROC"]
    )
    pr_gain = float(
        decision["Exploratory minus pre-specified best PR-AUC"]
    )
    tie_zone = float(
        decision[
            "AUROC simplicity tie-zone threshold locked before results"
        ]
    )

    if abs(tie_zone - EXPECTED_AUROC_TIE_ZONE) > 1e-12:
        raise RuntimeError(f"Unexpected AUROC tie zone: {tie_zone}")

    # Extract paired LightGBM - ElasticNet differences robustly.
    def get_pair(metric_name: str):
        direct = pair.loc[
            (pair["model_A"] == SECONDARY_EXPLORATORY_MODEL)
            & (pair["model_B"] == PRIMARY_MODEL)
            & (pair["metric"] == metric_name)
        ]
        if len(direct) == 1:
            r = direct.iloc[0]
            return (
                float(r["observed_difference_A_minus_B"]),
                float(r["difference_ci_lower_95"]),
                float(r["difference_ci_upper_95"]),
            )

        reverse = pair.loc[
            (pair["model_A"] == PRIMARY_MODEL)
            & (pair["model_B"] == SECONDARY_EXPLORATORY_MODEL)
            & (pair["metric"] == metric_name)
        ]
        if len(reverse) != 1:
            raise RuntimeError(
                f"Pairwise row missing for {metric_name}"
            )
        r = reverse.iloc[0]
        return (
            -float(r["observed_difference_A_minus_B"]),
            -float(r["difference_ci_upper_95"]),
            -float(r["difference_ci_lower_95"]),
        )

    auc_diff, auc_lo, auc_hi = get_pair("AUROC")
    pr_diff, pr_lo, pr_hi = get_pair("Average_Precision_PR_AUC")

    # Scientific consistency checks supporting this manual role lock.
    if auc_gain >= tie_zone:
        raise RuntimeError(
            "Exploratory AUROC gain now exceeds the locked tie zone; "
            "manual rationale must be reconsidered."
        )
    if not (auc_lo <= 0 <= auc_hi):
        raise RuntimeError(
            "Paired AUROC CI no longer includes zero; "
            "manual rationale must be reconsidered."
        )

    p_primary = perf.loc[perf["model"] == PRIMARY_MODEL]
    p_secondary = perf.loc[perf["model"] == SECONDARY_EXPLORATORY_MODEL]

    if len(p_primary) != 1 or len(p_secondary) != 1:
        raise RuntimeError("Expected exactly one performance row per locked model.")

    p_primary = p_primary.iloc[0]
    p_secondary = p_secondary.iloc[0]

    lock_rows = [
        (
            "PRIMARY_FINAL_MODEL_FAMILY",
            PRIMARY_MODEL,
            "PRE_SPECIFIED_PRIMARY_ANALYSIS",
            "Locked for CF18 onward",
        ),
        (
            "SECONDARY_EXPLORATORY_CHALLENGER",
            SECONDARY_EXPLORATORY_MODEL,
            "POST_HOC_EXPLORATORY",
            "Carry forward as secondary comparator; cannot replace primary retrospectively",
        ),
        (
            "PRIMARY_SELECTION_METRIC",
            "AUROC",
            "PRE_LOCKED",
            "Unchanged",
        ),
        (
            "PRIMARY_MODEL_MEAN_AUROC",
            f"{float(p_primary['mean_AUROC']):.6f}",
            "EVIDENCE",
            "",
        ),
        (
            "PRIMARY_MODEL_MEAN_PR_AUC",
            f"{float(p_primary['mean_PR_AUC']):.6f}",
            "EVIDENCE",
            "",
        ),
        (
            "EXPLORATORY_MODEL_MEAN_AUROC",
            f"{float(p_secondary['mean_AUROC']):.6f}",
            "EVIDENCE",
            "",
        ),
        (
            "EXPLORATORY_MODEL_MEAN_PR_AUC",
            f"{float(p_secondary['mean_PR_AUC']):.6f}",
            "EVIDENCE",
            "",
        ),
        (
            "LIGHTGBM_MINUS_ELASTICNET_AUROC",
            f"{auc_diff:.6f}",
            "PAIRED_BOOTSTRAP_EVIDENCE",
            f"95% CI {auc_lo:.6f} to {auc_hi:.6f}",
        ),
        (
            "LIGHTGBM_MINUS_ELASTICNET_PR_AUC",
            f"{pr_diff:.6f}",
            "PAIRED_BOOTSTRAP_EVIDENCE",
            f"95% CI {pr_lo:.6f} to {pr_hi:.6f}",
        ),
        (
            "AUROC_TIE_ZONE",
            f"{tie_zone:.6f}",
            "PRE_LOCKED",
            "Exploratory AUROC gain remains inside tie zone",
        ),
        (
            "SCANB_ROLE_BEFORE_EXTERNAL_VALIDATION",
            "UNTOUCHED",
            "LOCKED",
            "No tuning or selection may use SCAN-B",
        ),
        (
            "APOLLO_ROLE",
            "BIOLOGICAL_CROSS_OMICS_CONFIRMATION_ONLY",
            "LOCKED",
            "Must not influence model selection/tuning",
        ),
    ]

    pd.DataFrame(
        lock_rows,
        columns=["lock_item", "value", "evidence_status", "note"],
    ).to_csv(LOCK_OUT, sep="\t", index=False)

    lock_summary = pd.DataFrame(
        [
            ("Primary final model family", PRIMARY_MODEL),
            (
                "Primary model analysis status",
                "PRE_SPECIFIED_PRIMARY_ANALYSIS",
            ),
            (
                "Secondary exploratory challenger",
                SECONDARY_EXPLORATORY_MODEL,
            ),
            (
                "Secondary model analysis status",
                "POST_HOC_EXPLORATORY",
            ),
            ("Primary metric", "AUROC"),
            ("LightGBM minus Elastic-Net AUROC", round(auc_diff, 6)),
            (
                "LightGBM minus Elastic-Net AUROC 95% CI",
                f"{auc_lo:.6f} to {auc_hi:.6f}",
            ),
            ("LightGBM minus Elastic-Net PR-AUC", round(pr_diff, 6)),
            (
                "LightGBM minus Elastic-Net PR-AUC 95% CI",
                f"{pr_lo:.6f} to {pr_hi:.6f}",
            ),
            ("SCAN-B accessed", "NO"),
            ("APOLLO accessed", "NO"),
            ("Model retraining", "NO"),
            (
                "CF17 lock gate",
                "MODEL_ROLES_LOCKED_READY_FOR_CF18",
            ),
        ],
        columns=["metric", "value"],
    )
    lock_summary.to_csv(LOCK_SUMMARY, sep="\t", index=False)

    provenance = pd.DataFrame(
        [
            ("code_file", "CF17_lock_model_roles.py"),
            ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
            ("CF17_summary_sha256", sha256_file(SUMMARY)),
            ("CF17_decision_sha256", sha256_file(DECISION)),
            ("CF17_performance_sha256", sha256_file(PERFORMANCE)),
            ("CF17_pairwise_sha256", sha256_file(PAIRWISE)),
            (
                "manual_lock_rationale",
                "Elastic-Net retained as primary because AUROC was pre-locked "
                "primary metric; it is the best pre-specified model; LightGBM "
                "AUROC gain is <0.01 and paired AUROC CI includes zero. "
                "LightGBM retained as secondary exploratory challenger because "
                "its PR-AUC advantage is supported by paired bootstrap.",
            ),
            ("python_version", platform.python_version()),
            ("CF17_lock_gate", "MODEL_ROLES_LOCKED_READY_FOR_CF18"),
        ],
        columns=["field", "value"],
    )
    provenance.to_csv(LOCK_PROVENANCE, sep="\t", index=False)

    LOCK_MARKER.write_text(
        "CF17 MODEL ROLES LOCKED\n"
        f"Primary final model family: {PRIMARY_MODEL}\n"
        f"Secondary exploratory challenger: {SECONDARY_EXPLORATORY_MODEL}\n"
        "SCAN-B remains untouched.\n"
        "APOLLO remains untouched.\n"
        "STATUS: MODEL_ROLES_LOCKED_READY_FOR_CF18\n",
        encoding="utf-8",
    )

    print("Primary final model: ElasticNet_Logistic")
    print("Secondary exploratory challenger: LightGBM")
    print("")
    print(
        f"LightGBM - Elastic-Net AUROC: {auc_diff:+.4f} "
        f"(95% CI {auc_lo:.4f} to {auc_hi:.4f})"
    )
    print(
        f"LightGBM - Elastic-Net PR-AUC: {pr_diff:+.4f} "
        f"(95% CI {pr_lo:.4f} to {pr_hi:.4f})"
    )
    print("")
    print("SCAN-B accessed: NO")
    print("APOLLO accessed: NO")
    print("Model retraining: NO")
    print("")
    print("STATUS: MODEL_ROLES_LOCKED_READY_FOR_CF18")
    print("")


if __name__ == "__main__":
    main()
