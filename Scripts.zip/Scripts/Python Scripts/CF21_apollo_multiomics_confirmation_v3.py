"""
============================================================
CF21 v3 - APOLLO MULTI-OMICS CONFIRMATION
============================================================

Purpose:
    Confirm CF18 Elastic-Net predictive genes using APOLLO RNA,
    protein and phosphoprotein evidence.

Corrections:
    - Protein matching uses APOLLO "Gene" column
    - Phosphoprotein matching uses APOLLO "Gene" column

Rules:
    NO retraining
    NO feature selection
    NO model modification

============================================================
"""

import os
import time
import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

START = time.time()

BASE = r"D:\Masters\Research\TCGA_BRCA"

MODEL_FILE = os.path.join(
    BASE,
    "data", "processed", "ml_ready",
    "CF18_final_model",
    "CF18_final_ElasticNet_model_bundle.joblib"
)

APOLLO_DIR = os.path.join(
    BASE,
    "data", "raw", "apollo_brca1", "open"
)

RNA_FILE = os.path.join(
    APOLLO_DIR,
    "apollo-brca1.rnaseq.expressed_genes.level3.UQnorm_log2.txt"
)

PROTEIN_FILE = os.path.join(
    APOLLO_DIR,
    "apollo-brca1.globalproteomics_level3_unimputed.txt"
)

PHOSPHO_FILE = os.path.join(
    APOLLO_DIR,
    "apollo-brca1.phosphoproteomics_level3_adjusted_by_global_unimputed.txt"
)

OUT = os.path.join(
    BASE,
    "results",
    "CF21_apollo_multiomics_confirmation_v3"
)

os.makedirs(OUT, exist_ok=True)


def get_predictive_genes():

    print("[1/6] Loading CF18 model bundle...")

    bundle = joblib.load(MODEL_FILE)

    all_genes = np.array(
        bundle["feature_universe_gene_symbols"]
    )

    selected = all_genes[
        bundle["select_k_best"].get_support()
    ]

    coef = (
        bundle["elasticnet_model"]
        .coef_
        .flatten()
    )

    df = pd.DataFrame({
        "gene": selected,
        "coefficient": coef
    })

    df = df[
        df["coefficient"] != 0
    ].copy()

    print("Predictive genes:", len(df))

    return df


def read_gene_column(path, column_name=None):

    print("Reading:", os.path.basename(path))

    if column_name:
        df = pd.read_csv(
            path,
            sep="\t",
            usecols=[column_name],
            low_memory=False
        )
        genes = df[column_name]
    else:
        df = pd.read_csv(
            path,
            sep="\t",
            usecols=[0],
            low_memory=False
        )
        genes = df.iloc[:, 0]

    return set(
        genes.astype(str)
        .str.upper()
        .str.strip()
    )


def main():

    print("""
============================================================
 CF21 v3 - APOLLO MULTI-OMICS CONFIRMATION
============================================================
NO ML
NO RETRAINING
NO FEATURE SELECTION
============================================================
""")

    genes = get_predictive_genes()

    genes["gene_upper"] = (
        genes["gene"]
        .astype(str)
        .str.upper()
        .str.strip()
    )

    print("\n[2/6] Checking APOLLO RNA...")
    rna_genes = read_gene_column(RNA_FILE)

    print("\n[3/6] Checking APOLLO Protein...")
    protein_genes = read_gene_column(
        PROTEIN_FILE,
        "Gene"
    )

    print("\n[4/6] Checking APOLLO Phosphoprotein...")
    phospho_genes = read_gene_column(
        PHOSPHO_FILE,
        "Gene"
    )

    result = genes.copy()

    result["RNA_support"] = result.gene_upper.isin(rna_genes)
    result["Protein_support"] = result.gene_upper.isin(protein_genes)
    result["Phospho_support"] = result.gene_upper.isin(phospho_genes)

    print(
        "RNA supported:",
        result.RNA_support.sum(),
        "/",
        len(result)
    )

    print(
        "Protein supported:",
        result.Protein_support.sum(),
        "/",
        len(result)
    )

    print(
        "Phospho supported:",
        result.Phospho_support.sum(),
        "/",
        len(result)
    )

    def evidence(row):
        if row.RNA_support and row.Protein_support and row.Phospho_support:
            return "RNA+Protein+Phospho"
        if row.RNA_support and row.Protein_support:
            return "RNA+Protein"
        if row.RNA_support:
            return "RNA_only"
        return "No_match"

    result["Evidence_level"] = result.apply(
        evidence,
        axis=1
    )

    result.to_csv(
        os.path.join(
            OUT,
            "CF21v3_predictive_gene_multiomics_table.tsv"
        ),
        sep="\t",
        index=False
    )

    summary = (
        result["Evidence_level"]
        .value_counts()
        .reset_index()
    )

    summary.columns = [
        "Evidence_level",
        "Gene_count"
    ]

    summary.to_csv(
        os.path.join(
            OUT,
            "CF21v3_multiomics_summary.tsv"
        ),
        sep="\t",
        index=False
    )

    plt.figure(figsize=(7,4))
    plt.bar(
        summary["Evidence_level"],
        summary["Gene_count"]
    )
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("Gene count")
    plt.title("CF21 v3 APOLLO Multi-Omics Evidence")
    plt.tight_layout()

    plt.savefig(
        os.path.join(
            OUT,
            "CF21v3_evidence_barplot.png"
        ),
        dpi=300
    )

    plt.close()

    print("""
============================================================
 CF21 v3 COMPLETE
============================================================
""")

    print("Genes evaluated:", len(result))
    print(
        "Runtime:",
        round((time.time()-START)/60, 2),
        "min"
    )
    print("STATUS: READY_FOR_REVIEW")


if __name__ == "__main__":
    main()
