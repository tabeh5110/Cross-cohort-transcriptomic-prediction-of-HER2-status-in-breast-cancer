"""
============================================================
CF19 - SCAN-B EXTERNAL VALIDATION
============================================================

Purpose:
    Apply locked TCGA HER2 Elastic-Net model to SCAN-B.

Rules:
    NO retraining
    NO feature selection
    NO threshold optimization
    NO batch correction

Input:
    CF18 locked model bundle
    CF11 SCAN-B expression and metadata

============================================================
"""

import os
import time
import joblib
import numpy as np
import pandas as pd

from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
    roc_curve,
    precision_recall_curve
)

import matplotlib.pyplot as plt


START = time.time()


BASE = r"D:\Masters\Research\TCGA_BRCA"


MODEL_FILE = os.path.join(
    BASE,
    "data",
    "processed",
    "ml_ready",
    "CF18_final_model",
    "CF18_final_ElasticNet_model_bundle.joblib"
)


SCAN_EXPR = os.path.join(
    BASE,
    "data",
    "processed",
    "scanb",
    "CF11_SCANB_primary_expression.tsv.gz"
)


SCAN_META = os.path.join(
    BASE,
    "data",
    "processed",
    "scanb",
    "CF11_SCANB_primary_sample_metadata.tsv"
)


OUT = os.path.join(
    BASE,
    "results",
    "CF19_scanb_external_validation"
)

os.makedirs(OUT, exist_ok=True)



def banner():

    print("""
============================================================
 CF19 - SCAN-B EXTERNAL VALIDATION
============================================================

Estimated runtime: ~10-20 minutes

NO MODEL TRAINING
NO FEATURE SELECTION
NO THRESHOLD OPTIMIZATION
NO BATCH CORRECTION

External cohort:
SCAN-B / GSE96058

""")



def load_model():

    print("[1/8] Loading CF18 locked model...")

    if not os.path.exists(MODEL_FILE):
        raise FileNotFoundError(MODEL_FILE)


    bundle = joblib.load(MODEL_FILE)


    print(
        "Model family:",
        bundle["primary_model_family"]
    )

    print(
        "Rank representation:",
        bundle["rank_representation"]
    )


    print("Model loaded.")

    return bundle



def load_scan_metadata():

    print("\n[2/8] Loading SCAN-B metadata...")


    meta = pd.read_csv(
        SCAN_META,
        sep="\t",
        dtype=str
    )


    print(
        "SCAN-B metadata rows:",
        len(meta)
    )


    return meta



def read_expression():

    print("\n[3/8] Loading SCAN-B expression matrix...")
    print("Streaming compressed matrix...")


    expr = pd.read_csv(
        SCAN_EXPR,
        sep="\t",
        compression="gzip",
        index_col=0
    )


    print(
        "Expression matrix:",
        expr.shape[0],
        "genes x",
        expr.shape[1],
        "samples"
    )


    return expr



def prepare_features(expr, bundle):

    print("\n[4/8] Preparing locked model features...")


    genes = bundle[
        "feature_universe_gene_symbols"
    ]


    print(
        "Locked model genes:",
        len(genes)
    )


    missing = [
        g for g in genes
        if g not in expr.index
    ]


    print(
        "Missing SCAN-B genes:",
        len(missing)
    )

    X = pd.DataFrame(
        0.0,
        index=genes,
        columns=expr.columns,
        dtype=np.float64
    )


    available = list(
        set(genes).intersection(expr.index)
    )


    X.loc[available] = expr.loc[available]


    return X



def rank_transform(df):

    print(
        "\n[5/8] Applying within-sample percentile ranking..."
    )


    ranked = df.rank(
        axis=0,
        pct=True
    )


    ranked = ranked.astype(
        np.float32
    )


    print(
        "Rank matrix:",
        ranked.shape
    )


    return ranked
def evaluate(y, prob, LOCKED_THRESHOLD):

    print("\n[6/8] Calculating external validation metrics...")


    auc = roc_auc_score(
        y,
        prob
    )


    ap = average_precision_score(
        y,
        prob
    )


    pred = (
        prob >= LOCKED_THRESHOLD
    ).astype(int)


    tn, fp, fn, tp = confusion_matrix(
        y,
        pred
    ).ravel()


    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    specificity = tn / (tn + fp) if (tn + fp) > 0 else np.nan


    results = pd.DataFrame(
        {
            "metric":
            [
                "AUROC",
                "PR_AUC",
                "Sensitivity",
                "Specificity",
                "Threshold"
            ],

            "value":
            [
                auc,
                ap,
                sensitivity,
                specificity,
                LOCKED_THRESHOLD
            ]
        }
    )


    results.to_csv(
        os.path.join(
            OUT,
            "CF19_metrics.tsv"
        ),
        sep="\t",
        index=False
    )


    print(
        "AUROC:",
        round(auc,4)
    )

    print(
        "PR-AUC:",
        round(ap,4)
    )

    print(
        "Sensitivity:",
        round(sensitivity,4)
    )

    print(
        "Specificity:",
        round(specificity,4)
    )


    return pred



def figures(y, prob):

    print("\n[7/8] Generating figures...")


    fpr, tpr, _ = roc_curve(
        y,
        prob
    )


    plt.figure(figsize=(6,5))

    plt.plot(
        fpr,
        tpr
    )

    plt.xlabel(
        "False Positive Rate"
    )

    plt.ylabel(
        "True Positive Rate"
    )

    plt.title(
        "CF19 SCAN-B ROC Curve"
    )

    plt.savefig(
        os.path.join(
            OUT,
            "CF19_ROC.png"
        ),
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()



    precision, recall, _ = precision_recall_curve(
        y,
        prob
    )


    plt.figure(figsize=(6,5))

    plt.plot(
        recall,
        precision
    )

    plt.xlabel(
        "Recall"
    )

    plt.ylabel(
        "Precision"
    )

    plt.title(
        "CF19 SCAN-B Precision-Recall Curve"
    )


    plt.savefig(
        os.path.join(
            OUT,
            "CF19_PR_curve.png"
        ),
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()



def main():

    banner()


    bundle = load_model()


    # IMPORTANT:
    # Threshold comes only from frozen CF18 artifact

    LOCKED_THRESHOLD = bundle[
        "classification_threshold"
    ]


    print(
        "Locked CF18 threshold:",
        LOCKED_THRESHOLD
    )


    meta = load_scan_metadata()
    print("\nHER2-related metadata columns:")
    print(
        [
            c for c in meta.columns
            if "her2" in c.lower()
        ]
    )


    expr = read_expression()



    X = prepare_features(
        expr,
        bundle
    )

    ranked = rank_transform(
        X
    )

    print(
        "\nApplying frozen CF18 preprocessing..."
    )

    # Convert samples x genes
    X_scanb = ranked.T

    # Apply frozen variance filtering
    variance_filter = bundle["variance_threshold"]

    X_scanb = variance_filter.transform(
        X_scanb
    )

    # Apply frozen scaling
    scaler = bundle["standard_scaler"]

    X_scanb = scaler.transform(
        X_scanb
    )

    # Apply frozen SelectKBest feature selection
    selector = bundle["select_k_best"]

    X_scanb = selector.transform(
        X_scanb
    )

    print(
        "Final model input shape:",
        X_scanb.shape
    )

    print(
        "\nApplying locked Elastic-Net model..."
    )

    model = bundle[
        "elasticnet_model"
    ]

    prob = model.predict_proba(
        X_scanb
    )[:, 1]


    print(
        "Predictions generated:",
        len(prob)
    )

    HER2_COLUMN = "characteristic_her2_status"

    if HER2_COLUMN not in meta.columns:
        print("Available metadata columns:")
        print(list(meta.columns))

        raise RuntimeError(
            f"{HER2_COLUMN} not found in SCAN-B metadata"
        )

    print(
        "Using SCAN-B HER2 endpoint:",
        HER2_COLUMN
    )

    y = (
        meta[HER2_COLUMN]
        .astype(str)
        .str.lower()
        .isin(
            [
                "positive",
                "pos",
                "her2 positive",
                "her2_positive",
                "1",
                "yes"
            ]
        )
        .astype(int)
        .values
    )


    if len(y) != len(prob):

        raise RuntimeError(
            "Expression samples and HER2 labels do not match"
        )



    pred = evaluate(
        y,
        prob,
        LOCKED_THRESHOLD
    )



    prediction_table = pd.DataFrame(
        {
            "sample_id":
            expr.columns,

            "HER2_probability":
            prob,

            "prediction":
            pred,

            "locked_threshold":
            LOCKED_THRESHOLD
        }
    )


    prediction_table.to_csv(
        os.path.join(
            OUT,
            "CF19_predictions.tsv"
        ),
        sep="\t",
        index=False
    )



    figures(
        y,
        prob
    )



    summary = pd.DataFrame(
        {
            "item":
            [
                "External cohort",
                "Samples",
                "HER2 positives",
                "HER2 negatives",
                "Threshold",
                "Model"
            ],

            "value":
            [
                "SCAN-B",
                len(prob),
                int(sum(y)),
                int(len(y)-sum(y)),
                LOCKED_THRESHOLD,
                "CF18 Elastic-Net"
            ]
        }
    )


    summary.to_csv(
        os.path.join(
            OUT,
            "CF19_summary.tsv"
        ),
        sep="\t",
        index=False
    )



    provenance = pd.DataFrame(
        {
            "item":
            [
                "Training cohort",
                "Validation cohort",
                "Retraining",
                "Feature selection",
                "Threshold optimization",
                "Batch correction"
            ],

            "value":
            [
                "TCGA-BRCA",
                "SCAN-B",
                "NO",
                "NO",
                "NO",
                "NO"
            ]
        }
    )


    provenance.to_csv(
        os.path.join(
            OUT,
            "CF19_provenance.tsv"
        ),
        sep="\t",
        index=False
    )



    print(
        "\n============================================================"
    )

    print(
        " CF19 COMPLETE - EXTERNAL VALIDATION FINISHED"
    )

    print(
        "============================================================"
    )


    print(
        "Runtime:",
        round((time.time()-START)/60,2),
        "min"
    )

    print(
        "SCAN-B accessed: YES"
    )

    print(
        "APOLLO accessed: NO"
    )

    print(
        "Model retraining: NO"
    )



if __name__ == "__main__":

    main()