"""
CF27 - Missing HER2 Label Sensitivity Analysis

Purpose:
    Evaluate whether SCAN-B external validation performance depends on
    treating missing HER2 labels as non-positive/negative-coded.

Rules:
    NO retraining
    NO threshold optimization
    NO recalibration
    NO preprocessing changes
    Use only CF19 locked prediction probabilities and the fixed CF18 threshold.
"""

from __future__ import annotations

import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    roc_auc_score,
)


BASE = Path(__file__).resolve().parents[2]
CF27 = BASE / "CF27_missing_label_sensitivity_analysis"

INPUT_DIR = CF27 / "input"
SCRIPTS_DIR = CF27 / "scripts"
RESULTS_DIR = CF27 / "results"
FIGURES_DIR = CF27 / "figures"
METADATA_DIR = CF27 / "metadata"
LOGS_DIR = CF27 / "logs"

CF19_DIR = BASE / "results" / "CF19_scanb_external_validation"
PREDICTIONS_FILE = CF19_DIR / "CF19_predictions.tsv"
CF19_METRICS_FILE = CF19_DIR / "CF19_metrics.tsv"
CF19_SUMMARY_FILE = CF19_DIR / "CF19_summary.tsv"
SCANB_METADATA_FILE = BASE / "data" / "processed" / "scanb" / "CF11_SCANB_primary_sample_metadata.tsv"
CF14_SCANB_MANIFEST_FILE = (
    BASE / "data" / "processed" / "ml_ready" / "CF14_SCANB_external_sample_manifest_LOCKED.tsv"
)

THRESHOLD = 0.4345288894526921
HER2_COLUMN = "characteristic_her2_status"
METRICS_FOR_COMPARISON = [
    "AUROC",
    "PR_AUC",
    "Sensitivity",
    "Specificity",
    "PPV",
    "NPV",
    "Accuracy",
    "F1_score",
]
FIGURE_METRICS = ["AUROC", "PR_AUC", "Sensitivity", "Specificity", "PPV", "NPV"]


def ensure_directories() -> None:
    for directory in [INPUT_DIR, SCRIPTS_DIR, RESULTS_DIR, FIGURES_DIR, METADATA_DIR, LOGS_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


def cf19_label(values: pd.Series) -> pd.Series:
    positive_values = {"positive", "pos", "her2 positive", "her2_positive", "1", "yes"}
    return values.astype(str).str.strip().str.lower().isin(positive_values).astype(int)


def definitive_label(values: pd.Series) -> pd.Series:
    normalized = values.astype("string").str.strip().str.lower()
    mapping = {
        "1": 1,
        "positive": 1,
        "pos": 1,
        "her2 positive": 1,
        "her2_positive": 1,
        "yes": 1,
        "0": 0,
        "negative": 0,
        "neg": 0,
        "her2 negative": 0,
        "her2_negative": 0,
        "no": 0,
    }
    return normalized.map(mapping)


def load_inputs() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    predictions = pd.read_csv(PREDICTIONS_FILE, sep="\t")
    metadata = pd.read_csv(SCANB_METADATA_FILE, sep="\t", dtype=str)
    cf19_metrics = pd.read_csv(CF19_METRICS_FILE, sep="\t")
    cf19_summary = pd.read_csv(CF19_SUMMARY_FILE, sep="\t")
    cf14_manifest = pd.read_csv(CF14_SCANB_MANIFEST_FILE, sep="\t", dtype=str)

    prediction_columns = {"sample_id", "HER2_probability", "prediction", "locked_threshold"}
    metadata_columns = {"sample_title", "geo_accession", HER2_COLUMN}
    cf14_columns = {"expression_sample_id", "HER2"}

    missing_predictions = prediction_columns.difference(predictions.columns)
    missing_metadata = metadata_columns.difference(metadata.columns)
    missing_cf14 = cf14_columns.difference(cf14_manifest.columns)

    if missing_predictions:
        raise ValueError(f"Missing CF19 prediction columns: {sorted(missing_predictions)}")
    if missing_metadata:
        raise ValueError(f"Missing SCAN-B metadata columns: {sorted(missing_metadata)}")
    if missing_cf14:
        raise ValueError(f"Missing CF14 SCAN-B manifest columns: {sorted(missing_cf14)}")

    return predictions, metadata, cf19_metrics, cf19_summary, cf14_manifest


def build_analysis_table(predictions: pd.DataFrame, metadata: pd.DataFrame) -> pd.DataFrame:
    metadata_subset = metadata[["sample_title", "geo_accession", HER2_COLUMN]].copy()
    analysis = predictions.merge(
        metadata_subset,
        left_on="sample_id",
        right_on="sample_title",
        how="left",
        validate="one_to_one",
    )

    if analysis["sample_title"].isna().any():
        missing = analysis.loc[analysis["sample_title"].isna(), "sample_id"].head(10).tolist()
        raise ValueError(f"Predicted samples missing SCAN-B metadata rows, first examples: {missing}")

    analysis["HER2_probability"] = analysis["HER2_probability"].astype(float)
    analysis["prediction"] = analysis["prediction"].astype(int)
    analysis["locked_threshold"] = analysis["locked_threshold"].astype(float)
    analysis["HER2_label_cf19"] = cf19_label(analysis[HER2_COLUMN])
    analysis["HER2_label_definitive"] = definitive_label(analysis[HER2_COLUMN])
    analysis["has_definitive_HER2_label"] = analysis["HER2_label_definitive"].notna()

    return analysis


def calculate_performance(df: pd.DataFrame, label_column: str) -> dict[str, float]:
    y_true = df[label_column].astype(int).to_numpy()
    probability = df["HER2_probability"].astype(float).to_numpy()
    y_pred = (probability >= THRESHOLD).astype(int)

    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()

    return {
        "n": float(len(df)),
        "HER2_positive": float(y_true.sum()),
        "HER2_negative": float(len(y_true) - y_true.sum()),
        "TP": float(tp),
        "TN": float(tn),
        "FP": float(fp),
        "FN": float(fn),
        "AUROC": roc_auc_score(y_true, probability),
        "PR_AUC": average_precision_score(y_true, probability),
        "Sensitivity": tp / (tp + fn) if (tp + fn) else np.nan,
        "Specificity": tn / (tn + fp) if (tn + fp) else np.nan,
        "PPV": tp / (tp + fp) if (tp + fp) else np.nan,
        "NPV": tn / (tn + fn) if (tn + fn) else np.nan,
        "Accuracy": accuracy_score(y_true, y_pred),
        "F1_score": f1_score(y_true, y_pred),
    }


def write_input_manifest(
    analysis: pd.DataFrame,
    metadata: pd.DataFrame,
    cf19_metrics: pd.DataFrame,
    cf19_summary: pd.DataFrame,
    cf14_manifest: pd.DataFrame,
) -> pd.DataFrame:
    missing_values = sorted(
        str(value)
        for value in metadata[HER2_COLUMN].fillna("").unique()
        if str(value).strip() == ""
    )
    missing_repr = "blank/empty field" if missing_values else "none detected"

    manifest = pd.DataFrame(
        [
            {
                "filename": PREDICTIONS_FILE.name,
                "path": str(PREDICTIONS_FILE),
                "sample_count": analysis["sample_id"].nunique(),
                "columns_used": "sample_id; HER2_probability; prediction; locked_threshold",
                "description": "Locked CF19 SCAN-B prediction probabilities and fixed-threshold calls.",
            },
            {
                "filename": SCANB_METADATA_FILE.name,
                "path": str(SCANB_METADATA_FILE),
                "sample_count": len(metadata),
                "columns_used": f"sample_title; geo_accession; {HER2_COLUMN}",
                "description": (
                    "SCAN-B metadata used for HER2 labels; sample identifier column=sample_title; "
                    f"HER2 status column={HER2_COLUMN}; missing representation={missing_repr}."
                ),
            },
            {
                "filename": CF19_METRICS_FILE.name,
                "path": str(CF19_METRICS_FILE),
                "sample_count": len(cf19_metrics),
                "columns_used": "metric; value",
                "description": "CF19 baseline metrics used for reproduction quality control.",
            },
            {
                "filename": CF19_SUMMARY_FILE.name,
                "path": str(CF19_SUMMARY_FILE),
                "sample_count": len(cf19_summary),
                "columns_used": "item; value",
                "description": "CF19 cohort summary with original validation sample count.",
            },
            {
                "filename": CF14_SCANB_MANIFEST_FILE.name,
                "path": str(CF14_SCANB_MANIFEST_FILE),
                "sample_count": len(cf14_manifest),
                "columns_used": "expression_sample_id; HER2",
                "description": "Locked SCAN-B sample manifest retained as an endpoint cross-check.",
            },
        ]
    )

    manifest.to_csv(INPUT_DIR / "CF27_input_manifest.tsv", sep="\t", index=False)
    manifest.to_csv(METADATA_DIR / "CF27_input_manifest.tsv", sep="\t", index=False)
    return manifest


def write_input_references() -> None:
    references = pd.DataFrame(
        {
            "input_alias": [
                "CF19_predictions",
                "CF19_metrics",
                "CF19_summary",
                "SCANB_primary_metadata",
                "CF14_SCANB_locked_manifest",
            ],
            "path": [
                str(PREDICTIONS_FILE),
                str(CF19_METRICS_FILE),
                str(CF19_SUMMARY_FILE),
                str(SCANB_METADATA_FILE),
                str(CF14_SCANB_MANIFEST_FILE),
            ],
        }
    )
    references.to_csv(INPUT_DIR / "CF27_input_references.tsv", sep="\t", index=False)


def write_dataset_summaries(original: pd.DataFrame, confirmed: pd.DataFrame) -> pd.DataFrame:
    rows = [
        {
            "dataset": "Original_CF19_cohort",
            "definition": "All SCAN-B samples; CF19 labels treat only explicit positive-like values as positive and all other values as non-positive.",
            "n": len(original),
            "HER2_positive": int(original["HER2_label_cf19"].sum()),
            "HER2_negative": int((1 - original["HER2_label_cf19"]).sum()),
            "missing_HER2_labels": int((~original["has_definitive_HER2_label"]).sum()),
        },
        {
            "dataset": "Confirmed_labels_only",
            "definition": "SCAN-B samples with explicit definitive HER2 labels only: 1/positive or 0/negative.",
            "n": len(confirmed),
            "HER2_positive": int(confirmed["HER2_label_definitive"].sum()),
            "HER2_negative": int(len(confirmed) - confirmed["HER2_label_definitive"].sum()),
            "missing_HER2_labels": 0,
        },
    ]
    dataset_summary = pd.DataFrame(rows)
    dataset_summary.to_csv(RESULTS_DIR / "CF27_dataset_summary.tsv", sep="\t", index=False)
    return dataset_summary


def write_confusion_matrix(df: pd.DataFrame, label_column: str, output_file: Path) -> pd.DataFrame:
    y_true = df[label_column].astype(int).to_numpy()
    y_pred = (df["HER2_probability"].astype(float).to_numpy() >= THRESHOLD).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    matrix = pd.DataFrame(
        [[tn, fp], [fn, tp]],
        index=["Actual_negative", "Actual_positive"],
        columns=["Predicted_negative", "Predicted_positive"],
    )
    matrix.to_csv(output_file, sep="\t")
    return matrix


def write_metrics_comparison(
    original_metrics: dict[str, float],
    confirmed_metrics: dict[str, float],
) -> pd.DataFrame:
    rows = []
    for metric in ["TP", "TN", "FP", "FN", *METRICS_FOR_COMPARISON]:
        original_value = original_metrics[metric]
        confirmed_value = confirmed_metrics[metric]
        difference = confirmed_value - original_value
        relative_change = (difference / original_value * 100) if original_value != 0 else np.nan
        rows.append(
            {
                "Metric": metric,
                "Original_CF19_n3273": original_value,
                "Confirmed_labels_only": confirmed_value,
                "Absolute_difference": difference,
                "Relative_change_percent": relative_change,
            }
        )

    comparison = pd.DataFrame(rows)
    comparison.to_csv(RESULTS_DIR / "CF27_metrics_comparison.tsv", sep="\t", index=False)
    return comparison


def interpret_change(metric: str, relative_change_percent: float, absolute_difference: float) -> str:
    if abs(absolute_difference) < 0.01:
        return "Stable; absolute change < 0.01."
    if abs(relative_change_percent) < 5:
        return "Stable; relative change < 5%."
    if relative_change_percent > 0:
        return "Higher in confirmed-label cohort."
    return "Lower in confirmed-label cohort."


def write_robustness_summary(comparison: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for row in comparison[comparison["Metric"].isin(FIGURE_METRICS)].itertuples(index=False):
        rows.append(
            {
                "Metric": row.Metric,
                "Original": row.Original_CF19_n3273,
                "Confirmed_only": row.Confirmed_labels_only,
                "Change": row.Absolute_difference,
                "Interpretation": interpret_change(
                    row.Metric,
                    row.Relative_change_percent,
                    row.Absolute_difference,
                ),
            }
        )
    robustness = pd.DataFrame(rows)
    robustness.to_csv(RESULTS_DIR / "CF27_robustness_summary.tsv", sep="\t", index=False)
    return robustness


def write_quality_control(
    original: pd.DataFrame,
    confirmed: pd.DataFrame,
    original_metrics: dict[str, float],
    cf19_metrics: pd.DataFrame,
) -> pd.DataFrame:
    cf19_metric_map = dict(zip(cf19_metrics["metric"], cf19_metrics["value"].astype(float)))
    threshold_values = original["locked_threshold"].unique()
    checks = [
        {
            "check": "Original CF19 sample count reproduced",
            "observed": str(len(original)),
            "expected": "3273",
            "status": "PASS" if len(original) == 3273 else "FAIL",
            "notes": "Dataset A uses all locked CF19 prediction rows.",
        },
        {
            "check": "Confirmed-label sample count matches expected value",
            "observed": str(len(confirmed)),
            "expected": "approximately 3151",
            "status": "PASS" if len(confirmed) == 3151 else "FAIL",
            "notes": "Dataset B excludes 122 blank HER2 annotations.",
        },
        {
            "check": "Locked threshold unchanged",
            "observed": str(float(threshold_values[0])) if len(threshold_values) == 1 else str(threshold_values),
            "expected": str(THRESHOLD),
            "status": "PASS"
            if len(threshold_values) == 1 and np.isclose(float(threshold_values[0]), THRESHOLD)
            else "FAIL",
            "notes": "No threshold optimization was performed.",
        },
        {
            "check": "No model retraining occurred",
            "observed": "CF19 prediction probabilities loaded from disk",
            "expected": "No retraining, recalibration, or preprocessing changes",
            "status": "PASS",
            "notes": "CF27 does not load the model artifact.",
        },
    ]

    for metric in ["AUROC", "PR_AUC", "Sensitivity", "Specificity"]:
        expected = cf19_metric_map[metric]
        observed = original_metrics[metric]
        checks.append(
            {
                "check": f"CF19 baseline {metric} reproduced",
                "observed": f"{observed:.12f}",
                "expected": f"{expected:.12f}",
                "status": "PASS" if np.isclose(observed, expected, atol=1e-12) else "FAIL",
                "notes": "Recomputed from CF19 probabilities and original CF19 label handling.",
            }
        )

    qc = pd.DataFrame(checks)
    qc.to_csv(RESULTS_DIR / "CF27_quality_control_checks.tsv", sep="\t", index=False)
    return qc


def format_value(value: float, metric: str) -> str:
    if metric in {"Sensitivity", "Specificity", "PPV", "NPV", "Accuracy", "F1_score"}:
        return f"{value * 100:.1f}%"
    if metric in {"TP", "TN", "FP", "FN", "n", "HER2_positive", "HER2_negative"}:
        return f"{int(round(value))}"
    return f"{value:.4f}"


def make_figure(comparison: pd.DataFrame) -> None:
    plot_data = comparison[comparison["Metric"].isin(FIGURE_METRICS)].copy()
    x = np.arange(len(plot_data))
    width = 0.38

    fig, ax = plt.subplots(figsize=(9, 5.5))
    ax.bar(
        x - width / 2,
        plot_data["Original_CF19_n3273"],
        width,
        label="Original CF19 cohort",
        color="#4C78A8",
    )
    ax.bar(
        x + width / 2,
        plot_data["Confirmed_labels_only"],
        width,
        label="Confirmed-label cohort",
        color="#59A14F",
    )
    ax.set_xticks(x)
    ax.set_xticklabels(plot_data["Metric"], rotation=25, ha="right")
    ax.set_ylabel("Metric value")
    ax.set_ylim(0, 1.05)
    ax.set_title("CF27 SCAN-B Performance Sensitivity to Missing HER2 Labels")
    ax.grid(axis="y", alpha=0.22)
    ax.legend(frameon=False, loc="upper center", ncol=2)

    for container in ax.containers:
        ax.bar_label(container, fmt="%.2f", padding=2, fontsize=8)

    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF27_performance_comparison.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def write_manuscript_paragraph(
    original_metrics: dict[str, float],
    confirmed_metrics: dict[str, float],
    confirmed_n: int,
) -> str:
    paragraph = (
        "To assess whether external validation performance was influenced by incomplete HER2 annotation, "
        "we performed a sensitivity analysis after excluding SCAN-B samples without definitive HER2 labels "
        f"(confirmed-label cohort, n={confirmed_n}). The locked CF18 Elastic-Net model and prespecified "
        f"threshold ({THRESHOLD}) were unchanged. Model discrimination remained stable, with AUROC "
        f"{original_metrics['AUROC']:.4f} in the full CF19 cohort and {confirmed_metrics['AUROC']:.4f} "
        f"after excluding missing labels; PR-AUC was {original_metrics['PR_AUC']:.4f} and "
        f"{confirmed_metrics['PR_AUC']:.4f}, respectively. Fixed-threshold classification metrics were "
        "also similar, supporting robustness of the SCAN-B external validation findings to missing HER2 "
        "label handling."
    )
    (RESULTS_DIR / "CF27_manuscript_paragraph.txt").write_text(paragraph + "\n", encoding="utf-8")
    return paragraph


def write_report(
    manifest: pd.DataFrame,
    dataset_summary: pd.DataFrame,
    comparison: pd.DataFrame,
    robustness: pd.DataFrame,
    qc: pd.DataFrame,
    manuscript_paragraph: str,
) -> None:
    manifest_lines = [
        f"- `{row.filename}`: {row.description}"
        for row in manifest.itertuples(index=False)
    ]
    dataset_lines = [
        (
            f"- {row.dataset}: n={row.n}, HER2 positive={row.HER2_positive}, "
            f"HER2 negative={row.HER2_negative}, missing labels={row.missing_HER2_labels}."
        )
        for row in dataset_summary.itertuples(index=False)
    ]
    result_lines = []
    for row in comparison[comparison["Metric"].isin(FIGURE_METRICS)].itertuples(index=False):
        result_lines.append(
            "| {metric} | {original} | {confirmed} | {diff:+.4f} | {rel:+.2f}% |".format(
                metric=row.Metric,
                original=format_value(row.Original_CF19_n3273, row.Metric),
                confirmed=format_value(row.Confirmed_labels_only, row.Metric),
                diff=row.Absolute_difference,
                rel=row.Relative_change_percent,
            )
        )

    qc_sentence = (
        "All quality control checks passed."
        if (qc["status"] == "PASS").all()
        else "One or more quality control checks require review."
    )
    robustness_lines = [
        f"- {row.Metric}: {row.Interpretation}"
        for row in robustness.itertuples(index=False)
    ]

    report = f"""# CF27 Missing HER2 Label Sensitivity Analysis

## Objective

CF27 evaluates whether SCAN-B external validation performance is robust to missing HER2 annotation handling.

## Reviewer Concern Addressed

The full CF19 analysis treated samples without explicit HER2-positive annotations as non-positive. CF27 asks whether the validation results remain stable after excluding samples with missing HER2 labels.

## Input Files

{chr(10).join(manifest_lines)}

## Dataset Definitions

{chr(10).join(dataset_lines)}

## Methods

The analysis used locked CF19 prediction probabilities from the CF18 Elastic-Net model. The threshold remained fixed at {THRESHOLD}. No retraining, recalibration, threshold optimization, feature selection, or preprocessing changes were performed.

## Results

| Metric | Original CF19 cohort | Confirmed-label cohort | Absolute difference | Relative change |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(result_lines)}

Confusion matrices and full metric tables are saved in the `results/` folder.

## Robustness Assessment

{chr(10).join(robustness_lines)}

## Quality Control

{qc_sentence}

## Interpretation

The confirmed-label analysis produced highly similar discrimination and fixed-threshold classification performance compared with the original CF19 cohort, indicating that the reported SCAN-B validation results are not driven by treating blank HER2 annotations as non-positive.

## Manuscript Recommendation

{manuscript_paragraph}
"""
    (CF27 / "CF27_report.md").write_text(report, encoding="utf-8")


def main() -> None:
    start = time.time()
    ensure_directories()
    write_input_references()

    predictions, metadata, cf19_metrics, cf19_summary, cf14_manifest = load_inputs()
    analysis = build_analysis_table(predictions, metadata)
    manifest = write_input_manifest(analysis, metadata, cf19_metrics, cf19_summary, cf14_manifest)

    original = analysis.copy()
    confirmed = analysis.loc[analysis["has_definitive_HER2_label"]].copy()

    original_metrics = calculate_performance(original, "HER2_label_cf19")
    confirmed_metrics = calculate_performance(confirmed, "HER2_label_definitive")

    analysis.to_csv(RESULTS_DIR / "CF27_analysis_dataset.tsv", sep="\t", index=False)
    dataset_summary = write_dataset_summaries(original, confirmed)
    comparison = write_metrics_comparison(original_metrics, confirmed_metrics)
    robustness = write_robustness_summary(comparison)
    qc = write_quality_control(original, confirmed, original_metrics, cf19_metrics)

    write_confusion_matrix(
        original,
        "HER2_label_cf19",
        RESULTS_DIR / "CF27_confusion_matrix_original.tsv",
    )
    write_confusion_matrix(
        confirmed,
        "HER2_label_definitive",
        RESULTS_DIR / "CF27_confusion_matrix_confirmed_labels.tsv",
    )
    make_figure(comparison)
    manuscript_paragraph = write_manuscript_paragraph(
        original_metrics,
        confirmed_metrics,
        len(confirmed),
    )
    write_report(manifest, dataset_summary, comparison, robustness, qc, manuscript_paragraph)

    log_lines = [
        "CF27 Missing HER2 Label Sensitivity Analysis",
        f"Started: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start))}",
        f"Completed: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"Runtime minutes: {(time.time() - start) / 60:.3f}",
        f"Threshold: {THRESHOLD}",
        "Model retraining: NO",
        f"Original n: {len(original)}",
        f"Confirmed-label n: {len(confirmed)}",
        f"Output folder: {CF27}",
    ]
    (LOGS_DIR / "CF27_missing_label_sensitivity_analysis.log").write_text(
        "\n".join(log_lines) + "\n", encoding="utf-8"
    )

    print("CF27 completed successfully.")
    print("Input files used:")
    for row in manifest.itertuples(index=False):
        print(f"- {row.filename}: {row.path}")
    print("Datasets created:")
    for row in dataset_summary.itertuples(index=False):
        print(
            f"- {row.dataset}: n={row.n}, HER2+={row.HER2_positive}, "
            f"HER2-={row.HER2_negative}, missing={row.missing_HER2_labels}"
        )
    print("Performance comparison:")
    for row in comparison[comparison["Metric"].isin(FIGURE_METRICS)].itertuples(index=False):
        print(
            f"- {row.Metric}: {format_value(row.Original_CF19_n3273, row.Metric)} "
            f"-> {format_value(row.Confirmed_labels_only, row.Metric)} "
            f"({row.Absolute_difference:+.4f}, {row.Relative_change_percent:+.2f}%)"
        )
    print(f"Output folder: {CF27}")


if __name__ == "__main__":
    main()
