#!/usr/bin/env python
"""
CF16B - POST-HOC EXPLORATORY MODEL EXTENSION (TCGA ONLY)

Purpose
-------
Extend the already-frozen CF16 model-development experiment with four additional
model families BEFORE any SCAN-B external validation:

1) Ridge Logistic Regression
2) RBF-kernel Support Vector Machine
3) Extra Trees
4) LightGBM

IMPORTANT SCIENTIFIC STATUS
---------------------------
CF16 (Elastic-Net Logistic, Linear SVM, XGBoost) remains the PRE-SPECIFIED
PRIMARY model comparison.

CF16B is explicitly POST-HOC / EXPLORATORY because it was added after the CF16
internal nested-CV results were observed. It must never be rewritten as if it
had been pre-specified.

The extension nevertheless preserves a valid model-development workflow because:
- SCAN-B remains completely untouched;
- APOLLO remains completely untouched;
- the exact CF15 sample set, gene universe, rank representation and outer
  partitions are reused;
- all scaling / variance filtering / supervised feature selection / tuning
  remain inside training folds;
- the same primary tuning metric (AUROC) is retained.

No final model family is selected here. CF17 will compare the pre-specified and
exploratory families, with their status reported separately.

Checkpoint / resume
-------------------
There are 15 frozen outer partitions x 4 exploratory models = 60 independent
jobs. Every completed job is checkpointed. Re-running this script skips
completed jobs.

Runtime planning
----------------
Expected on the machine that completed CF16 in ~2.05 h:
~1-3 h, with RBF-SVM and Extra Trees likely to dominate.
Progress is printed frequently.
"""

from __future__ import annotations

import hashlib
import importlib.metadata as ilm
import json
import logging
import os
import platform
import re
import sys
import time
import warnings
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

from sklearn.ensemble import ExtraTreesClassifier
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_selection import SelectKBest, VarianceThreshold, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC


# ============================================================
# PATHS / LOCKED INPUTS
# ============================================================

ROOT = Path.cwd()

CF15_DIR = ROOT / "results" / "CF15_ml_experiment_design"
CF15_SUMMARY = CF15_DIR / "CF15_summary.tsv"
OUTER_ASSIGNMENTS = CF15_DIR / "CF15_outer_cv_test_assignments.tsv"

CF16_DIR = ROOT / "results" / "CF16_nested_cv_training"
CF16_SUMMARY = CF16_DIR / "CF16_summary.tsv"

ML_READY = ROOT / "data" / "processed" / "ml_ready"
MATRIX_NPZ = ML_READY / "CF15_TCGA_HER2_rank_matrix.npz"

RESULTS = ROOT / "results" / "CF16B_exploratory_model_extension"
CHECKPOINTS = RESULTS / "checkpoints"
LOG_DIR = ROOT / "logs"
LOG_FILE = LOG_DIR / "CF16B_exploratory_model_extension.log"

PROTOCOL_OUT = RESULTS / "CF16B_exploratory_extension_protocol.tsv"
INNER_SEARCH_OUT = RESULTS / "CF16B_inner_search_results.tsv"
BEST_PARAMS_OUT = RESULTS / "CF16B_best_params.tsv"
OUTER_PRED_OUT = RESULTS / "CF16B_outer_predictions.tsv"
OUTER_METRICS_OUT = RESULTS / "CF16B_outer_metrics.tsv"
FEATURES_OUT = RESULTS / "CF16B_selected_features.tsv"
JOB_STATUS_OUT = RESULTS / "CF16B_job_status.tsv"
SUMMARY_OUT = RESULTS / "CF16B_summary.tsv"
PROVENANCE_OUT = RESULTS / "CF16B_provenance.tsv"


# ============================================================
# LOCKED VALUES
# ============================================================

SEED = 20260815

EXPECTED_N = 938
EXPECTED_P = 22106
EXPECTED_POS = 182
EXPECTED_NEG = 756
EXPECTED_OUTER_SPLITS = 15

MODEL_NAMES = [
    "Ridge_Logistic",
    "RBF_SVM",
    "Extra_Trees",
    "LightGBM",
]
EXPECTED_JOBS = EXPECTED_OUTER_SPLITS * len(MODEL_NAMES)

K_VALUES = [25, 50, 100, 250, 500]
INNER_FOLDS = 4

CPU_COUNT = os.cpu_count() or 1
TREE_THREADS = max(1, min(4, CPU_COUNT - 1 if CPU_COUNT > 1 else 1))

# Ridge search: 5 k x 6 C = 30 candidates
RIDGE_C_VALUES = [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]

# RBF-SVM search: 5 k x 4 C x 4 gamma = 80 candidates
RBF_C_VALUES = [0.1, 1.0, 10.0, 100.0]
RBF_GAMMA_VALUES = ["scale", 0.001, 0.01, 0.1]

# Deterministic randomized search budgets.
EXTRATREES_RANDOM_CANDIDATES = 15
LIGHTGBM_RANDOM_CANDIDATES = 15


# ============================================================
# UTILITIES
# ============================================================

def setup_logging() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    CHECKPOINTS.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def package_version(name: str) -> str:
    try:
        return ilm.version(name)
    except ilm.PackageNotFoundError:
        return "MISSING"


def metric_dict(path: Path) -> Dict[str, str]:
    df = pd.read_csv(path, sep="\t", dtype=str)
    if not {"metric", "value"}.issubset(df.columns):
        raise RuntimeError(f"Expected metric/value columns in {path}")
    return dict(zip(df["metric"].astype(str), df["value"].astype(str)))


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(block_size), b""):
            h.update(block)
    return h.hexdigest()


def atomic_write_json(obj: dict, path: Path) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(path)


def safe_model_name(model: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", model).strip("_")


def checkpoint_paths(split_id: str, model: str) -> Dict[str, Path]:
    prefix = CHECKPOINTS / f"CF16B_{split_id}_{safe_model_name(model)}"
    return {
        "search": Path(str(prefix) + "_inner_search.tsv"),
        "best": Path(str(prefix) + "_best_params.tsv"),
        "pred": Path(str(prefix) + "_outer_predictions.tsv"),
        "metric": Path(str(prefix) + "_outer_metrics.tsv"),
        "features": Path(str(prefix) + "_selected_features.tsv"),
        "done": Path(str(prefix) + "_DONE.json"),
    }


def checkpoint_complete(split_id: str, model: str) -> bool:
    p = checkpoint_paths(split_id, model)
    return all(p[k].exists() for k in ["search", "best", "pred", "metric", "features", "done"])


def outer_split_sort_key(split_id: str) -> Tuple[int, int]:
    m = re.fullmatch(r"R(\d+)_F(\d+)", str(split_id))
    if not m:
        raise RuntimeError(f"Unexpected split ID: {split_id}")
    return int(m.group(1)), int(m.group(2))


# ============================================================
# FORMAL EXTENSION PROTOCOL
# ============================================================

def write_protocol() -> None:
    rows = [
        ("Analysis status", "POST-HOC EXPLORATORY MODEL EXTENSION", "LOCKED_CF16B"),
        ("Original CF16 status", "PRE-SPECIFIED PRIMARY ANALYSIS REMAINS FROZEN", "LOCKED_CF16B"),
        ("Endpoint", "HER2 measured/pathology status", "UNCHANGED"),
        ("TCGA classifiable N", EXPECTED_N, "UNCHANGED"),
        ("HER2 positive / negative", f"{EXPECTED_POS} / {EXPECTED_NEG}", "UNCHANGED"),
        ("Feature universe", EXPECTED_P, "UNCHANGED"),
        ("Representation", "Within-sample percentile ranks", "UNCHANGED"),
        ("Outer CV", "Exact frozen CF15 5-fold x 3-repeat registry", "UNCHANGED"),
        ("Inner CV", "Stratified 4-fold", "UNCHANGED"),
        ("Fold preprocessing", "VarianceThreshold -> StandardScaler -> SelectKBest(f_classif)", "UNCHANGED"),
        ("Feature k", "25|50|100|250|500", "UNCHANGED"),
        ("Primary tuning metric", "Mean inner AUROC", "UNCHANGED"),
        ("Secondary tuning metric", "Mean inner average precision / PR-AUC", "UNCHANGED"),
        ("Ridge Logistic", "L2-regularized logistic regression with balanced class weights", "EXPLORATORY"),
        ("RBF-SVM", "RBF-kernel SVC with balanced class weights; decision_function used", "EXPLORATORY"),
        ("Extra Trees", "Extremely randomized tree ensemble with balanced class weights", "EXPLORATORY"),
        ("LightGBM", "Gradient-boosted decision-tree classifier with fold-specific class imbalance weight", "EXPLORATORY"),
        ("SCAN-B accessed", "NO", "LOCKED_CF16B"),
        ("APOLLO accessed", "NO", "LOCKED_CF16B"),
        ("Final model selection", "NOT PERFORMED IN CF16B", "LOCKED_CF16B"),
    ]
    pd.DataFrame(
        rows,
        columns=["protocol_item", "decision", "status"],
    ).to_csv(PROTOCOL_OUT, sep="\t", index=False)


# ============================================================
# DETERMINISTIC RANDOM CANDIDATES
# ============================================================

def generate_unique_candidates(
    choices: Dict[str, list],
    n: int,
    seed_offset: int,
) -> List[dict]:
    rng = np.random.default_rng(SEED + seed_offset)
    seen = set()
    out = []

    keys = list(choices.keys())

    while len(out) < n:
        row = {}
        signature = []
        for key in keys:
            val = rng.choice(choices[key])
            if isinstance(val, np.generic):
                val = val.item()
            row[key] = val
            signature.append((key, str(val)))
        signature = tuple(signature)
        if signature in seen:
            continue
        seen.add(signature)
        out.append(row)

    return out


EXTRATREES_CANDIDATES = generate_unique_candidates(
    {
        "k": K_VALUES,
        "n_estimators": [200, 300],
        "max_features": ["sqrt", 0.25, 0.5, 1.0],
        "min_samples_leaf": [1, 2, 5],
        "max_depth": [None, 10, 20],
        "criterion": ["gini", "entropy"],
    },
    EXTRATREES_RANDOM_CANDIDATES,
    seed_offset=101,
)

LIGHTGBM_CANDIDATES = generate_unique_candidates(
    {
        "k": K_VALUES,
        "n_estimators": [100, 200, 400],
        "num_leaves": [7, 15, 31],
        "max_depth": [-1, 5, 10],
        "learning_rate": [0.02, 0.05, 0.1],
        "subsample": [0.8, 1.0],
        "colsample_bytree": [0.5, 0.75, 1.0],
        "min_child_samples": [10, 20, 40],
        "reg_alpha": [0.0, 0.1, 1.0],
        "reg_lambda": [0.0, 1.0, 5.0],
    },
    LIGHTGBM_RANDOM_CANDIDATES,
    seed_offset=202,
)


# ============================================================
# MODEL FACTORIES
# ============================================================

def make_ridge(params: dict) -> LogisticRegression:
    return LogisticRegression(
        penalty="l2",
        C=float(params["C"]),
        solver="liblinear",
        class_weight="balanced",
        max_iter=5000,
        tol=1e-4,
        random_state=SEED,
    )


def make_rbf_svm(params: dict) -> SVC:
    gamma = params["gamma"]
    if gamma != "scale":
        gamma = float(gamma)

    return SVC(
        C=float(params["C"]),
        kernel="rbf",
        gamma=gamma,
        class_weight="balanced",
        probability=False,
        cache_size=2048,
        random_state=SEED,
    )


def make_extra_trees(params: dict) -> ExtraTreesClassifier:
    max_features = params["max_features"]
    if max_features != "sqrt":
        max_features = float(max_features)

    max_depth = params["max_depth"]
    if max_depth is not None:
        max_depth = int(max_depth)

    return ExtraTreesClassifier(
        n_estimators=int(params["n_estimators"]),
        max_features=max_features,
        min_samples_leaf=int(params["min_samples_leaf"]),
        max_depth=max_depth,
        criterion=str(params["criterion"]),
        class_weight="balanced",
        n_jobs=TREE_THREADS,
        random_state=SEED,
    )


def make_lightgbm(params: dict, y_train: np.ndarray):
    from lightgbm import LGBMClassifier

    pos = int((y_train == 1).sum())
    neg = int((y_train == 0).sum())
    if pos == 0 or neg == 0:
        raise RuntimeError("LightGBM training fold has one class.")

    return LGBMClassifier(
        objective="binary",
        n_estimators=int(params["n_estimators"]),
        num_leaves=int(params["num_leaves"]),
        max_depth=int(params["max_depth"]),
        learning_rate=float(params["learning_rate"]),
        subsample=float(params["subsample"]),
        colsample_bytree=float(params["colsample_bytree"]),
        min_child_samples=int(params["min_child_samples"]),
        reg_alpha=float(params["reg_alpha"]),
        reg_lambda=float(params["reg_lambda"]),
        scale_pos_weight=float(neg / pos),
        n_jobs=TREE_THREADS,
        random_state=SEED,
        verbosity=-1,
    )


def model_scores(model_name: str, model, X: np.ndarray) -> Tuple[np.ndarray, str]:
    if model_name == "RBF_SVM":
        return model.decision_function(X).astype(float), "decision_function"

    return model.predict_proba(X)[:, 1].astype(float), "probability"


def fit_and_score(
    model_name: str,
    params: dict,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_valid: np.ndarray,
    y_valid: np.ndarray,
) -> Tuple[float, float, int]:
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")

        if model_name == "Ridge_Logistic":
            model = make_ridge(params)
        elif model_name == "RBF_SVM":
            model = make_rbf_svm(params)
        elif model_name == "Extra_Trees":
            model = make_extra_trees(params)
        elif model_name == "LightGBM":
            model = make_lightgbm(params, y_train)
        else:
            raise RuntimeError(model_name)

        model.fit(X_train, y_train)
        scores, _ = model_scores(model_name, model, X_valid)

    auc = float(roc_auc_score(y_valid, scores))
    ap = float(average_precision_score(y_valid, scores))
    conv = sum(issubclass(w.category, ConvergenceWarning) for w in caught)
    return auc, ap, int(conv)


# ============================================================
# LEAKAGE-SAFE CACHED PREPROCESSING
# ============================================================

def prepare_inner_cache(
    X_outer: np.ndarray,
    y_outer: np.ndarray,
) -> List[dict]:
    cv = StratifiedKFold(
        n_splits=INNER_FOLDS,
        shuffle=True,
        random_state=SEED,
    )

    folds = []

    for fold_i, (tr_idx, va_idx) in enumerate(
        cv.split(np.zeros(len(y_outer)), y_outer),
        start=1,
    ):
        Xtr = X_outer[tr_idx]
        Xva = X_outer[va_idx]
        ytr = y_outer[tr_idx]
        yva = y_outer[va_idx]

        vt = VarianceThreshold(threshold=0.0)
        Xtr_v = vt.fit_transform(Xtr)
        Xva_v = vt.transform(Xva)

        scaler = StandardScaler()
        Xtr_s = scaler.fit_transform(Xtr_v)
        Xva_s = scaler.transform(Xva_v)

        k_cache = {}

        for k in K_VALUES:
            selector = SelectKBest(score_func=f_classif, k=k)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                Xtr_k = selector.fit_transform(Xtr_s, ytr)
            Xva_k = selector.transform(Xva_s)

            k_cache[k] = {
                "X_train": np.asarray(Xtr_k, dtype=np.float32),
                "X_valid": np.asarray(Xva_k, dtype=np.float32),
            }

        folds.append(
            {
                "fold": fold_i,
                "y_train": ytr,
                "y_valid": yva,
                "k_cache": k_cache,
            }
        )

    return folds


# ============================================================
# SEARCH SPACE
# ============================================================

def candidate_rows_for_model(model_name: str) -> List[dict]:
    if model_name == "Ridge_Logistic":
        return [
            {"k": k, "C": C}
            for k in K_VALUES
            for C in RIDGE_C_VALUES
        ]

    if model_name == "RBF_SVM":
        return [
            {"k": k, "C": C, "gamma": gamma}
            for k in K_VALUES
            for C in RBF_C_VALUES
            for gamma in RBF_GAMMA_VALUES
        ]

    if model_name == "Extra_Trees":
        return [dict(x) for x in EXTRATREES_CANDIDATES]

    if model_name == "LightGBM":
        return [dict(x) for x in LIGHTGBM_CANDIDATES]

    raise RuntimeError(model_name)


def choose_best_candidate(df: pd.DataFrame, model_name: str) -> pd.Series:
    work = df.copy()

    # AUROC is primary, AP secondary. Exact ties favor fewer features and
    # simpler regularization / tree structure where applicable.
    if model_name == "Ridge_Logistic":
        work = work.sort_values(
            ["mean_inner_auc", "mean_inner_ap", "k", "C"],
            ascending=[False, False, True, True],
            kind="mergesort",
        )
    elif model_name == "RBF_SVM":
        work["gamma_tiebreak"] = work["gamma"].astype(str)
        work = work.sort_values(
            ["mean_inner_auc", "mean_inner_ap", "k", "C", "gamma_tiebreak"],
            ascending=[False, False, True, True, True],
            kind="mergesort",
        )
    elif model_name == "Extra_Trees":
        work["max_depth_sort"] = pd.to_numeric(
            work["max_depth"], errors="coerce"
        ).fillna(10**9)
        work = work.sort_values(
            ["mean_inner_auc", "mean_inner_ap", "k", "max_depth_sort", "n_estimators"],
            ascending=[False, False, True, True, True],
            kind="mergesort",
        )
    elif model_name == "LightGBM":
        work = work.sort_values(
            ["mean_inner_auc", "mean_inner_ap", "k", "num_leaves", "n_estimators"],
            ascending=[False, False, True, True, True],
            kind="mergesort",
        )
    else:
        raise RuntimeError(model_name)

    return work.iloc[0]


def normalize_best_params(model_name: str, row: pd.Series) -> dict:
    if model_name == "Ridge_Logistic":
        return {
            "k": int(row["k"]),
            "C": float(row["C"]),
        }

    if model_name == "RBF_SVM":
        gamma = row["gamma"]
        gamma = "scale" if str(gamma) == "scale" else float(gamma)
        return {
            "k": int(row["k"]),
            "C": float(row["C"]),
            "gamma": gamma,
        }

    if model_name == "Extra_Trees":
        max_depth = row["max_depth"]
        if pd.isna(max_depth) or str(max_depth) in {"None", "nan"}:
            max_depth = None
        else:
            max_depth = int(float(max_depth))

        max_features = row["max_features"]
        if str(max_features) != "sqrt":
            max_features = float(max_features)

        return {
            "k": int(row["k"]),
            "n_estimators": int(row["n_estimators"]),
            "max_features": max_features,
            "min_samples_leaf": int(row["min_samples_leaf"]),
            "max_depth": max_depth,
            "criterion": str(row["criterion"]),
        }

    if model_name == "LightGBM":
        return {
            "k": int(row["k"]),
            "n_estimators": int(row["n_estimators"]),
            "num_leaves": int(row["num_leaves"]),
            "max_depth": int(row["max_depth"]),
            "learning_rate": float(row["learning_rate"]),
            "subsample": float(row["subsample"]),
            "colsample_bytree": float(row["colsample_bytree"]),
            "min_child_samples": int(row["min_child_samples"]),
            "reg_alpha": float(row["reg_alpha"]),
            "reg_lambda": float(row["reg_lambda"]),
        }

    raise RuntimeError(model_name)


def search_model(
    model_name: str,
    split_id: str,
    inner_cache: List[dict],
) -> Tuple[pd.DataFrame, dict]:
    candidates = candidate_rows_for_model(model_name)
    rows = []
    start = time.perf_counter()

    for candidate_i, params in enumerate(candidates, start=1):
        aucs = []
        aps = []
        warnings_n = 0
        k = int(params["k"])

        for fold in inner_cache:
            cached = fold["k_cache"][k]
            auc, ap, conv = fit_and_score(
                model_name,
                params,
                cached["X_train"],
                fold["y_train"],
                cached["X_valid"],
                fold["y_valid"],
            )
            aucs.append(auc)
            aps.append(ap)
            warnings_n += conv

        row = {
            "analysis_status": "POST_HOC_EXPLORATORY",
            "split_id": split_id,
            "model": model_name,
            "candidate_index": candidate_i,
            **params,
            "mean_inner_auc": float(np.mean(aucs)),
            "sd_inner_auc": float(np.std(aucs, ddof=1)),
            "mean_inner_ap": float(np.mean(aps)),
            "sd_inner_ap": float(np.std(aps, ddof=1)),
            "convergence_warning_count": int(warnings_n),
        }

        for i, val in enumerate(aucs, 1):
            row[f"fold{i}_auc"] = val
        for i, val in enumerate(aps, 1):
            row[f"fold{i}_ap"] = val

        rows.append(row)

        progress_step = {
            "Ridge_Logistic": 10,
            "RBF_SVM": 10,
            "Extra_Trees": 5,
            "LightGBM": 5,
        }[model_name]

        if candidate_i % progress_step == 0 or candidate_i == len(candidates):
            elapsed = (time.perf_counter() - start) / 60.0
            logging.info(
                f"      {model_name}: {candidate_i}/{len(candidates)} "
                f"candidates ({elapsed:.1f} min)"
            )

    search_df = pd.DataFrame(rows)
    best_row = choose_best_candidate(search_df, model_name)
    best_params = normalize_best_params(model_name, best_row)
    best_params["mean_inner_auc"] = float(best_row["mean_inner_auc"])
    best_params["mean_inner_ap"] = float(best_row["mean_inner_ap"])
    best_params["convergence_warning_count"] = int(
        best_row["convergence_warning_count"]
    )

    return search_df, best_params


# ============================================================
# OUTER REFIT
# ============================================================

def refit_outer_and_predict(
    model_name: str,
    best_params: dict,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    gene_symbols: np.ndarray,
):
    vt = VarianceThreshold(threshold=0.0)
    Xtr_v = vt.fit_transform(X_train)
    Xte_v = vt.transform(X_test)

    scaler = StandardScaler()
    Xtr_s = scaler.fit_transform(Xtr_v)
    Xte_s = scaler.transform(Xte_v)

    k = int(best_params["k"])
    selector = SelectKBest(score_func=f_classif, k=k)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        Xtr_k = selector.fit_transform(Xtr_s, y_train)
    Xte_k = selector.transform(Xte_s)

    if model_name == "Ridge_Logistic":
        model = make_ridge(best_params)
    elif model_name == "RBF_SVM":
        model = make_rbf_svm(best_params)
    elif model_name == "Extra_Trees":
        model = make_extra_trees(best_params)
    elif model_name == "LightGBM":
        model = make_lightgbm(best_params, y_train)
    else:
        raise RuntimeError(model_name)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        model.fit(Xtr_k, y_train)

    scores, score_type = model_scores(model_name, model, Xte_k)

    auc = float(roc_auc_score(y_test, scores))
    ap = float(average_precision_score(y_test, scores))

    conv = sum(
        issubclass(w.category, ConvergenceWarning) for w in caught
    )

    vt_indices = np.flatnonzero(vt.get_support())
    selector_indices = np.flatnonzero(selector.get_support())
    original_indices = vt_indices[selector_indices]
    selected_genes = gene_symbols[original_indices]

    selector_scores = selector.scores_[selector_indices]

    if model_name == "Ridge_Logistic":
        importance = np.ravel(model.coef_).astype(float)
        importance_type = "coefficient"
    elif model_name in {"Extra_Trees", "LightGBM"}:
        importance = np.ravel(model.feature_importances_).astype(float)
        importance_type = "native_tree_feature_importance"
    else:
        importance = np.full(k, np.nan)
        importance_type = "selector_only_RBF_has_no_native_gene_coefficient"

    feat = pd.DataFrame(
        {
            "analysis_status": "POST_HOC_EXPLORATORY",
            "gene_symbol": selected_genes.astype(str),
            "selector_f_score": selector_scores.astype(float),
            "model_weight_or_importance": importance,
            "importance_type": importance_type,
        }
    )
    feat["absolute_weight_or_importance"] = np.abs(
        pd.to_numeric(
            feat["model_weight_or_importance"],
            errors="coerce",
        )
    )

    if model_name == "RBF_SVM":
        feat = feat.sort_values(
            "selector_f_score",
            ascending=False,
            kind="mergesort",
        )
    else:
        feat = feat.sort_values(
            "absolute_weight_or_importance",
            ascending=False,
            kind="mergesort",
        )

    feat = feat.reset_index(drop=True)
    feat["within_model_rank"] = np.arange(1, len(feat) + 1)

    return scores, score_type, auc, ap, feat, int(conv)


# ============================================================
# CHECKPOINTING
# ============================================================

def write_checkpoint(
    split_id: str,
    model_name: str,
    search_df: pd.DataFrame,
    best_df: pd.DataFrame,
    pred_df: pd.DataFrame,
    metric_df: pd.DataFrame,
    feature_df: pd.DataFrame,
    elapsed_sec: float,
) -> None:
    p = checkpoint_paths(split_id, model_name)

    search_df.to_csv(p["search"], sep="\t", index=False)
    best_df.to_csv(p["best"], sep="\t", index=False)
    pred_df.to_csv(p["pred"], sep="\t", index=False)
    metric_df.to_csv(p["metric"], sep="\t", index=False)
    feature_df.to_csv(p["features"], sep="\t", index=False)

    atomic_write_json(
        {
            "split_id": split_id,
            "model": model_name,
            "analysis_status": "POST_HOC_EXPLORATORY",
            "elapsed_seconds": round(elapsed_sec, 3),
            "completed_utc": datetime.now(timezone.utc).isoformat(),
            "search_sha256": sha256_file(p["search"]),
            "best_sha256": sha256_file(p["best"]),
            "pred_sha256": sha256_file(p["pred"]),
            "metric_sha256": sha256_file(p["metric"]),
            "features_sha256": sha256_file(p["features"]),
        },
        p["done"],
    )


def write_job_status(split_ids: List[str]) -> pd.DataFrame:
    rows = []

    for split_id in split_ids:
        for model in MODEL_NAMES:
            p = checkpoint_paths(split_id, model)
            complete = checkpoint_complete(split_id, model)
            elapsed = np.nan
            completed_utc = ""

            if complete:
                meta = json.loads(p["done"].read_text(encoding="utf-8"))
                elapsed = meta.get("elapsed_seconds", np.nan)
                completed_utc = meta.get("completed_utc", "")

            rows.append(
                {
                    "analysis_status": "POST_HOC_EXPLORATORY",
                    "split_id": split_id,
                    "model": model,
                    "complete": complete,
                    "elapsed_seconds": elapsed,
                    "completed_utc": completed_utc,
                }
            )

    df = pd.DataFrame(rows)
    df.to_csv(JOB_STATUS_OUT, sep="\t", index=False)
    return df


def aggregate_checkpoints(split_ids: List[str]) -> None:
    groups = {
        "search": [],
        "best": [],
        "pred": [],
        "metric": [],
        "features": [],
    }

    for split_id in split_ids:
        for model in MODEL_NAMES:
            if not checkpoint_complete(split_id, model):
                raise RuntimeError(
                    f"Incomplete checkpoint: {split_id}/{model}"
                )

            p = checkpoint_paths(split_id, model)
            for key in groups:
                groups[key].append(pd.read_csv(p[key], sep="\t"))

    pd.concat(groups["search"], ignore_index=True).to_csv(
        INNER_SEARCH_OUT, sep="\t", index=False
    )
    pd.concat(groups["best"], ignore_index=True).to_csv(
        BEST_PARAMS_OUT, sep="\t", index=False
    )
    pd.concat(groups["pred"], ignore_index=True).to_csv(
        OUTER_PRED_OUT, sep="\t", index=False
    )
    pd.concat(groups["metric"], ignore_index=True).to_csv(
        OUTER_METRICS_OUT, sep="\t", index=False
    )
    pd.concat(groups["features"], ignore_index=True).to_csv(
        FEATURES_OUT, sep="\t", index=False
    )


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    setup_logging()
    start = time.perf_counter()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF16B - POST-HOC EXPLORATORY MODEL EXTENSION")
    logging.info("============================================================")
    logging.info("")
    logging.info("Expected runtime on this machine: ~1-3 hours")
    logging.info("Likely bottlenecks: RBF-SVM and Extra Trees nested-CV searches")
    logging.info("Long silent periods: NOT expected; progress is printed frequently")
    logging.info("Checkpoint/resume: ENABLED")
    logging.info("SCAN-B accessed: NO")
    logging.info("APOLLO accessed: NO")
    logging.info("")
    logging.info("IMPORTANT:")
    logging.info("CF16 remains the PRE-SPECIFIED PRIMARY analysis.")
    logging.info("CF16B is explicitly POST-HOC / EXPLORATORY.")
    logging.info("")

    for p in [CF15_SUMMARY, CF16_SUMMARY, OUTER_ASSIGNMENTS, MATRIX_NPZ]:
        if not p.exists():
            raise FileNotFoundError(f"Required input missing: {p}")

    cf15 = metric_dict(CF15_SUMMARY)
    cf16 = metric_dict(CF16_SUMMARY)

    if cf15.get("CF15 stage gate") != "PASS_READY_FOR_CF16":
        raise RuntimeError("CF15 frozen gate is not PASS_READY_FOR_CF16.")

    if cf16.get("CF16 stage gate") != "PASS_READY_FOR_CF17":
        raise RuntimeError(
            "Original CF16 is not complete/frozen. "
            f"Observed gate={cf16.get('CF16 stage gate')}"
        )

    # LightGBM must be available before starting any exploratory jobs.
    lightgbm_version = package_version("lightgbm")
    if lightgbm_version == "MISSING":
        logging.info("============================================================")
        logging.info(" LIGHTGBM DEPENDENCY MISSING - NO CF16B TRAINING STARTED")
        logging.info("============================================================")
        logging.info("")
        logging.info("Install in the active hasan_2026 environment with:")
        logging.info("    pip install lightgbm")
        logging.info("")
        logging.info("Then rerun this same CF16B command.")
        logging.info("No exploratory model job was started.")
        sys.exit(2)

    write_protocol()

    logging.info(f"LightGBM version: {lightgbm_version} [READY]")
    logging.info(f"Tree-model threads: {TREE_THREADS}")
    logging.info("")

    # Trusted locally-generated CF15 artifact. IDs were stored as object arrays.
    z = np.load(MATRIX_NPZ, allow_pickle=True)
    X = np.asarray(z["X"], dtype=np.float32)
    y = np.asarray(z["y"], dtype=np.int8)
    patient_ids = z["patient_ids"].astype(str)
    sample_ids = z["sample_ids"].astype(str)
    gene_symbols = z["gene_symbols"].astype(str)

    if X.shape != (EXPECTED_N, EXPECTED_P):
        raise RuntimeError(f"Unexpected matrix shape {X.shape}.")
    if len(np.unique(patient_ids)) != EXPECTED_N:
        raise RuntimeError("Duplicate patient IDs.")
    if int((y == 1).sum()) != EXPECTED_POS or int((y == 0).sum()) != EXPECTED_NEG:
        raise RuntimeError("HER2 class counts changed.")

    assignments = pd.read_csv(OUTER_ASSIGNMENTS, sep="\t")
    split_ids = sorted(
        assignments["split_id"].astype(str).unique(),
        key=outer_split_sort_key,
    )

    if len(split_ids) != EXPECTED_OUTER_SPLITS:
        raise RuntimeError("Expected 15 frozen outer splits.")

    status = write_job_status(split_ids)
    already = int(status["complete"].sum())

    logging.info(f"Existing completed CF16B jobs: {already}/{EXPECTED_JOBS}")
    if already:
        logging.info("Completed jobs will be skipped.")
    logging.info("")

    all_idx = np.arange(EXPECTED_N)
    observed_job_times = (
        pd.to_numeric(
            status.loc[status["complete"], "elapsed_seconds"],
            errors="coerce",
        )
        .dropna()
        .tolist()
    )

    job_number = 0

    for outer_i, split_id in enumerate(split_ids, 1):
        split_rows = assignments.loc[
            assignments["split_id"].astype(str) == split_id
        ].sort_values("row_index")

        test_idx = np.sort(split_rows["row_index"].astype(int).to_numpy())
        train_idx = np.setdiff1d(all_idx, test_idx, assume_unique=True)

        if not np.array_equal(
            patient_ids[test_idx],
            split_rows["patient_id"].astype(str).to_numpy(),
        ):
            raise RuntimeError(f"Patient registry mismatch in {split_id}.")

        X_outer_train = X[train_idx]
        y_outer_train = y[train_idx]
        X_outer_test = X[test_idx]
        y_outer_test = y[test_idx]

        logging.info("------------------------------------------------------------")
        logging.info(
            f"[Outer {outer_i:02d}/15] {split_id} | "
            f"train={len(train_idx)} test={len(test_idx)} | "
            f"test HER2+={int(y_outer_test.sum())}"
        )

        pending = [
            m for m in MODEL_NAMES
            if not checkpoint_complete(split_id, m)
        ]

        if not pending:
            logging.info("All 4 exploratory model jobs already complete; skipping.")
            logging.info("")
            job_number += 4
            continue

        prep_start = time.perf_counter()
        logging.info("  Preparing leakage-safe inner-fold preprocessing cache...")
        inner_cache = prepare_inner_cache(X_outer_train, y_outer_train)
        logging.info(
            f"  Inner cache ready in "
            f"{(time.perf_counter()-prep_start)/60:.2f} min."
        )
        logging.info("")

        for model_name in MODEL_NAMES:
            job_number += 1

            if checkpoint_complete(split_id, model_name):
                logging.info(
                    f"  [Job {job_number:02d}/60] {model_name}: "
                    f"CHECKPOINT EXISTS -> SKIP"
                )
                continue

            logging.info(
                f"  [Job {job_number:02d}/60] {model_name}: START"
            )

            job_start = time.perf_counter()

            search_df, best_params = search_model(
                model_name,
                split_id,
                inner_cache,
            )

            (
                scores,
                score_type,
                outer_auc,
                outer_ap,
                feature_df,
                outer_conv,
            ) = refit_outer_and_predict(
                model_name,
                best_params,
                X_outer_train,
                y_outer_train,
                X_outer_test,
                y_outer_test,
                gene_symbols,
            )

            elapsed = time.perf_counter() - job_start

            best_df = pd.DataFrame(
                [
                    {
                        "analysis_status": "POST_HOC_EXPLORATORY",
                        "split_id": split_id,
                        "model": model_name,
                        **best_params,
                        "outer_refit_convergence_warning_count": outer_conv,
                        "job_elapsed_seconds": elapsed,
                    }
                ]
            )

            pred_df = pd.DataFrame(
                {
                    "analysis_status": "POST_HOC_EXPLORATORY",
                    "split_id": split_id,
                    "repeat": int(split_rows["repeat"].iloc[0]),
                    "fold": int(split_rows["fold"].iloc[0]),
                    "model": model_name,
                    "row_index": test_idx,
                    "patient_id": patient_ids[test_idx],
                    "expression_sample_id": sample_ids[test_idx],
                    "y_true": y_outer_test,
                    "score": scores,
                    "score_type": score_type,
                }
            )

            metric_df = pd.DataFrame(
                [
                    {
                        "analysis_status": "POST_HOC_EXPLORATORY",
                        "split_id": split_id,
                        "repeat": int(split_rows["repeat"].iloc[0]),
                        "fold": int(split_rows["fold"].iloc[0]),
                        "model": model_name,
                        "test_n": len(test_idx),
                        "test_positive": int((y_outer_test == 1).sum()),
                        "test_negative": int((y_outer_test == 0).sum()),
                        "outer_AUROC": outer_auc,
                        "outer_average_precision": outer_ap,
                        "selected_k": int(best_params["k"]),
                        "best_mean_inner_AUROC": float(
                            best_params["mean_inner_auc"]
                        ),
                        "best_mean_inner_average_precision": float(
                            best_params["mean_inner_ap"]
                        ),
                        "outer_refit_convergence_warning_count": outer_conv,
                    }
                ]
            )

            feature_df.insert(1, "model", model_name)
            feature_df.insert(1, "split_id", split_id)

            write_checkpoint(
                split_id,
                model_name,
                search_df,
                best_df,
                pred_df,
                metric_df,
                feature_df,
                elapsed,
            )

            observed_job_times.append(elapsed)
            status = write_job_status(split_ids)

            n_done = int(status["complete"].sum())
            n_left = EXPECTED_JOBS - n_done
            eta_h = (
                np.mean(observed_job_times) * n_left / 3600.0
                if observed_job_times
                else np.nan
            )

            logging.info(
                f"      BEST inner AUROC={best_params['mean_inner_auc']:.4f}, "
                f"inner AP={best_params['mean_inner_ap']:.4f}, "
                f"k={int(best_params['k'])}"
            )
            logging.info(
                f"      OUTER AUROC={outer_auc:.4f}, "
                f"outer AP={outer_ap:.4f}"
            )
            logging.info(
                f"      Job time={elapsed/60:.1f} min | "
                f"completed={n_done}/60 | rough ETA={eta_h:.2f} h"
            )
            logging.info("")

        del inner_cache

    status = write_job_status(split_ids)
    n_complete = int(status["complete"].sum())

    if n_complete != EXPECTED_JOBS:
        logging.info("============================================================")
        logging.info(" CF16B INCOMPLETE - CHECKPOINTS PRESERVED")
        logging.info("============================================================")
        logging.info(f"Completed jobs: {n_complete}/{EXPECTED_JOBS}")
        logging.info("Re-run the same command to resume.")
        return

    aggregate_checkpoints(split_ids)

    search_all = pd.read_csv(INNER_SEARCH_OUT, sep="\t")
    best_all = pd.read_csv(BEST_PARAMS_OUT, sep="\t")
    pred_all = pd.read_csv(OUTER_PRED_OUT, sep="\t")
    metric_all = pd.read_csv(OUTER_METRICS_OUT, sep="\t")
    features_all = pd.read_csv(FEATURES_OUT, sep="\t")

    expected_search_rows = EXPECTED_OUTER_SPLITS * (
        len(K_VALUES) * len(RIDGE_C_VALUES)
        + len(K_VALUES) * len(RBF_C_VALUES) * len(RBF_GAMMA_VALUES)
        + EXTRATREES_RANDOM_CANDIDATES
        + LIGHTGBM_RANDOM_CANDIDATES
    )

    if len(search_all) != expected_search_rows:
        raise RuntimeError(
            f"Search rows={len(search_all)}; expected {expected_search_rows}."
        )

    if len(best_all) != EXPECTED_JOBS:
        raise RuntimeError("Expected 60 best-parameter rows.")
    if len(metric_all) != EXPECTED_JOBS:
        raise RuntimeError("Expected 60 outer-metric rows.")

    expected_pred_rows = EXPECTED_N * 3 * len(MODEL_NAMES)
    if len(pred_all) != expected_pred_rows:
        raise RuntimeError(
            f"Prediction rows={len(pred_all)}; expected {expected_pred_rows}."
        )

    pred_counts = pred_all.groupby(
        ["model", "repeat", "patient_id"]
    ).size()

    if not (pred_counts == 1).all():
        raise RuntimeError(
            "Prediction registry is not one prediction per "
            "patient/repeat/exploratory model."
        )

    runtime_min = (time.perf_counter() - start) / 60.0

    summary = pd.DataFrame(
        [
            ("Analysis status", "POST_HOC_EXPLORATORY"),
            ("Original CF16 primary analysis changed", "NO"),
            ("Exploratory model families", 4),
            ("Completed outer/model jobs", n_complete),
            ("Inner search candidate summaries", len(search_all)),
            ("Outer prediction rows", len(pred_all)),
            ("Selected-feature rows", len(features_all)),
            ("SCAN-B accessed", "NO"),
            ("APOLLO accessed", "NO"),
            ("Final model family selected", "NO"),
            ("CF16B runtime minutes this invocation", round(runtime_min, 2)),
            ("CF16B stage gate", "PASS_READY_FOR_CF17_COMBINED_EVALUATION"),
        ],
        columns=["metric", "value"],
    )
    summary.to_csv(SUMMARY_OUT, sep="\t", index=False)

    provenance = pd.DataFrame(
        [
            ("code_file", "CF16B_exploratory_model_extension.py"),
            ("analysis_status", "POST_HOC_EXPLORATORY"),
            ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
            ("CF15_summary_sha256", sha256_file(CF15_SUMMARY)),
            ("CF16_primary_summary_sha256", sha256_file(CF16_SUMMARY)),
            ("CF15_matrix_sha256", sha256_file(MATRIX_NPZ)),
            ("outer_assignments_sha256", sha256_file(OUTER_ASSIGNMENTS)),
            ("protocol_sha256", sha256_file(PROTOCOL_OUT)),
            ("inner_search_sha256", sha256_file(INNER_SEARCH_OUT)),
            ("outer_predictions_sha256", sha256_file(OUTER_PRED_OUT)),
            ("outer_metrics_sha256", sha256_file(OUTER_METRICS_OUT)),
            ("selected_features_sha256", sha256_file(FEATURES_OUT)),
            (
                "preprocessing_rule",
                "VarianceThreshold, StandardScaler and SelectKBest fitted "
                "inside training folds only",
            ),
            (
                "external_data_rule",
                "SCAN-B and APOLLO not accessed",
            ),
            ("python_version", platform.python_version()),
            ("numpy_version", package_version("numpy")),
            ("pandas_version", package_version("pandas")),
            ("scikit_learn_version", package_version("scikit-learn")),
            ("lightgbm_version", lightgbm_version),
            ("tree_threads", TREE_THREADS),
            ("CF16B_stage_gate", "PASS_READY_FOR_CF17_COMBINED_EVALUATION"),
        ],
        columns=["field", "value"],
    )
    provenance.to_csv(PROVENANCE_OUT, sep="\t", index=False)

    logging.info("============================================================")
    logging.info(" CF16B COMPLETE - EXPLORATORY MODEL EXTENSION PASSED")
    logging.info("============================================================")
    logging.info("")
    logging.info(f"Completed jobs: {n_complete}/60")
    logging.info(f"Inner candidate summaries: {len(search_all)}")
    logging.info(f"Outer prediction rows: {len(pred_all)}")
    logging.info(f"Selected-feature rows: {len(features_all)}")
    logging.info(f"Runtime this invocation: {runtime_min/60:.2f} h")
    logging.info("")
    logging.info("Original CF16 primary analysis changed: NO")
    logging.info("SCAN-B accessed: NO")
    logging.info("APOLLO accessed: NO")
    logging.info("Final model selected: NO")
    logging.info("STATUS: PASS_READY_FOR_CF17_COMBINED_EVALUATION")
    logging.info("")
    logging.info("Send the full terminal output before CF17.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logging.info("")
        logging.info("CF16B interrupted. Completed checkpoints are preserved.")
        logging.info("Re-run the same command to resume.")
        sys.exit(130)
    except Exception as exc:
        logging.exception(f"\nCF16B ERROR: {exc}")
        logging.info("")
        logging.info("Completed checkpoints are preserved. Fix and rerun to resume.")
        sys.exit(1)
