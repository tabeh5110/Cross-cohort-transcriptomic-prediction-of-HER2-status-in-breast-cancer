from __future__ import annotations

import math
import os
from datetime import date
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
CF30 = ROOT / "CF30_ranked_GSEA_pathway_analysis"
INPUT_DIR = CF30 / "input"
RESULTS_DIR = CF30 / "results"
FIGURES_DIR = CF30 / "figures"
METADATA_DIR = CF30 / "metadata"
LOGS_DIR = CF30 / "logs"

CF18_FEATURES = ROOT / "results" / "CF18_stable_signature_xai_final_model" / "CF18_final_ElasticNet_features.tsv"
CF18_SUMMARY = ROOT / "results" / "CF18_stable_signature_xai_final_model" / "CF18_summary.tsv"
CF20_COEFFICIENTS = ROOT / "results" / "CF20_model_interpretation" / "CF20_all_selected_coefficients.tsv"
FEATURE_UNIVERSE = ROOT / "data" / "processed" / "ml_ready" / "CF14_external_validation_gene_universe_LOCKED.tsv"
GENE_ANNOTATION = ROOT / "data" / "processed" / "tcga_brca" / "expression" / "CF6_gene_annotation.tsv"
CROSSWALK = ROOT / "data" / "processed" / "cross_cohort" / "CF13_transcriptomic_feature_crosswalk.tsv"
CF22_HALLMARK = ROOT / "results" / "CF22_signature_biology" / "CF22_Hallmark_enrichment.tsv"
CF22_REACTOME = ROOT / "results" / "CF22_signature_biology" / "CF22_Reactome_enrichment.tsv"

HALLMARK_LIBRARY = "MSigDB_Hallmark_2020"
REACTOME_LIBRARY = "Reactome_2022"
PERMUTATIONS = 10_000
MIN_SIZE = 15
MAX_SIZE = 500
SEED = 42
N_WORKERS = max(1, min(4, (os.cpu_count() or 2) - 1))
_WORKER_WEIGHTS = None
_WORKER_N_GENES = None
_WORKER_RANKED_GENES = None


def ensure_dirs() -> None:
    for directory in [INPUT_DIR, RESULTS_DIR, FIGURES_DIR, METADATA_DIR, LOGS_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


def read_tsv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path, sep="\t")


def count_rows(path: Path) -> int | str:
    try:
        return len(read_tsv(path))
    except Exception:
        return "NA"


def write_manifest() -> pd.DataFrame:
    rows = [
        {
            "filename": CF18_FEATURES.name,
            "path": str(CF18_FEATURES),
            "sample_count": "NA",
            "number_of_genes": count_rows(CF18_FEATURES),
            "description": "Locked final model feature table with standardized Elastic-Net coefficients for the 500 selected model features; all other locked model-universe genes are assigned zero contribution in CF30.",
        },
        {
            "filename": CF20_COEFFICIENTS.name,
            "path": str(CF20_COEFFICIENTS),
            "sample_count": "NA",
            "number_of_genes": count_rows(CF20_COEFFICIENTS),
            "description": "Locked Elastic-Net coefficient table used to verify that CF30 ranking preserves prior model interpretation.",
        },
        {
            "filename": FEATURE_UNIVERSE.name,
            "path": str(FEATURE_UNIVERSE),
            "sample_count": "NA",
            "number_of_genes": count_rows(FEATURE_UNIVERSE),
            "description": "Locked cross-cohort transcriptomic feature universe used as the complete CF30 ranked GSEA background.",
        },
        {
            "filename": GENE_ANNOTATION.name,
            "path": str(GENE_ANNOTATION),
            "sample_count": "NA",
            "number_of_genes": count_rows(GENE_ANNOTATION),
            "description": "Local gene annotation table. It contains symbols and Ensembl identifiers but no Entrez identifier column.",
        },
        {
            "filename": CROSSWALK.name,
            "path": str(CROSSWALK),
            "sample_count": "NA",
            "number_of_genes": count_rows(CROSSWALK),
            "description": "TCGA/SCAN-B gene-symbol crosswalk used to verify model-gene mapping consistency.",
        },
        {
            "filename": CF22_HALLMARK.name,
            "path": str(CF22_HALLMARK),
            "sample_count": "NA",
            "number_of_genes": "86 selected nonzero model genes",
            "description": "Prior over-representation analysis Hallmark enrichment table used for method comparison.",
        },
        {
            "filename": CF22_REACTOME.name,
            "path": str(CF22_REACTOME),
            "sample_count": "NA",
            "number_of_genes": "86 selected nonzero model genes",
            "description": "Prior over-representation analysis Reactome enrichment table used for method comparison.",
        },
    ]
    manifest = pd.DataFrame(rows)
    manifest.to_csv(INPUT_DIR / "CF30_input_manifest.tsv", sep="\t", index=False)
    return manifest


def build_ranked_list() -> pd.DataFrame:
    features = read_tsv(CF18_FEATURES)
    required = {"gene_symbol", "standardized_ElasticNet_coefficient"}
    missing = required.difference(features.columns)
    if missing:
        raise ValueError(f"Missing required CF18 feature columns: {sorted(missing)}")

    universe = read_tsv(FEATURE_UNIVERSE)
    universe_col = "gene_symbol" if "gene_symbol" in universe.columns else universe.columns[0]
    ranked = universe[[universe_col]].copy()
    ranked.columns = ["Gene"]
    ranked["Gene"] = ranked["Gene"].astype(str)
    ranked = ranked.dropna(subset=["Gene"]).drop_duplicates("Gene", keep="first")

    model_coefficients = features[["gene_symbol", "standardized_ElasticNet_coefficient"]].copy()
    model_coefficients.columns = ["Gene", "Coefficient"]
    ranked = ranked.merge(model_coefficients, on="Gene", how="left")
    ranked["Coefficient"] = pd.to_numeric(ranked["Coefficient"], errors="coerce").fillna(0.0)
    ranked = ranked.sort_values(["Coefficient", "Gene"], ascending=[False, True]).reset_index(drop=True)
    ranked.insert(0, "Rank", range(1, len(ranked) + 1))
    ranked["Direction"] = ranked["Coefficient"].map(
        lambda x: "Positive" if x > 0 else ("Negative" if x < 0 else "Zero")
    )

    ranked[["Rank", "Gene", "Coefficient", "Direction"]].to_csv(
        RESULTS_DIR / "CF30_ranked_gene_list.tsv", sep="\t", index=False
    )
    ranked[["Gene", "Coefficient"]].to_csv(
        INPUT_DIR / "CF30_ranked_gene_list.rnk", sep="\t", index=False, header=False
    )
    return ranked


def verify_cf20_consistency(ranked: pd.DataFrame) -> tuple[bool, str]:
    cf20 = read_tsv(CF20_COEFFICIENTS)
    if not {"gene", "coefficient"}.issubset(cf20.columns):
        return False, "CF20 coefficient table does not contain expected gene/coefficient columns."
    merged = cf20.merge(ranked, left_on="gene", right_on="Gene", how="left")
    missing = merged["Coefficient"].isna().sum()
    max_abs_delta = (merged["coefficient"] - merged["Coefficient"]).abs().max()
    ok = missing == 0 and pd.notna(max_abs_delta) and max_abs_delta < 1e-8
    detail = f"CF20 coefficient rows found in CF30 ranked list: {len(cf20) - missing}/{len(cf20)}; max absolute coefficient delta: {max_abs_delta:.3g}."
    return bool(ok), detail


def load_gene_sets(library_name: str) -> dict[str, list[str]]:
    import gseapy as gp

    return gp.get_library(name=library_name, organism="Human")


def enrichment_score(
    hit_positions: np.ndarray, weights_at_hits: np.ndarray, n_genes: int
) -> tuple[float, int]:
    hit_positions = np.sort(hit_positions.astype(int))
    n_hits = len(hit_positions)
    if n_hits == 0 or n_hits == n_genes:
        return 0.0, -1
    weight_sum = float(weights_at_hits.sum())
    if weight_sum <= 0:
        hit_increments = np.repeat(1.0 / n_hits, n_hits)
    else:
        hit_increments = weights_at_hits[np.argsort(hit_positions)] / weight_sum
    hit_cumsum = np.cumsum(hit_increments)
    miss_penalty = 1.0 / (n_genes - n_hits)
    hit_numbers = np.arange(1, n_hits + 1)
    miss_before_or_at_hit = hit_positions + 1 - hit_numbers
    running_after_hit = hit_cumsum - miss_before_or_at_hit * miss_penalty
    running_before_hit = np.concatenate([[0.0], hit_cumsum[:-1]]) - (hit_positions - (hit_numbers - 1)) * miss_penalty
    max_idx = int(np.argmax(running_after_hit))
    min_idx = int(np.argmin(running_before_hit))
    max_es = float(running_after_hit[max_idx])
    min_es = float(running_before_hit[min_idx])
    if abs(max_es) >= abs(min_es):
        return max_es, max_idx
    return min_es, min_idx


def leading_edge_genes(
    pathway_genes: list[str], hit_positions: np.ndarray, edge_idx: int, es: float, ranked_genes: np.ndarray
) -> str:
    if edge_idx < 0 or len(hit_positions) == 0:
        return ""
    ordered_positions = np.sort(hit_positions.astype(int))
    if es >= 0:
        edge_positions = ordered_positions[: edge_idx + 1]
    else:
        edge_positions = ordered_positions[edge_idx:]
    genes = [ranked_genes[pos] for pos in edge_positions]
    pathway_set = set(pathway_genes)
    return ",".join([gene for gene in genes if gene in pathway_set])


def init_worker(weights: np.ndarray, ranked_genes: np.ndarray) -> None:
    global _WORKER_WEIGHTS, _WORKER_N_GENES, _WORKER_RANKED_GENES
    _WORKER_WEIGHTS = weights
    _WORKER_N_GENES = len(weights)
    _WORKER_RANKED_GENES = ranked_genes


def permutation_worker(task: tuple[int, str, list[str], np.ndarray, int]) -> tuple[dict, dict]:
    task_index, pathway, pathway_genes, member_positions, gene_count = task
    weights = _WORKER_WEIGHTS
    n_genes = _WORKER_N_GENES
    ranked_genes = _WORKER_RANKED_GENES
    if weights is None or n_genes is None or ranked_genes is None:
        raise RuntimeError("Worker globals were not initialized.")

    rng = np.random.default_rng(SEED + task_index * 1009)
    observed_es, edge_idx = enrichment_score(member_positions, weights[member_positions], n_genes)
    null_es = np.empty(PERMUTATIONS, dtype=float)
    overlap_size = len(member_positions)
    for i in range(PERMUTATIONS):
        sampled = rng.choice(n_genes, size=overlap_size, replace=False)
        null_es[i], _ = enrichment_score(sampled, weights[sampled], n_genes)

    if observed_es >= 0:
        same_direction = null_es[null_es >= 0]
        nominal_p = (np.sum(same_direction >= observed_es) + 1) / (len(same_direction) + 1)
        mean_null = np.mean(same_direction) if len(same_direction) else 1.0
    else:
        same_direction = null_es[null_es < 0]
        nominal_p = (np.sum(same_direction <= observed_es) + 1) / (len(same_direction) + 1)
        mean_null = abs(np.mean(same_direction)) if len(same_direction) else 1.0
    nes = observed_es / mean_null if mean_null else np.nan
    lead = leading_edge_genes(pathway_genes, member_positions, edge_idx, observed_es, ranked_genes)
    result_row = {
        "Pathway": pathway,
        "NES": nes,
        "Nominal_p_value": nominal_p,
        "FDR": np.nan,
        "Leading_edge_genes": lead,
        "Gene_count": gene_count,
    }
    raw_row = {
        "Pathway": pathway,
        "Observed_ES": observed_es,
        "Mean_same_direction_null_abs_ES": mean_null,
        "NES": nes,
        "Nominal_p_value": nominal_p,
        "Overlap_gene_count": overlap_size,
        "Gene_count": gene_count,
        "Permutations": PERMUTATIONS,
    }
    return result_row, raw_row


def bh_fdr(p_values: pd.Series) -> pd.Series:
    p = pd.to_numeric(p_values, errors="coerce").fillna(1.0).to_numpy(dtype=float)
    n = len(p)
    order = np.argsort(p)
    ranked_p = p[order]
    adjusted = np.empty(n, dtype=float)
    cumulative = 1.0
    for i in range(n - 1, -1, -1):
        value = ranked_p[i] * n / (i + 1)
        cumulative = min(cumulative, value)
        adjusted[order[i]] = min(cumulative, 1.0)
    return pd.Series(adjusted, index=p_values.index)


def run_prerank(
    ranked: pd.DataFrame, gene_sets: dict[str, list[str]], label: str
) -> tuple[pd.DataFrame, pd.DataFrame]:
    ranked_genes = ranked["Gene"].astype(str).to_numpy()
    scores = ranked["Coefficient"].to_numpy(dtype=float)
    weights = np.abs(scores)
    n_genes = len(ranked_genes)
    gene_to_position = {gene: i for i, gene in enumerate(ranked_genes)}
    nonzero_positions = set(np.flatnonzero(weights > 0).tolist())

    tasks = []
    for pathway, genes in sorted(gene_sets.items()):
        member_positions = np.array(
            [gene_to_position[gene] for gene in genes if gene in gene_to_position], dtype=int
        )
        overlap_size = len(member_positions)
        if overlap_size < MIN_SIZE or overlap_size > MAX_SIZE:
            continue
        if not (nonzero_positions & set(member_positions.tolist())):
            continue
        tasks.append((len(tasks), pathway, genes, member_positions, len(genes)))

    rows = []
    raw_rows = []
    with ProcessPoolExecutor(max_workers=N_WORKERS, initializer=init_worker, initargs=(weights, ranked_genes)) as pool:
        futures = [pool.submit(permutation_worker, task) for task in tasks]
        for future in as_completed(futures):
            result_row, raw_row = future.result()
            rows.append(result_row)
            raw_rows.append(raw_row)

    results = pd.DataFrame(rows)
    if results.empty:
        raise LookupError(f"No {label} gene sets passed CF30 min/max size filtering.")
    results["FDR"] = bh_fdr(results["Nominal_p_value"])
    results = results.sort_values(["FDR", "Nominal_p_value", "NES"], ascending=[True, True, False]).reset_index(
        drop=True
    )
    raw = pd.DataFrame(raw_rows).sort_values("Nominal_p_value").reset_index(drop=True)
    raw.to_csv(RESULTS_DIR / f"CF30_{label}_GSEA_raw_permutation_results.tsv", sep="\t", index=False)
    results.to_csv(RESULTS_DIR / f"CF30_{label}_GSEA_results.tsv", sep="\t", index=False)
    return results, raw


def significance_label(fdr: float) -> str:
    if pd.notna(fdr) and fdr < 0.05:
        return "Significant_FDR_lt_0.05"
    if pd.notna(fdr) and fdr < 0.25:
        return "Suggestive_FDR_lt_0.25"
    return "Not_significant"


def interpret_pathway(pathway: str, nes: float) -> str:
    term = pathway.upper()
    direction = "higher HER2 probability" if nes > 0 else "lower HER2 probability"
    mappings = [
        (["ERBB2", "HER2", "GRB7"], "ERBB2 receptor tyrosine kinase signaling"),
        (["PI3K", "AKT", "MTOR"], "PI3K/AKT/mTOR growth signaling"),
        (["MAPK", "RAS", "RAF", "MEK", "ERK"], "MAPK pathway signaling"),
        (["E2F", "G2M", "MITOTIC", "CELL_CYCLE", "DNA_REPLICATION", "M_PHASE"], "proliferation and cell-cycle activity"),
        (["DNA_REPAIR", "REPAIR", "CHECKPOINT"], "DNA repair and checkpoint biology"),
        (["INTERFERON", "INFLAMMATORY", "IMMUNE", "COMPLEMENT", "ANTIGEN", "CYTOKINE"], "immune and inflammatory response"),
        (["ESTROGEN", "ANDROGEN"], "hormone receptor biology"),
        (["CHOLESTEROL", "FATTY_ACID", "ADIPOGENESIS", "METABOLISM"], "metabolic state associated with subtype context"),
    ]
    for keys, text in mappings:
        if any(key in term for key in keys):
            return f"{text}; enrichment direction is associated with {direction}."
    return f"Model-ranked pathway signal; enrichment direction is associated with {direction}."


def write_pathway_summary(hallmark: pd.DataFrame, reactome: pd.DataFrame) -> pd.DataFrame:
    joined = pd.concat(
        [hallmark.assign(Database="Hallmark"), reactome.assign(Database="Reactome")],
        ignore_index=True,
    )
    joined["Significance_class"] = joined["FDR"].map(significance_label)
    joined["Biological_interpretation"] = [
        interpret_pathway(pathway, nes) for pathway, nes in zip(joined["Pathway"], joined["NES"])
    ]
    summary = joined.copy()
    summary = summary[
        [
            "Database",
            "Pathway",
            "NES",
            "Nominal_p_value",
            "FDR",
            "Significance_class",
            "Leading_edge_genes",
            "Gene_count",
            "Biological_interpretation",
        ]
    ].sort_values(["FDR", "Database", "Pathway"])
    summary.to_csv(RESULTS_DIR / "CF30_pathway_summary.tsv", sep="\t", index=False)
    return summary


def top_pathways(df: pd.DataFrame, name_col: str, p_col: str, n: int = 5) -> str:
    if df.empty:
        return ""
    work = df.copy()
    work[p_col] = pd.to_numeric(work[p_col], errors="coerce")
    return "; ".join(work.sort_values(p_col)[name_col].astype(str).head(n).tolist())


def cf22_comparison(hallmark: pd.DataFrame, reactome: pd.DataFrame, ranked: pd.DataFrame) -> pd.DataFrame:
    h22 = read_tsv(CF22_HALLMARK)
    r22 = read_tsv(CF22_REACTOME)
    rows = [
        {
            "Analysis": "CF30 Hallmark ranked GSEA",
            "Input_genes": f"{len(ranked)} ranked locked model-universe genes with Elastic-Net coefficients or zero model contribution",
            "Method": f"Preranked GSEA; coefficient-informative gene sets only; gene-set permutations={PERMUTATIONS}; BH FDR; min_size={MIN_SIZE}; max_size={MAX_SIZE}; seed={SEED}",
            "Number_pathways_tested": len(hallmark),
            "Significant_pathways": int((hallmark["FDR"] < 0.05).sum()),
            "Top_pathways": top_pathways(hallmark, "Pathway", "FDR"),
        },
        {
            "Analysis": "CF30 Reactome ranked GSEA",
            "Input_genes": f"{len(ranked)} ranked locked model-universe genes with Elastic-Net coefficients or zero model contribution",
            "Method": f"Preranked GSEA; coefficient-informative gene sets only; gene-set permutations={PERMUTATIONS}; BH FDR; min_size={MIN_SIZE}; max_size={MAX_SIZE}; seed={SEED}",
            "Number_pathways_tested": len(reactome),
            "Significant_pathways": int((reactome["FDR"] < 0.05).sum()),
            "Top_pathways": top_pathways(reactome, "Pathway", "FDR"),
        },
        {
            "Analysis": "CF22 Hallmark selected-gene ORA",
            "Input_genes": "86 nonzero final model genes",
            "Method": "Over-representation analysis against Enrichr/MSigDB_Hallmark_2020",
            "Number_pathways_tested": len(h22),
            "Significant_pathways": int((pd.to_numeric(h22["Adjusted P-value"], errors="coerce") < 0.05).sum()),
            "Top_pathways": top_pathways(h22, "Term", "Adjusted P-value"),
        },
        {
            "Analysis": "CF22 Reactome selected-gene ORA",
            "Input_genes": "86 nonzero final model genes",
            "Method": "Over-representation analysis against Enrichr/Reactome_2022",
            "Number_pathways_tested": len(r22),
            "Significant_pathways": int((pd.to_numeric(r22["Adjusted P-value"], errors="coerce") < 0.05).sum()),
            "Top_pathways": top_pathways(r22, "Term", "Adjusted P-value"),
        },
    ]
    comparison = pd.DataFrame(rows)
    comparison.to_csv(RESULTS_DIR / "CF30_vs_CF22_comparison.tsv", sep="\t", index=False)
    return comparison


def make_dotplot(df: pd.DataFrame, title: str, output: Path) -> None:
    plot_df = df.copy()
    plot_df["abs_NES"] = plot_df["NES"].abs()
    plot_df = plot_df.sort_values(["FDR", "abs_NES"], ascending=[True, False]).head(20)
    plot_df = plot_df.sort_values("NES")
    if plot_df.empty:
        return

    safe_fdr = plot_df["FDR"].clip(lower=1e-300)
    sizes = (-safe_fdr.map(math.log10)).clip(lower=0.5, upper=8) * 35
    colors = plot_df["NES"].map(lambda x: "#b13f3f" if x >= 0 else "#2f6f9f")

    fig_height = max(5, 0.32 * len(plot_df) + 1.8)
    fig, ax = plt.subplots(figsize=(9.5, fig_height))
    ax.scatter(plot_df["NES"], plot_df["Pathway"], s=sizes, c=colors, alpha=0.86, edgecolor="black", linewidth=0.35)
    ax.axvline(0, color="#666666", linewidth=0.8)
    ax.set_xlabel("Normalized enrichment score (NES)")
    ax.set_ylabel("")
    ax.set_title(title)
    ax.grid(axis="x", color="#dddddd", linewidth=0.6)
    for spine in ["top", "right", "left"]:
        ax.spines[spine].set_visible(False)
    fig.tight_layout()
    fig.savefig(output, dpi=300)
    plt.close(fig)


def make_network(summary: pd.DataFrame) -> None:
    graph_df = summary.head(12).copy()
    if len(graph_df) < 2:
        return
    gene_sets = {
        row.Pathway: {g.strip() for g in str(row.Leading_edge_genes).replace(";", ",").split(",") if g.strip()}
        for row in graph_df.itertuples()
    }
    nodes = list(gene_sets)
    angles = [2 * math.pi * i / len(nodes) for i in range(len(nodes))]
    coords = {node: (math.cos(angle), math.sin(angle)) for node, angle in zip(nodes, angles)}

    fig, ax = plt.subplots(figsize=(9, 9))
    for i, a in enumerate(nodes):
        for b in nodes[i + 1 :]:
            union = gene_sets[a] | gene_sets[b]
            if not union:
                continue
            jaccard = len(gene_sets[a] & gene_sets[b]) / len(union)
            if jaccard >= 0.15:
                ax.plot(
                    [coords[a][0], coords[b][0]],
                    [coords[a][1], coords[b][1]],
                    color="#999999",
                    linewidth=0.6 + 3 * jaccard,
                    alpha=0.45,
                )
    for row in graph_df.itertuples():
        x, y = coords[row.Pathway]
        color = "#b13f3f" if row.NES >= 0 else "#2f6f9f"
        ax.scatter([x], [y], s=180, c=color, edgecolor="black", linewidth=0.5, zorder=3)
        label = row.Pathway.replace("HALLMARK_", "").replace("REACTOME_", "").replace("_", " ")
        ax.text(x * 1.12, y * 1.12, label[:42], ha="center", va="center", fontsize=7.5)
    ax.set_axis_off()
    ax.set_title("CF30 pathway network: shared leading-edge genes")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF30_pathway_network.png", dpi=300)
    plt.close(fig)


def write_database_metadata(hallmark_sets: dict[str, list[str]], reactome_sets: dict[str, list[str]]) -> pd.DataFrame:
    rows = [
        {
            "Database": "Hallmark",
            "Library_name": HALLMARK_LIBRARY,
            "Version_or_source": "Enrichr library retrieved through gseapy; library name encodes 2020 release.",
            "Download_date": date.today().isoformat(),
            "Mapping_method": "HGNC gene symbols matched directly to locked model gene symbols; no Entrez conversion was performed because local annotation lacks Entrez IDs. Tested gene sets were required to pass min/max overlap and contain at least one nonzero model coefficient. Nominal permutation p-values were adjusted using Benjamini-Hochberg FDR.",
            "Gene_sets_retrieved": len(hallmark_sets),
            "GSEA_min_size": MIN_SIZE,
            "GSEA_max_size": MAX_SIZE,
            "Permutations": PERMUTATIONS,
            "Seed": SEED,
        },
        {
            "Database": "Reactome",
            "Library_name": REACTOME_LIBRARY,
            "Version_or_source": "Enrichr library retrieved through gseapy; library name encodes 2022 release.",
            "Download_date": date.today().isoformat(),
            "Mapping_method": "HGNC gene symbols matched directly to locked model gene symbols; no Entrez conversion was performed because local annotation lacks Entrez IDs. Tested gene sets were required to pass min/max overlap and contain at least one nonzero model coefficient. Nominal permutation p-values were adjusted using Benjamini-Hochberg FDR.",
            "Gene_sets_retrieved": len(reactome_sets),
            "GSEA_min_size": MIN_SIZE,
            "GSEA_max_size": MAX_SIZE,
            "Permutations": PERMUTATIONS,
            "Seed": SEED,
        },
    ]
    metadata = pd.DataFrame(rows)
    metadata.to_csv(METADATA_DIR / "CF30_pathway_database_metadata.tsv", sep="\t", index=False)
    return metadata


def write_her2_biology_summary(summary: pd.DataFrame) -> pd.DataFrame:
    topics = [
        ("Receptor tyrosine kinase signaling", ["ERBB2", "ERBB", "GRB7", "EGFR", "RECEPTOR_TYROSINE_KINASE"]),
        ("ERBB2/HER2 signaling", ["ERBB2", "HER2", "GRB7"]),
        ("PI3K/AKT signaling", ["PI3K", "AKT", "MTOR"]),
        ("MAPK signaling", ["MAPK", "RAS", "RAF", "MEK", "ERK"]),
        ("Cell proliferation", ["E2F", "G2M", "MITOTIC", "CELL_CYCLE", "M_PHASE", "DNA_REPLICATION"]),
        ("DNA repair", ["DNA_REPAIR", "REPAIR", "CHECKPOINT"]),
        ("Immune response", ["INTERFERON", "INFLAMMATORY", "IMMUNE", "COMPLEMENT", "ANTIGEN", "CYTOKINE"]),
    ]
    rows = []
    supported_summary = summary[summary["FDR"] < 0.25].copy()
    for topic, keys in topics:
        mask = supported_summary["Pathway"].str.upper().apply(lambda value: any(key in value for key in keys))
        evidence = supported_summary.loc[mask].sort_values("FDR")
        if evidence.empty:
            rows.append(
                {
                    "Biological_process": topic,
                    "Support_level": "Not_supported_by_CF30_FDR_lt_0.25",
                    "Evidence_pathways": "",
                    "Direction": "",
                    "Interpretation": f"No CF30 significant or suggestive pathway directly supported {topic}.",
                }
            )
            continue
        best = evidence.iloc[0]
        support = "Supported_FDR_lt_0.05" if best["FDR"] < 0.05 else "Suggestive_FDR_lt_0.25"
        direction = "Positive_NES_higher_HER2_probability" if best["NES"] > 0 else "Negative_NES_lower_HER2_probability"
        rows.append(
            {
                "Biological_process": topic,
                "Support_level": support,
                "Evidence_pathways": "; ".join(evidence["Pathway"].head(5).tolist()),
                "Direction": direction,
                "Interpretation": best["Biological_interpretation"],
            }
        )
    her2 = pd.DataFrame(rows)
    her2.to_csv(RESULTS_DIR / "CF30_HER2_biology_summary.tsv", sep="\t", index=False)
    return her2


def write_qc(ranked: pd.DataFrame, comparison: pd.DataFrame, cf20_ok: bool, cf20_detail: str) -> pd.DataFrame:
    universe = read_tsv(FEATURE_UNIVERSE)
    crosswalk = read_tsv(CROSSWALK)
    annotation = read_tsv(GENE_ANNOTATION)
    ranked_genes = set(ranked["Gene"])
    universe_col = "gene_symbol" if "gene_symbol" in universe.columns else universe.columns[0]
    crosswalk_cols = set(crosswalk.columns)
    crosswalk_gene_col = "gene_symbol" if "gene_symbol" in crosswalk_cols else (
        "gene_name" if "gene_name" in crosswalk_cols else crosswalk.columns[0]
    )
    annotation_gene_col = "gene_name" if "gene_name" in annotation.columns else annotation.columns[0]
    universe_overlap = len(ranked_genes & set(universe[universe_col].dropna().astype(str)))
    crosswalk_overlap = len(ranked_genes & set(crosswalk[crosswalk_gene_col].dropna().astype(str)))
    annotation_overlap = len(ranked_genes & set(annotation[annotation_gene_col].dropna().astype(str)))
    has_entrez = any("entrez" in c.lower() for c in annotation.columns)
    zero_count = int((ranked["Coefficient"] == 0).sum())

    rows = [
        {
            "QC_check": "Ranking based only on locked coefficients",
            "Status": "PASS" if cf20_ok else "FAIL",
            "Details": cf20_detail,
        },
        {
            "QC_check": "No outcome labels used",
            "Status": "PASS",
            "Details": "CF30 script reads coefficient, gene-universe, annotation, gene-set, and CF22 enrichment files only; no phenotype or HER2 label file is loaded.",
        },
        {
            "QC_check": "No model retraining performed",
            "Status": "PASS",
            "Details": "CF30 uses preranked GSEA on locked Elastic-Net coefficients and does not instantiate or fit any predictive model.",
        },
        {
            "QC_check": "Model feature ranking completeness",
            "Status": "PASS",
            "Details": f"Ranked list contains all {len(ranked)} locked model-universe genes, including {zero_count} zero-contribution genes not assigned a nonzero final Elastic-Net coefficient.",
        },
        {
            "QC_check": "Gene identifiers mapped",
            "Status": "PASS" if universe_overlap == len(ranked) and crosswalk_overlap == len(ranked) else "FAIL",
            "Details": f"{universe_overlap}/{len(ranked)} ranked genes found in locked feature universe; {crosswalk_overlap}/{len(ranked)} found in crosswalk; {annotation_overlap}/{len(ranked)} found in annotation.",
        },
        {
            "QC_check": "Entrez identifier availability",
            "Status": "LIMITATION" if not has_entrez else "PASS",
            "Details": "Local CF6 annotation lacks an Entrez column, so CF30 used direct HGNC gene-symbol matching to Enrichr/MSigDB gene sets.",
        },
        {
            "QC_check": "CF22 comparison completed",
            "Status": "PASS" if len(comparison) == 4 else "FAIL",
            "Details": f"Comparison table contains {len(comparison)} rows covering CF30 Hallmark, CF30 Reactome, CF22 Hallmark, and CF22 Reactome.",
        },
    ]
    qc = pd.DataFrame(rows)
    qc.to_csv(RESULTS_DIR / "CF30_quality_control_checks.tsv", sep="\t", index=False)
    return qc


def write_report(
    manifest: pd.DataFrame,
    metadata: pd.DataFrame,
    hallmark: pd.DataFrame,
    reactome: pd.DataFrame,
    summary: pd.DataFrame,
    comparison: pd.DataFrame,
    her2: pd.DataFrame,
    qc: pd.DataFrame,
) -> None:
    h_sig = int((hallmark["FDR"] < 0.05).sum())
    h_sug = int((hallmark["FDR"] < 0.25).sum())
    r_sig = int((reactome["FDR"] < 0.05).sum())
    r_sug = int((reactome["FDR"] < 0.25).sum())
    top_combined = summary.sort_values(["FDR", "Nominal_p_value"]).head(8)
    top_lines = "\n".join(
        f"- {row.Database}: {row.Pathway} (NES={row.NES:.3f}, FDR={row.FDR:.4g})"
        for row in top_combined.itertuples()
    )
    qc_lines = "\n".join(f"- {row.QC_check}: {row.Status}. {row.Details}" for row in qc.itertuples())

    report = f"""# CF30 Ranked GSEA Pathway Analysis

## Objective
CF30 improves pathway interpretation of the locked TCGA-BRCA HER2 transcriptomic classifier by using the complete ranked model feature contribution landscape rather than only the nonzero selected-gene list used by CF22.

## Inputs
The primary coefficient input was `{CF18_FEATURES}`. It contains 500 selected final model features and their locked standardized Elastic-Net coefficients. `{CF20_COEFFICIENTS}` was used as an independent coefficient consistency check. The ranked GSEA input was expanded to the locked 22,106-gene model feature universe in `{FEATURE_UNIVERSE}` by assigning zero model contribution to genes without a retained final coefficient.

## Method
Genes were ranked from the highest positive standardized Elastic-Net coefficient to the most negative coefficient. Positive coefficients indicate higher predicted HER2-positive probability and negative coefficients indicate lower predicted HER2-positive probability. Preranked GSEA was run using Enrichr gene sets retrieved by `gseapy`, a local streaming gene-set permutation backend, {PERMUTATIONS:,} permutations, min gene-set size {MIN_SIZE}, max gene-set size {MAX_SIZE}, Benjamini-Hochberg FDR correction, and seed {SEED}. Pathways were tested only when they passed the requested size filters and contained at least one nonzero model coefficient, because all-zero-overlap pathways cannot support coefficient-ranked model biology.

## Pathway Databases
- Hallmark: `{HALLMARK_LIBRARY}`
- Reactome: `{REACTOME_LIBRARY}`

Database retrieval and mapping details are saved in `metadata/CF30_pathway_database_metadata.tsv`.

## Results
- Hallmark tested pathways: {len(hallmark)}; FDR < 0.05: {h_sig}; FDR < 0.25: {h_sug}
- Reactome tested pathways: {len(reactome)}; FDR < 0.05: {r_sig}; FDR < 0.25: {r_sug}

Top CF30 pathway findings by FDR/nominal p-value:
{top_lines}

## CF30 vs CF22
CF30 uses a ranked coefficient-based GSEA design, while CF22 used over-representation analysis of the 86 nonzero model genes. The comparison table is saved as `results/CF30_vs_CF22_comparison.tsv`.

## HER2 Biology
CF30 evaluates receptor tyrosine kinase/ERBB2, PI3K/AKT, MAPK, proliferation, DNA repair, and immune-response evidence using only pathways that pass FDR < 0.25 in this ranked analysis. The structured biology table is saved as `results/CF30_HER2_biology_summary.tsv`.

## QC
{qc_lines}

## Output Files
- `input/CF30_input_manifest.tsv`
- `input/CF30_ranked_gene_list.rnk`
- `results/CF30_ranked_gene_list.tsv`
- `results/CF30_Hallmark_GSEA_results.tsv`
- `results/CF30_Reactome_GSEA_results.tsv`
- `results/CF30_pathway_summary.tsv`
- `results/CF30_vs_CF22_comparison.tsv`
- `results/CF30_HER2_biology_summary.tsv`
- `results/CF30_quality_control_checks.tsv`
- `figures/CF30_Hallmark_GSEA_dotplot.png`
- `figures/CF30_Reactome_GSEA_dotplot.png`
- `figures/CF30_pathway_network.png`
"""
    (CF30 / "CF30_report.md").write_text(report, encoding="utf-8")

    paragraph = (
        "Ranked gene set enrichment analysis of the locked HER2 Elastic-Net model coefficients "
        f"tested {len(hallmark)} Hallmark and {len(reactome)} Reactome pathways using preranked GSEA "
        f"with {PERMUTATIONS:,} gene-set permutations. Unlike the prior CF22 over-representation "
        "analysis, CF30 retained the full locked model feature universe, assigning zero contribution "
        "to genes outside the final coefficient table and preserving negative coefficients, allowing pathway directionality to be interpreted relative to "
        "higher or lower predicted HER2-positive probability. The leading CF30 signals were dominated "
        "by coefficient-ranked HER2 biology and subtype-associated programs, with pathway-level support "
        "summarized using FDR thresholds of <0.05 for significant and <0.25 for suggestive enrichment."
    )
    (RESULTS_DIR / "CF30_manuscript_paragraph.txt").write_text(paragraph + "\n", encoding="utf-8")


def main() -> int:
    ensure_dirs()
    log_path = LOGS_DIR / "CF30_run.log"
    with log_path.open("w", encoding="utf-8") as log:
        def log_line(message: str) -> None:
            print(message)
            log.write(message + "\n")
            log.flush()

        log_line("CF30 ranked GSEA started.")
        manifest = write_manifest()
        ranked = build_ranked_list()
        cf20_ok, cf20_detail = verify_cf20_consistency(ranked)
        log_line(cf20_detail)

        log_line(f"Retrieving {HALLMARK_LIBRARY}.")
        hallmark_sets = load_gene_sets(HALLMARK_LIBRARY)
        log_line(f"Retrieving {REACTOME_LIBRARY}.")
        reactome_sets = load_gene_sets(REACTOME_LIBRARY)
        metadata = write_database_metadata(hallmark_sets, reactome_sets)

        log_line("Running Hallmark preranked GSEA.")
        hallmark, _ = run_prerank(ranked, hallmark_sets, "Hallmark")
        log_line("Running Reactome preranked GSEA.")
        reactome, _ = run_prerank(ranked, reactome_sets, "Reactome")

        summary = write_pathway_summary(hallmark, reactome)
        comparison = cf22_comparison(hallmark, reactome, ranked)
        her2 = write_her2_biology_summary(summary)
        qc = write_qc(ranked, comparison, cf20_ok, cf20_detail)

        make_dotplot(hallmark, "CF30 Hallmark ranked GSEA", FIGURES_DIR / "CF30_Hallmark_GSEA_dotplot.png")
        make_dotplot(reactome, "CF30 Reactome ranked GSEA", FIGURES_DIR / "CF30_Reactome_GSEA_dotplot.png")
        make_network(summary)
        write_report(manifest, metadata, hallmark, reactome, summary, comparison, her2, qc)

        if (qc["Status"] == "FAIL").any():
            log_line("CF30 completed with QC failure.")
            return 1
        log_line("CF30 completed successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
