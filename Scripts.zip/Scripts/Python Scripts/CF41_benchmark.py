"""Benchmark saved TCGA predictions without fitting or tuning any model."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent/'_runtime'))
import hashlib, json, platform
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import sklearn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix, roc_curve, precision_recall_curve

OUT=Path(__file__).resolve().parents[1]; ROOT=OUT.parent
RES=OUT/'results'; FIG=OUT/'figures'; REPORT=OUT/'report'
CF18=ROOT/'results/CF18_stable_signature_xai_final_model'
CF39=ROOT/'CF39_minimal_HER2_signature/results'
CF40=ROOT/'CF40_Robustness_Stability_Validation_20Gene_Signature/results'
ERBB=ROOT/'CF32_5_ERBB2_benchmarking/results/CF32_5_TCGA_predictions.tsv'
MATRIX=ROOT/'data/processed/ml_ready/CF15_TCGA_HER2_rank_matrix.npz'
PAM50=RES/'source_data/BRCA_clinicalMatrix.tsv'
THRESHOLD=.5; B=5000; SEED=20260925

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''): h.update(block)
    return h.hexdigest()

def save(d,name): d.to_csv(RES/f'CF41_{name}.tsv',sep='\t',index=False)

def metrics(y,score=None,pred=None):
    if pred is None: pred=(np.asarray(score)>=THRESHOLD).astype(int)
    y=np.asarray(y,int); pred=np.asarray(pred,int)
    tn,fp,fn,tp=confusion_matrix(y,pred,labels=[0,1]).ravel()
    div=lambda a,b:float(a/b) if b else np.nan
    return {'AUROC':roc_auc_score(y,score) if score is not None else np.nan,
            'PR_AUC':average_precision_score(y,score) if score is not None else np.nan,
            'sensitivity':div(tp,tp+fn),'specificity':div(tn,tn+fp),'accuracy':div(tp+tn,len(y)),
            'PPV':div(tp,tp+fp),'NPV':div(tn,tn+fn),'TN':int(tn),'FP':int(fp),'FN':int(fn),'TP':int(tp)}

def main():
    protected=sorted(p for folder in [CF18,CF39,CF40] for p in folder.rglob('*') if p.is_file())+[ERBB,MATRIX]
    before={str(p.relative_to(ROOT)):sha(p) for p in protected}
    panel=pd.read_csv(CF39/'CF39_recommended_gene_panel.tsv',sep='\t').sort_values('CF39_rank')
    assert len(panel)==20 and panel.gene_symbol.is_unique
    cf40_panel=pd.read_csv(CF40/'CF40_fixed_20_gene_panel.tsv',sep='\t').sort_values('CF39_rank')
    assert panel.gene_symbol.tolist()==cf40_panel.gene_symbol.tolist()
    cf40_summary=pd.read_csv(CF40/'CF40_performance_stability.tsv',sep='\t')
    saved=pd.read_csv(CF39/'CF39_patient_OOF_predictions.tsv',sep='\t')
    twenty=saved[saved.model=='Top 20'][['patient_id','y_true','mean_OOF_probability']].rename(columns={'mean_OOF_probability':'score_20gene'})
    full=saved[saved.model=='CF18 full'][['patient_id','y_true','mean_OOF_probability']].rename(columns={'mean_OOF_probability':'score_CF18'})
    assert len(twenty)==len(full)==938 and twenty.patient_id.is_unique and full.patient_id.is_unique
    base=twenty.merge(full,on=['patient_id','y_true'],validate='one_to_one')
    erbb=pd.read_csv(ERBB,sep='\t')
    erbb=erbb[erbb.Model=='ERBB2_only'].copy()
    erbb['patient_id']=erbb.sample_id.str[:12]
    erbb=erbb.rename(columns={'probability':'score_ERBB2'})[['patient_id','y_true','score_ERBB2']]
    assert len(erbb)==938 and erbb.patient_id.is_unique
    base=base.merge(erbb,on=['patient_id','y_true'],validate='one_to_one')
    z=np.load(MATRIX,allow_pickle=True)
    cohort=pd.DataFrame({'patient_id':z['patient_ids'].astype(str),'sample_key':[s[:15] for s in z['sample_ids'].astype(str)],'matrix_y':z['y'].astype(int)})
    assert cohort.patient_id.is_unique and len(cohort)==938
    base=cohort.merge(base,on='patient_id',validate='one_to_one')
    assert np.array_equal(base.matrix_y,base.y_true)
    pam=pd.read_csv(PAM50,sep='\t',usecols=['sampleID','PAM50Call_RNAseq'],dtype=str)
    assert pam.sampleID.is_unique
    base=base.merge(pam,left_on='sample_key',right_on='sampleID',how='left',validate='one_to_one')
    base['PAM50_HER2_enriched']=np.where(base.PAM50Call_RNAseq.notna(),(base.PAM50Call_RNAseq=='Her2').astype(int),np.nan)
    base['pred_20gene']=(base.score_20gene>=THRESHOLD).astype(int)
    base['pred_ERBB2']=(base.score_ERBB2>=THRESHOLD).astype(int)
    base['pred_CF18']=(base.score_CF18>=THRESHOLD).astype(int)
    matched=base[base.PAM50Call_RNAseq.notna()].copy()
    assert len(matched)==716 and int(matched.y_true.sum())==143
    save(base,'all_TCGA_predictions_and_PAM50_availability')
    save(matched,'matched_PAM50_predictions')
    methods=[('20-gene signature',20,'score_20gene','pred_20gene','Continuous patient-averaged repeated OOF score'),
             ('ERBB2 expression only',1,'score_ERBB2','pred_ERBB2','Continuous patient-averaged repeated OOF score'),
             ('CF18 original model',86,'score_CF18','pred_CF18','Continuous patient-averaged repeated OOF score; internal development reference'),
             ('PAM50 HER2-enriched call',50,None,'PAM50_HER2_enriched','Categorical published subtype call; no probability available')]
    table=[]; cms=[]
    for name,k,score_col,pred_col,note in methods:
        m=metrics(matched.y_true,matched[score_col] if score_col else None,matched[pred_col])
        table.append({'Method':name,'Number_of_genes':k,'Evaluation_samples':len(matched),'HER2_positive':int(matched.y_true.sum()),
                      'Score_availability':'continuous' if score_col else 'categorical only','Common_threshold':THRESHOLD if score_col else np.nan,
                      **m,'Evaluation_note':note})
        cms.append({'Method':name,**{q:m[q] for q in ['TN','FP','FN','TP']}})
    table1=pd.DataFrame(table); save(table1,'Table1_performance_comparison'); save(pd.DataFrame(cms),'confusion_matrices')
    # Secondary complete-cohort comparison for continuous saved predictions only.
    full_rows=[]
    for name,k,score_col,pred_col,note in methods[:3]:
        m=metrics(base.y_true,base[score_col],base[pred_col])
        full_rows.append({'Method':name,'Number_of_genes':k,'Evaluation_samples':len(base),'Threshold':THRESHOLD,**m})
    save(pd.DataFrame(full_rows),'continuous_methods_full_cohort')
    # Paired stratified patient bootstrap, common draws and fixed scores/threshold.
    rng=np.random.default_rng(SEED); y=matched.y_true.to_numpy(int); pos=np.flatnonzero(y==1); neg=np.flatnonzero(y==0)
    metric_order=['AUROC','PR_AUC','sensitivity','specificity','accuracy','PPV','NPV']
    continuous={'20-gene signature':matched.score_20gene.to_numpy(),
                'ERBB2 expression only':matched.score_ERBB2.to_numpy(),
                'CF18 original model':matched.score_CF18.to_numpy()}
    point={n:metrics(y,s) for n,s in continuous.items()}
    deltas={(ref,m):np.empty(B) for ref in ['ERBB2 expression only','CF18 original model'] for m in metric_order}
    for b in range(B):
        ix=np.r_[rng.choice(pos,len(pos),replace=True),rng.choice(neg,len(neg),replace=True)]
        a=metrics(y[ix],continuous['20-gene signature'][ix])
        for ref in ['ERBB2 expression only','CF18 original model']:
            c=metrics(y[ix],continuous[ref][ix])
            for m in metric_order:deltas[(ref,m)][b]=a[m]-c[m]
    stat=[]
    for ref in ['ERBB2 expression only','CF18 original model']:
        for m in metric_order:
            d=deltas[(ref,m)]
            p=min(1.,2*min((d<=0).mean(),(d>=0).mean()))
            stat.append({'Comparison':f'20-gene minus {ref}','Metric':m,'Difference':point['20-gene signature'][m]-point[ref][m],
                         'CI_lower_95':np.quantile(d,.025),'CI_upper_95':np.quantile(d,.975),'two_sided_bootstrap_p':p,
                         'bootstrap_replicates':B,'interpretation':'paired stratified patient bootstrap; exploratory, no multiplicity adjustment'})
    stats=pd.DataFrame(stat); save(stats,'paired_statistical_comparisons')
    availability=pd.DataFrame([
      {'Method':'20-gene signature','Availability':'Evaluated','Gene_list':'Fixed CF39 20-gene panel','Scoring_method':'Archived patient-averaged repeated OOF probabilities','TCGA_compatibility':'Complete: 938/938; primary PAM50-matched table uses 716','Limitation':'Post-selection internal estimate; no independently locked serialized 20-gene estimator.'},
      {'Method':'ERBB2 expression only','Availability':'Evaluated','Gene_list':'ERBB2','Scoring_method':'Archived class-balanced Elastic-Net single-gene repeated OOF probabilities','TCGA_compatibility':'Complete: 938/938; same historical 15 outer folds','Limitation':'Single-gene transcript signal is not an IHC/ISH assay; common 0.5 threshold is not clinically validated.'},
      {'Method':'CF18 original model','Availability':'Evaluated as internal reference','Gene_list':'86 nonzero genes in locked 500-feature pipeline','Scoring_method':'Archived calibrated patient-averaged OOF probabilities','TCGA_compatibility':'Complete: 938/938','Limitation':'Internal project reference, not an established external approach; common 0.5 benchmark cutoff differs from locked 0.4345288895 operating point.'},
      {'Method':'PAM50 HER2-enriched call','Availability':'Evaluated classification only','Gene_list':'Published PAM50 intrinsic-subtype panel','Scoring_method':'Public TCGA PAM50Call_RNAseq categorical annotation','TCGA_compatibility':'716/938 matched; 222 missing','Limitation':'No subtype probabilities locally; HER2-enriched is a biological subtype and is not equivalent to clinical HER2 positivity.'},
      {'Method':'SCMGENE','Availability':'Not evaluated','Gene_list':'ESR1, ERBB2, AURKA documented','Scoring_method':'Published pretrained Gaussian subtype model in genefu','TCGA_compatibility':'Genes present, but the validated pretrained R implementation/platform mapping is not available in the locked Python runtime','Limitation':'Reimplementing or refitting the mixture model would add unvalidated assumptions and violate the no-new-model constraint.'},
      {'Method':'BluePrint','Availability':'Not evaluated','Gene_list':'80-gene commercial assay','Scoring_method':'Assay-specific subtype index/templates not sufficiently available for faithful local recreation','TCGA_compatibility':'No validated mapping from locked rank representation to commercial assay index','Limitation':'A substitute score would be invented and is therefore prohibited.'},
      {'Method':'MammaPrint / Oncotype DX / Prosigna ROR','Availability':'Out of scope','Gene_list':'Published/commercial prognostic panels','Scoring_method':'Recurrence-risk/prognostic endpoints','TCGA_compatibility':'Not assessed','Limitation':'They do not directly predict the clinical HER2 endpoint asked here; comparing them would answer a different question.'}])
    save(availability,'Table2_method_availability')
    pamtab=pd.crosstab(matched.PAM50Call_RNAseq,matched.y_true).rename(columns={0:'HER2_negative',1:'HER2_positive'}).reset_index()
    save(pamtab,'PAM50_by_clinical_HER2')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.dpi':400})
    colors={'20-gene signature':'#0072B2','ERBB2 expression only':'#D55E00','CF18 original model':'#555555','PAM50 HER2-enriched call':'#009E73'}
    def finish(fig,name):
        fig.tight_layout()
        for ext in ['png','pdf']:fig.savefig(FIG/f'CF41_{name}.{ext}',bbox_inches='tight')
        plt.close(fig)
    fig,ax=plt.subplots(figsize=(6.5,5.7))
    for name,_,score_col,_,_ in methods[:3]:
        fpr,tpr,_=roc_curve(y,matched[score_col]); au=table1.set_index('Method').loc[name,'AUROC']
        ax.plot(fpr,tpr,lw=2,color=colors[name],label=f'{name}: {au:.3f}')
    pamrow=table1.set_index('Method').loc['PAM50 HER2-enriched call']
    ax.scatter(1-pamrow.specificity,pamrow.sensitivity,s=75,marker='D',color=colors['PAM50 HER2-enriched call'],label='PAM50 categorical operating point',zorder=5)
    ax.plot([0,1],[0,1],':',color='.6');ax.set(xlabel='False-positive rate',ylabel='Sensitivity',xlim=(0,1),ylim=(0,1.02),title='CF41 | Matched TCGA ROC comparison (n=716)');ax.legend(loc='lower right',fontsize=8)
    finish(fig,'Figure1_ROC_comparison')
    fig,ax=plt.subplots(figsize=(6.5,5.7))
    for name,_,score_col,_,_ in methods[:3]:
        precision,recall,_=precision_recall_curve(y,matched[score_col]); ap=table1.set_index('Method').loc[name,'PR_AUC']
        ax.step(recall,precision,where='post',lw=2,color=colors[name],label=f'{name}: {ap:.3f}')
    ax.scatter(pamrow.sensitivity,pamrow.PPV,s=75,marker='D',color=colors['PAM50 HER2-enriched call'],label='PAM50 categorical operating point',zorder=5)
    ax.axhline(y.mean(),ls=':',color='.6',label=f'Prevalence {y.mean():.3f}');ax.set(xlabel='Recall (sensitivity)',ylabel='Precision (PPV)',xlim=(0,1),ylim=(0,1.02),title='CF41 | Matched TCGA precision–recall comparison');ax.legend(loc='lower left',fontsize=8)
    finish(fig,'Figure2_PR_comparison')
    fig,ax=plt.subplots(figsize=(10,5.2))
    plotmetrics=['AUROC','PR_AUC','sensitivity','specificity','accuracy']
    x=np.arange(len(plotmetrics)); width=.19
    for j,(name,*_) in enumerate(methods):
        vals=table1.set_index('Method').loc[name,plotmetrics].astype(float).to_numpy()
        bars=ax.bar(x+(j-1.5)*width,vals,width,color=colors[name],label=name)
        if name=='PAM50 HER2-enriched call':
            for i in [0,1]:bars[i].set_visible(False)
    ax.set(xticks=x,xticklabels=[m.replace('_','-') for m in plotmetrics],ylabel='Metric value',ylim=(0,1.05),title='CF41 | Performance summary on identical 716-patient set');ax.legend(fontsize=8,ncol=2);ax.grid(axis='y',alpha=.15)
    finish(fig,'Figure3_performance_summary')
    fig,ax=plt.subplots(figsize=(9,4.8))
    clinical=['sensitivity','specificity','PPV','NPV','accuracy']
    mat=table1.set_index('Method').loc[[m[0] for m in methods],clinical].astype(float).to_numpy()
    im=ax.imshow(mat,vmin=0,vmax=1,cmap='Blues',aspect='auto')
    ax.set(xticks=np.arange(len(clinical)),xticklabels=[c.upper() if c in ['PPV','NPV'] else c.title() for c in clinical],yticks=np.arange(4),yticklabels=[m[0] for m in methods],title='CF41 | Clinical operating characteristics\nCommon 0.5 cutoff for continuous scores; published call for PAM50')
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):ax.text(j,i,f'{mat[i,j]:.3f}',ha='center',va='center',color='white' if mat[i,j]>.55 else 'black')
    fig.colorbar(im,ax=ax,label='Metric value',fraction=.035,pad=.03);finish(fig,'Figure4_clinical_interpretation')
    assert all(sha(ROOT/p)==h for p,h in before.items())
    prov={'completed_utc':datetime.now(timezone.utc).isoformat(),'input_sha256':before,'protected_CF18_CF39_CF40_hashes_unchanged':True,
          'PAM50_source_url':'https://tcga.xenahubs.net/download/TCGA.BRCA.sampleMap/BRCA_clinicalMatrix',
          'PAM50_source_sha256':sha(PAM50),'PAM50_downloaded_utc_date':'2026-09-22','threshold_continuous_methods':THRESHOLD,
          'bootstrap_replicates':B,'bootstrap_seed':SEED,'matched_n':len(matched),'matched_positive':int(y.sum()),
          'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__,
          'model_fit_calls':0,'threshold_optimization':False,'external_validation_cohorts_used':False}
    (RES/'CF41_provenance.json').write_text(json.dumps(prov,indent=2),encoding='utf-8')
    t1='\n'.join(f'| {r.Method} | {r.Number_of_genes} | '+('NA' if pd.isna(r.AUROC) else f'{r.AUROC:.4f}')+' | '+('NA' if pd.isna(r.PR_AUC) else f'{r.PR_AUC:.4f}')+f' | {r.sensitivity:.4f} | {r.specificity:.4f} | {r.accuracy:.4f} | {r.PPV:.4f} | {r.NPV:.4f} |' for r in table1.itertuples())
    delta=stats[(stats.Comparison=='20-gene minus ERBB2 expression only')&stats.Metric.isin(['AUROC','PR_AUC'])]
    au=delta[delta.Metric=='AUROC'].iloc[0]; ap=delta[delta.Metric=='PR_AUC'].iloc[0]
    t2='\n'.join(f'| {r.Method} | {r.Availability} | {r.TCGA_compatibility} | {r.Limitation} |' for r in availability.itertuples())
    conclusion=(f'On the identical 716-patient PAM50-matched subset, the locked 20-gene OOF score had higher discrimination than the archived ERBB2-only score: AUROC difference {au.Difference:+.4f} (paired conditional 95% interval {au.CI_lower_95:+.4f} to {au.CI_upper_95:+.4f}) and PR-AUC difference {ap.Difference:+.4f} ({ap.CI_lower_95:+.4f} to {ap.CI_upper_95:+.4f}). This supports additional predictive discrimination beyond ERBB2 expression alone within TCGA. It does not establish independent superiority: the panel was selected using TCGA, and PAM50 supplies only a categorical, biologically different subtype call. The available evidence therefore supports comparative value and further external testing, not replacement of established clinical HER2 assays.')
    report=f'''# CF41: Benchmark Existing HER2 Approaches

## 1. Objective

Does the finalized 20-gene HER2 transcriptomic signature provide additional predictive value compared with existing HER2-related approaches?

{conclusion}

## 2. Compared approaches

The primary comparator is ERBB2 expression alone. The CF18 original model is shown as an internal project reference. PAM50 HER2-enriched subtype is evaluated because a public TCGA categorical call is available. PAM50 is not a clinical HER2 test: TCGA reported that clinically HER2-positive tumors and HER2-enriched mRNA tumors overlap incompletely. SCMGENE, BluePrint, and prognostic assays are documented in the availability table and are not replaced by invented approximations.

The finalized panel contains: **{', '.join(panel.gene_symbol)}**. CF40 supports conditional internal robustness (mean OOB AUROC {cf40_summary.set_index('metric').loc['AUROC','mean']:.4f}), but its varying OOB samples are not mixed into the primary matched benchmark.

## 3. Data used

Use only TCGA-BRCA patients in the locked CF15 cohort. Saved patient-averaged repeated OOF scores come from CF39 for the 20-gene signature and CF18 original model, and from CF32.5 for ERBB2 alone. The historical ERBB2 procedure used the same CF15 matrix, 5-fold x 3-repeat CV seed, and all 15 outer test partitions as CF18/CF39; fold identity was verified. No model is fitted in CF41.

Public `PAM50Call_RNAseq` annotations were downloaded from the [UCSC Xena TCGA-BRCA phenotype matrix](https://tcga.xenahubs.net/download/TCGA.BRCA.sampleMap/BRCA_clinicalMatrix). Of 938 locked patients, 716 have a PAM50 call: {int(y.sum())} HER2-positive and {int((y==0).sum())} HER2-negative by the project clinical endpoint. The primary Table 1 uses exactly those same 716 patients for every method. A secondary 938-patient table is supplied for the three continuous-score methods. No external-validation cohort is used.

## 4. Evaluation methodology

The 20-gene, ERBB2-only, and CF18 scores are evaluated identically as fixed saved OOF scores. Classification uses a common prespecified cutoff of **0.5** for all three; no method receives threshold optimization or recalibration. This common cutoff differs from CF18's original locked 0.4345288895 operating point, so CF18 classification numbers here are benchmarking values rather than the original CF18 operating result.

PAM50 has only a categorical call locally. `Her2` is positive and LumA, LumB, Basal, and Normal are negative. AUROC and PR-AUC are reported as unavailable rather than manufacturing a probability or treating a binary call as a full curve. Its single operating point is shown on the ROC and PR figures. The comparison evaluates association with clinical HER2 status, not PAM50's intended intrinsic-subtyping performance.

Metrics are AUROC, average precision (PR-AUC), sensitivity, specificity, accuracy, PPV, and NPV. Paired differences use 5,000 stratified patient bootstrap samples with common resamples, seed {SEED}. The intervals condition on saved predictions and selected patients, omit model-fitting and gene-selection uncertainty, and are exploratory without multiplicity adjustment. A two-sided empirical bootstrap p-value is included, but claims are based chiefly on effect sizes and paired intervals.

## 5. Results

### Table 1. Matched-cohort comparison

| Method | Genes | AUROC | PR-AUC | Sensitivity | Specificity | Accuracy | PPV | NPV |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
{t1}

The 20-gene minus ERBB2 AUROC difference is **{au.Difference:+.4f}** (95% conditional interval {au.CI_lower_95:+.4f} to {au.CI_upper_95:+.4f}; exploratory bootstrap p={au.two_sided_bootstrap_p:.4g}). The PR-AUC difference is **{ap.Difference:+.4f}** ({ap.CI_lower_95:+.4f} to {ap.CI_upper_95:+.4f}; p={ap.two_sided_bootstrap_p:.4g}). At the common cutoff, tradeoffs across sensitivity and specificity are reported rather than collapsed into a claim of universal superiority. Full paired differences for seven metrics are saved.

PAM50 categorical performance should be interpreted through its distinct biological purpose. The original TCGA study explicitly reported that not all clinically HER2-positive tumors are HER2-enriched and not all HER2-enriched tumors are clinically HER2-positive ([TCGA 2012](https://www.nature.com/articles/nature11412)).

### Table 2. Availability and limitations

| Method | Availability | TCGA compatibility | Limitation |
|---|---|---|---|
{t2}

SCMGENE has a published three-gene list and pretrained Gaussian approach ([original study](https://pmc.ncbi.nlm.nih.gov/articles/PMC3283537/); [genefu manual](https://bioc.r-universe.dev/genefu/doc/manual.html)), but its validated pretrained R implementation and platform mapping are absent from the locked runtime. Recreating it in Python or refitting a mixture would constitute a new, unvalidated implementation. BluePrint is an assay-specific 80-gene subtype index; public descriptions confirm that expression is compared with three subtype profiles, while the templates and validated TCGA mapping needed for faithful scoring are unavailable ([analytical validation](https://pmc.ncbi.nlm.nih.gov/articles/PMC7097521/)).

## 6. Interpretation

{conclusion}

The strongest supported positioning is that a multigene transcriptomic context improves discrimination over ERBB2 transcript rank alone on the same internal patients. The benchmark does not show incremental clinical utility over IHC/ISH, treatment benefit prediction, or transportability. It also does not establish that 20 genes outperform PAM50 as a subtype classifier, because the endpoints and outputs differ.

## 7. Limitations

- CF18/CF39 selected and evaluated the 20 genes in TCGA. Paired bootstrap intervals do not account for that feature-selection optimism.
- The compared continuous predictors use historical OOF scores, but their training details differ: CF39 tuned its 20-gene model within outer folds, while the archived ERBB2 approach used a fixed Elastic-Net setting. The test partitions and metric calculations match; training policies are not identical.
- The 0.5 cutoff is common and untuned, but not clinically validated. Probability scales differ and are not necessarily calibrated risks.
- PAM50 is available for only 716 patients and only as a hard subtype call. Missingness can affect the matched subset, and a categorical point cannot support a full AUROC/PR-AUC comparison.
- PAM50 HER2-enriched, SCMGENE/BluePrint molecular subtype, and clinical HER2 positivity are related but non-identical constructs.
- No external cohort is used, and no comparison with clinical IHC/ISH assay accuracy or decision consequences is made.
- PPV and NPV depend on the matched cohort's prevalence.

## Reproducibility

CF41 performs zero model fits. It writes saved-score evaluations, matched predictions, confusion counts, paired bootstrap comparisons, method availability, four 400-dpi PNG/PDF figures, and provenance hashes. SHA-256 checks confirm that CF18, CF39, and CF40 are unchanged. Run from the project root with `.venv/Scripts/python.exe CF41_Benchmark_Existing_HER2_Approaches/scripts/CF41_benchmark.py`.
'''
    (REPORT/'CF41_report.md').write_text(report,encoding='utf-8')
    print(table1[['Method','AUROC','PR_AUC','sensitivity','specificity','accuracy','PPV','NPV']].to_string(index=False),flush=True)
    print(f'COMPLETE: AUROC delta vs ERBB2 {au.Difference:+.4f} [{au.CI_lower_95:+.4f}, {au.CI_upper_95:+.4f}]',flush=True)

if __name__=='__main__':main()
