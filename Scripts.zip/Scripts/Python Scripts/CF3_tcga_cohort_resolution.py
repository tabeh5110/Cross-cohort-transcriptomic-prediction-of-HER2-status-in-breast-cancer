#!/usr/bin/env python
"""
CF3 - TCGA-BRCA Cohort Resolution and Frozen Acquisition Manifest

Purpose
-------
Resolve the biological duplicate structure identified in CF1 using the
biospecimen/QC/annotation evidence collected in CF2, and freeze the exact
TCGA-BRCA RNA-seq acquisition cohort for Data Release 46.0.

Design principles
-----------------
1. No GDC API calls.
2. No RNA-seq downloads.
3. Exclude approved case-level protocol-ineligible cases.
4. For eligible patients with multiple Primary Tumor biological samples,
   select one sample using a prespecified QC hierarchy:
      a) non-FFPE over FFPE
      b) higher RNA Integrity Number (RIN)
      c) higher median tumor nuclei percentage
      d) higher median tumor cell percentage
      e) lower median necrosis percentage
      f) lower median normal-cell percentage
   If all criteria tie, stop for manual review rather than choose arbitrarily.
5. Keep multiple GDC files from the same selected biological sample as
   technical/aliquot replicates pending expression-level QC in a later CF.
6. Preserve one row per GDC file in the final acquisition manifest.

Inputs
------
results/CF1_duplicate_resolution_audit/CF1_full_manifest_with_barcode_components.tsv
results/CF2_biospecimen_annotation_audit/CF2_duplicate_qc_review.tsv
results/CF2_biospecimen_annotation_audit/CF2_annotations.tsv
results/CF2_biospecimen_annotation_audit/CF2_provenance.tsv

Outputs
-------
All outputs begin with CF3_ and are written to:
results/CF3_tcga_cohort_resolution/
"""

from __future__ import annotations

import hashlib
import json
import logging
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


SCRIPT_VERSION = "1.0.0"
PROJECT_ID = "TCGA-BRCA"
TARGET_GDC_RELEASE = "46.0"
REFERENCE_GENOME = "GRCh38/hg38"
WORKFLOW = "STAR - Counts"

PROJECT_ROOT = Path(__file__).resolve().parents[1]

CF1_MANIFEST = (
    PROJECT_ROOT
    / "results"
    / "CF1_duplicate_resolution_audit"
    / "CF1_full_manifest_with_barcode_components.tsv"
)

CF2_QC = (
    PROJECT_ROOT
    / "results"
    / "CF2_biospecimen_annotation_audit"
    / "CF2_duplicate_qc_review.tsv"
)

CF2_ANNOTATIONS = (
    PROJECT_ROOT
    / "results"
    / "CF2_biospecimen_annotation_audit"
    / "CF2_annotations.tsv"
)

CF2_PROVENANCE = (
    PROJECT_ROOT
    / "results"
    / "CF2_biospecimen_annotation_audit"
    / "CF2_provenance.tsv"
)

OUTPUT_DIR = PROJECT_ROOT / "results" / "CF3_tcga_cohort_resolution"
LOG_DIR = PROJECT_ROOT / "logs"
LOG_FILE = LOG_DIR / "CF3_tcga_cohort_resolution.log"


# -----------------------------------------------------------------------------
# Utility functions
# -----------------------------------------------------------------------------


def md5_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.md5()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def require_file(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required input file not found: {path}")


def require_columns(df: pd.DataFrame, required: Iterable[str], label: str) -> None:
    missing = [column for column in required if column not in df.columns]
    if missing:
        raise ValueError(
            f"{label} is missing required columns: {', '.join(missing)}"
        )


def to_bool(value: Any) -> bool | None:
    if pd.isna(value):
        return None
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"true", "t", "1", "yes", "y"}:
        return True
    if text in {"false", "f", "0", "no", "n"}:
        return False
    return None


def safe_float(value: Any, *, higher_is_better: bool) -> float:
    """Convert to a sortable float; missing values rank worst."""
    if pd.isna(value):
        return -np.inf if higher_is_better else np.inf
    try:
        return float(value)
    except (TypeError, ValueError):
        return -np.inf if higher_is_better else np.inf


def setup_logging() -> logging.Logger:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("CF3")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    formatter = logging.Formatter("%(message)s")

    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    logger.addHandler(console)

    file_handler = logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger


def read_tsv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t", dtype={"sample_code": "string"})


def write_tsv(df: pd.DataFrame, filename: str) -> None:
    path = OUTPUT_DIR / filename
    df.to_csv(path, sep="\t", index=False, na_rep="NA")


def unique_nonmissing(series: pd.Series) -> list[Any]:
    values = []
    for value in series:
        if pd.isna(value):
            continue
        if value not in values:
            values.append(value)
    return values


def first_consistent_value(group: pd.DataFrame, column: str) -> Any:
    vals = unique_nonmissing(group[column])
    if len(vals) > 1:
        raise ValueError(
            f"QC inconsistency within biological sample {group['sample_id'].iloc[0]} "
            f"for field {column}: {vals}"
        )
    return vals[0] if vals else np.nan


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------


def main() -> None:
    logger = setup_logging()

    logger.info("")
    logger.info("=" * 60)
    logger.info(" CF3 - TCGA-BRCA COHORT RESOLUTION")
    logger.info("=" * 60)
    logger.info("")

    # ------------------------------------------------------------------
    # 1. Validate and load frozen inputs
    # ------------------------------------------------------------------
    logger.info("[1/10] Validating frozen CF1/CF2 inputs...\n")

    for path in [CF1_MANIFEST, CF2_QC, CF2_ANNOTATIONS, CF2_PROVENANCE]:
        require_file(path)

    input_md5 = {
        "CF1_full_manifest": md5_file(CF1_MANIFEST),
        "CF2_duplicate_qc_review": md5_file(CF2_QC),
        "CF2_annotations": md5_file(CF2_ANNOTATIONS),
        "CF2_provenance": md5_file(CF2_PROVENANCE),
    }

    manifest = read_tsv(CF1_MANIFEST)
    qc = read_tsv(CF2_QC)
    annotations = read_tsv(CF2_ANNOTATIONS)
    provenance2 = read_tsv(CF2_PROVENANCE)

    require_columns(
        manifest,
        [
            "patient_id",
            "sample_id",
            "aliquot_barcode",
            "sample_type",
            "file_id",
            "file_name",
            "md5sum",
            "file_size",
            "workflow",
        ],
        "CF1 manifest",
    )

    require_columns(
        qc,
        [
            "patient_id",
            "sample_id",
            "aliquot_barcode",
            "sample_type_cf1",
            "file_id",
            "portion_is_ffpe",
            "rna_integrity_number",
            "median_percent_tumor_cells",
            "median_percent_tumor_nuclei",
            "median_percent_normal_cells",
            "median_percent_necrosis",
            "direct_annotation_total",
        ],
        "CF2 QC review",
    )

    require_columns(
        annotations,
        [
            "annotation_id",
            "case_submitter_id",
            "entity_type",
            "category",
            "classification",
            "status",
            "notes",
        ],
        "CF2 annotations",
    )

    if len(manifest) != 1224:
        raise ValueError(
            f"CF3 is frozen to the validated DR46 CF1 cohort of 1224 files; "
            f"found {len(manifest)}."
        )
    if len(qc) != 27:
        raise ValueError(
            f"CF3 expects the validated CF2 duplicate-review set of 27 records; "
            f"found {len(qc)}."
        )

    if manifest["file_id"].duplicated().any():
        duplicated = manifest.loc[manifest["file_id"].duplicated(), "file_id"].tolist()
        raise ValueError(f"Duplicate GDC file UUIDs in CF1 manifest: {duplicated}")

    logger.info(f"CF1 manifest files loaded: {len(manifest)}")
    logger.info(f"CF2 QC records loaded: {len(qc)}")
    logger.info(f"CF2 annotations loaded: {len(annotations)}\n")

    # Verify the GDC release recorded by CF2.
    prov_map = dict(zip(provenance2["field"].astype(str), provenance2["value"].astype(str)))
    release = prov_map.get("gdc_data_release_target", "")
    if release != TARGET_GDC_RELEASE:
        raise ValueError(
            f"CF2 provenance reports GDC release {release!r}; "
            f"CF3 expects {TARGET_GDC_RELEASE!r}."
        )

    # ------------------------------------------------------------------
    # 2. Identify case-level protocol exclusions
    # ------------------------------------------------------------------
    logger.info("[2/10] Identifying approved case-level protocol exclusions...\n")

    protocol_ann = annotations[
        annotations["entity_type"].astype(str).str.lower().eq("case")
        & annotations["category"].astype(str).str.strip().eq(
            "Item does not meet study protocol"
        )
        & annotations["status"].astype(str).str.lower().eq("approved")
    ].copy()

    protocol_excluded_patients = sorted(
        protocol_ann["case_submitter_id"].dropna().astype(str).unique().tolist()
    )

    if not protocol_excluded_patients:
        raise ValueError(
            "No approved case-level 'Item does not meet study protocol' annotation "
            "was found. Stop for manual review because this differs from CF2."
        )

    logger.info(
        "Protocol-ineligible patient(s): " + ", ".join(protocol_excluded_patients)
    )
    logger.info("")

    # ------------------------------------------------------------------
    # 3. Build sample-level QC table for duplicate biological tumors
    # ------------------------------------------------------------------
    logger.info("[3/10] Building sample-level QC evidence for repeated tumors...\n")

    qc_fields = [
        "patient_id",
        "sample_id",
        "sample_type_cf1",
        "portion_is_ffpe",
        "rna_integrity_number",
        "a260_a280_ratio",
        "median_percent_tumor_nuclei",
        "median_percent_tumor_cells",
        "median_percent_normal_cells",
        "median_percent_necrosis",
        "median_percent_stromal_cells",
        "max_percent_tumor_nuclei",
        "max_percent_tumor_cells",
        "direct_annotation_total",
        "direct_annotation_categories",
        "direct_annotation_details",
    ]

    sample_qc_rows: list[dict[str, Any]] = []

    for sample_id, group in qc.groupby("sample_id", sort=True):
        row: dict[str, Any] = {
            "patient_id": first_consistent_value(group, "patient_id"),
            "sample_id": sample_id,
            "sample_type": first_consistent_value(group, "sample_type_cf1"),
            "n_gdc_files_in_cf2_review": group["file_id"].nunique(),
        }
        for field in qc_fields[3:]:
            row[field] = first_consistent_value(group, field)
        sample_qc_rows.append(row)

    sample_qc = pd.DataFrame(sample_qc_rows)

    # Duplicate biological tumor patients, excluding protocol-ineligible cases.
    tumor_sample_counts = (
        manifest[
            (manifest["sample_type"] == "Primary Tumor")
            & (~manifest["patient_id"].isin(protocol_excluded_patients))
        ][["patient_id", "sample_id"]]
        .drop_duplicates()
        .groupby("patient_id")
        .size()
    )

    duplicate_tumor_patients = sorted(
        tumor_sample_counts[tumor_sample_counts > 1].index.astype(str).tolist()
    )

    logger.info(
        f"Eligible patients with >1 Primary Tumor biological sample: "
        f"{len(duplicate_tumor_patients)}\n"
    )

    # ------------------------------------------------------------------
    # 4. Apply prespecified biological-sample selection hierarchy
    # ------------------------------------------------------------------
    logger.info("[4/10] Resolving repeated biological tumor specimens...\n")

    selection_rows: list[dict[str, Any]] = []
    selected_tumor_sample_by_patient: dict[str, str] = {}

    for patient_id in duplicate_tumor_patients:
        patient_samples = sample_qc[
            (sample_qc["patient_id"] == patient_id)
            & (sample_qc["sample_type"] == "Primary Tumor")
        ].copy()

        expected_samples = sorted(
            manifest.loc[
                (manifest["patient_id"] == patient_id)
                & (manifest["sample_type"] == "Primary Tumor"),
                "sample_id",
            ]
            .drop_duplicates()
            .astype(str)
            .tolist()
        )

        found_samples = sorted(patient_samples["sample_id"].astype(str).tolist())
        if found_samples != expected_samples:
            raise ValueError(
                f"CF2 QC does not cover all repeated tumor samples for {patient_id}. "
                f"Expected {expected_samples}, found {found_samples}."
            )

        ranked: list[tuple[tuple[float, ...], pd.Series]] = []

        for _, sample in patient_samples.iterrows():
            ffpe = to_bool(sample["portion_is_ffpe"])
            if ffpe is None:
                raise ValueError(
                    f"FFPE status missing/unparseable for repeated tumor sample "
                    f"{sample['sample_id']}."
                )

            # Larger tuple is better.
            rank_key = (
                1.0 if not ffpe else 0.0,
                safe_float(sample["rna_integrity_number"], higher_is_better=True),
                safe_float(
                    sample["median_percent_tumor_nuclei"], higher_is_better=True
                ),
                safe_float(
                    sample["median_percent_tumor_cells"], higher_is_better=True
                ),
                -safe_float(
                    sample["median_percent_necrosis"], higher_is_better=False
                ),
                -safe_float(
                    sample["median_percent_normal_cells"], higher_is_better=False
                ),
            )
            ranked.append((rank_key, sample))

        ranked.sort(key=lambda item: item[0], reverse=True)

        if len(ranked) < 2:
            raise ValueError(
                f"Expected at least two biological tumor samples for {patient_id}."
            )

        if ranked[0][0] == ranked[1][0]:
            raise RuntimeError(
                f"QC hierarchy is tied for {patient_id}: "
                f"{ranked[0][1]['sample_id']} and {ranked[1][1]['sample_id']}. "
                "CF3 refuses to use an arbitrary barcode/file-order tie-break."
            )

        selected_sample_id = str(ranked[0][1]["sample_id"])
        selected_tumor_sample_by_patient[patient_id] = selected_sample_id

        for rank_position, (rank_key, sample) in enumerate(ranked, start=1):
            selected = str(sample["sample_id"]) == selected_sample_id
            selection_rows.append(
                {
                    "patient_id": patient_id,
                    "sample_id": sample["sample_id"],
                    "selected": selected,
                    "rank_position": rank_position,
                    "selection_rule": (
                        "non_FFPE > higher_RIN > higher_median_tumor_nuclei > "
                        "higher_median_tumor_cells > lower_median_necrosis > "
                        "lower_median_normal_cells"
                    ),
                    "portion_is_ffpe": sample["portion_is_ffpe"],
                    "rna_integrity_number": sample["rna_integrity_number"],
                    "a260_a280_ratio": sample["a260_a280_ratio"],
                    "median_percent_tumor_nuclei": sample[
                        "median_percent_tumor_nuclei"
                    ],
                    "median_percent_tumor_cells": sample[
                        "median_percent_tumor_cells"
                    ],
                    "median_percent_necrosis": sample[
                        "median_percent_necrosis"
                    ],
                    "median_percent_normal_cells": sample[
                        "median_percent_normal_cells"
                    ],
                    "median_percent_stromal_cells": sample[
                        "median_percent_stromal_cells"
                    ],
                    "n_gdc_files_in_cf2_review": sample[
                        "n_gdc_files_in_cf2_review"
                    ],
                    "decision": (
                        "INCLUDE_SELECTED_BIOLOGICAL_TUMOR"
                        if selected
                        else "EXCLUDE_LOWER_QUALITY_BIOLOGICAL_DUPLICATE"
                    ),
                }
            )

        logger.info(f"{patient_id}: selected {selected_sample_id}")

    biological_selection = pd.DataFrame(selection_rows)
    logger.info("")

    # ------------------------------------------------------------------
    # 5. Apply decisions to all 1,224 GDC files
    # ------------------------------------------------------------------
    logger.info("[5/10] Applying cohort decisions to the complete CF1 manifest...\n")

    decisions = manifest.copy()
    decisions["CF3_include_file"] = True
    decisions["CF3_decision"] = "INCLUDE_UNIQUE_BIOLOGICAL_SAMPLE"
    decisions["CF3_reason"] = (
        "Eligible case; no competing biological sample after CF3 rules"
    )

    # Case-level protocol exclusion applies to all files from the case,
    # including matched normal tissue, to preserve a coherent invasive-BRCA cohort.
    protocol_mask = decisions["patient_id"].isin(protocol_excluded_patients)
    decisions.loc[protocol_mask, "CF3_include_file"] = False
    decisions.loc[protocol_mask, "CF3_decision"] = "EXCLUDE_CASE_PROTOCOL_INELIGIBLE"
    decisions.loc[protocol_mask, "CF3_reason"] = (
        "Approved GDC case-level annotation: Item does not meet study protocol"
    )

    # Exclude lower-ranked biological tumor sample(s) for eligible duplicate patients.
    excluded_duplicate_sample_ids = biological_selection.loc[
        ~biological_selection["selected"], "sample_id"
    ].astype(str).tolist()

    duplicate_exclusion_mask = decisions["sample_id"].isin(excluded_duplicate_sample_ids)
    decisions.loc[duplicate_exclusion_mask, "CF3_include_file"] = False
    decisions.loc[
        duplicate_exclusion_mask, "CF3_decision"
    ] = "EXCLUDE_LOWER_QUALITY_BIOLOGICAL_DUPLICATE"
    decisions.loc[duplicate_exclusion_mask, "CF3_reason"] = (
        "Competing Primary Tumor specimen ranked lower by prespecified CF3 QC hierarchy"
    )

    # Mark selected duplicate-biological tumor samples explicitly.
    selected_duplicate_sample_ids = biological_selection.loc[
        biological_selection["selected"], "sample_id"
    ].astype(str).tolist()
    selected_dup_mask = decisions["sample_id"].isin(selected_duplicate_sample_ids)
    decisions.loc[
        selected_dup_mask & decisions["CF3_include_file"], "CF3_decision"
    ] = "INCLUDE_SELECTED_BIOLOGICAL_TUMOR"
    decisions.loc[
        selected_dup_mask & decisions["CF3_include_file"], "CF3_reason"
    ] = (
        "Selected among repeated Primary Tumor specimens by prespecified CF3 QC hierarchy"
    )

    # ------------------------------------------------------------------
    # 6. Identify retained technical/aliquot replicate files
    # ------------------------------------------------------------------
    logger.info("[6/10] Identifying retained same-sample technical/aliquot replicates...\n")

    included = decisions[decisions["CF3_include_file"]].copy()
    included_file_counts = included.groupby("sample_id")["file_id"].nunique()
    technical_sample_ids = sorted(
        included_file_counts[included_file_counts > 1].index.astype(str).tolist()
    )

    decisions["CF3_technical_replicate_status"] = "SINGLE_GDC_FILE"
    technical_mask = decisions["sample_id"].isin(technical_sample_ids) & decisions[
        "CF3_include_file"
    ]
    decisions.loc[
        technical_mask, "CF3_technical_replicate_status"
    ] = "RETAIN_ALL_PENDING_EXPRESSION_QC"
    decisions.loc[
        technical_mask, "CF3_decision"
    ] = "INCLUDE_TECHNICAL_REPLICATE_PENDING_EXPRESSION_QC"
    decisions.loc[technical_mask, "CF3_reason"] = (
        "Multiple GDC RNA-seq files map to the same selected biological sample; "
        "retain all until expression-level concordance/QC"
    )

    # ------------------------------------------------------------------
    # 7. Construct final candidate acquisition manifest and cohort tables
    # ------------------------------------------------------------------
    logger.info("[7/10] Constructing frozen acquisition manifest and cohort tables...\n")

    final_manifest = decisions[decisions["CF3_include_file"]].copy()
    final_manifest = final_manifest.sort_values(
        ["patient_id", "sample_type", "sample_id", "aliquot_barcode", "file_id"]
    ).reset_index(drop=True)

    # Add a deterministic technical-replicate group identifier.
    final_manifest["CF3_replicate_group"] = np.where(
        final_manifest["sample_id"].isin(technical_sample_ids),
        final_manifest["sample_id"],
        "",
    )

    sample_table = (
        final_manifest.sort_values(["patient_id", "sample_type", "sample_id"])
        .groupby(["patient_id", "sample_id", "sample_type"], as_index=False)
        .agg(
            n_gdc_files=("file_id", "nunique"),
            aliquot_barcodes=(
                "aliquot_barcode",
                lambda s: ";".join(sorted(set(map(str, s)))),
            ),
            file_ids=("file_id", lambda s: ";".join(sorted(set(map(str, s))))),
            technical_replicate_status=(
                "CF3_technical_replicate_status",
                "first",
            ),
            cohort_decision=("CF3_decision", "first"),
        )
    )

    tumor_samples = sample_table[sample_table["sample_type"] == "Primary Tumor"]
    normal_samples = sample_table[
        sample_table["sample_type"] == "Solid Tissue Normal"
    ]

    # A resolved discovery cohort must have exactly one biological tumor sample per patient.
    tumor_per_patient = tumor_samples.groupby("patient_id")["sample_id"].nunique()
    if not (tumor_per_patient == 1).all():
        bad = tumor_per_patient[tumor_per_patient != 1]
        raise ValueError(
            "CF3 failed to resolve exactly one biological tumor sample per eligible patient:\n"
            + bad.to_string()
        )

    normal_per_patient = normal_samples.groupby("patient_id")["sample_id"].nunique()
    if (normal_per_patient > 1).any():
        bad = normal_per_patient[normal_per_patient > 1]
        raise ValueError(
            "More than one selected normal biological sample exists for a patient:\n"
            + bad.to_string()
        )

    paired_patients = sorted(
        set(tumor_samples["patient_id"]) & set(normal_samples["patient_id"])
    )

    tumor_map = tumor_samples.set_index("patient_id")
    normal_map = normal_samples.set_index("patient_id")

    paired_rows: list[dict[str, Any]] = []
    for patient_id in paired_patients:
        t = tumor_map.loc[patient_id]
        n = normal_map.loc[patient_id]
        paired_rows.append(
            {
                "patient_id": patient_id,
                "tumor_sample_id": t["sample_id"],
                "tumor_gdc_file_count": int(t["n_gdc_files"]),
                "tumor_file_ids": t["file_ids"],
                "normal_sample_id": n["sample_id"],
                "normal_gdc_file_count": int(n["n_gdc_files"]),
                "normal_file_ids": n["file_ids"],
            }
        )
    paired_table = pd.DataFrame(paired_rows)

    retained_technical = final_manifest[
        final_manifest["sample_id"].isin(technical_sample_ids)
    ].copy()

    # Case-level exclusion summary.
    excluded_case_rows: list[dict[str, Any]] = []
    for patient_id in protocol_excluded_patients:
        patient_manifest = manifest[manifest["patient_id"] == patient_id]
        patient_annotations = protocol_ann[
            protocol_ann["case_submitter_id"] == patient_id
        ]
        for _, ann in patient_annotations.iterrows():
            excluded_case_rows.append(
                {
                    "patient_id": patient_id,
                    "annotation_id": ann["annotation_id"],
                    "category": ann["category"],
                    "classification": ann["classification"],
                    "status": ann["status"],
                    "notes": ann["notes"],
                    "files_excluded": patient_manifest["file_id"].nunique(),
                    "tumor_files_excluded": patient_manifest.loc[
                        patient_manifest["sample_type"] == "Primary Tumor", "file_id"
                    ].nunique(),
                    "normal_files_excluded": patient_manifest.loc[
                        patient_manifest["sample_type"] == "Solid Tissue Normal", "file_id"
                    ].nunique(),
                    "CF3_decision": "EXCLUDE_CASE_PROTOCOL_INELIGIBLE",
                }
            )
    excluded_cases = pd.DataFrame(excluded_case_rows)

    excluded_duplicate_samples = biological_selection[
        ~biological_selection["selected"]
    ].copy()
    selected_lookup = biological_selection[biological_selection["selected"]].set_index(
        "patient_id"
    )
    excluded_duplicate_samples["selected_sample_id"] = excluded_duplicate_samples[
        "patient_id"
    ].map(selected_lookup["sample_id"])
    excluded_duplicate_samples["CF3_exclusion_reason"] = (
        "Lower-ranked biological Primary Tumor specimen by prespecified QC hierarchy"
    )

    # ------------------------------------------------------------------
    # 8. Validate resolved cohort invariants
    # ------------------------------------------------------------------
    logger.info("[8/10] Running CF3 cohort integrity checks...\n")

    if final_manifest["file_id"].duplicated().any():
        raise ValueError("Final candidate manifest contains duplicate GDC file UUIDs.")

    if set(protocol_excluded_patients) & set(final_manifest["patient_id"]):
        raise ValueError("Protocol-ineligible patient remains in final candidate manifest.")

    if set(excluded_duplicate_sample_ids) & set(final_manifest["sample_id"]):
        raise ValueError("Excluded biological duplicate remains in final candidate manifest.")

    if len(final_manifest) + int((~decisions["CF3_include_file"]).sum()) != len(manifest):
        raise ValueError("Included + excluded file counts do not reconcile to CF1 manifest.")

    if not set(retained_technical["sample_id"].unique()) == set(technical_sample_ids):
        raise ValueError("Technical replicate sample accounting failed.")

    # Ensure all files for each retained technical sample are still present.
    for sample_id in technical_sample_ids:
        pre = manifest.loc[manifest["sample_id"] == sample_id, "file_id"].nunique()
        post = final_manifest.loc[
            final_manifest["sample_id"] == sample_id, "file_id"
        ].nunique()
        if pre != post:
            raise ValueError(
                f"Technical replicate files were lost for {sample_id}: {pre} -> {post}"
            )

    logger.info("All CF3 cohort integrity checks passed.\n")

    # ------------------------------------------------------------------
    # 9. Build summaries, rules, and provenance
    # ------------------------------------------------------------------
    logger.info("[9/10] Building CF3 summary, rules, and provenance...\n")

    excluded_file_count = int((~decisions["CF3_include_file"]).sum())
    protocol_excluded_file_count = int(protocol_mask.sum())
    duplicate_excluded_file_count = int(duplicate_exclusion_mask.sum())

    technical_extra_files = int(
        sum(
            final_manifest.loc[final_manifest["sample_id"] == sid, "file_id"].nunique()
            - 1
            for sid in technical_sample_ids
        )
    )

    summary = pd.DataFrame(
        {
            "metric": [
                "Input GDC RNA-seq files",
                "Input unique patients",
                "Approved protocol-ineligible patients excluded",
                "Files excluded by case-level protocol rule",
                "Eligible patients with repeated biological tumor samples",
                "Lower-quality biological tumor samples excluded",
                "Files excluded as lower-quality biological duplicates",
                "Final candidate acquisition files",
                "Final eligible patients",
                "Final selected biological samples",
                "Final Primary Tumor biological samples",
                "Final Solid Tissue Normal biological samples",
                "Paired tumor-normal patients",
                "Selected biological samples with multiple GDC files",
                "Extra technical/aliquot replicate files retained",
                "Total files excluded by CF3",
            ],
            "value": [
                len(manifest),
                manifest["patient_id"].nunique(),
                len(protocol_excluded_patients),
                protocol_excluded_file_count,
                len(duplicate_tumor_patients),
                len(excluded_duplicate_sample_ids),
                duplicate_excluded_file_count,
                len(final_manifest),
                final_manifest["patient_id"].nunique(),
                sample_table["sample_id"].nunique(),
                tumor_samples["sample_id"].nunique(),
                normal_samples["sample_id"].nunique(),
                len(paired_table),
                len(technical_sample_ids),
                technical_extra_files,
                excluded_file_count,
            ],
        }
    )

    rules = pd.DataFrame(
        [
            {
                "priority": 1,
                "rule": "case_protocol_eligibility",
                "action": "Exclude the entire case when an approved case-level GDC annotation category equals 'Item does not meet study protocol'.",
                "rationale": "Maintain an invasive TCGA-BRCA discovery cohort and avoid retaining matched normal tissue from an ineligible case.",
            },
            {
                "priority": 2,
                "rule": "biological_tumor_duplicate_resolution",
                "action": "Among multiple Primary Tumor biological samples from an eligible patient, prefer non-FFPE; then higher RIN; then higher median tumor nuclei%; then higher median tumor cells%; then lower median necrosis%; then lower median normal cells%.",
                "rationale": "Use objective biospecimen/RNA/pathology QC rather than vial letter or file order.",
            },
            {
                "priority": 3,
                "rule": "no_arbitrary_tie_break",
                "action": "If competing biological tumor samples tie on the complete QC hierarchy, stop and require manual review.",
                "rationale": "Prevent silent arbitrary selection.",
            },
            {
                "priority": 4,
                "rule": "technical_replicate_retention",
                "action": "Retain all GDC RNA-seq files mapping to the same selected biological sample until expression-level QC/concordance is performed.",
                "rationale": "Do not discard potentially informative technical/aliquot replicates before inspecting expression data.",
            },
        ]
    )

    provenance = pd.DataFrame(
        {
            "field": [
                "code_file",
                "script_version",
                "project",
                "reference_genome",
                "workflow",
                "gdc_data_release",
                "CF1_manifest_path",
                "CF1_manifest_md5",
                "CF2_qc_path",
                "CF2_qc_md5",
                "CF2_annotations_path",
                "CF2_annotations_md5",
                "CF2_provenance_path",
                "CF2_provenance_md5",
                "run_datetime_utc",
                "python_version",
                "platform",
                "pandas_version",
            ],
            "value": [
                Path(__file__).name,
                SCRIPT_VERSION,
                PROJECT_ID,
                REFERENCE_GENOME,
                WORKFLOW,
                TARGET_GDC_RELEASE,
                str(CF1_MANIFEST.relative_to(PROJECT_ROOT)),
                input_md5["CF1_full_manifest"],
                str(CF2_QC.relative_to(PROJECT_ROOT)),
                input_md5["CF2_duplicate_qc_review"],
                str(CF2_ANNOTATIONS.relative_to(PROJECT_ROOT)),
                input_md5["CF2_annotations"],
                str(CF2_PROVENANCE.relative_to(PROJECT_ROOT)),
                input_md5["CF2_provenance"],
                datetime.now(timezone.utc).isoformat(),
                sys.version.replace("\n", " "),
                platform.platform(),
                pd.__version__,
            ],
        }
    )

    # ------------------------------------------------------------------
    # 10. Save all CF3 outputs
    # ------------------------------------------------------------------
    logger.info("[10/10] Saving CF3 outputs...\n")

    write_tsv(final_manifest, "CF3_final_candidate_manifest.tsv")
    write_tsv(sample_table, "CF3_selected_biological_samples.tsv")
    write_tsv(excluded_cases, "CF3_excluded_cases.tsv")
    write_tsv(
        excluded_duplicate_samples,
        "CF3_excluded_duplicate_samples.tsv",
    )
    write_tsv(retained_technical, "CF3_retained_technical_duplicates.tsv")
    write_tsv(paired_table, "CF3_paired_tumor_normal_cohort.tsv")
    write_tsv(decisions, "CF3_selection_decisions.tsv")
    write_tsv(biological_selection, "CF3_duplicate_sample_ranking.tsv")
    write_tsv(rules, "CF3_selection_rules.tsv")
    write_tsv(summary, "CF3_cohort_summary.tsv")
    write_tsv(provenance, "CF3_provenance.tsv")

    logger.info("=" * 60)
    logger.info(" CF3 COMPLETE")
    logger.info("=" * 60)
    logger.info("")
    logger.info(summary.to_string(index=False))
    logger.info("")
    logger.info(f"Results saved to: {OUTPUT_DIR.relative_to(PROJECT_ROOT)}")
    logger.info("")
    logger.info("CF3 generated:")
    for name in [
        "CF3_final_candidate_manifest.tsv",
        "CF3_selected_biological_samples.tsv",
        "CF3_excluded_cases.tsv",
        "CF3_excluded_duplicate_samples.tsv",
        "CF3_retained_technical_duplicates.tsv",
        "CF3_paired_tumor_normal_cohort.tsv",
        "CF3_selection_decisions.tsv",
        "CF3_duplicate_sample_ranking.tsv",
        "CF3_selection_rules.tsv",
        "CF3_cohort_summary.tsv",
        "CF3_provenance.tsv",
        "CF3_tcga_cohort_resolution.log",
    ]:
        logger.info(f"  {name}")

    logger.info("")
    logger.info("IMPORTANT:")
    logger.info("No GDC API call was made by CF3.")
    logger.info("No RNA-seq expression data were downloaded.")
    logger.info("CF3 freezes the acquisition cohort and preserves same-sample")
    logger.info("technical/aliquot replicate files for later expression-level QC.")
    logger.info("=" * 60)


if __name__ == "__main__":
    main()