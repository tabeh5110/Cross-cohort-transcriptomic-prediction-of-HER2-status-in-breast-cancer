"""
CF26 - Bootstrap Confidence Interval Analysis for SCAN-B External Validation

Purpose:
    Quantify uncertainty around locked CF18 Elastic-Net performance on the
    SCAN-B / GSE96058 external validation cohort using CF19 predictions.

Rules:
    NO retraining
    NO threshold optimization
    NO model reapplication
    CF19 probabilities and locked threshold are treated as immutable inputs.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, confusion_matrix, roc_auc_score


BASE = Path(__file__).resolve().parents[2]
CF26 = BASE / "CF26_bootstrap_confidence_intervals"

INPUT_DIR = CF26 / "input"
RESULTS_DIR = CF26 / "results"
FIGURES_DIR = CF26 / "figures"
LOGS_DIR = CF26 / "logs"
METADATA_DIR = CF26 / "metadata"

CF19_DIR = BASE / "results" / "CF19_scanb_external_validation"
PREDICTIONS_FILE = CF19_DIR / "CF19_predictions.tsv"
CF19_METRICS_FILE = CF19_DIR / "CF19_metrics.tsv"
CF19_SUMMARY_FILE = CF19_DIR / "CF19_summary.tsv"
SCANB_METADATA_FILE = BASE / "data" / "processed" / "scanb" / "CF11_SCANB_primary_sample_metadata.tsv"
CF14_SCANB_MANIFEST_FILE = (
    BASE / "data" / "processed" / "ml_ready" / "CF14_SCANB_external_sample_manifest_LOCKED.tsv"
)

THRESHOLD = 0.4345288894526921
N_BOOTSTRAPS = 10000
RANDOM_SEED = 42
HER2_COLUMN = "characteristic_her2_status"

METRIC_ORDER = ["AUROC", "PR_AUC", "Sensitivity", "Specificity", "PPV", "NPV"]


def ensure_directories() -> None:
    for directory in [INPUT_DIR, RESULTS_DIR, FIGURES_DIR, LOGS_DIR, METADATA_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


def read_table(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t", dtype=str)


def numeric_her2_label(values: pd.Series) -> pd.Series:
    positive_values = {"positive", "pos", "her2 positive", "her2_positive", "1", "yes"}
    return values.astype(str).str.strip().str.lower().isin(positive_values).astype(int)


def calculate_metrics(y_true: np.ndarray, probabilities: np.ndarray, threshold: float) -> dict[str, float]:
    if len(np.unique(y_true)) < 2:
        auroc = np.nan
        pr_auc = np.nan
    else:
        auroc = roc_auc_score(y_true, probabilities)
        pr_auc = average_precision_score(y_true, probabilities)

    predicted = (probabilities >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, predicted, labels=[0, 1]).ravel()

    sensitivity = tp / (tp + fn) if (tp + fn) else np.nan
    specificity = tn / (tn + fp) if (tn + fp) else np.nan
    ppv = tp / (tp + fp) if (tp + fp) else np.nan
    npv = tn / (tn + fn) if (tn + fn) else np.nan

    return {
        "AUROC": auroc,
        "PR_AUC": pr_auc,
        "Sensitivity": sensitivity,
        "Specificity": specificity,
        "PPV": ppv,
        "NPV": npv,
    }


def load_analysis_dataset() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    predictions = pd.read_csv(PREDICTIONS_FILE, sep="\t")
    metadata = read_table(SCANB_METADATA_FILE)
    cf19_metrics = pd.read_csv(CF19_METRICS_FILE, sep="\t")
    cf19_summary = pd.read_csv(CF19_SUMMARY_FILE, sep="\t")

    required_prediction_columns = {"sample_id", "HER2_probability", "prediction", "locked_threshold"}
    missing_prediction_columns = required_prediction_columns.difference(predictions.columns)
    if missing_prediction_columns:
        raise ValueError(f"Missing CF19 prediction columns: {sorted(missing_prediction_columns)}")

    required_metadata_columns = {"sample_title", HER2_COLUMN}
    missing_metadata_columns = required_metadata_columns.difference(metadata.columns)
    if missing_metadata_columns:
        raise ValueError(f"Missing SCAN-B metadata columns: {sorted(missing_metadata_columns)}")

    metadata_subset = metadata[["sample_title", "geo_accession", HER2_COLUMN]].copy()
    metadata_subset["HER2_label"] = numeric_her2_label(metadata_subset[HER2_COLUMN])

    analysis = predictions.merge(
        metadata_subset,
        left_on="sample_id",
        right_on="sample_title",
        how="left",
        validate="one_to_one",
    )

    if analysis["sample_title"].isna().any():
        missing = analysis.loc[analysis["sample_title"].isna(), "sample_id"].head(10).tolist()
        raise ValueError(f"Predicted samples missing SCAN-B metadata rows, first examples: {missing}")

    analysis["HER2_probability"] = analysis["HER2_probability"].astype(float)
    analysis["prediction"] = analysis["prediction"].astype(int)
    analysis["locked_threshold"] = analysis["locked_threshold"].astype(float)
    analysis["HER2_label"] = analysis["HER2_label"].astype(int)

    return analysis, metadata, cf19_metrics, cf19_summary


def write_input_manifest(
    analysis: pd.DataFrame,
    metadata: pd.DataFrame,
    cf19_metrics: pd.DataFrame,
    cf19_summary: pd.DataFrame,
) -> pd.DataFrame:
    cf14_samples = pd.read_csv(CF14_SCANB_MANIFEST_FILE, sep="\t") if CF14_SCANB_MANIFEST_FILE.exists() else None
    manifest_rows = [
        {
            "filename": PREDICTIONS_FILE.name,
            "path": str(PREDICTIONS_FILE),
            "number_of_samples": analysis["sample_id"].nunique(),
            "required_columns": "sample_id; HER2_probability; prediction; locked_threshold",
            "description": "Locked CF19 SCAN-B predictions from the CF18 Elastic-Net model.",
        },
        {
            "filename": SCANB_METADATA_FILE.name,
            "path": str(SCANB_METADATA_FILE),
            "number_of_samples": len(metadata),
            "required_columns": f"sample_title; geo_accession; {HER2_COLUMN}",
            "description": "SCAN-B primary sample metadata containing the pathology HER2 endpoint used in CF19.",
        },
        {
            "filename": CF19_METRICS_FILE.name,
            "path": str(CF19_METRICS_FILE),
            "number_of_samples": len(cf19_metrics),
            "required_columns": "metric; value",
            "description": "Previously reported CF19 external validation point estimates and locked threshold.",
        },
        {
            "filename": CF19_SUMMARY_FILE.name,
            "path": str(CF19_SUMMARY_FILE),
            "number_of_samples": len(cf19_summary),
            "required_columns": "item; value",
            "description": "CF19 external validation cohort summary.",
        },
    ]

    if cf14_samples is not None:
        manifest_rows.append(
            {
                "filename": CF14_SCANB_MANIFEST_FILE.name,
                "path": str(CF14_SCANB_MANIFEST_FILE),
                "number_of_samples": len(cf14_samples),
                "required_columns": "expression_sample_id; HER2",
                "description": "Locked SCAN-B external validation manifest retained as an endpoint cross-check.",
            }
        )

    manifest = pd.DataFrame(manifest_rows)
    manifest.to_csv(INPUT_DIR / "CF26_input_manifest.tsv", sep="\t", index=False)
    manifest.to_csv(METADATA_DIR / "CF26_input_manifest.tsv", sep="\t", index=False)
    return manifest


def run_bootstrap(analysis: pd.DataFrame) -> pd.DataFrame:
    rng = np.random.default_rng(RANDOM_SEED)
    y = analysis["HER2_label"].to_numpy(dtype=int)
    probabilities = analysis["HER2_probability"].to_numpy(dtype=float)
    n_samples = len(analysis)

    rows = []
    for iteration in range(1, N_BOOTSTRAPS + 1):
        indices = rng.integers(0, n_samples, size=n_samples)
        metrics = calculate_metrics(y[indices], probabilities[indices], THRESHOLD)
        rows.append(
            {
                "bootstrap_iteration": iteration,
                "sample_size": len(indices),
                "HER2_prevalence": float(np.mean(y[indices])),
                **metrics,
            }
        )

    bootstrap = pd.DataFrame(rows)
    bootstrap.to_csv(RESULTS_DIR / "CF26_bootstrap_iteration_metrics.tsv", sep="\t", index=False)
    return bootstrap


def write_metric_summaries(point_estimates: dict[str, float], bootstrap: pd.DataFrame) -> pd.DataFrame:
    rows = []
    manuscript_rows = []
    for metric in METRIC_ORDER:
        values = bootstrap[metric].dropna()
        lower, upper = np.percentile(values, [2.5, 97.5])
        mean = values.mean()
        rows.append(
            {
                "Metric": metric,
                "Point_estimate": point_estimates[metric],
                "Bootstrap_mean": mean,
                "CI_lower_95": lower,
                "CI_upper_95": upper,
            }
        )
        manuscript_rows.append(
            {
                "Metric": metric,
                "Estimate": format_metric(point_estimates[metric], metric),
                "95% CI": f"{format_metric(lower, metric)}-{format_metric(upper, metric)}",
            }
        )

    summary = pd.DataFrame(rows)
    summary.to_csv(RESULTS_DIR / "CF26_bootstrap_metrics_summary.tsv", sep="\t", index=False)
    pd.DataFrame(manuscript_rows).to_csv(
        RESULTS_DIR / "CF26_manuscript_table.tsv", sep="\t", index=False
    )
    return summary


def format_metric(value: float, metric: str) -> str:
    if metric in {"Sensitivity", "Specificity", "PPV", "NPV"}:
        return f"{value * 100:.1f}%"
    return f"{value:.4f}"


def write_validation_checks(
    analysis: pd.DataFrame,
    bootstrap: pd.DataFrame,
    point_estimates: dict[str, float],
    cf19_metrics: pd.DataFrame,
) -> pd.DataFrame:
    cf19_metric_map = dict(zip(cf19_metrics["metric"], cf19_metrics["value"].astype(float)))
    threshold_values = analysis["locked_threshold"].unique()
    prevalence = analysis["HER2_label"].mean()
    bootstrap_prevalence_mean = bootstrap["HER2_prevalence"].mean()
    bootstrap_prevalence_ci = np.percentile(bootstrap["HER2_prevalence"], [2.5, 97.5])

    checks = [
        {
            "check": "Bootstrap sample size equals original SCAN-B sample size",
            "observed": str(int(bootstrap["sample_size"].min())),
            "expected": str(len(analysis)),
            "status": "PASS" if (bootstrap["sample_size"] == len(analysis)).all() else "FAIL",
            "notes": f"All {N_BOOTSTRAPS} bootstrap replicates sampled with replacement at n={len(analysis)}.",
        },
        {
            "check": "HER2 prevalence approximately similar across bootstrap replicates",
            "observed": f"original={prevalence:.6f}; bootstrap_mean={bootstrap_prevalence_mean:.6f}",
            "expected": "Bootstrap mean within 0.01 absolute prevalence of original",
            "status": "PASS" if abs(bootstrap_prevalence_mean - prevalence) <= 0.01 else "FAIL",
            "notes": f"Bootstrap prevalence 95% percentile range={bootstrap_prevalence_ci[0]:.6f}-{bootstrap_prevalence_ci[1]:.6f}.",
        },
        {
            "check": "Locked threshold unchanged",
            "observed": json.dumps([float(x) for x in threshold_values]),
            "expected": str(THRESHOLD),
            "status": "PASS"
            if len(threshold_values) == 1 and np.isclose(float(threshold_values[0]), THRESHOLD)
            else "FAIL",
            "notes": "CF26 uses CF19 locked_threshold and the CF18 locked threshold constant only.",
        },
    ]

    for metric in ["AUROC", "PR_AUC", "Sensitivity", "Specificity"]:
        observed = point_estimates[metric]
        expected = cf19_metric_map[metric]
        checks.append(
            {
                "check": f"Point estimate reproduces CF19 {metric}",
                "observed": f"{observed:.12f}",
                "expected": f"{expected:.12f}",
                "status": "PASS" if np.isclose(observed, expected, atol=1e-12) else "FAIL",
                "notes": "Recalculated from CF19 probabilities and SCAN-B HER2 labels.",
            }
        )

    validation = pd.DataFrame(checks)
    validation.to_csv(RESULTS_DIR / "CF26_validation_checks.tsv", sep="\t", index=False)
    return validation


def plot_single_distribution(
    bootstrap: pd.DataFrame,
    summary: pd.DataFrame,
    metric: str,
    output_file: Path,
) -> None:
    row = summary.loc[summary["Metric"] == metric].iloc[0]
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.hist(bootstrap[metric].dropna(), bins=45, color="#4C78A8", alpha=0.82, edgecolor="white")
    ax.axvline(row["Point_estimate"], color="#111111", linewidth=2, label="Observed")
    ax.axvline(row["CI_lower_95"], color="#D62728", linestyle="--", linewidth=1.8, label="95% CI")
    ax.axvline(row["CI_upper_95"], color="#D62728", linestyle="--", linewidth=1.8)
    ax.set_title(f"CF26 {metric} Bootstrap Distribution")
    ax.set_xlabel(metric)
    ax.set_ylabel("Bootstrap replicates")
    ax.grid(axis="y", alpha=0.2)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(output_file, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_classification_distributions(bootstrap: pd.DataFrame, summary: pd.DataFrame) -> None:
    metrics = ["Sensitivity", "Specificity", "PPV", "NPV"]
    fig, axes = plt.subplots(2, 2, figsize=(10, 7))
    for ax, metric in zip(axes.ravel(), metrics):
        row = summary.loc[summary["Metric"] == metric].iloc[0]
        ax.hist(bootstrap[metric].dropna(), bins=45, color="#59A14F", alpha=0.82, edgecolor="white")
        ax.axvline(row["Point_estimate"], color="#111111", linewidth=2)
        ax.axvline(row["CI_lower_95"], color="#D62728", linestyle="--", linewidth=1.6)
        ax.axvline(row["CI_upper_95"], color="#D62728", linestyle="--", linewidth=1.6)
        ax.set_title(metric)
        ax.set_xlabel("Metric value")
        ax.set_ylabel("Replicates")
        ax.grid(axis="y", alpha=0.2)

    handles = [
        plt.Line2D([0], [0], color="#111111", linewidth=2, label="Observed"),
        plt.Line2D([0], [0], color="#D62728", linestyle="--", linewidth=1.8, label="95% CI"),
    ]
    fig.legend(handles=handles, loc="upper center", ncol=2, frameon=False)
    fig.suptitle("CF26 Classification Metric Bootstrap Distributions", y=0.995)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(
        FIGURES_DIR / "CF26_classification_metrics_bootstrap_distribution.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def write_report(
    manifest: pd.DataFrame,
    analysis: pd.DataFrame,
    summary: pd.DataFrame,
    validation: pd.DataFrame,
) -> None:
    manifest_lines = [
        f"- `{row.filename}`: {row.description} ({row.number_of_samples} rows/samples)."
        for row in manifest.itertuples(index=False)
    ]
    result_lines = [
        (
            f"| {row.Metric} | {format_metric(row.Point_estimate, row.Metric)} | "
            f"{format_metric(row.CI_lower_95, row.Metric)}-{format_metric(row.CI_upper_95, row.Metric)} |"
        )
        for row in summary.itertuples(index=False)
    ]
    failed_checks = validation.loc[validation["status"] != "PASS", "check"].tolist()
    check_sentence = (
        "All validation checks passed."
        if not failed_checks
        else "Validation checks requiring review: " + "; ".join(failed_checks)
    )

    report = f"""# CF26 Bootstrap Confidence Interval Analysis

## Objective

CF26 quantifies uncertainty for locked CF18 Elastic-Net performance on the SCAN-B / GSE96058 external validation cohort. It uses the CF19 prediction probabilities and the locked threshold without retraining, feature selection, threshold optimization, or batch correction.

## Input Files

{chr(10).join(manifest_lines)}

## Methods

Non-parametric bootstrap resampling was performed at the SCAN-B patient/sample level. Each replicate sampled {len(analysis)} SCAN-B samples with replacement and recalculated discrimination and fixed-threshold classification metrics.

## Bootstrap Parameters

- Iterations: {N_BOOTSTRAPS}
- Random seed: {RANDOM_SEED}
- Locked threshold: {THRESHOLD}
- Original sample size: {len(analysis)}
- HER2 positives: {int(analysis["HER2_label"].sum())}
- HER2 negatives: {int((1 - analysis["HER2_label"]).sum())}

## Results Summary

| Metric | Estimate | 95% CI |
| --- | --- | --- |
{chr(10).join(result_lines)}

## Validation Checks

{check_sentence}

## Interpretation

The locked CF18 Elastic-Net model retained high discrimination on SCAN-B. Bootstrap intervals quantify sampling uncertainty around both ranking performance and the fixed-threshold operating point, supporting manuscript-ready reporting without changing the original model or threshold.
"""
    (CF26 / "CF26_report.md").write_text(report, encoding="utf-8")


def write_input_reference_files() -> None:
    references = pd.DataFrame(
        {
            "input_alias": [
                "CF19_predictions",
                "CF19_metrics",
                "CF19_summary",
                "SCANB_primary_metadata",
                "CF14_SCANB_locked_manifest",
            ],
            "path": [
                str(PREDICTIONS_FILE),
                str(CF19_METRICS_FILE),
                str(CF19_SUMMARY_FILE),
                str(SCANB_METADATA_FILE),
                str(CF14_SCANB_MANIFEST_FILE),
            ],
        }
    )
    references.to_csv(INPUT_DIR / "CF26_input_references.tsv", sep="\t", index=False)


def main() -> None:
    start = time.time()
    ensure_directories()
    write_input_reference_files()

    log_lines = [
        "CF26 Bootstrap Confidence Interval Analysis",
        f"Started: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"Base directory: {BASE}",
    ]

    analysis, metadata, cf19_metrics, cf19_summary = load_analysis_dataset()
    manifest = write_input_manifest(analysis, metadata, cf19_metrics, cf19_summary)

    y = analysis["HER2_label"].to_numpy(dtype=int)
    probabilities = analysis["HER2_probability"].to_numpy(dtype=float)
    point_estimates = calculate_metrics(y, probabilities, THRESHOLD)

    bootstrap = run_bootstrap(analysis)
    summary = write_metric_summaries(point_estimates, bootstrap)
    validation = write_validation_checks(analysis, bootstrap, point_estimates, cf19_metrics)

    plot_single_distribution(
        bootstrap,
        summary,
        "AUROC",
        FIGURES_DIR / "CF26_AUROC_bootstrap_distribution.png",
    )
    plot_single_distribution(
        bootstrap,
        summary,
        "PR_AUC",
        FIGURES_DIR / "CF26_PR_AUC_bootstrap_distribution.png",
    )
    plot_classification_distributions(bootstrap, summary)

    write_report(manifest, analysis, summary, validation)

    completed = time.time()
    log_lines.extend(
        [
            f"Completed: {time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"Runtime minutes: {(completed - start) / 60:.3f}",
            f"Sample size: {len(analysis)}",
            f"Bootstrap iterations: {N_BOOTSTRAPS}",
            f"Results directory: {RESULTS_DIR}",
            f"Figures directory: {FIGURES_DIR}",
        ]
    )
    (LOGS_DIR / "CF26_bootstrap_confidence_intervals.log").write_text(
        "\n".join(log_lines) + "\n", encoding="utf-8"
    )

    print("CF26 completed successfully.")
    print("Input files used:")
    for row in manifest.itertuples(index=False):
        print(f"- {row.filename}: {row.path}")
    print(f"Sample size: {len(analysis)}")
    print(f"Bootstrap iterations: {N_BOOTSTRAPS}")
    print(f"Output locations: {CF26}")
    print("Key results:")
    for row in summary.itertuples(index=False):
        print(
            f"- {row.Metric}: {format_metric(row.Point_estimate, row.Metric)} "
            f"(95% CI {format_metric(row.CI_lower_95, row.Metric)}-"
            f"{format_metric(row.CI_upper_95, row.Metric)})"
        )


if __name__ == "__main__":
    main()
