#!/usr/bin/env python
"""
CF11 - SCAN-B / GSE96058 acquisition and QC

Purpose
-------
Acquire the public processed SCAN-B validation cohort (GSE96058), parse GEO
sample metadata, identify the 136 technical-replicate libraries, quantify
replicate concordance, and freeze a one-column-per-primary-sample expression
matrix for later cross-cohort harmonization.

This stage does NOT:
- harmonize genes to TCGA yet (CF13);
- choose the final ML endpoint;
- train any model;
- use SCAN-B to tune TCGA models.

Source
------
NCBI GEO GSE96058:
- 3,273 biological validation samples
- 136 technical replicate libraries
- 3,409 expression columns total
- public processed gene-expression matrix

Raw sequence reads are not publicly available for this cohort; CF11 therefore
uses the deposited processed gene-level expression matrix.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import json
import logging
import math
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path.cwd()

ACCESSION = "GSE96058"

# Official NCBI/GEO source URLs.
EXPRESSION_URL = (
    "https://www.ncbi.nlm.nih.gov/geo/download/"
    "?acc=GSE96058&file="
    "GSE96058_gene_expression_3273_samples_and_136_replicates_transformed.csv.gz"
    "&format=file"
)

SERIES_MATRIX_URLS = {
    "GPL11154": (
        "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE96nnn/GSE96058/"
        "matrix/GSE96058-GPL11154_series_matrix.txt.gz"
    ),
    "GPL18573": (
        "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE96nnn/GSE96058/"
        "matrix/GSE96058-GPL18573_series_matrix.txt.gz"
    ),
}

RAW_DIR = PROJECT_ROOT / "data" / "raw" / "scanb" / ACCESSION
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed" / "scanb"
RESULTS_DIR = PROJECT_ROOT / "results" / "CF11_scanb_acquisition_qc"
LOG_DIR = PROJECT_ROOT / "logs"
LOG_FILE = LOG_DIR / "CF11_scanb_acquisition_qc.log"

RAW_EXPRESSION = (
    RAW_DIR
    / "CF11_GSE96058_gene_expression_3273_samples_and_136_replicates_transformed.csv.gz"
)
RAW_SERIES_MATRICES = {
    "GPL11154": RAW_DIR / "CF11_GSE96058-GPL11154_series_matrix.txt.gz",
    "GPL18573": RAW_DIR / "CF11_GSE96058-GPL18573_series_matrix.txt.gz",
}

PRIMARY_EXPRESSION = PROCESSED_DIR / "CF11_SCANB_primary_expression.tsv.gz"
PRIMARY_METADATA = PROCESSED_DIR / "CF11_SCANB_primary_sample_metadata.tsv"
ALL_METADATA = RESULTS_DIR / "CF11_SCANB_all_GEO_sample_metadata.tsv"

EXPECTED_TOTAL_GEO_SAMPLES = 3409
EXPECTED_PRIMARY_SAMPLES = 3273
EXPECTED_TECHNICAL_REPLICATES = 136

CHUNK_ROWS = 750

# The deposited expression file is >500 MB compressed. Require enough room
# for source + processed primary-only matrix + normal filesystem overhead.
MIN_FREE_GIB = 3.0

# Replicate correlations are descriptive QC only. They are not used to select
# "better" libraries because GEO explicitly designates primary vs repl.
REPLICATE_REVIEW_CORRELATION = 0.90


# ============================================================
# UTILITIES
# ============================================================

def setup_logging() -> None:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def sha256_file(path: Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(chunk_size), b""):
            h.update(block)
    return h.hexdigest()


def free_gib(path: Path) -> float:
    usage = shutil.disk_usage(path)
    return usage.free / (1024 ** 3)


def run_curl_download(url: str, dest: Path, expected_min_bytes: int = 1) -> None:
    """
    Download with Windows curl.exe because it has proven more reliable on the
    user's Windows network than R/libcurl. Existing non-empty files are reused.
    """
    if dest.exists() and dest.stat().st_size >= expected_min_bytes:
        logging.info(
            f"Reusing existing source file: {dest.name} "
            f"({dest.stat().st_size / (1024**2):.1f} MiB)"
        )
        return

    partial = dest.with_suffix(dest.suffix + ".partial")
    if partial.exists():
        partial.unlink()

    cmd = [
        "curl.exe",
        "-4",
        "-L",
        "--fail",
        "--retry", "8",
        "--retry-delay", "5",
        "--connect-timeout", "30",
        "--max-time", "7200",
        url,
        "-o", str(partial),
    ]

    logging.info(f"Downloading: {dest.name}")
    proc = subprocess.run(cmd)
    if proc.returncode != 0:
        raise RuntimeError(
            f"curl.exe failed with exit code {proc.returncode}: {dest.name}"
        )

    if not partial.exists() or partial.stat().st_size < expected_min_bytes:
        raise RuntimeError(
            f"Downloaded file is unexpectedly small: {partial}"
        )

    partial.replace(dest)


def gzip_integrity_test(path: Path) -> Tuple[int, int]:
    """
    Stream through the gzip file once. This validates the gzip CRC/footer and
    returns uncompressed bytes and line count without writing a temporary copy.
    """
    n_bytes = 0
    n_lines = 0
    with gzip.open(path, "rb") as f:
        while True:
            block = f.read(8 * 1024 * 1024)
            if not block:
                break
            n_bytes += len(block)
            n_lines += block.count(b"\n")
    return n_bytes, n_lines


def strip_geo_quotes(parts: Sequence[str]) -> List[str]:
    out = []
    for x in parts:
        x = x.strip()
        if len(x) >= 2 and x[0] == '"' and x[-1] == '"':
            x = x[1:-1]
        out.append(x.replace('\\"', '"'))
    return out


def normalize_field_name(text: str) -> str:
    x = text.strip().lower()
    x = re.sub(r"[^a-z0-9]+", "_", x)
    return x.strip("_")


def parse_series_matrix_metadata(path: Path) -> pd.DataFrame:
    """
    Parse only GEO sample metadata lines before the expression table.

    Repeated !Sample_characteristics_ch1 lines are expanded into columns when
    they use 'field: value' formatting.
    """
    simple_fields: Dict[str, List[str]] = {}
    characteristics_rows: List[List[str]] = []

    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as f:
        for line in f:
            if line.startswith("!series_matrix_table_begin"):
                break
            if not line.startswith("!Sample_"):
                continue

            parts = line.rstrip("\n\r").split("\t")
            key = parts[0].lstrip("!")
            values = strip_geo_quotes(parts[1:])

            if key == "Sample_characteristics_ch1":
                characteristics_rows.append(values)
            elif key not in simple_fields:
                simple_fields[key] = values
            else:
                # Preserve repeated non-characteristic fields deterministically.
                suffix = 2
                new_key = f"{key}_{suffix}"
                while new_key in simple_fields:
                    suffix += 1
                    new_key = f"{key}_{suffix}"
                simple_fields[new_key] = values

    if "Sample_geo_accession" not in simple_fields:
        raise RuntimeError("Series matrix metadata lacks !Sample_geo_accession.")
    if "Sample_title" not in simple_fields:
        raise RuntimeError("Series matrix metadata lacks !Sample_title.")

    n = len(simple_fields["Sample_geo_accession"])
    if n == 0:
        raise RuntimeError("No samples found in GEO series matrix metadata.")

    for key, values in simple_fields.items():
        if len(values) != n:
            raise RuntimeError(
                f"GEO metadata field {key} has {len(values)} values; expected {n}."
            )

    df = pd.DataFrame(simple_fields)
    df = df.rename(
        columns={
            "Sample_geo_accession": "geo_accession",
            "Sample_title": "sample_title",
        }
    )

    # Expand characteristics lines.
    char_columns: Dict[str, List[Optional[str]]] = {}

    for row_values in characteristics_rows:
        if len(row_values) != n:
            raise RuntimeError(
                "A !Sample_characteristics_ch1 line has an unexpected sample count."
            )

        parsed_keys = []
        parsed_vals = []
        for cell in row_values:
            if ":" in cell:
                k, v = cell.split(":", 1)
                parsed_keys.append(normalize_field_name(k))
                parsed_vals.append(v.strip())
            else:
                parsed_keys.append("unparsed_characteristic")
                parsed_vals.append(cell.strip())

        # Normally one characteristics row has the same key for all samples.
        unique_keys = sorted(set(k for k in parsed_keys if k))
        if len(unique_keys) == 1:
            col = f"characteristic_{unique_keys[0]}"
            if col in char_columns:
                # Multiple rows with same label: retain with suffix.
                suffix = 2
                while f"{col}_{suffix}" in char_columns:
                    suffix += 1
                col = f"{col}_{suffix}"
            char_columns[col] = parsed_vals
        else:
            # Heterogeneous row: add values into per-sample key-specific columns.
            for i, (k, v) in enumerate(zip(parsed_keys, parsed_vals)):
                col = f"characteristic_{k or 'unknown'}"
                if col not in char_columns:
                    char_columns[col] = [None] * n
                if char_columns[col][i] is None:
                    char_columns[col][i] = v
                else:
                    char_columns[col][i] = (
                        str(char_columns[col][i]) + " | " + v
                    )

    for col, values in char_columns.items():
        df[col] = values

    df["is_technical_replicate"] = (
        df["sample_title"].astype(str).str.lower().str.endswith("repl")
    )
    df["biological_sample_id"] = (
        df["sample_title"]
        .astype(str)
        .str.replace(r"repl$", "", regex=True, flags=re.IGNORECASE)
    )

    return df


def determine_expression_column_mapping(
    expression_columns: Sequence[str],
    metadata: pd.DataFrame,
) -> Tuple[str, Dict[str, str]]:
    """
    Determine whether expression columns are GEO accessions or sample titles.

    Returns:
      mode: 'sample_title' or 'geo_accession'
      mapping from expression column -> sample_title
    """
    expr = [str(x) for x in expression_columns]
    title_to_title = dict(
        zip(metadata["sample_title"].astype(str), metadata["sample_title"].astype(str))
    )
    geo_to_title = dict(
        zip(metadata["geo_accession"].astype(str), metadata["sample_title"].astype(str))
    )

    title_overlap = sum(x in title_to_title for x in expr)
    geo_overlap = sum(x in geo_to_title for x in expr)

    if title_overlap == len(expr):
        return "sample_title", {x: title_to_title[x] for x in expr}
    if geo_overlap == len(expr):
        return "geo_accession", {x: geo_to_title[x] for x in expr}

    raise RuntimeError(
        "Expression sample columns do not map completely to either GEO "
        f"sample_title or geo_accession. title overlap={title_overlap}/{len(expr)}, "
        f"GSM overlap={geo_overlap}/{len(expr)}."
    )


def pearson_from_accumulators(
    n: np.ndarray,
    sx: np.ndarray,
    sy: np.ndarray,
    sxx: np.ndarray,
    syy: np.ndarray,
    sxy: np.ndarray,
) -> np.ndarray:
    num = n * sxy - sx * sy
    den1 = n * sxx - sx * sx
    den2 = n * syy - sy * sy
    den = np.sqrt(np.maximum(den1, 0) * np.maximum(den2, 0))
    out = np.full_like(num, np.nan, dtype=np.float64)
    ok = (n > 2) & (den > 0)
    out[ok] = num[ok] / den[ok]
    return out


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    setup_logging()
    start = time.time()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF11 - SCAN-B / GSE96058 ACQUISITION + QC")
    logging.info("============================================================")
    logging.info("")
    logging.info("Expected runtime:")
    logging.info("  Download: network-dependent, commonly 10-40 min")
    logging.info("  Integrity + parsing + primary-matrix build: commonly 15-35 min")
    logging.info("  Typical total: ~25-75 min")
    logging.info("  Main bottleneck: 564 MB compressed GEO expression file")
    logging.info("")

    # --------------------------------------------------------
    # 1. Preflight
    # --------------------------------------------------------
    logging.info("[1/8] Preflight and disk-space check...")
    logging.info("")

    free = free_gib(PROJECT_ROOT)
    logging.info(f"Free disk space: {free:.2f} GiB")
    if free < MIN_FREE_GIB:
        raise RuntimeError(
            f"CF11 requires at least {MIN_FREE_GIB:.1f} GiB free; found {free:.2f} GiB."
        )

    curl_check = subprocess.run(
        ["curl.exe", "--version"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if curl_check.returncode != 0:
        raise RuntimeError("Windows curl.exe is not available.")

    # --------------------------------------------------------
    # 2. Download official GEO sources
    # --------------------------------------------------------
    logging.info("[2/8] Downloading/reusing official NCBI GEO source files...")
    logging.info("")

    # Expression file is ~564.3 MB according to GEO. 400 MB is a conservative
    # minimum that rejects HTML/error pages without hardcoding an exact size.
    run_curl_download(
        EXPRESSION_URL,
        RAW_EXPRESSION,
        expected_min_bytes=400 * 1024 * 1024,
    )

    # Series matrix metadata should be much smaller but still non-trivial.
    for platform_id, url in SERIES_MATRIX_URLS.items():
        # The two official platform-specific series matrices are small
        # (~214 KiB and ~41 KiB); use a low minimum that still rejects empty/error pages.
        run_curl_download(
            url,
            RAW_SERIES_MATRICES[platform_id],
            expected_min_bytes=20 * 1024,
        )

    logging.info(
        f"Expression source size: {RAW_EXPRESSION.stat().st_size / (1024**2):.1f} MiB"
    )
    for platform_id, path in RAW_SERIES_MATRICES.items():
        logging.info(
            f"{platform_id} series matrix size: "
            f"{path.stat().st_size / 1024:.1f} KiB"
        )
    logging.info("")

    # --------------------------------------------------------
    # 3. Source integrity + hashes
    # --------------------------------------------------------
    logging.info("[3/8] Verifying gzip integrity and recording SHA256...")
    logging.info("")

    # Record the raw expression checksum now. Its gzip integrity is validated
    # during the mandatory complete streaming read in step 6; this avoids
    # decompressing the 564 MB archive twice and substantially reduces runtime.
    expr_sha = sha256_file(RAW_EXPRESSION)

    matrix_integrity = {}
    matrix_sha = {}
    for platform_id, path in RAW_SERIES_MATRICES.items():
        matrix_uncompressed, matrix_lines = gzip_integrity_test(path)
        matrix_integrity[platform_id] = {
            "uncompressed_bytes": matrix_uncompressed,
            "lines": matrix_lines,
        }
        matrix_sha[platform_id] = sha256_file(path)
        logging.info(
            f"{platform_id} series matrix gzip: PASS; lines={matrix_lines:,}"
        )

    logging.info(
        "Expression source SHA256 recorded; gzip integrity will be validated "
        "by complete streaming parse in step 6."
    )
    logging.info("")

    # --------------------------------------------------------
    # 4. Parse GEO metadata + technical-replicate structure
    # --------------------------------------------------------
    logging.info("[4/8] Parsing GEO sample metadata and replicate structure...")
    logging.info("")

    metadata_parts = []
    for platform_id, path in RAW_SERIES_MATRICES.items():
        part = parse_series_matrix_metadata(path)
        part["CF11_series_matrix_platform"] = platform_id
        metadata_parts.append(part)

    metadata = pd.concat(metadata_parts, ignore_index=True, sort=False)

    if len(metadata) != EXPECTED_TOTAL_GEO_SAMPLES:
        raise RuntimeError(
            f"GEO metadata sample count={len(metadata)}; expected "
            f"{EXPECTED_TOTAL_GEO_SAMPLES}."
        )
    if metadata["geo_accession"].duplicated().any():
        raise RuntimeError("Duplicate GEO accessions found in series metadata.")
    if metadata["sample_title"].duplicated().any():
        raise RuntimeError("Duplicate GEO sample titles found in series metadata.")

    n_repl = int(metadata["is_technical_replicate"].sum())
    n_primary = int((~metadata["is_technical_replicate"]).sum())
    n_bio = int(metadata["biological_sample_id"].nunique())

    if n_repl != EXPECTED_TECHNICAL_REPLICATES:
        raise RuntimeError(
            f"Detected technical replicates={n_repl}; expected "
            f"{EXPECTED_TECHNICAL_REPLICATES}."
        )
    if n_primary != EXPECTED_PRIMARY_SAMPLES:
        raise RuntimeError(
            f"Detected primary samples={n_primary}; expected "
            f"{EXPECTED_PRIMARY_SAMPLES}."
        )
    if n_bio != EXPECTED_PRIMARY_SAMPLES:
        raise RuntimeError(
            f"Unique biological sample IDs={n_bio}; expected "
            f"{EXPECTED_PRIMARY_SAMPLES}."
        )

    # Every repl must map to an existing non-repl title.
    primary_titles = set(
        metadata.loc[
            ~metadata["is_technical_replicate"], "sample_title"
        ].astype(str)
    )
    repl_meta = metadata.loc[
        metadata["is_technical_replicate"],
        ["geo_accession", "sample_title", "biological_sample_id"],
    ].copy()

    missing_primary_for_repl = sorted(
        set(repl_meta["biological_sample_id"]) - primary_titles
    )
    if missing_primary_for_repl:
        raise RuntimeError(
            "Technical replicate(s) lack matching primary title: "
            f"{missing_primary_for_repl[:10]}"
        )

    metadata.to_csv(ALL_METADATA, sep="\t", index=False)

    logging.info(f"GEO sample records: {len(metadata)}")
    for platform_id, grp in metadata.groupby("CF11_series_matrix_platform"):
        logging.info(f"  {platform_id} samples: {len(grp)}")
    logging.info(f"Primary biological samples: {n_primary}")
    logging.info(f"Technical replicate libraries: {n_repl}")
    logging.info("")

    # --------------------------------------------------------
    # 5. Inspect expression header + align sample identities
    # --------------------------------------------------------
    logging.info("[5/8] Validating expression sample columns against GEO metadata...")
    logging.info("")

    header = pd.read_csv(
        RAW_EXPRESSION,
        compression="gzip",
        nrows=0,
        low_memory=False,
    )
    columns = [str(c) for c in header.columns]
    if len(columns) < 2:
        raise RuntimeError("SCAN-B expression file has fewer than two columns.")

    gene_id_col = columns[0]
    expr_sample_cols = columns[1:]

    if len(expr_sample_cols) != EXPECTED_TOTAL_GEO_SAMPLES:
        raise RuntimeError(
            f"Expression sample columns={len(expr_sample_cols)}; expected "
            f"{EXPECTED_TOTAL_GEO_SAMPLES}."
        )

    mapping_mode, expr_to_title = determine_expression_column_mapping(
        expr_sample_cols,
        metadata,
    )

    title_to_expr = {title: expr for expr, title in expr_to_title.items()}
    if len(title_to_expr) != EXPECTED_TOTAL_GEO_SAMPLES:
        raise RuntimeError("Expression-to-title mapping is not one-to-one.")

    primary_expr_cols = [
        title_to_expr[t]
        for t in metadata.loc[
            ~metadata["is_technical_replicate"], "sample_title"
        ].astype(str)
    ]

    if len(primary_expr_cols) != EXPECTED_PRIMARY_SAMPLES:
        raise RuntimeError("Failed to resolve exactly 3273 primary expression columns.")

    logging.info(f"Expression identifier column: {gene_id_col}")
    logging.info(f"Expression sample columns: {len(expr_sample_cols)}")
    logging.info(f"Expression column identity mode: {mapping_mode}")
    logging.info("")

    # --------------------------------------------------------
    # 6. Stream expression QC, replicate correlations, freeze primary matrix
    # --------------------------------------------------------
    logging.info("[6/8] Streaming expression QC + technical-replicate concordance...")
    logging.info("      This is usually the main post-download bottleneck.")
    logging.info("")

    pair_primary_titles = repl_meta["biological_sample_id"].astype(str).tolist()
    pair_repl_titles = repl_meta["sample_title"].astype(str).tolist()

    pair_primary_cols = [title_to_expr[x] for x in pair_primary_titles]
    pair_repl_cols = [title_to_expr[x] for x in pair_repl_titles]

    # Accumulators for Pearson correlation.
    p = len(pair_primary_cols)
    n = np.zeros(p, dtype=np.float64)
    sx = np.zeros(p, dtype=np.float64)
    sy = np.zeros(p, dtype=np.float64)
    sxx = np.zeros(p, dtype=np.float64)
    syy = np.zeros(p, dtype=np.float64)
    sxy = np.zeros(p, dtype=np.float64)

    gene_ids_seen = set()
    duplicate_gene_ids = 0
    expression_rows = 0
    nonfinite_values = 0
    negative_values = 0

    if PRIMARY_EXPRESSION.exists():
        PRIMARY_EXPRESSION.unlink()

    with gzip.open(PRIMARY_EXPRESSION, "wt", encoding="utf-8", newline="") as out_handle:
        write_header = True

        reader = pd.read_csv(
            RAW_EXPRESSION,
            compression="gzip",
            chunksize=CHUNK_ROWS,
            low_memory=False,
        )

        for chunk_idx, chunk in enumerate(reader, start=1):
            if gene_id_col not in chunk.columns:
                raise RuntimeError(
                    f"Gene identifier column disappeared from chunk: {gene_id_col}"
                )

            ids = chunk[gene_id_col].astype(str)
            for gid in ids:
                if gid in gene_ids_seen:
                    duplicate_gene_ids += 1
                else:
                    gene_ids_seen.add(gid)

            expression_rows += len(chunk)

            # Coerce all expression values once per chunk.
            values = chunk[expr_sample_cols].apply(
                pd.to_numeric,
                errors="coerce",
            )

            arr = values.to_numpy(dtype=np.float64, copy=False)
            nonfinite_values += int((~np.isfinite(arr)).sum())
            finite = np.isfinite(arr)
            negative_values += int((arr[finite] < 0).sum())

            # Replicate correlation block.
            x = values[pair_primary_cols].to_numpy(dtype=np.float64, copy=False)
            y = values[pair_repl_cols].to_numpy(dtype=np.float64, copy=False)

            mask = np.isfinite(x) & np.isfinite(y)
            x0 = np.where(mask, x, 0.0)
            y0 = np.where(mask, y, 0.0)

            n += mask.sum(axis=0)
            sx += x0.sum(axis=0)
            sy += y0.sum(axis=0)
            sxx += (x0 * x0).sum(axis=0)
            syy += (y0 * y0).sum(axis=0)
            sxy += (x0 * y0).sum(axis=0)

            # Freeze primary-only expression matrix using biological sample titles
            # as stable external-cohort sample identifiers.
            primary_chunk = pd.concat(
                [ids.rename("gene_id"), values[primary_expr_cols]],
                axis=1,
            )
            primary_chunk.columns = (
                ["gene_id"]
                + [expr_to_title[c] for c in primary_expr_cols]
            )

            primary_chunk.to_csv(
                out_handle,
                sep="\t",
                index=False,
                header=write_header,
                float_format="%.10g",
            )
            write_header = False

            if chunk_idx % 10 == 0:
                logging.info(
                    f"Expression rows processed: {expression_rows:,}"
                )

    # Reaching EOF through pandas/gzip without exception validates the large
    # expression archive's gzip CRC/trailer as part of the complete parse.
    logging.info("Expression gzip complete-stream integrity: PASS")

    corrs = pearson_from_accumulators(n, sx, sy, sxx, syy, sxy)

    replicate_qc = repl_meta.copy()
    replicate_qc["primary_sample_title"] = pair_primary_titles
    replicate_qc["replicate_sample_title"] = pair_repl_titles
    replicate_qc["paired_finite_genes"] = n.astype(np.int64)
    replicate_qc["pearson_expression"] = corrs
    replicate_qc["review_flag_correlation_lt_0_90"] = (
        replicate_qc["pearson_expression"] < REPLICATE_REVIEW_CORRELATION
    )
    replicate_qc["CF11_disposition_primary"] = "KEEP_PRIMARY"
    replicate_qc["CF11_disposition_replicate"] = "EXCLUDE_REPL_FROM_INDEPENDENT_COHORT"

    replicate_qc.to_csv(
        RESULTS_DIR / "CF11_technical_replicate_qc.tsv",
        sep="\t",
        index=False,
    )

    logging.info("")
    logging.info(f"Expression gene rows: {expression_rows:,}")
    logging.info(f"Duplicate gene identifiers: {duplicate_gene_ids}")
    logging.info(f"Non-finite expression values: {nonfinite_values:,}")
    logging.info(f"Negative transformed-expression values: {negative_values:,}")
    logging.info(
        f"Technical replicate Pearson range: "
        f"{np.nanmin(corrs):.4f} - {np.nanmax(corrs):.4f}"
    )
    logging.info(
        f"Replicate pairs below r<{REPLICATE_REVIEW_CORRELATION:.2f}: "
        f"{int(np.nansum(corrs < REPLICATE_REVIEW_CORRELATION))}"
    )
    logging.info("")

    # --------------------------------------------------------
    # 7. Freeze primary metadata + audits
    # --------------------------------------------------------
    logging.info("[7/8] Freezing primary SCAN-B cohort metadata and QC audits...")
    logging.info("")

    primary_meta = metadata.loc[
        ~metadata["is_technical_replicate"]
    ].copy()

    primary_meta["CF11_include"] = True
    primary_meta["CF11_reason"] = "GEO-designated primary sample"

    primary_meta.to_csv(PRIMARY_METADATA, sep="\t", index=False)

    field_rows = []
    for col in metadata.columns:
        s = metadata[col]
        known = int(
            s.notna()
            & s.astype(str).str.strip().ne("")
        ).sum()
        field_rows.append(
            {
                "field": col,
                "known_n": known,
                "missing_n": len(metadata) - known,
                "known_percent": round(100 * known / len(metadata), 2),
                "unique_nonmissing_values": int(
                    s[
                        s.notna() & s.astype(str).str.strip().ne("")
                    ].astype(str).nunique()
                ),
            }
        )

    pd.DataFrame(field_rows).to_csv(
        RESULTS_DIR / "CF11_metadata_field_audit.tsv",
        sep="\t",
        index=False,
    )

    expression_qc = pd.DataFrame(
        [
            ("GEO accession", ACCESSION),
            ("Expression gene identifier column", gene_id_col),
            ("Expression gene rows", expression_rows),
            ("Expression sample columns total", len(expr_sample_cols)),
            ("Primary sample columns frozen", len(primary_expr_cols)),
            ("Technical replicate columns excluded", n_repl),
            ("Duplicate gene identifiers", duplicate_gene_ids),
            ("Non-finite expression values", nonfinite_values),
            ("Negative transformed-expression values", negative_values),
            ("Replicate Pearson minimum", float(np.nanmin(corrs))),
            ("Replicate Pearson median", float(np.nanmedian(corrs))),
            ("Replicate Pearson maximum", float(np.nanmax(corrs))),
            (
                f"Replicate pairs below r<{REPLICATE_REVIEW_CORRELATION:.2f}",
                int(np.nansum(corrs < REPLICATE_REVIEW_CORRELATION)),
            ),
        ],
        columns=["metric", "value"],
    )
    expression_qc.to_csv(
        RESULTS_DIR / "CF11_expression_qc.tsv",
        sep="\t",
        index=False,
    )

    # --------------------------------------------------------
    # 8. Summary + provenance + final gate
    # --------------------------------------------------------
    logging.info("[8/8] Writing CF11 summary and provenance...")
    logging.info("")

    runtime_min = (time.time() - start) / 60

    primary_sha = sha256_file(PRIMARY_EXPRESSION)
    primary_meta_sha = sha256_file(PRIMARY_METADATA)

    low_corr_n = int(np.nansum(corrs < REPLICATE_REVIEW_CORRELATION))

    summary = pd.DataFrame(
        [
            ("GEO accession", ACCESSION),
            ("GEO sample records", len(metadata)),
            ("Primary biological samples", n_primary),
            ("Technical replicate libraries", n_repl),
            ("Unique biological sample IDs", n_bio),
            ("Expression gene rows", expression_rows),
            ("Primary expression columns", len(primary_expr_cols)),
            ("Duplicate gene identifiers", duplicate_gene_ids),
            ("Non-finite expression values", nonfinite_values),
            ("Replicate Pearson median", float(np.nanmedian(corrs))),
            (
                f"Replicate pairs below r<{REPLICATE_REVIEW_CORRELATION:.2f}",
                low_corr_n,
            ),
            ("Technical replicates retained in independent cohort", 0),
            ("Primary ML endpoint selected", "NO"),
            ("CF11 runtime minutes", round(runtime_min, 2)),
            (
                "CF11 stage gate",
                "PASS_WITH_REPLICATE_REVIEW" if low_corr_n > 0 else "PASS",
            ),
        ],
        columns=["metric", "value"],
    )
    summary.to_csv(
        RESULTS_DIR / "CF11_summary.tsv",
        sep="\t",
        index=False,
    )

    provenance = pd.DataFrame(
        [
            ("code_file", "CF11_scanb_acquisition_qc.py"),
            ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
            ("GEO_accession", ACCESSION),
            ("expression_source_url", EXPRESSION_URL),
            (
                "series_matrix_source_urls",
                json.dumps(SERIES_MATRIX_URLS, sort_keys=True),
            ),
            ("raw_expression_sha256", expr_sha),
            (
                "raw_series_matrix_sha256",
                json.dumps(matrix_sha, sort_keys=True),
            ),
            ("primary_expression_sha256", primary_sha),
            ("primary_metadata_sha256", primary_meta_sha),
            (
                "replicate_definition",
                "GEO sample title suffix 'repl'; base title is biological sample ID",
            ),
            (
                "replicate_policy",
                "GEO-designated primary retained; technical replicate excluded "
                "from independent validation cohort but retained for QC evidence",
            ),
            (
                "replicate_correlation_role",
                "descriptive QC only; not used to choose among primary/repl",
            ),
            (
                "expression_transform",
                "as deposited by GSE96058; no re-normalization in CF11",
            ),
            ("gene_harmonization_to_TCGA", "NOT_PERFORMED_CF13"),
            ("ML_training_or_tuning", "NONE"),
            ("python_version", sys.version.replace("\n", " ")),
            ("pandas_version", pd.__version__),
            ("numpy_version", np.__version__),
            ("platform", platform.platform()),
        ],
        columns=["field", "value"],
    )
    provenance.to_csv(
        RESULTS_DIR / "CF11_provenance.tsv",
        sep="\t",
        index=False,
    )

    logging.info("============================================================")
    if low_corr_n > 0:
        logging.info(" CF11 COMPLETE - SCAN-B ACQUISITION/QC PASSED WITH REVIEW")
    else:
        logging.info(" CF11 COMPLETE - SCAN-B ACQUISITION/QC GATE PASSED")
    logging.info("============================================================")
    logging.info("")
    logging.info(f"GEO sample records: {len(metadata)}")
    logging.info(f"Primary biological samples frozen: {n_primary}")
    logging.info(f"Technical replicate libraries excluded: {n_repl}")
    logging.info(f"Expression gene rows: {expression_rows}")
    logging.info(
        f"Technical replicate Pearson median: {np.nanmedian(corrs):.4f}"
    )
    logging.info(
        f"Replicate pairs below r<{REPLICATE_REVIEW_CORRELATION:.2f}: {low_corr_n}"
    )
    logging.info(f"CF11 total runtime: {runtime_min:.1f} min")
    logging.info("")
    logging.info("CF11 generated:")
    logging.info(
        "  data/raw/scanb/GSE96058/"
        "CF11_GSE96058_gene_expression_3273_samples_and_136_replicates_transformed.csv.gz"
    )
    logging.info(
        "  data/raw/scanb/GSE96058/"
        "CF11_GSE96058-GPL11154_series_matrix.txt.gz"
    )
    logging.info(
        "  data/raw/scanb/GSE96058/"
        "CF11_GSE96058-GPL18573_series_matrix.txt.gz"
    )
    logging.info(
        "  data/processed/scanb/CF11_SCANB_primary_expression.tsv.gz"
    )
    logging.info(
        "  data/processed/scanb/CF11_SCANB_primary_sample_metadata.tsv"
    )
    logging.info(
        "  results/CF11_scanb_acquisition_qc/CF11_technical_replicate_qc.tsv"
    )
    logging.info(
        "  results/CF11_scanb_acquisition_qc/CF11_expression_qc.tsv"
    )
    logging.info(
        "  results/CF11_scanb_acquisition_qc/CF11_metadata_field_audit.tsv"
    )
    logging.info(
        "  results/CF11_scanb_acquisition_qc/CF11_summary.tsv"
    )
    logging.info(
        "  results/CF11_scanb_acquisition_qc/CF11_provenance.tsv"
    )
    logging.info(
        "  logs/CF11_scanb_acquisition_qc.log"
    )
    logging.info("")
    logging.info("IMPORTANT:")
    logging.info("SCAN-B was not used for model training or tuning.")
    logging.info("Technical replicates were retained as QC evidence only.")
    logging.info("No TCGA-SCAN-B gene harmonization was performed yet.")
    logging.info("No ML endpoint was selected.")
    logging.info("CF11 is ready for review before CF12 APOLLO acquisition/QC.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF11 ERROR: {exc}")
        sys.exit(1)