#!/usr/bin/env python
"""
CF14 - LOCK PRE-ML PROTOCOL

Run this script ONLY if the user accepts the recommended pre-ML protocol.

This script performs NO machine learning. It:
- validates the completed CF14 manual audit;
- locks HER2 as the primary measured/pathology endpoint;
- locks the leakage-safe cross-platform preprocessing strategy;
- locks nested-CV/model-selection rules;
- promotes CF14 DRAFT manifests to LOCKED manifests;
- writes the formal protocol lock required before CF15.

Running this file constitutes explicit manual approval of the protocol.
"""

from __future__ import annotations

import hashlib
import logging
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


ROOT = Path.cwd()

AUDIT_DIR = ROOT / "results" / "CF14_pre_ml_manual_audit"
DRAFT_DATA = ROOT / "data" / "processed" / "ml_ready"
LOG_DIR = ROOT / "logs"
LOG_FILE = LOG_DIR / "CF14_lock_pre_ml_protocol.log"

SUMMARY = AUDIT_DIR / "CF14_summary.tsv"
BALANCE = AUDIT_DIR / "CF14_candidate_endpoint_balance.tsv"
LEAKAGE = AUDIT_DIR / "CF14_leakage_audit.tsv"
DRAFT_PROTOCOL = AUDIT_DIR / "CF14_protocol_draft.tsv"

TCGA_DRAFT = DRAFT_DATA / "CF14_TCGA_ML_sample_manifest_DRAFT.tsv"
SCANB_DRAFT = DRAFT_DATA / "CF14_SCANB_external_sample_manifest_DRAFT.tsv"
GENES_DRAFT = DRAFT_DATA / "CF14_external_validation_gene_universe_DRAFT.tsv"

TCGA_LOCKED = DRAFT_DATA / "CF14_TCGA_ML_sample_manifest_LOCKED.tsv"
SCANB_LOCKED = DRAFT_DATA / "CF14_SCANB_external_sample_manifest_LOCKED.tsv"
GENES_LOCKED = DRAFT_DATA / "CF14_external_validation_gene_universe_LOCKED.tsv"

LOCKED_PROTOCOL = AUDIT_DIR / "CF14_LOCKED_pre_ml_protocol.tsv"
LOCKED_SUMMARY = AUDIT_DIR / "CF14_LOCKED_summary.tsv"
LOCK_SENTINEL = AUDIT_DIR / "CF14_PROTOCOL_LOCKED.txt"

EXPECTED = {
    ("TCGA", "HER2"): (938, 182, 756),
    ("SCANB", "HER2"): (3151, 420, 2731),
}


def setup_logging():
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def sha256_file(path: Path, block=8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(block), b""):
            h.update(b)
    return h.hexdigest()


def metric_dict(path: Path):
    df = pd.read_csv(path, sep="\t", dtype=str)
    return dict(zip(df["metric"], df["value"]))


def main():
    setup_logging()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF14 - LOCK PRE-ML PROTOCOL")
    logging.info("============================================================")
    logging.info("")
    logging.info("Estimated runtime: <1 minute")
    logging.info("NO ML WILL RUN.")
    logging.info("")

    required = [
        SUMMARY, BALANCE, LEAKAGE, DRAFT_PROTOCOL,
        TCGA_DRAFT, SCANB_DRAFT, GENES_DRAFT,
    ]
    for p in required:
        if not p.exists():
            raise FileNotFoundError(f"Required CF14 audit artifact missing: {p}")

    # --------------------------------------------------------
    # Validate manual audit
    # --------------------------------------------------------
    s = metric_dict(SUMMARY)

    if s.get("CF14 status") != "AUDIT_COMPLETE_NOT_LOCKED":
        raise RuntimeError(
            f"CF14 audit is not in expected state: {s.get('CF14 status')}"
        )
    if s.get("ML performed") != "NO":
        raise RuntimeError("CF14 indicates ML was already performed; lock aborted.")
    if int(float(s["TCGA discovery tumors"])) != 1094:
        raise RuntimeError("Unexpected TCGA discovery cohort size.")
    if int(float(s["SCAN-B external tumors"])) != 3273:
        raise RuntimeError("Unexpected SCAN-B external cohort size.")
    if int(float(s["External-validation feature universe"])) != 22106:
        raise RuntimeError("Unexpected external-validation gene universe.")
    if int(float(s["APOLLO complete multi-omics cases"])) != 68:
        raise RuntimeError("Unexpected APOLLO multi-omics overlap.")

    bal = pd.read_csv(BALANCE, sep="\t")
    for key, expected in EXPECTED.items():
        cohort, endpoint = key
        row = bal.loc[
            (bal["cohort"] == cohort) & (bal["endpoint"] == endpoint)
        ]
        if len(row) != 1:
            raise RuntimeError(f"Missing unique balance row for {cohort}/{endpoint}.")
        row = row.iloc[0]
        observed = (
            int(row["known_n"]),
            int(row["positive_n"]),
            int(row["negative_n"]),
        )
        if observed != expected:
            raise RuntimeError(
                f"{cohort}/{endpoint} counts changed: {observed} != {expected}"
            )

    leak = pd.read_csv(LEAKAGE, sep="\t", dtype=str)
    true_checks = leak.loc[leak["check"] != "ML executed in CF14", "value"]
    if not true_checks.astype(str).str.lower().isin(["true", "1", "yes"]).all():
        raise RuntimeError("One or more required leakage checks are not TRUE.")
    ml_row = leak.loc[leak["check"] == "ML executed in CF14", "value"]
    if len(ml_row) != 1 or ml_row.iloc[0].lower() not in {"false", "0", "no"}:
        raise RuntimeError("CF14 ML execution check is not FALSE.")

    # --------------------------------------------------------
    # Promote frozen manifests
    # --------------------------------------------------------
    shutil.copy2(TCGA_DRAFT, TCGA_LOCKED)
    shutil.copy2(SCANB_DRAFT, SCANB_LOCKED)
    shutil.copy2(GENES_DRAFT, GENES_LOCKED)

    # --------------------------------------------------------
    # Formal lock
    # --------------------------------------------------------
    rows = [
        (
            "Primary endpoint",
            "HER2 measured/pathology status",
            "LOCKED",
            "Best primary cross-cohort compromise: 938 TCGA classifiable "
            "(182 positive/756 negative) and 3151 SCAN-B classifiable "
            "(420 positive/2731 negative); measured pathology, not expression-derived.",
        ),
        (
            "Secondary endpoints",
            "ER, PR, TNBC",
            "LOCKED_AS_SECONDARY",
            "May be evaluated only after the primary HER2 analysis is frozen; "
            "they cannot be used to alter the HER2 pipeline.",
        ),
        (
            "Discovery cohort",
            "TCGA-BRCA Primary Tumor",
            "LOCKED",
            "1094 resolved tumor patients; HER2 model uses 938 classifiable patients.",
        ),
        (
            "External cohort",
            "SCAN-B GSE96058",
            "LOCKED",
            "3273 independent primary tumors; HER2 evaluation uses 3151 classifiable tumors.",
        ),
        (
            "Cross-omics cohort",
            "APOLLO-BRCA-1",
            "LOCKED",
            "68 complete RNA+protein+phosphoprotein cases; biological confirmation only.",
        ),
        (
            "Feature availability universe",
            "22106 exact one-to-one TCGA∩SCAN-B gene symbols",
            "LOCKED",
            "APOLLO presence is not required; no CF9-DEG global preselection.",
        ),
        (
            "Primary cross-platform expression representation",
            "Within-sample average percentile rank across the 22106 common genes",
            "LOCKED",
            "Computed independently for every sample; scale-invariant and does not use "
            "external labels or external-cohort distribution parameters.",
        ),
        (
            "TCGA native source",
            "TPM",
            "LOCKED",
            "CF6 TPM is the source; no DESeq2-normalized values are used for ML.",
        ),
        (
            "SCAN-B native source",
            "Deposited log2(FPKM + 0.1)",
            "LOCKED",
            "Kept as deposited before sample-wise rank representation.",
        ),
        (
            "Training-fold scaling",
            "Feature-wise StandardScaler fitted on training data only",
            "LOCKED",
            "Applied after sample-wise rank transform; scaler parameters are never "
            "estimated from outer-test or SCAN-B labels/data distributions.",
        ),
        (
            "Zero-variance filter",
            "Training-fold only",
            "LOCKED",
            "Remove only genes with zero variance in the current training data.",
        ),
        (
            "Supervised feature selection",
            "SelectKBest(f_classif) inside CV only",
            "LOCKED",
            "Candidate k = {25, 50, 100, 250, 500}; selection is refit within every "
            "inner/outer training split.",
        ),
        (
            "Class imbalance treatment",
            "Class weighting only; no SMOTE/oversampling",
            "LOCKED",
            "Balanced class weights for linear models; fold-specific positive weighting "
            "for boosted trees.",
        ),
        (
            "Model family 1",
            "Elastic-Net logistic regression",
            "LOCKED",
            "Sparse interpretable linear benchmark.",
        ),
        (
            "Model family 2",
            "Linear SVM",
            "LOCKED",
            "Independent margin-based linear comparator.",
        ),
        (
            "Model family 3",
            "XGBoost",
            "LOCKED",
            "Nonlinear comparator; modest randomized hyperparameter search only.",
        ),
        (
            "Outer validation",
            "Repeated stratified 5-fold CV × 3 repeats",
            "LOCKED",
            "15 outer evaluations; patient independence already guaranteed by one tumor/patient.",
        ),
        (
            "Inner tuning",
            "Stratified 4-fold CV",
            "LOCKED",
            "All scaling, feature selection and hyperparameter tuning occur inside inner training data.",
        ),
        (
            "Random seed",
            "20260815",
            "LOCKED",
            "Fixed for CV splits and randomized searches.",
        ),
        (
            "Primary model-selection metric",
            "AUROC",
            "LOCKED",
            "Threshold-free discrimination metric; robust to the cross-cohort prevalence shift.",
        ),
        (
            "Key secondary discrimination metric",
            "Average precision / PR-AUC",
            "LOCKED",
            "Required because HER2-positive cases are the minority class.",
        ),
        (
            "Additional performance metrics",
            "MCC, balanced accuracy, sensitivity, specificity, Brier score, calibration",
            "LOCKED",
            "No accuracy-only claims.",
        ),
        (
            "Model tie-break rule",
            "Prefer simpler model if mean outer AUROC is within 0.01 of the best "
            "and PR-AUC is not materially worse",
            "LOCKED",
            "Complexity cannot be justified by trivial discrimination gains.",
        ),
        (
            "Final probability calibration",
            "Sigmoid calibration using TCGA only",
            "LOCKED",
            "Calibration is cross-fitted within TCGA; SCAN-B is never used to calibrate.",
        ),
        (
            "Classification threshold",
            "Chosen from TCGA out-of-fold calibrated predictions by maximum MCC",
            "LOCKED",
            "Threshold is fixed before external validation and applied unchanged to SCAN-B.",
        ),
        (
            "External validation timing",
            "One untouched SCAN-B evaluation after TCGA model/signature lock",
            "LOCKED",
            "No iterative tuning against SCAN-B performance.",
        ),
        (
            "External uncertainty",
            "2000 stratified patient-level bootstrap replicates",
            "LOCKED",
            "Report 95% confidence intervals for principal external metrics.",
        ),
        (
            "Cross-cohort ComBat",
            "FORBIDDEN",
            "LOCKED",
            "Discovery and external validation distributions are not jointly batch-corrected.",
        ),
        (
            "Pooled quantile normalization",
            "FORBIDDEN",
            "LOCKED",
            "No pooled normalization of TCGA and SCAN-B.",
        ),
        (
            "CF9 stable DEG list",
            "Biology/pathway evidence only",
            "LOCKED",
            "Never used as a global supervised ML prefilter.",
        ),
        (
            "APOLLO role",
            "Post-signature cross-omics confirmation",
            "LOCKED",
            "APOLLO cannot influence model choice, tuning, or external performance claims.",
        ),
        (
            "Stable signature derivation",
            "TCGA only, after model family selection",
            "LOCKED",
            "Selection frequency/effect stability are estimated without SCAN-B or APOLLO feedback.",
        ),
    ]

    protocol = pd.DataFrame(
        rows,
        columns=["protocol_item", "locked_decision", "status", "rationale"],
    )
    protocol.to_csv(LOCKED_PROTOCOL, sep="\t", index=False)

    locked_summary = pd.DataFrame(
        [
            ("CF14 status", "PROTOCOL_LOCKED_READY_FOR_CF15"),
            ("Primary endpoint", "HER2"),
            ("TCGA HER2 classifiable", 938),
            ("TCGA HER2 positive", 182),
            ("TCGA HER2 negative", 756),
            ("SCAN-B HER2 classifiable", 3151),
            ("SCAN-B HER2 positive", 420),
            ("SCAN-B HER2 negative", 2731),
            ("External-validation genes", 22106),
            ("APOLLO multi-omics cases", 68),
            ("ML performed during lock", "NO"),
            ("Locked UTC", datetime.now(timezone.utc).isoformat()),
            ("Locked protocol SHA256", sha256_file(LOCKED_PROTOCOL)),
            ("TCGA locked manifest SHA256", sha256_file(TCGA_LOCKED)),
            ("SCANB locked manifest SHA256", sha256_file(SCANB_LOCKED)),
            ("Locked gene universe SHA256", sha256_file(GENES_LOCKED)),
        ],
        columns=["metric", "value"],
    )
    locked_summary.to_csv(LOCKED_SUMMARY, sep="\t", index=False)

    LOCK_SENTINEL.write_text(
        "CF14 PRE-ML PROTOCOL LOCKED.\n"
        "Primary endpoint: HER2 measured/pathology status.\n"
        "No ML was executed by CF14.\n"
        "CF15 may begin using only the locked protocol and manifests.\n",
        encoding="utf-8",
    )

    logging.info("============================================================")
    logging.info(" CF14 PROTOCOL LOCKED - READY FOR CF15")
    logging.info("============================================================")
    logging.info("")
    logging.info("Primary endpoint: HER2")
    logging.info("TCGA HER2: 938 classifiable (182 positive / 756 negative)")
    logging.info("SCAN-B HER2: 3151 classifiable (420 positive / 2731 negative)")
    logging.info("External feature universe: 22106 genes")
    logging.info("Primary representation: within-sample percentile ranks")
    logging.info("Nested CV: 5-fold outer x 3 repeats; 4-fold inner")
    logging.info("Models: Elastic Net logistic, Linear SVM, XGBoost")
    logging.info("Primary metric: AUROC; key secondary: PR-AUC")
    logging.info("SCAN-B remains untouched until final external validation.")
    logging.info("NO ML was performed.")
    logging.info("")
    logging.info("STATUS: PROTOCOL_LOCKED_READY_FOR_CF15")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF14 LOCK ERROR: {exc}")
        sys.exit(1)
