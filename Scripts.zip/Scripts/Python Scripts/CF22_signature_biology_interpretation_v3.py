"""
============================================================
CF22 v3 - SIGNATURE BIOLOGY INTERPRETATION
============================================================

CF18 locked signature interpretation.

NO ML
NO RETRAINING
NO FEATURE SELECTION

Outputs:
- predictive genes
- Hallmark enrichment
- Reactome enrichment
- figures
============================================================
"""

import os
import time
import math
import joblib
import pandas as pd
import matplotlib.pyplot as plt
import gseapy as gp


START = time.time()

BASE = r"D:\Masters\Research\TCGA_BRCA"

MODEL_FILE = os.path.join(
    BASE,
    "data",
    "processed",
    "ml_ready",
    "CF18_final_model",
    "CF18_final_ElasticNet_model_bundle.joblib"
)

OUT = os.path.join(BASE, "results", "CF22_signature_biology")
os.makedirs(OUT, exist_ok=True)


def load_predictors():

    print("[1/6] Loading CF18 locked model bundle...")

    bundle = joblib.load(MODEL_FILE)

    all_genes = bundle["feature_universe_gene_symbols"]
    mask = bundle["select_k_best"].get_support()

    selected_genes = [
        g for g, keep in zip(all_genes, mask) if keep
    ]

    coef = bundle["elasticnet_model"].coef_.ravel()

    df = pd.DataFrame({
        "Gene": selected_genes,
        "Coefficient": coef
    })

    df = df[df["Coefficient"] != 0].copy()

    df["Direction"] = df["Coefficient"].apply(
        lambda x: "Positive_predictor" if x > 0 else "Negative_predictor"
    )

    df.to_csv(
        os.path.join(OUT, "CF22_predictive_gene_list.tsv"),
        sep="\t",
        index=False
    )

    print("Selected genes:", len(selected_genes))
    print("Non-zero predictors:", len(df))

    return df


def run_enrichment(genes):

    print("[2/6] Running Hallmark enrichment...")

    hallmark = gp.enrichr(
        gene_list=list(genes),
        gene_sets="MSigDB_Hallmark_2020",
        organism="human",
        outdir=None
    ).results

    hallmark.to_csv(
        os.path.join(OUT, "CF22_Hallmark_enrichment.tsv"),
        sep="\t",
        index=False
    )

    print("[3/6] Running Reactome enrichment...")

    reactome = gp.enrichr(
        gene_list=list(genes),
        gene_sets="Reactome_2022",
        organism="human",
        outdir=None
    ).results

    reactome.to_csv(
        os.path.join(OUT, "CF22_Reactome_enrichment.tsv"),
        sep="\t",
        index=False
    )

    return hallmark, reactome


def plot_results(df, title, filename):

    if df.empty:
        return

    top = df.sort_values("Adjusted P-value").head(15)

    values = [
        -math.log10(max(x, 1e-300))
        for x in top["Adjusted P-value"]
    ]

    plt.figure(figsize=(8,6))
    plt.barh(top["Term"][::-1], values[::-1])
    plt.xlabel("-log10 Adjusted P-value")
    plt.title(title)
    plt.tight_layout()

    plt.savefig(
        os.path.join(OUT, filename),
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()


def main():

    print("""
============================================================
CF22 v3 - SIGNATURE BIOLOGY INTERPRETATION
============================================================
NO ML
NO RETRAINING
NO FEATURE SELECTION
============================================================
""")

    genes = load_predictors()

    hallmark, reactome = run_enrichment(
        genes["Gene"]
    )

    print("[4/6] Generating figures...")

    plot_results(
        hallmark,
        "CF22 Hallmark Pathways",
        "CF22_Hallmark_Pathways.png"
    )

    plot_results(
        reactome,
        "CF22 Reactome Pathways",
        "CF22_Reactome_Pathways.png"
    )

    print("[5/6] Writing summary...")

    pd.DataFrame({
        "Item": [
            "Non-zero predictive genes",
            "Hallmark pathways",
            "Reactome pathways"
        ],
        "Value": [
            len(genes),
            len(hallmark),
            len(reactome)
        ]
    }).to_csv(
        os.path.join(OUT, "CF22_summary.tsv"),
        sep="\t",
        index=False
    )

    print("[6/6] Final gate")

    print("""
============================================================
CF22 v3 COMPLETE - BIOLOGICAL INTERPRETATION PASSED
============================================================
""")

    print("Predictive genes:", len(genes))
    print("Runtime:", round((time.time()-START)/60, 2), "min")
    print("STATUS: READY_FOR_CF23")


if __name__ == "__main__":
    main()
