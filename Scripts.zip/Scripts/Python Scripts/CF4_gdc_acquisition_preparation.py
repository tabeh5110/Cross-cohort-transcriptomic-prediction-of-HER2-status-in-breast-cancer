from __future__ import annotations

import hashlib
import io
import json
import logging
import shutil
import subprocess
import sys
import time
from pathlib import Path

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# ============================================================
# CF4 - GDC ACQUISITION PREPARATION + MANIFEST VALIDATION
# ============================================================
# Purpose
#   1. Validate the frozen CF3 acquisition cohort.
#   2. Verify the installed GDC Data Transfer Tool.
#   3. Verify the current GDC data release.
#   4. Generate an official GDC download manifest from the
#      exact CF3 file UUIDs.
#   5. Cross-check UUID, filename, MD5 and file size against CF3.
#   6. Check disk-space readiness.
#   7. Write the exact download command for CF5.
#
# IMPORTANT
#   CF4 DOES NOT DOWNLOAD RNA-seq DATA.
# ============================================================

PROJECT_ROOT = Path.cwd()

CF3_INPUT = PROJECT_ROOT / "results" / "CF3_tcga_cohort_resolution" / "CF3_final_candidate_manifest.tsv"
CF3_SUMMARY = PROJECT_ROOT / "results" / "CF3_tcga_cohort_resolution" / "CF3_cohort_summary.tsv"
CF3_PROVENANCE = PROJECT_ROOT / "results" / "CF3_tcga_cohort_resolution" / "CF3_provenance.tsv"

OUTPUT_DIR = PROJECT_ROOT / "results" / "CF4_gdc_acquisition_preparation"
LOG_DIR = PROJECT_ROOT / "logs"
RAW_DOWNLOAD_DIR = PROJECT_ROOT / "data" / "raw" / "tcga_brca" / "star_counts"

GDC_CLIENT = Path(r"D:\Tools\gdc-client.exe")
GDC_STATUS_URL = "https://api.gdc.cancer.gov/status"
GDC_MANIFEST_URL = "https://api.gdc.cancer.gov/manifest"
GDC_MANIFEST_FALLBACK_URL = "https://api.gdc.cancer.gov/v0/manifest"

EXPECTED_PROJECT = "TCGA-BRCA"
EXPECTED_WORKFLOW = "STAR - Counts"
EXPECTED_RELEASE_MAJOR = 46
EXPECTED_RELEASE_MINOR = 0

REQUEST_CONNECT_TIMEOUT = 20
REQUEST_READ_TIMEOUT = 180
RECOMMENDED_SPACE_MULTIPLIER = 2.0


# ------------------------------------------------------------
# Utilities
# ------------------------------------------------------------

def md5_file(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def human_bytes(n: int | float) -> str:
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    value = float(n)
    for unit in units:
        if value < 1024.0 or unit == units[-1]:
            return f"{value:.2f} {unit}"
        value /= 1024.0
    return f"{value:.2f} TiB"


def setup_logging() -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_path = LOG_DIR / "CF4_gdc_acquisition_preparation.log"

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    formatter = logging.Formatter("%(message)s")

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    file_handler = logging.FileHandler(log_path, mode="w", encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return log_path


def build_session() -> requests.Session:
    retry = Retry(
        total=6,
        connect=6,
        read=6,
        status=6,
        backoff_factor=1.5,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET", "POST"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session = requests.Session()
    session.mount("https://", adapter)
    session.headers.update({"User-Agent": "TCGA-BRCA-CF4/1.0"})
    return session


def fail(message: str) -> None:
    raise RuntimeError(message)


# ------------------------------------------------------------
# Main
# ------------------------------------------------------------

def main() -> None:
    log_path = setup_logging()

    logging.info("\n============================================================")
    logging.info(" CF4 - GDC ACQUISITION PREPARATION + MANIFEST VALIDATION")
    logging.info("============================================================\n")

    # --------------------------------------------------------
    # 1. Validate CF3 inputs
    # --------------------------------------------------------
    logging.info("[1/9] Validating frozen CF3 acquisition cohort...\n")

    for path in (CF3_INPUT, CF3_SUMMARY, CF3_PROVENANCE):
        if not path.exists():
            fail(f"Required CF3 input not found: {path}")

    cf3 = pd.read_csv(CF3_INPUT, sep="\t", dtype={"file_id": str, "file_name": str, "md5sum": str})
    required = {
        "patient_id",
        "sample_id",
        "sample_type",
        "file_id",
        "file_name",
        "md5sum",
        "file_size",
        "workflow",
        "CF3_include_file",
    }
    missing = sorted(required - set(cf3.columns))
    if missing:
        fail("CF3 manifest is missing required columns: " + ", ".join(missing))

    if cf3.empty:
        fail("CF3 final candidate manifest is empty.")

    # Robust boolean interpretation in case TSV parser returns strings.
    include_series = cf3["CF3_include_file"].astype(str).str.lower()
    if not include_series.isin(["true", "1"]).all():
        fail("CF3_final_candidate_manifest.tsv contains rows not marked for inclusion.")

    if cf3["file_id"].isna().any() or (cf3["file_id"].str.strip() == "").any():
        fail("Missing GDC file UUID detected in CF3 manifest.")
    if cf3["file_id"].duplicated().any():
        fail("Duplicate GDC file UUIDs detected in CF3 manifest.")
    if cf3["file_name"].duplicated().any():
        fail("Duplicate GDC filenames detected in CF3 manifest.")
    if cf3["md5sum"].isna().any() or (cf3["md5sum"].str.len() != 32).any():
        fail("Invalid or missing MD5 values detected in CF3 manifest.")

    cf3["file_size"] = pd.to_numeric(cf3["file_size"], errors="raise").astype("int64")
    if (cf3["file_size"] <= 0).any():
        fail("Non-positive file size detected in CF3 manifest.")
    if not (cf3["workflow"] == EXPECTED_WORKFLOW).all():
        fail(f"CF3 contains workflow values other than '{EXPECTED_WORKFLOW}'.")

    n_files = len(cf3)
    n_patients = cf3["patient_id"].nunique()
    n_samples = cf3["sample_id"].nunique()
    total_bytes_cf3 = int(cf3["file_size"].sum())
    cf3_md5 = md5_file(CF3_INPUT)

    logging.info(f"CF3 candidate files: {n_files}")
    logging.info(f"Unique patients: {n_patients}")
    logging.info(f"Unique biological sample IDs: {n_samples}")
    logging.info(f"CF3 total expected bytes: {total_bytes_cf3:,} ({human_bytes(total_bytes_cf3)})")
    logging.info(f"CF3 manifest MD5: {cf3_md5}\n")

    # --------------------------------------------------------
    # 2. Verify GDC Data Transfer Tool
    # --------------------------------------------------------
    logging.info("[2/9] Verifying GDC Data Transfer Tool...\n")

    if not GDC_CLIENT.exists():
        fail(f"GDC client not found at: {GDC_CLIENT}")

    version_proc = subprocess.run(
        [str(GDC_CLIENT), "--version"],
        capture_output=True,
        text=True,
        check=False,
    )
    if version_proc.returncode != 0:
        fail("gdc-client --version failed: " + (version_proc.stderr or version_proc.stdout).strip())

    gdc_client_version = (version_proc.stdout or version_proc.stderr).strip()
    logging.info(f"GDC client path: {GDC_CLIENT}")
    logging.info(f"GDC client version: {gdc_client_version}\n")

    # --------------------------------------------------------
    # 3. Verify GDC API release/status
    # --------------------------------------------------------
    logging.info("[3/9] Verifying GDC API status and data release...\n")

    session = build_session()
    status_response = session.get(
        GDC_STATUS_URL,
        timeout=(REQUEST_CONNECT_TIMEOUT, REQUEST_READ_TIMEOUT),
    )
    status_response.raise_for_status()
    status_payload = status_response.json()

    status_path = OUTPUT_DIR / "CF4_gdc_status.json"
    status_path.write_text(json.dumps(status_payload, indent=2, sort_keys=True), encoding="utf-8")

    if status_payload.get("status") != "OK":
        fail(f"GDC API status is not OK: {status_payload}")

    release_version = status_payload.get("data_release_version", {})
    release_major = release_version.get("major")
    release_minor = release_version.get("minor")

    if release_major != EXPECTED_RELEASE_MAJOR or release_minor != EXPECTED_RELEASE_MINOR:
        fail(
            "GDC data release changed. Expected "
            f"{EXPECTED_RELEASE_MAJOR}.{EXPECTED_RELEASE_MINOR}, got {release_major}.{release_minor}. "
            "Stop and re-audit before acquisition."
        )

    logging.info(f"GDC status: {status_payload.get('status')}")
    logging.info(f"GDC data release: {status_payload.get('data_release')}\n")

    # --------------------------------------------------------
    # 4. Generate official GDC manifest
    # --------------------------------------------------------
    logging.info("[4/9] Generating official GDC manifest from CF3 UUIDs...\n")

    ids = cf3["file_id"].tolist()
    manifest_response = None
    manifest_url_used = None

    for endpoint in (GDC_MANIFEST_URL, GDC_MANIFEST_FALLBACK_URL):
        response = session.post(
            endpoint,
            json={"ids": ids},
            headers={"Content-Type": "application/json"},
            timeout=(REQUEST_CONNECT_TIMEOUT, REQUEST_READ_TIMEOUT),
        )
        if response.ok and response.text.strip():
            manifest_response = response
            manifest_url_used = endpoint
            break
        logging.info(f"Manifest endpoint attempt failed: {endpoint} -> HTTP {response.status_code}")
        time.sleep(1)

    if manifest_response is None:
        fail("Unable to generate a GDC manifest from either manifest endpoint.")

    manifest_text = manifest_response.text.replace("\r\n", "\n")
    manifest_path = OUTPUT_DIR / "CF4_gdc_manifest.txt"
    manifest_path.write_text(manifest_text, encoding="utf-8")

    logging.info(f"Manifest endpoint used: {manifest_url_used}")
    logging.info(f"Official manifest saved: {manifest_path}\n")

    # --------------------------------------------------------
    # 5. Parse and cross-check official manifest
    # --------------------------------------------------------
    logging.info("[5/9] Cross-checking GDC manifest against frozen CF3 metadata...\n")

    try:
        gdc_manifest = pd.read_csv(io.StringIO(manifest_text), sep="\t", dtype=str)
    except Exception as exc:
        fail(f"Unable to parse official GDC manifest: {exc}")

    expected_manifest_cols = {"id", "filename", "md5", "size", "state"}
    missing_manifest_cols = sorted(expected_manifest_cols - set(gdc_manifest.columns))
    if missing_manifest_cols:
        fail("Official GDC manifest is missing columns: " + ", ".join(missing_manifest_cols))

    if len(gdc_manifest) != n_files:
        fail(f"GDC manifest row count mismatch: CF3={n_files}, GDC={len(gdc_manifest)}")
    if gdc_manifest["id"].duplicated().any():
        fail("Official GDC manifest contains duplicate UUIDs.")

    gdc_manifest["size"] = pd.to_numeric(gdc_manifest["size"], errors="raise").astype("int64")

    cross = cf3[["file_id", "file_name", "md5sum", "file_size"]].merge(
        gdc_manifest[["id", "filename", "md5", "size", "state"]],
        left_on="file_id",
        right_on="id",
        how="outer",
        indicator=True,
    )

    cross["uuid_match"] = cross["file_id"].fillna("") == cross["id"].fillna("")
    cross["filename_match"] = cross["file_name"].fillna("") == cross["filename"].fillna("")
    cross["md5_match"] = cross["md5sum"].fillna("").str.lower() == cross["md5"].fillna("").str.lower()
    cross["size_match"] = cross["file_size"].fillna(-1).astype("int64") == cross["size"].fillna(-2).astype("int64")
    # GDC download manifests currently report downloadable file entries
    # with state="validated". Earlier versions of this script incorrectly
    # required state="released", which caused a false failure for every row.
    # We therefore validate the transfer state against the states observed
    # for downloadable GDC files while preserving the exact state in output.
    acceptable_states = {"validated", "released"}
    cross["gdc_state_acceptable"] = (
        cross["state"].fillna("").str.lower().isin(acceptable_states)
    )

    cross["all_checks_pass"] = (
        (cross["_merge"] == "both")
        & cross["uuid_match"]
        & cross["filename_match"]
        & cross["md5_match"]
        & cross["size_match"]
        & cross["gdc_state_acceptable"]
    )

    cross_path = OUTPUT_DIR / "CF4_manifest_crosscheck.tsv"
    cross.to_csv(cross_path, sep="\t", index=False)

    if not cross["all_checks_pass"].all():
        failures = int((~cross["all_checks_pass"]).sum())
        fail(f"GDC/CF3 manifest cross-check failed for {failures} row(s). See {cross_path}")

    total_bytes_gdc = int(gdc_manifest["size"].sum())
    if total_bytes_gdc != total_bytes_cf3:
        fail(f"Total byte count mismatch: CF3={total_bytes_cf3}, GDC={total_bytes_gdc}")

    state_counts = gdc_manifest["state"].fillna("<missing>").value_counts().to_dict()

    logging.info(f"Manifest files cross-checked: {len(cross)}")
    logging.info("UUID / filename / MD5 / size: ALL EXACT MATCH")
    logging.info(f"GDC manifest state distribution: {state_counts}")
    logging.info("GDC transfer-state validation: ALL PASS")
    logging.info(f"GDC total bytes: {total_bytes_gdc:,} ({human_bytes(total_bytes_gdc)})\n")

    # --------------------------------------------------------
    # 6. Disk-space readiness
    # --------------------------------------------------------
    logging.info("[6/9] Checking download destination and free disk space...\n")

    RAW_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    usage = shutil.disk_usage(RAW_DOWNLOAD_DIR)
    recommended_bytes = int(total_bytes_gdc * RECOMMENDED_SPACE_MULTIPLIER)
    disk_ready = usage.free >= recommended_bytes

    disk_table = pd.DataFrame(
        [
            {"metric": "Expected download bytes", "bytes": total_bytes_gdc, "human_readable": human_bytes(total_bytes_gdc)},
            {"metric": "Recommended free bytes (2x)", "bytes": recommended_bytes, "human_readable": human_bytes(recommended_bytes)},
            {"metric": "Current free bytes", "bytes": int(usage.free), "human_readable": human_bytes(usage.free)},
        ]
    )
    disk_table["CF4_disk_ready"] = disk_ready
    disk_table.to_csv(OUTPUT_DIR / "CF4_disk_space_summary.tsv", sep="\t", index=False)

    logging.info(f"Download directory: {RAW_DOWNLOAD_DIR}")
    logging.info(f"Expected data volume: {human_bytes(total_bytes_gdc)}")
    logging.info(f"Recommended free space: {human_bytes(recommended_bytes)}")
    logging.info(f"Available free space: {human_bytes(usage.free)}")
    logging.info(f"Disk-space readiness: {'PASS' if disk_ready else 'FAIL'}\n")

    if not disk_ready:
        fail("Insufficient free disk space for the conservative 2x acquisition threshold.")

    # --------------------------------------------------------
    # 7. Create acquisition plan and exact command
    # --------------------------------------------------------
    logging.info("[7/9] Writing frozen acquisition plan and download command...\n")

    download_log = LOG_DIR / "CF5_gdc_download.log"
    command_parts = [
        f'"{GDC_CLIENT}"',
        "download",
        "-m",
        f'"{manifest_path}"',
        "-d",
        f'"{RAW_DOWNLOAD_DIR}"',
        "--log-file",
        f'"{download_log}"',
        "--no-related-files",
        "--no-annotations",
        "--retry-amount",
        "10",
        "--wait-time",
        "10",
    ]
    download_command = " ".join(command_parts)

    command_path = OUTPUT_DIR / "CF4_download_command.txt"
    command_path.write_text(download_command + "\n", encoding="utf-8")

    acquisition_plan = pd.DataFrame(
        [
            {"field": "project", "value": EXPECTED_PROJECT},
            {"field": "workflow", "value": EXPECTED_WORKFLOW},
            {"field": "gdc_data_release", "value": status_payload.get("data_release")},
            {"field": "gdc_client_version", "value": gdc_client_version},
            {"field": "candidate_files", "value": n_files},
            {"field": "biological_sample_ids", "value": n_samples},
            {"field": "patients", "value": n_patients},
            {"field": "total_bytes", "value": total_bytes_gdc},
            {"field": "download_directory", "value": str(RAW_DOWNLOAD_DIR)},
            {"field": "manifest_file", "value": str(manifest_path)},
            {"field": "gdc_manifest_state_distribution", "value": json.dumps(state_counts, sort_keys=True)},
            {"field": "download_command_file", "value": str(command_path)},
        ]
    )
    acquisition_plan.to_csv(OUTPUT_DIR / "CF4_acquisition_plan.tsv", sep="\t", index=False)

    logging.info("Acquisition plan written.")
    logging.info("Download command written, but NOT executed.\n")

    # --------------------------------------------------------
    # 8. Summary + provenance
    # --------------------------------------------------------
    logging.info("[8/9] Writing CF4 summary and provenance...\n")

    summary = pd.DataFrame(
        [
            {"metric": "CF3 candidate files", "value": n_files},
            {"metric": "Official GDC manifest files", "value": len(gdc_manifest)},
            {"metric": "Manifest cross-check failures", "value": int((~cross["all_checks_pass"]).sum())},
            {"metric": "Unique patients", "value": n_patients},
            {"metric": "Unique biological sample IDs", "value": n_samples},
            {"metric": "Expected bytes", "value": total_bytes_gdc},
            {"metric": "Disk readiness", "value": "PASS" if disk_ready else "FAIL"},
            {"metric": "GDC release", "value": status_payload.get("data_release")},
            {"metric": "GDC client version", "value": gdc_client_version},
        ]
    )
    summary.to_csv(OUTPUT_DIR / "CF4_summary.tsv", sep="\t", index=False)

    provenance = pd.DataFrame(
        [
            {"field": "code_file", "value": "CF4_gdc_acquisition_preparation.py"},
            {"field": "cf3_input", "value": str(CF3_INPUT)},
            {"field": "cf3_input_md5", "value": cf3_md5},
            {"field": "cf3_input_records", "value": n_files},
            {"field": "gdc_status_url", "value": GDC_STATUS_URL},
            {"field": "gdc_manifest_url_used", "value": manifest_url_used},
            {"field": "gdc_data_release", "value": status_payload.get("data_release")},
            {"field": "gdc_api_commit", "value": status_payload.get("commit")},
            {"field": "gdc_client_path", "value": str(GDC_CLIENT)},
            {"field": "gdc_client_version", "value": gdc_client_version},
            {"field": "gdc_manifest_state_distribution", "value": json.dumps(state_counts, sort_keys=True)},
            {"field": "python_version", "value": sys.version.replace("\n", " ")},
            {"field": "pandas_version", "value": pd.__version__},
            {"field": "requests_version", "value": requests.__version__},
            {"field": "run_datetime_local", "value": time.strftime("%Y-%m-%d %H:%M:%S %Z")},
        ]
    )
    provenance.to_csv(OUTPUT_DIR / "CF4_provenance.tsv", sep="\t", index=False)

    # --------------------------------------------------------
    # 9. Final report
    # --------------------------------------------------------
    logging.info("[9/9] CF4 preparation complete.\n")
    logging.info("============================================================")
    logging.info(" CF4 COMPLETE")
    logging.info("============================================================\n")
    logging.info(f"Candidate files validated: {n_files}")
    logging.info(f"Official GDC manifest files: {len(gdc_manifest)}")
    logging.info("Manifest cross-check failures: 0")
    logging.info(f"Expected download size: {human_bytes(total_bytes_gdc)}")
    logging.info(f"Available free space: {human_bytes(usage.free)}")
    logging.info(f"GDC data release: {status_payload.get('data_release')}")
    logging.info(f"GDC client version: {gdc_client_version}")
    logging.info("\nCF4 generated:")
    for name in [
        "CF4_gdc_status.json",
        "CF4_gdc_manifest.txt",
        "CF4_manifest_crosscheck.tsv",
        "CF4_disk_space_summary.tsv",
        "CF4_acquisition_plan.tsv",
        "CF4_download_command.txt",
        "CF4_summary.tsv",
        "CF4_provenance.tsv",
    ]:
        logging.info(f"  {name}")
    logging.info(f"  {log_path.name}")
    logging.info("\nIMPORTANT:")
    logging.info("No RNA-seq expression file was downloaded by CF4.")
    logging.info("Do NOT run CF4_download_command.txt until CF4 outputs are reviewed.")
    logging.info("============================================================\n")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF4 FAILED: {exc}")
        sys.exit(1)