#!/usr/bin/env python
"""
CF11 - Resume/finalize SCAN-B after the stage-7 audit bug.

This version DOES NOT require CF11_expression_qc.tsv because the original CF11
run failed before that file was written. Instead it reconstructs the compact
expression-QC table from:
  1) the completed CF11 log,
  2) the already-written replicate-QC table,
  3) the already-written primary expression header.

The 564 MB GEO source is NOT re-downloaded or reprocessed.
"""

from __future__ import annotations

import hashlib
import json
import logging
import platform
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd


PROJECT_ROOT = Path.cwd()

RAW_DIR = PROJECT_ROOT / "data" / "raw" / "scanb" / "GSE96058"
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed" / "scanb"
RESULTS_DIR = PROJECT_ROOT / "results" / "CF11_scanb_acquisition_qc"
LOG_DIR = PROJECT_ROOT / "logs"

ORIGINAL_LOG = LOG_DIR / "CF11_scanb_acquisition_qc.log"
RESUME_LOG = LOG_DIR / "CF11_resume_finalize_v2.log"

RAW_EXPRESSION = RAW_DIR / "CF11_GSE96058_gene_expression_3273_samples_and_136_replicates_transformed.csv.gz"
RAW_SERIES_MATRICES = {
    "GPL11154": RAW_DIR / "CF11_GSE96058-GPL11154_series_matrix.txt.gz",
    "GPL18573": RAW_DIR / "CF11_GSE96058-GPL18573_series_matrix.txt.gz",
}

PRIMARY_EXPRESSION = PROCESSED_DIR / "CF11_SCANB_primary_expression.tsv.gz"
PRIMARY_METADATA = PROCESSED_DIR / "CF11_SCANB_primary_sample_metadata.tsv"

ALL_METADATA = RESULTS_DIR / "CF11_SCANB_all_GEO_sample_metadata.tsv"
REPLICATE_QC = RESULTS_DIR / "CF11_technical_replicate_qc.tsv"
EXPRESSION_QC = RESULTS_DIR / "CF11_expression_qc.tsv"

EXPECTED_TOTAL_GEO_SAMPLES = 3409
EXPECTED_PRIMARY_SAMPLES = 3273
EXPECTED_TECHNICAL_REPLICATES = 136
EXPECTED_GENE_ROWS = 30865
EXPECTED_DUPLICATE_GENE_IDS = 0
EXPECTED_NONFINITE = 0
REPLICATE_REVIEW_CORRELATION = 0.90

EXPRESSION_URL = (
    "https://www.ncbi.nlm.nih.gov/geo/download/"
    "?acc=GSE96058&file="
    "GSE96058_gene_expression_3273_samples_and_136_replicates_transformed.csv.gz"
    "&format=file"
)
SERIES_MATRIX_URLS = {
    "GPL11154": (
        "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE96nnn/GSE96058/"
        "matrix/GSE96058-GPL11154_series_matrix.txt.gz"
    ),
    "GPL18573": (
        "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE96nnn/GSE96058/"
        "matrix/GSE96058-GPL18573_series_matrix.txt.gz"
    ),
}


def setup_logging():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(RESUME_LOG, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def sha256_file(path: Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(chunk_size), b""):
            h.update(block)
    return h.hexdigest()


def parse_int_from_log(text: str, label: str) -> int:
    m = re.search(
        rf"^{re.escape(label)}:\s*([\d,]+)\s*$",
        text,
        flags=re.MULTILINE,
    )
    if not m:
        raise RuntimeError(f"Could not recover '{label}' from original CF11 log.")
    return int(m.group(1).replace(",", ""))


def parse_float_range_from_log(text: str, label: str):
    m = re.search(
        rf"^{re.escape(label)}:\s*([0-9.]+)\s*-\s*([0-9.]+)\s*$",
        text,
        flags=re.MULTILINE,
    )
    if not m:
        raise RuntimeError(f"Could not recover '{label}' from original CF11 log.")
    return float(m.group(1)), float(m.group(2))


def main():
    setup_logging()
    start = time.time()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF11 - RESUME + FINALIZE SCAN-B (V2)")
    logging.info("============================================================")
    logging.info("")
    logging.info("Estimated runtime: ~2-8 minutes")
    logging.info("The 564 MB GEO source will NOT be reprocessed.")
    logging.info("")

    # --------------------------------------------------------
    # 1. Validate completed expensive outputs
    # --------------------------------------------------------
    logging.info("[1/4] Validating completed stage-6 evidence...")
    logging.info("")

    required = [
        RAW_EXPRESSION,
        *RAW_SERIES_MATRICES.values(),
        PRIMARY_EXPRESSION,
        ALL_METADATA,
        REPLICATE_QC,
        ORIGINAL_LOG,
    ]
    for p in required:
        if not p.exists():
            raise FileNotFoundError(f"Required completed CF11 artifact missing: {p}")

    log_text = ORIGINAL_LOG.read_text(encoding="utf-8", errors="replace")

    if "Expression gzip complete-stream integrity: PASS" not in log_text:
        raise RuntimeError(
            "Original CF11 log does not contain the completed expression "
            "gzip-integrity PASS evidence."
        )

    gene_rows = parse_int_from_log(log_text, "Expression gene rows")
    duplicate_gene_ids = parse_int_from_log(log_text, "Duplicate gene identifiers")
    nonfinite_values = parse_int_from_log(log_text, "Non-finite expression values")
    negative_values = parse_int_from_log(log_text, "Negative transformed-expression values")
    logged_corr_min, logged_corr_max = parse_float_range_from_log(
        log_text, "Technical replicate Pearson range"
    )

    if gene_rows != EXPECTED_GENE_ROWS:
        raise RuntimeError(f"Recovered gene rows={gene_rows}; expected {EXPECTED_GENE_ROWS}.")
    if duplicate_gene_ids != EXPECTED_DUPLICATE_GENE_IDS:
        raise RuntimeError(
            f"Recovered duplicate gene IDs={duplicate_gene_ids}; expected 0."
        )
    if nonfinite_values != EXPECTED_NONFINITE:
        raise RuntimeError(
            f"Recovered non-finite values={nonfinite_values}; expected 0."
        )

    metadata = pd.read_csv(ALL_METADATA, sep="\t", dtype=str)
    repl_qc = pd.read_csv(REPLICATE_QC, sep="\t")

    if len(metadata) != EXPECTED_TOTAL_GEO_SAMPLES:
        raise RuntimeError(
            f"Metadata rows={len(metadata)}; expected {EXPECTED_TOTAL_GEO_SAMPLES}."
        )

    repl_flag = (
        metadata["is_technical_replicate"]
        .astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes"])
    )
    n_repl = int(repl_flag.sum())
    n_primary = int((~repl_flag).sum())

    if n_repl != EXPECTED_TECHNICAL_REPLICATES:
        raise RuntimeError(
            f"Technical replicates={n_repl}; expected {EXPECTED_TECHNICAL_REPLICATES}."
        )
    if n_primary != EXPECTED_PRIMARY_SAMPLES:
        raise RuntimeError(
            f"Primary samples={n_primary}; expected {EXPECTED_PRIMARY_SAMPLES}."
        )
    if len(repl_qc) != EXPECTED_TECHNICAL_REPLICATES:
        raise RuntimeError(
            f"Replicate QC rows={len(repl_qc)}; expected {EXPECTED_TECHNICAL_REPLICATES}."
        )

    header = pd.read_csv(
        PRIMARY_EXPRESSION,
        sep="\t",
        compression="gzip",
        nrows=0,
    )
    primary_expression_columns = len(header.columns) - 1
    if primary_expression_columns != EXPECTED_PRIMARY_SAMPLES:
        raise RuntimeError(
            f"Primary expression columns={primary_expression_columns}; "
            f"expected {EXPECTED_PRIMARY_SAMPLES}."
        )

    corrs = pd.to_numeric(repl_qc["pearson_expression"], errors="coerce")
    if corrs.isna().any():
        raise RuntimeError("Replicate QC contains missing/non-numeric correlations.")

    corr_min = float(corrs.min())
    corr_median = float(corrs.median())
    corr_max = float(corrs.max())
    low_corr_n = int((corrs < REPLICATE_REVIEW_CORRELATION).sum())

    # Cross-check computed correlation range against original log, allowing
    # rounding in the logged values.
    if abs(corr_min - logged_corr_min) > 0.00015 or abs(corr_max - logged_corr_max) > 0.00015:
        raise RuntimeError(
            "Replicate correlation range does not reconcile with original CF11 log."
        )

    logging.info(f"GEO metadata rows: {len(metadata)}")
    logging.info(f"Primary samples: {n_primary}")
    logging.info(f"Technical replicates: {n_repl}")
    logging.info(f"Primary expression columns: {primary_expression_columns}")
    logging.info(f"Expression gene rows recovered from log: {gene_rows}")
    logging.info(f"Replicate Pearson median: {corr_median:.4f}")
    logging.info(f"Replicate pairs below r<0.90: {low_corr_n}")
    logging.info("")

    # --------------------------------------------------------
    # 2. Reconstruct missing expression-QC table + freeze metadata
    # --------------------------------------------------------
    logging.info("[2/4] Reconstructing missing compact QC table and freezing metadata...")
    logging.info("")

    expression_qc = pd.DataFrame(
        [
            ("GEO accession", "GSE96058"),
            ("Expression gene rows", gene_rows),
            ("Expression sample columns total", EXPECTED_TOTAL_GEO_SAMPLES),
            ("Primary sample columns frozen", primary_expression_columns),
            ("Technical replicate columns excluded", n_repl),
            ("Duplicate gene identifiers", duplicate_gene_ids),
            ("Non-finite expression values", nonfinite_values),
            ("Negative transformed-expression values", negative_values),
            ("Replicate Pearson minimum", corr_min),
            ("Replicate Pearson median", corr_median),
            ("Replicate Pearson maximum", corr_max),
            ("Replicate pairs below r<0.90", low_corr_n),
            ("Expression gzip complete-stream integrity", "PASS"),
        ],
        columns=["metric", "value"],
    )
    expression_qc.to_csv(EXPRESSION_QC, sep="\t", index=False)

    primary_meta = metadata.loc[~repl_flag].copy()
    primary_meta["CF11_include"] = True
    primary_meta["CF11_reason"] = "GEO-designated primary sample"

    if primary_meta["sample_title"].duplicated().any():
        raise RuntimeError("Duplicate primary sample titles found.")

    primary_meta.to_csv(PRIMARY_METADATA, sep="\t", index=False)

    logging.info("CF11_expression_qc.tsv reconstructed from completed evidence.")
    logging.info(f"Primary metadata frozen: {len(primary_meta)} rows")
    logging.info("")

    # --------------------------------------------------------
    # 3. Fixed metadata completeness audit
    # --------------------------------------------------------
    logging.info("[3/4] Writing fixed metadata completeness audit...")
    logging.info("")

    field_rows = []
    for col in metadata.columns:
        s = metadata[col]
        present = s.notna() & s.astype(str).str.strip().ne("")
        known = int(present.sum())
        field_rows.append(
            {
                "field": col,
                "known_n": known,
                "missing_n": int(len(metadata) - known),
                "known_percent": round(100 * known / len(metadata), 2),
                "unique_nonmissing_values": int(
                    s.loc[present].astype(str).nunique()
                ),
            }
        )

    pd.DataFrame(field_rows).to_csv(
        RESULTS_DIR / "CF11_metadata_field_audit.tsv",
        sep="\t",
        index=False,
    )
    logging.info(f"Metadata fields audited: {len(field_rows)}")
    logging.info("")

    # --------------------------------------------------------
    # 4. Final summary/provenance
    # --------------------------------------------------------
    logging.info("[4/4] Writing final summary and provenance...")
    logging.info("")

    # Hash only source + reusable processed outputs. No decompression/rebuild.
    raw_expression_sha = sha256_file(RAW_EXPRESSION)
    raw_series_sha = {
        key: sha256_file(path) for key, path in RAW_SERIES_MATRICES.items()
    }
    primary_expression_sha = sha256_file(PRIMARY_EXPRESSION)
    primary_metadata_sha = sha256_file(PRIMARY_METADATA)

    runtime_min = (time.time() - start) / 60

    summary = pd.DataFrame(
        [
            ("GEO accession", "GSE96058"),
            ("GEO sample records", len(metadata)),
            ("Primary biological samples", n_primary),
            ("Technical replicate libraries", n_repl),
            ("Expression gene rows", gene_rows),
            ("Primary expression columns", primary_expression_columns),
            ("Duplicate gene identifiers", duplicate_gene_ids),
            ("Non-finite expression values", nonfinite_values),
            ("Negative transformed-expression values", negative_values),
            ("Replicate Pearson minimum", corr_min),
            ("Replicate Pearson median", corr_median),
            ("Replicate Pearson maximum", corr_max),
            ("Replicate pairs below r<0.90", low_corr_n),
            ("Technical replicates retained in independent cohort", 0),
            ("Primary ML endpoint selected", "NO"),
            ("CF11 resume/finalize runtime minutes", round(runtime_min, 2)),
            ("CF11 stage gate", "PASS"),
        ],
        columns=["metric", "value"],
    )
    summary.to_csv(RESULTS_DIR / "CF11_summary.tsv", sep="\t", index=False)

    provenance = pd.DataFrame(
        [
            ("code_file", "CF11_resume_finalize_v2.py"),
            ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
            ("GEO_accession", "GSE96058"),
            ("expression_source_url", EXPRESSION_URL),
            ("series_matrix_source_urls", json.dumps(SERIES_MATRIX_URLS, sort_keys=True)),
            ("raw_expression_sha256", raw_expression_sha),
            ("raw_series_matrix_sha256", json.dumps(raw_series_sha, sort_keys=True)),
            ("primary_expression_sha256", primary_expression_sha),
            ("primary_metadata_sha256", primary_metadata_sha),
            (
                "stage6_recovery_evidence",
                "Original CF11 log + CF11_technical_replicate_qc.tsv + "
                "already-written primary-expression header",
            ),
            ("expression_gene_rows", gene_rows),
            ("primary_expression_columns", primary_expression_columns),
            (
                "replicate_policy",
                "GEO-designated primary retained; repl libraries excluded "
                "from independent validation cohort but retained as QC evidence",
            ),
            (
                "replicate_correlation_role",
                "descriptive QC only; no correlation-based sample selection",
            ),
            (
                "expression_transform",
                "as deposited by GSE96058; negative transformed values allowed",
            ),
            ("gene_harmonization_to_TCGA", "NOT_PERFORMED_CF13"),
            ("ML_training_or_tuning", "NONE"),
            ("python_version", sys.version.replace("\n", " ")),
            ("pandas_version", pd.__version__),
            ("numpy_version", np.__version__),
            ("platform", platform.platform()),
            ("CF11_stage_gate", "PASS"),
        ],
        columns=["field", "value"],
    )
    provenance.to_csv(
        RESULTS_DIR / "CF11_provenance.tsv",
        sep="\t",
        index=False,
    )

    logging.info("============================================================")
    logging.info(" CF11 COMPLETE - SCAN-B ACQUISITION/QC GATE PASSED")
    logging.info("============================================================")
    logging.info("")
    logging.info(f"GEO sample records: {len(metadata)}")
    logging.info(f"Primary biological samples frozen: {n_primary}")
    logging.info(f"Technical replicate libraries excluded: {n_repl}")
    logging.info(f"Expression gene rows: {gene_rows}")
    logging.info(f"Duplicate gene identifiers: {duplicate_gene_ids}")
    logging.info(f"Non-finite expression values: {nonfinite_values}")
    logging.info(f"Replicate Pearson range: {corr_min:.4f} - {corr_max:.4f}")
    logging.info(f"Replicate Pearson median: {corr_median:.4f}")
    logging.info(f"Replicate pairs below r<0.90: {low_corr_n}")
    logging.info(f"Resume/finalize runtime: {runtime_min:.1f} min")
    logging.info("")
    logging.info("CF11 is ready to freeze.")
    logging.info("No TCGA-SCAN-B harmonization or ML was performed.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF11 RESUME V2 ERROR: {exc}")
        sys.exit(1)