"""
============================================================
CF24 - FINAL RESEARCH ARTIFACT CONSOLIDATION
============================================================

Purpose:
    Collect all important figures and important result files
    from CF1-CF23 into one final publication archive.

Rules:
    - NO analysis
    - NO ML
    - NO modification of results
    - Only copy existing artifacts

Output:

results/
└── CF24_final_archive/
    |
    ├── ALL_FIGURES/
    |       all unique figures (png/pdf/jpg)
    |
    └── IMPORTANT_RESULTS/
            selected important tables/results

============================================================
"""

import os
import shutil
import hashlib
import time


BASE = r"D:\Masters\Research\TCGA_BRCA"

RESULTS = os.path.join(BASE, "results")

OUT = os.path.join(
    RESULTS,
    "CF24_final_archive"
)

FIG_OUT = os.path.join(
    OUT,
    "ALL_FIGURES"
)

RESULT_OUT = os.path.join(
    OUT,
    "IMPORTANT_RESULTS"
)

os.makedirs(FIG_OUT, exist_ok=True)
os.makedirs(RESULT_OUT, exist_ok=True)


# Files considered important for manuscript/reproducibility
IMPORTANT_KEYWORDS = [
    "summary",
    "metric",
    "performance",
    "prediction",
    "gene",
    "signature",
    "enrichment",
    "pathway",
    "validation",
    "apollo",
    "scanb",
    "provenance",
    "qc",
    "model",
    "cohort"
]

FIG_EXT = [
    ".png",
    ".pdf",
    ".jpg",
    ".jpeg",
    ".svg"
]

DATA_EXT = [
    ".csv",
    ".tsv",
    ".txt"
]


def file_hash(path):

    h = hashlib.md5()

    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)

    return h.hexdigest()


def collect_files():

    print("[1/4] Searching CF1-CF23 result folders...")

    seen_figures = set()
    seen_results = set()

    figure_count = 0
    result_count = 0

    for root, dirs, files in os.walk(RESULTS):

        # avoid copying CF24 into itself
        if OUT in root:
            continue

        for file in files:

            path = os.path.join(root, file)

            ext = os.path.splitext(file)[1].lower()

            try:
                h = file_hash(path)
            except:
                continue


            if ext in FIG_EXT:

                if h in seen_figures:
                    continue

                seen_figures.add(h)

                target = os.path.join(
                    FIG_OUT,
                    file
                )

                # avoid name collision
                if os.path.exists(target):
                    base, extension = os.path.splitext(file)
                    target = os.path.join(
                        FIG_OUT,
                        base + "_" + h[:8] + extension
                    )

                shutil.copy2(path, target)
                figure_count += 1


            elif ext in DATA_EXT:

                lower = file.lower()

                if not any(
                    k in lower
                    for k in IMPORTANT_KEYWORDS
                ):
                    continue

                if h in seen_results:
                    continue

                seen_results.add(h)

                target = os.path.join(
                    RESULT_OUT,
                    file
                )

                if os.path.exists(target):
                    base, extension = os.path.splitext(file)
                    target = os.path.join(
                        RESULT_OUT,
                        base + "_" + h[:8] + extension
                    )

                shutil.copy2(path, target)
                result_count += 1


    return figure_count, result_count


def write_manifest(fig_count, result_count):

    print("[3/4] Writing archive manifest...")

    manifest = os.path.join(
        OUT,
        "CF24_manifest.txt"
    )

    with open(manifest, "w", encoding="utf-8") as f:

        f.write(
            "CF24 FINAL RESEARCH ARCHIVE\n\n"
        )

        f.write(
            f"Figures collected: {fig_count}\n"
        )

        f.write(
            f"Important result files collected: {result_count}\n"
        )

        f.write(
            "\nContains artifacts from CF1-CF23.\n"
        )


def main():

    start = time.time()

    print("""
============================================================
CF24 - FINAL RESEARCH ARTIFACT CONSOLIDATION
============================================================
Collecting figures and important result files only.
============================================================
""")

    figures, results = collect_files()

    print("[2/4] Files copied")

    write_manifest(
        figures,
        results
    )

    print("[4/4] Complete")

    print("""
============================================================
CF24 COMPLETE
============================================================
""")

    print("Figures:", figures)
    print("Important result files:", results)
    print("Output:")
    print(OUT)
    print(
        "Runtime:",
        round((time.time()-start)/60,2),
        "min"
    )


if __name__ == "__main__":
    main()
