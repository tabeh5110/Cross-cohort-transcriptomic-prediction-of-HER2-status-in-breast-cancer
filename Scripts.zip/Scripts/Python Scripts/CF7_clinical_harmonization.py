#!/usr/bin/env python
"""
CF7 - TCGA-BRCA Clinical Harmonization

Goal
----
Create a trustworthy, auditable patient-level clinical phenotype table for the
frozen CF6 cohort, without selecting the final ML target.

Evidence sources
----------------
1. GDC harmonized Cases API:
   demographic, diagnoses, follow-ups.
2. GDC open-access TCGA BCR Clinical Supplement XML:
   ER, PR, HER2 IHC and HER2 ISH/FISH fields when available.

Scientific principles
---------------------
- CF6 cohort membership is immutable here.
- No expression data are changed.
- No ML target is locked.
- No missing clinical value is imputed.
- Multiple diagnosis records are harmonized by consensus; conflicting values
  are flagged rather than arbitrarily choosing one record.
- Receptor conflicts are flagged and set to Unknown rather than forced.
- TNBC is defined conservatively only when ER, PR and harmonized HER2 are all
  definitively Negative; "Not TNBC" requires all three definitive with at least
  one Positive. Otherwise TNBC remains Unknown.
- Overall-survival variables are constructed conservatively from vital status,
  days_to_death, diagnosis days_to_last_follow_up, and follow-up
  days_to_follow_up. No survival modelling is performed in CF7.

Processed outputs
-----------------
data/processed/tcga_brca/clinical/
  CF7_patient_phenotypes.tsv
  CF7_sample_phenotypes.tsv

Raw/source cache
----------------
data/raw/tcga_brca/clinical/
  CF7_gdc_cases_raw.json
  CF7_gdc_clinical_files_manifest.tsv
  bcr_xml/<file_uuid>/<filename>

Formal results
--------------
results/CF7_clinical_harmonization/
  CF7_bcr_xml_download_integrity.tsv
  CF7_conflict_audit.tsv
  CF7_field_completeness.tsv
  CF7_receptor_status_distribution.tsv
  CF7_endpoint_usability.tsv
  CF7_summary.tsv
  CF7_provenance.tsv

Log
---
logs/CF7_clinical_harmonization.log
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import platform
import re
import sys
import time
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path.cwd()

CF6_DIR = PROJECT_ROOT / "results" / "CF6_expression_matrix_construction"
CF6_SUMMARY = CF6_DIR / "CF6_summary.tsv"
CF6_PROVENANCE = CF6_DIR / "CF6_provenance.tsv"
CF6_SAMPLE_MANIFEST = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "tcga_brca"
    / "expression"
    / "CF6_final_sample_manifest.tsv"
)

RAW_DIR = PROJECT_ROOT / "data" / "raw" / "tcga_brca" / "clinical"
XML_DIR = RAW_DIR / "bcr_xml"

PROCESSED_DIR = PROJECT_ROOT / "data" / "processed" / "tcga_brca" / "clinical"
OUTPUT_DIR = PROJECT_ROOT / "results" / "CF7_clinical_harmonization"
LOG_DIR = PROJECT_ROOT / "logs"
LOG_FILE = LOG_DIR / "CF7_clinical_harmonization.log"

GDC_API = "https://api.gdc.cancer.gov"
PROJECT_ID = "TCGA-BRCA"
EXPECTED_GDC_RELEASE_PREFIX = "Data Release 46.0"

HTTP_TIMEOUT = 90
MAX_WORKERS = 4

UNKNOWN_TOKENS = {
    "",
    "na",
    "n/a",
    "nan",
    "none",
    "null",
    "unknown",
    "not reported",
    "not available",
    "not applicable",
    "not evaluated",
    "[not available]",
    "[not applicable]",
    "--",
}

# Exact/known TCGA BCR XML local tag names for breast receptor information.
ER_XML_TAGS = {
    "breast_carcinoma_estrogen_receptor_status",
}
PR_XML_TAGS = {
    "breast_carcinoma_progesterone_receptor_status",
}
HER2_IHC_XML_TAGS = {
    "lab_proc_her2_neu_immunohistochemistry_receptor_status",
}
HER2_ISH_XML_TAGS = {
    "lab_procedure_her2_neu_in_situ_hybrid_outcome_type",
}

CORE_DIAGNOSIS_FIELDS = [
    "age_at_diagnosis",
    "ajcc_pathologic_stage",
    "ajcc_pathologic_t",
    "ajcc_pathologic_n",
    "ajcc_pathologic_m",
    "ajcc_clinical_stage",
    "ajcc_staging_system_edition",
    "primary_diagnosis",
    "morphology",
    "tissue_or_organ_of_origin",
    "laterality",
    "tumor_grade",
    "classification_of_tumor",
    "diagnosis_is_primary_disease",
    "prior_malignancy",
    "prior_treatment",
    "progression_or_recurrence",
    "days_to_recurrence",
    "last_known_disease_status",
]

DEMOGRAPHIC_FIELDS = [
    "age_at_index",
    "sex_at_birth",
    "race",
    "ethnicity",
    "vital_status",
    "days_to_birth",
    "days_to_death",
    "year_of_birth",
    "year_of_death",
]


# ============================================================
# UTILITIES
# ============================================================

def setup_logging() -> None:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    XML_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def load_metric_table(path: Path) -> Dict[str, str]:
    df = pd.read_csv(path, sep="\t", dtype=str)
    if {"metric", "value"}.issubset(df.columns):
        return dict(zip(df["metric"].astype(str), df["value"].astype(str)))
    if {"field", "value"}.issubset(df.columns):
        return dict(zip(df["field"].astype(str), df["value"].astype(str)))
    return {}


def hash_file(path: Path, algo: str = "sha256", chunk: int = 8 * 1024 * 1024) -> str:
    h = hashlib.new(algo)
    with path.open("rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def md5_file(path: Path) -> str:
    return hash_file(path, "md5")


def clean_scalar(value: Any) -> Optional[str]:
    if value is None:
        return None
    s = str(value).strip()
    if s.lower() in UNKNOWN_TOKENS:
        return None
    return s


def safe_float(value: Any) -> Optional[float]:
    v = clean_scalar(value)
    if v is None:
        return None
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def make_session() -> requests.Session:
    retry = Retry(
        total=8,
        connect=8,
        read=8,
        status=8,
        backoff_factor=1.0,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET", "POST"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=8, pool_maxsize=8)
    s = requests.Session()
    s.mount("https://", adapter)
    s.headers.update({"User-Agent": "TCGA-BRCA-CF7/1.0"})
    return s


def get_json(session: requests.Session, url: str, params: Optional[dict] = None) -> dict:
    r = session.get(url, params=params, timeout=HTTP_TIMEOUT)
    r.raise_for_status()
    return r.json()


def local_tag(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def consensus_text(values: Iterable[Any]) -> Tuple[Optional[str], bool, str]:
    cleaned = [clean_scalar(v) for v in values]
    cleaned = [v for v in cleaned if v is not None]
    unique = sorted(set(cleaned), key=lambda x: x.lower())
    if len(unique) == 0:
        return None, False, ""
    if len(unique) == 1:
        return unique[0], False, unique[0]
    return None, True, " | ".join(unique)


def consensus_numeric(values: Iterable[Any]) -> Tuple[Optional[float], bool, str]:
    nums = [safe_float(v) for v in values]
    nums = [x for x in nums if x is not None]
    unique = sorted(set(nums))
    if not unique:
        return None, False, ""
    if len(unique) == 1:
        return unique[0], False, str(unique[0])
    return None, True, " | ".join(str(x) for x in unique)


def max_numeric(values: Iterable[Any]) -> Optional[float]:
    nums = [safe_float(v) for v in values]
    nums = [x for x in nums if x is not None]
    return max(nums) if nums else None


def normalize_receptor(value: Any) -> str:
    s = clean_scalar(value)
    if s is None:
        return "Unknown"
    low = s.lower().strip()

    positive = {"positive", "pos", "3+", "amplified"}
    negative = {"negative", "neg", "0", "0+", "1+", "not amplified"}
    equivocal = {"equivocal", "2+", "borderline"}
    indeterminate = {"indeterminate", "inconclusive", "cannot be determined"}

    if low in positive:
        return "Positive"
    if low in negative:
        return "Negative"
    if low in equivocal:
        return "Equivocal"
    if low in indeterminate:
        return "Indeterminate"

    if "positive" in low or "amplified" == low:
        return "Positive"
    if "negative" in low or "not amplified" in low:
        return "Negative"
    if "equivocal" in low:
        return "Equivocal"
    if "indeterminate" in low or "inconclusive" in low:
        return "Indeterminate"

    return "Unknown"


def harmonize_receptor_values(values: Sequence[str]) -> Tuple[str, bool, str]:
    normalized = [normalize_receptor(v) for v in values]
    informative = [x for x in normalized if x != "Unknown"]
    distinct = sorted(set(informative))

    definitive = sorted(set(x for x in informative if x in {"Positive", "Negative"}))
    if len(definitive) > 1:
        return "Unknown", True, " | ".join(sorted(set(values)))

    if len(definitive) == 1:
        return definitive[0], False, " | ".join(sorted(set(values)))

    if "Equivocal" in informative:
        return "Equivocal", False, " | ".join(sorted(set(values)))
    if "Indeterminate" in informative:
        return "Indeterminate", False, " | ".join(sorted(set(values)))
    return "Unknown", False, " | ".join(sorted(set(values)))


def harmonize_her2(ihc: str, ish: str) -> Tuple[str, str]:
    # Definitive ISH/FISH result takes precedence when available.
    if ish in {"Positive", "Negative"}:
        return ish, "definitive_ISH"
    if ihc in {"Positive", "Negative"}:
        return ihc, "definitive_IHC"
    if "Equivocal" in {ihc, ish}:
        return "Equivocal", "equivocal_no_definitive_result"
    if "Indeterminate" in {ihc, ish}:
        return "Indeterminate", "indeterminate_no_definitive_result"
    return "Unknown", "no_definitive_result"


def derive_tnbc(er: str, pr: str, her2: str) -> str:
    vals = [er, pr, her2]
    if all(v == "Negative" for v in vals):
        return "TNBC"
    if all(v in {"Positive", "Negative"} for v in vals) and any(v == "Positive" for v in vals):
        return "Not_TNBC"
    return "Unknown"


def simplify_stage(stage: Any) -> Optional[str]:
    s = clean_scalar(stage)
    if s is None:
        return None
    u = s.upper().replace("STAGE", "").strip()
    # Match stage group while allowing substages such as IA, IIB, IIIA, etc.
    for group in ("IV", "III", "II", "I"):
        if u.startswith(group):
            return group
    return None


# ============================================================
# GDC CORE CLINICAL
# ============================================================

def fetch_gdc_status(session: requests.Session) -> dict:
    return get_json(session, f"{GDC_API}/status")


def fetch_cases(session: requests.Session) -> List[dict]:
    filters = {
        "op": "in",
        "content": {
            "field": "project.project_id",
            "value": [PROJECT_ID],
        },
    }
    params = {
        "filters": json.dumps(filters),
        "expand": "demographic,diagnoses,follow_ups",
        "size": 2000,
    }
    payload = get_json(session, f"{GDC_API}/cases", params=params)
    return payload["data"]["hits"]


def fetch_clinical_file_manifest(session: requests.Session) -> pd.DataFrame:
    filters = {
        "op": "and",
        "content": [
            {
                "op": "in",
                "content": {"field": "cases.project.project_id", "value": [PROJECT_ID]},
            },
            {
                "op": "in",
                "content": {"field": "data_category", "value": ["Clinical"]},
            },
            {
                "op": "in",
                "content": {"field": "data_type", "value": ["Clinical Supplement"]},
            },
            {
                "op": "in",
                "content": {"field": "data_format", "value": ["BCR XML"]},
            },
            {
                "op": "in",
                "content": {"field": "access", "value": ["open"]},
            },
        ],
    }

    params = {
        "filters": json.dumps(filters),
        "fields": (
            "file_id,file_name,md5sum,file_size,state,updated_datetime,"
            "cases.submitter_id"
        ),
        "size": 3000,
    }
    payload = get_json(session, f"{GDC_API}/files", params=params)
    hits = payload["data"]["hits"]

    rows = []
    for h in hits:
        cases = h.get("cases", []) or []
        for c in cases:
            rows.append(
                {
                    "patient_id": c.get("submitter_id"),
                    "file_id": h.get("file_id"),
                    "file_name": h.get("file_name"),
                    "md5sum": h.get("md5sum"),
                    "file_size": h.get("file_size"),
                    "state": h.get("state"),
                    "updated_datetime": h.get("updated_datetime"),
                }
            )
    return pd.DataFrame(rows)


# ============================================================
# BCR XML DOWNLOAD / PARSING
# ============================================================

def download_one_xml(row: dict) -> dict:
    file_id = str(row["file_id"])
    file_name = str(row["file_name"])
    expected_md5 = str(row["md5sum"]).lower()
    expected_size = int(row["file_size"])

    folder = XML_DIR / file_id
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / file_name

    def local_ok() -> bool:
        return (
            path.exists()
            and path.stat().st_size == expected_size
            and md5_file(path).lower() == expected_md5
        )

    if local_ok():
        return {
            **row,
            "local_path": str(path.resolve()),
            "download_status": "CACHED_VALID",
            "size_match": True,
            "md5_match": True,
        }

    tmp = path.with_suffix(path.suffix + ".partial")
    if tmp.exists():
        tmp.unlink()

    session = make_session()
    url = f"{GDC_API}/data/{file_id}"
    last_error = ""

    for attempt in range(1, 7):
        try:
            with session.get(url, stream=True, timeout=HTTP_TIMEOUT) as r:
                r.raise_for_status()
                with tmp.open("wb") as out:
                    for chunk in r.iter_content(chunk_size=1024 * 1024):
                        if chunk:
                            out.write(chunk)

            size_match = tmp.stat().st_size == expected_size
            md5_match = md5_file(tmp).lower() == expected_md5

            if size_match and md5_match:
                if path.exists():
                    path.unlink()
                tmp.replace(path)
                return {
                    **row,
                    "local_path": str(path.resolve()),
                    "download_status": "DOWNLOADED_VALID",
                    "size_match": True,
                    "md5_match": True,
                }

            last_error = f"integrity mismatch size={size_match}, md5={md5_match}"
            tmp.unlink(missing_ok=True)

        except Exception as exc:
            last_error = repr(exc)
            tmp.unlink(missing_ok=True)
            time.sleep(min(20, attempt * 2))

    return {
        **row,
        "local_path": str(path.resolve()),
        "download_status": "FAILED",
        "size_match": False,
        "md5_match": False,
        "error": last_error,
    }


def extract_xml_values(path: Path) -> Dict[str, List[str]]:
    tree = ET.parse(path)
    root = tree.getroot()
    out = {"er": [], "pr": [], "her2_ihc": [], "her2_ish": []}

    for elem in root.iter():
        tag = local_tag(elem.tag)
        value = clean_scalar(elem.text)
        if value is None:
            continue

        if tag in ER_XML_TAGS:
            out["er"].append(value)
        elif tag in PR_XML_TAGS:
            out["pr"].append(value)
        elif tag in HER2_IHC_XML_TAGS:
            out["her2_ihc"].append(value)
        elif tag in HER2_ISH_XML_TAGS:
            out["her2_ish"].append(value)

    return out


def combine_xml_for_patient(paths: Sequence[Path]) -> dict:
    pooled = {"er": [], "pr": [], "her2_ihc": [], "her2_ish": []}
    parse_errors = []

    for path in paths:
        try:
            vals = extract_xml_values(path)
            for k in pooled:
                pooled[k].extend(vals[k])
        except Exception as exc:
            parse_errors.append(f"{path.name}: {exc}")

    er, er_conflict, er_raw = harmonize_receptor_values(pooled["er"])
    pr, pr_conflict, pr_raw = harmonize_receptor_values(pooled["pr"])
    ihc, ihc_conflict, ihc_raw = harmonize_receptor_values(pooled["her2_ihc"])
    ish, ish_conflict, ish_raw = harmonize_receptor_values(pooled["her2_ish"])

    her2, her2_basis = harmonize_her2(ihc, ish)

    # Cross-method HER2 conflict: definitive IHC and ISH disagree.
    cross_her2_conflict = (
        ihc in {"Positive", "Negative"}
        and ish in {"Positive", "Negative"}
        and ihc != ish
    )
    if cross_her2_conflict:
        her2 = "Unknown"
        her2_basis = "IHC_ISH_conflict"

    return {
        "er_status": er,
        "pr_status": pr,
        "her2_ihc_status": ihc,
        "her2_ish_status": ish,
        "her2_status": her2,
        "her2_harmonization_basis": her2_basis,
        "tnbc_status": derive_tnbc(er, pr, her2),
        "er_raw_values": er_raw,
        "pr_raw_values": pr_raw,
        "her2_ihc_raw_values": ihc_raw,
        "her2_ish_raw_values": ish_raw,
        "er_conflict": er_conflict,
        "pr_conflict": pr_conflict,
        "her2_ihc_conflict": ihc_conflict,
        "her2_ish_conflict": ish_conflict,
        "her2_cross_method_conflict": cross_her2_conflict,
        "xml_parse_error": " | ".join(parse_errors),
    }


# ============================================================
# CASE HARMONIZATION
# ============================================================

def diagnosis_values(diagnoses: Sequence[dict], field: str) -> List[Any]:
    return [d.get(field) for d in diagnoses if isinstance(d, dict)]


def harmonize_case(case: dict) -> dict:
    patient_id = case.get("submitter_id")
    demographic = case.get("demographic") or {}
    diagnoses = case.get("diagnoses") or []
    follow_ups = case.get("follow_ups") or []

    row: Dict[str, Any] = {
        "patient_id": patient_id,
        "case_id": case.get("case_id"),
        "diagnosis_record_count": len(diagnoses),
        "followup_record_count": len(follow_ups),
    }

    conflict_fields = []

    # Demographic fields are case-level scalars.
    for field in DEMOGRAPHIC_FIELDS:
        row[field] = clean_scalar(demographic.get(field))

    # Diagnosis fields: consensus, never arbitrary first-record selection.
    numeric_fields = {"age_at_diagnosis", "days_to_recurrence"}
    for field in CORE_DIAGNOSIS_FIELDS:
        vals = diagnosis_values(diagnoses, field)
        if field in numeric_fields:
            value, conflict, raw = consensus_numeric(vals)
        else:
            value, conflict, raw = consensus_text(vals)
        row[field] = value
        row[f"{field}_conflict"] = conflict
        if conflict:
            conflict_fields.append(field)

    # Diagnosis follow-up fields use latest valid time for censoring support.
    diagnosis_last_fu = max_numeric(
        diagnosis_values(diagnoses, "days_to_last_follow_up")
    )
    followup_last_fu = max_numeric(
        [x.get("days_to_follow_up") for x in follow_ups if isinstance(x, dict)]
    )

    fu_candidates = [x for x in [diagnosis_last_fu, followup_last_fu] if x is not None]
    max_follow_up = max(fu_candidates) if fu_candidates else None

    row["diagnosis_days_to_last_follow_up_max"] = diagnosis_last_fu
    row["followup_days_to_follow_up_max"] = followup_last_fu
    row["days_to_last_follow_up_harmonized"] = max_follow_up

    age_dx = safe_float(row.get("age_at_diagnosis"))
    row["age_at_diagnosis_years"] = (
        round(age_dx / 365.25, 4) if age_dx is not None else None
    )

    row["pathologic_stage_group"] = simplify_stage(row.get("ajcc_pathologic_stage"))

    vital = clean_scalar(row.get("vital_status"))
    days_death = safe_float(row.get("days_to_death"))

    if vital is not None and vital.lower() == "dead":
        row["os_event"] = 1
        row["os_days"] = days_death
        row["os_source"] = "demographic.days_to_death"
        if days_death is None:
            conflict_fields.append("dead_without_days_to_death")
    elif vital is not None and vital.lower() == "alive":
        row["os_event"] = 0
        row["os_days"] = max_follow_up
        row["os_source"] = "max(diagnosis/follow_up censoring)"
    else:
        row["os_event"] = None
        row["os_days"] = None
        row["os_source"] = "unresolved_vital_status"

    row["diagnosis_conflict_any"] = bool(conflict_fields)
    row["diagnosis_conflict_fields"] = ";".join(sorted(set(conflict_fields)))

    return row


# ============================================================
# AUDITS
# ============================================================

def build_completeness(df: pd.DataFrame, fields: Sequence[str]) -> pd.DataFrame:
    rows = []
    n = len(df)
    for field in fields:
        if field not in df.columns:
            continue
        s = df[field]
        known = int(s.notna().sum())
        rows.append(
            {
                "field": field,
                "known_n": known,
                "missing_n": n - known,
                "known_percent": round(100 * known / n, 2) if n else 0,
                "unique_nonmissing_values": int(s.dropna().astype(str).nunique()),
            }
        )
    return pd.DataFrame(rows)


def status_distribution(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for field in [
        "er_status",
        "pr_status",
        "her2_ihc_status",
        "her2_ish_status",
        "her2_status",
        "tnbc_status",
    ]:
        counts = df[field].fillna("Unknown").value_counts(dropna=False)
        for value, count in counts.items():
            rows.append(
                {
                    "field": field,
                    "value": value,
                    "n": int(count),
                    "percent": round(100 * count / len(df), 2),
                }
            )
    return pd.DataFrame(rows)


def endpoint_usability(df: pd.DataFrame) -> pd.DataFrame:
    configs = {
        "ER": ("er_status", {"Positive", "Negative"}),
        "PR": ("pr_status", {"Positive", "Negative"}),
        "HER2": ("her2_status", {"Positive", "Negative"}),
        "TNBC": ("tnbc_status", {"TNBC", "Not_TNBC"}),
    }
    rows = []
    for endpoint, (field, definitive) in configs.items():
        s = df[field].astype(str)
        usable = s.isin(definitive)
        counts = s[usable].value_counts().to_dict()
        vals = sorted(counts.values())
        rows.append(
            {
                "endpoint": endpoint,
                "source_field": field,
                "definitive_n": int(usable.sum()),
                "unknown_or_ambiguous_n": int((~usable).sum()),
                "coverage_percent": round(100 * usable.mean(), 2),
                "class_counts_json": json.dumps(counts, sort_keys=True),
                "minority_class_n": int(vals[0]) if vals else 0,
                "CF7_status": "AUDIT_ONLY_NOT_LOCKED",
            }
        )
    return pd.DataFrame(rows)


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    setup_logging()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF7 - CLINICAL HARMONIZATION")
    logging.info("============================================================")
    logging.info("")

    # --------------------------------------------------------
    # 1. Validate frozen CF6 cohort
    # --------------------------------------------------------
    logging.info("[1/10] Validating frozen CF6 cohort...")
    logging.info("")

    for p in [CF6_SUMMARY, CF6_PROVENANCE, CF6_SAMPLE_MANIFEST]:
        if not p.exists():
            raise FileNotFoundError(f"Required CF6 input missing: {p}")

    cf6_summary = load_metric_table(CF6_SUMMARY)
    if cf6_summary.get("CF6 stage gate", "").upper() != "PASS":
        raise RuntimeError("CF6 stage gate is not PASS. CF7 is blocked.")

    samples = pd.read_csv(CF6_SAMPLE_MANIFEST, sep="\t", dtype=str)
    required = {"patient_id", "sample_id", "sample_type", "file_id"}
    missing = required.difference(samples.columns)
    if missing:
        raise RuntimeError(f"CF6 sample manifest missing columns: {sorted(missing)}")

    patient_ids = sorted(samples["patient_id"].dropna().unique().tolist())

    if len(samples) != 1206 or len(patient_ids) != 1094:
        logging.warning(
            f"CF6 cohort differs from prior expected dimensions: "
            f"samples={len(samples)}, patients={len(patient_ids)}"
        )

    logging.info(f"CF6 biological samples: {len(samples)}")
    logging.info(f"CF6 unique patients: {len(patient_ids)}")
    logging.info("")

    # --------------------------------------------------------
    # 2. GDC status
    # --------------------------------------------------------
    logging.info("[2/10] Verifying GDC API status and release...")
    logging.info("")

    session = make_session()
    status = fetch_gdc_status(session)
    release_text = str(
        status.get("data_release")
        or status.get("data_release_version")
        or status.get("version")
        or ""
    )
    status_text = str(status.get("status", ""))

    if status_text.upper() != "OK":
        raise RuntimeError(f"GDC API status is not OK: {status_text}")

    # Do not silently mix a different GDC release with the frozen cohort.
    if EXPECTED_GDC_RELEASE_PREFIX not in json.dumps(status):
        raise RuntimeError(
            "Current GDC release does not match frozen Data Release 46.0. "
            "Stop and review before mixing clinical data releases."
        )

    logging.info("GDC status: OK")
    logging.info(f"Frozen/current release compatibility: {EXPECTED_GDC_RELEASE_PREFIX} PASS")
    logging.info("")

    # --------------------------------------------------------
    # 3. Fetch harmonized GDC case data
    # --------------------------------------------------------
    logging.info("[3/10] Retrieving harmonized GDC case-level clinical data...")
    logging.info("")

    all_cases = fetch_cases(session)
    target_cases = [c for c in all_cases if c.get("submitter_id") in set(patient_ids)]
    found_ids = {c.get("submitter_id") for c in target_cases}

    missing_cases = sorted(set(patient_ids) - found_ids)
    if missing_cases:
        raise RuntimeError(
            f"{len(missing_cases)} frozen CF6 patient(s) missing from GDC cases endpoint: "
            f"{missing_cases[:10]}"
        )

    raw_cases_path = RAW_DIR / "CF7_gdc_cases_raw.json"
    raw_cases_path.write_text(
        json.dumps(target_cases, indent=2, sort_keys=True),
        encoding="utf-8",
    )

    logging.info(f"GDC TCGA-BRCA cases returned: {len(all_cases)}")
    logging.info(f"Frozen CF6 patients matched: {len(target_cases)}/{len(patient_ids)}")
    logging.info("")

    # --------------------------------------------------------
    # 4. Harmonize core clinical variables
    # --------------------------------------------------------
    logging.info("[4/10] Harmonizing demographics, diagnosis, stage, and follow-up...")
    logging.info("")

    patient_rows = [harmonize_case(c) for c in target_cases]
    patient_df = pd.DataFrame(patient_rows)

    if patient_df["patient_id"].duplicated().any():
        raise RuntimeError("Duplicate patient rows after GDC case harmonization.")

    logging.info(f"Patient-level core clinical rows: {len(patient_df)}")
    logging.info(
        f"Cases with diagnosis-field conflict flags: "
        f"{int(patient_df['diagnosis_conflict_any'].fillna(False).sum())}"
    )
    logging.info("")

    # --------------------------------------------------------
    # 5. Query BCR XML receptor source files
    # --------------------------------------------------------
    logging.info("[5/10] Querying GDC BCR Clinical Supplement XML files...")
    logging.info("")

    manifest = fetch_clinical_file_manifest(session)
    if manifest.empty:
        raise RuntimeError("No open TCGA-BRCA BCR XML Clinical Supplement files found.")

    manifest = manifest[manifest["patient_id"].isin(patient_ids)].copy()
    manifest = manifest.drop_duplicates(
        subset=["patient_id", "file_id"], keep="last"
    ).reset_index(drop=True)

    manifest_path = RAW_DIR / "CF7_gdc_clinical_files_manifest.tsv"
    manifest.to_csv(manifest_path, sep="\t", index=False)

    patients_with_xml_source = manifest["patient_id"].nunique()

    logging.info(f"BCR XML files linked to frozen cohort: {len(manifest)}")
    logging.info(
        f"Patients with >=1 BCR XML source file: "
        f"{patients_with_xml_source}/{len(patient_ids)}"
    )
    logging.info("")

    # --------------------------------------------------------
    # 6. Download/verify BCR XML source files
    # --------------------------------------------------------
    logging.info("[6/10] Downloading/verifying BCR XML clinical sources...")
    logging.info(
        f"Workers: {MAX_WORKERS}. Existing valid XML files are reused automatically."
    )
    logging.info("")

    rows = manifest.to_dict("records")
    integrity_results = []

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(download_one_xml, row): row for row in rows}
        for idx, future in enumerate(as_completed(futures), start=1):
            integrity_results.append(future.result())
            if idx % 100 == 0 or idx == len(futures):
                logging.info(f"BCR XML verified: {idx}/{len(futures)}")

    integrity_df = pd.DataFrame(integrity_results)
    integrity_out = OUTPUT_DIR / "CF7_bcr_xml_download_integrity.tsv"
    integrity_df.to_csv(integrity_out, sep="\t", index=False)

    valid_mask = (
        integrity_df["size_match"].astype(bool)
        & integrity_df["md5_match"].astype(bool)
        & integrity_df["download_status"].isin(["CACHED_VALID", "DOWNLOADED_VALID"])
    )

    if not valid_mask.all():
        bad = int((~valid_mask).sum())
        raise RuntimeError(
            f"{bad} BCR XML file(s) failed download/integrity validation. "
            "Rerun CF7 to resume only missing/invalid small clinical files."
        )

    logging.info("")
    logging.info(f"BCR XML integrity: {int(valid_mask.sum())}/{len(integrity_df)} PASS")
    logging.info("")

    # --------------------------------------------------------
    # 7. Parse receptor variables and merge
    # --------------------------------------------------------
    logging.info("[7/10] Harmonizing ER, PR, HER2, and conservative TNBC status...")
    logging.info("")

    patient_xml = {}
    grouped = integrity_df.groupby("patient_id", sort=False)

    for patient_id, grp in grouped:
        paths = [Path(x) for x in grp["local_path"].tolist()]
        patient_xml[patient_id] = combine_xml_for_patient(paths)

    receptor_rows = []
    for patient_id in patient_ids:
        vals = patient_xml.get(
            patient_id,
            {
                "er_status": "Unknown",
                "pr_status": "Unknown",
                "her2_ihc_status": "Unknown",
                "her2_ish_status": "Unknown",
                "her2_status": "Unknown",
                "her2_harmonization_basis": "no_BCR_XML",
                "tnbc_status": "Unknown",
                "er_raw_values": "",
                "pr_raw_values": "",
                "her2_ihc_raw_values": "",
                "her2_ish_raw_values": "",
                "er_conflict": False,
                "pr_conflict": False,
                "her2_ihc_conflict": False,
                "her2_ish_conflict": False,
                "her2_cross_method_conflict": False,
                "xml_parse_error": "",
            },
        )
        receptor_rows.append({"patient_id": patient_id, **vals})

    receptor_df = pd.DataFrame(receptor_rows)
    patient_df = patient_df.merge(
        receptor_df,
        on="patient_id",
        how="left",
        validate="one_to_one",
    )

    receptor_conflict_cols = [
        "er_conflict",
        "pr_conflict",
        "her2_ihc_conflict",
        "her2_ish_conflict",
        "her2_cross_method_conflict",
    ]
    patient_df["receptor_conflict_any"] = patient_df[receptor_conflict_cols].any(axis=1)

    logging.info(
        f"ER definitive: "
        f"{int(patient_df['er_status'].isin(['Positive','Negative']).sum())}/{len(patient_df)}"
    )
    logging.info(
        f"PR definitive: "
        f"{int(patient_df['pr_status'].isin(['Positive','Negative']).sum())}/{len(patient_df)}"
    )
    logging.info(
        f"HER2 definitive: "
        f"{int(patient_df['her2_status'].isin(['Positive','Negative']).sum())}/{len(patient_df)}"
    )
    logging.info(
        f"TNBC definitively classifiable: "
        f"{int(patient_df['tnbc_status'].isin(['TNBC','Not_TNBC']).sum())}/{len(patient_df)}"
    )
    logging.info("")

    # --------------------------------------------------------
    # 8. Save processed phenotype tables
    # --------------------------------------------------------
    logging.info("[8/10] Saving patient- and sample-level phenotype tables...")
    logging.info("")

    patient_df = patient_df.sort_values("patient_id").reset_index(drop=True)

    patient_out = PROCESSED_DIR / "CF7_patient_phenotypes.tsv"
    patient_df.to_csv(patient_out, sep="\t", index=False)

    sample_out = samples[
        ["patient_id", "sample_id", "sample_type", "file_id", "aliquot_barcode"]
    ].merge(
        patient_df,
        on="patient_id",
        how="left",
        validate="many_to_one",
    )

    if len(sample_out) != len(samples):
        raise RuntimeError("Sample-level phenotype merge changed CF6 sample count.")

    sample_out_path = PROCESSED_DIR / "CF7_sample_phenotypes.tsv"
    sample_out.to_csv(sample_out_path, sep="\t", index=False)

    logging.info(f"Patient phenotype rows: {len(patient_df)}")
    logging.info(f"Sample phenotype rows: {len(sample_out)}")
    logging.info("")

    # --------------------------------------------------------
    # 9. Audits, completeness, endpoint coverage
    # --------------------------------------------------------
    logging.info("[9/10] Writing clinical completeness and endpoint audit...")
    logging.info("")

    conflict_mask = (
        patient_df["diagnosis_conflict_any"].fillna(False)
        | patient_df["receptor_conflict_any"].fillna(False)
        | patient_df["xml_parse_error"].fillna("").ne("")
    )
    conflict_cols = [
        "patient_id",
        "diagnosis_record_count",
        "diagnosis_conflict_any",
        "diagnosis_conflict_fields",
        "er_conflict",
        "pr_conflict",
        "her2_ihc_conflict",
        "her2_ish_conflict",
        "her2_cross_method_conflict",
        "xml_parse_error",
    ]
    conflict_df = patient_df.loc[conflict_mask, conflict_cols].copy()
    conflict_df.to_csv(
        OUTPUT_DIR / "CF7_conflict_audit.tsv",
        sep="\t",
        index=False,
    )

    completeness_fields = [
        "age_at_diagnosis_years",
        "sex_at_birth",
        "race",
        "ethnicity",
        "vital_status",
        "ajcc_pathologic_stage",
        "pathologic_stage_group",
        "ajcc_pathologic_t",
        "ajcc_pathologic_n",
        "ajcc_pathologic_m",
        "primary_diagnosis",
        "morphology",
        "tumor_grade",
        "laterality",
        "days_to_last_follow_up_harmonized",
        "os_event",
        "os_days",
        "er_status",
        "pr_status",
        "her2_ihc_status",
        "her2_ish_status",
        "her2_status",
        "tnbc_status",
    ]
    completeness_df = build_completeness(patient_df, completeness_fields)
    completeness_df.to_csv(
        OUTPUT_DIR / "CF7_field_completeness.tsv",
        sep="\t",
        index=False,
    )

    receptor_dist = status_distribution(patient_df)
    receptor_dist.to_csv(
        OUTPUT_DIR / "CF7_receptor_status_distribution.tsv",
        sep="\t",
        index=False,
    )

    endpoint_df = endpoint_usability(patient_df)
    endpoint_df.to_csv(
        OUTPUT_DIR / "CF7_endpoint_usability.tsv",
        sep="\t",
        index=False,
    )

    # Summary
    summary_rows = [
        ("CF6 stage gate", "PASS"),
        ("Frozen CF6 biological samples", len(samples)),
        ("Frozen CF6 patients", len(patient_ids)),
        ("GDC patient cases matched", len(patient_df)),
        ("BCR XML source files", len(manifest)),
        ("Patients with BCR XML source", patients_with_xml_source),
        ("BCR XML integrity failures", int((~valid_mask).sum())),
        ("Diagnosis conflict patients", int(patient_df["diagnosis_conflict_any"].fillna(False).sum())),
        ("Receptor conflict patients", int(patient_df["receptor_conflict_any"].fillna(False).sum())),
        ("ER definitive patients", int(patient_df["er_status"].isin(["Positive", "Negative"]).sum())),
        ("PR definitive patients", int(patient_df["pr_status"].isin(["Positive", "Negative"]).sum())),
        ("HER2 definitive patients", int(patient_df["her2_status"].isin(["Positive", "Negative"]).sum())),
        ("TNBC classifiable patients", int(patient_df["tnbc_status"].isin(["TNBC", "Not_TNBC"]).sum())),
        ("Patients with OS event known", int(patient_df["os_event"].notna().sum())),
        ("Patients with OS time known", int(patient_df["os_days"].notna().sum())),
        ("Primary ML endpoint", "NOT_SELECTED_IN_CF7"),
        ("CF7 stage gate", "PASS"),
    ]
    pd.DataFrame(summary_rows, columns=["metric", "value"]).to_csv(
        OUTPUT_DIR / "CF7_summary.tsv",
        sep="\t",
        index=False,
    )

    provenance_rows = [
        ("code_file", "CF7_clinical_harmonization.py"),
        ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
        ("project_id", PROJECT_ID),
        ("gdc_api", GDC_API),
        ("gdc_release_required", EXPECTED_GDC_RELEASE_PREFIX),
        ("cf6_sample_manifest", str(CF6_SAMPLE_MANIFEST.resolve())),
        ("cf6_sample_manifest_sha256", hash_file(CF6_SAMPLE_MANIFEST)),
        ("cf6_summary_sha256", hash_file(CF6_SUMMARY)),
        ("cf6_provenance_sha256", hash_file(CF6_PROVENANCE)),
        ("gdc_cases_raw_sha256", hash_file(raw_cases_path)),
        ("gdc_clinical_manifest_sha256", hash_file(manifest_path)),
        ("patient_phenotypes_sha256", hash_file(patient_out)),
        ("sample_phenotypes_sha256", hash_file(sample_out_path)),
        ("receptor_source", "TCGA BCR Clinical Supplement XML from GDC"),
        ("HER2_rule", "definitive ISH > definitive IHC; disagreement => Unknown/conflict"),
        ("TNBC_rule", "ER Negative AND PR Negative AND HER2 Negative; otherwise definitive Not_TNBC only when all three definitive"),
        ("diagnosis_rule", "field-wise consensus; conflicts not arbitrarily resolved"),
        ("OS_rule", "Dead: days_to_death; Alive: max diagnosis/follow_up censoring time"),
        ("missing_value_rule", "no clinical imputation in CF7"),
        ("primary_ML_endpoint", "NOT_SELECTED_IN_CF7"),
        ("python_version", sys.version.replace("\n", " ")),
        ("pandas_version", pd.__version__),
        ("numpy_version", np.__version__),
        ("requests_version", requests.__version__),
        ("platform", platform.platform()),
        ("cf7_stage_gate", "PASS"),
    ]
    pd.DataFrame(provenance_rows, columns=["field", "value"]).to_csv(
        OUTPUT_DIR / "CF7_provenance.tsv",
        sep="\t",
        index=False,
    )

    logging.info(f"Conflict-audit patients: {len(conflict_df)}")
    logging.info("Primary ML endpoint remains: NOT SELECTED")
    logging.info("")

    # --------------------------------------------------------
    # 10. Final gate
    # --------------------------------------------------------
    logging.info("[10/10] Final CF7 stage gate...")
    logging.info("")
    logging.info("============================================================")
    logging.info(" CF7 COMPLETE - CLINICAL HARMONIZATION GATE PASSED")
    logging.info("============================================================")
    logging.info("")
    logging.info(f"Frozen biological samples: {len(samples)}")
    logging.info(f"Frozen patients: {len(patient_ids)}")
    logging.info(f"GDC patient cases matched: {len(patient_df)}")
    logging.info(f"BCR XML source files: {len(manifest)}")
    logging.info(f"Patients with BCR XML source: {patients_with_xml_source}")
    logging.info(f"Diagnosis conflict patients: {int(patient_df['diagnosis_conflict_any'].fillna(False).sum())}")
    logging.info(f"Receptor conflict patients: {int(patient_df['receptor_conflict_any'].fillna(False).sum())}")
    logging.info(f"ER definitive: {int(patient_df['er_status'].isin(['Positive','Negative']).sum())}")
    logging.info(f"PR definitive: {int(patient_df['pr_status'].isin(['Positive','Negative']).sum())}")
    logging.info(f"HER2 definitive: {int(patient_df['her2_status'].isin(['Positive','Negative']).sum())}")
    logging.info(f"TNBC classifiable: {int(patient_df['tnbc_status'].isin(['TNBC','Not_TNBC']).sum())}")
    logging.info(f"OS event known: {int(patient_df['os_event'].notna().sum())}")
    logging.info(f"OS time known: {int(patient_df['os_days'].notna().sum())}")
    logging.info("")
    logging.info("CF7 generated:")
    logging.info("  data/processed/tcga_brca/clinical/CF7_patient_phenotypes.tsv")
    logging.info("  data/processed/tcga_brca/clinical/CF7_sample_phenotypes.tsv")
    logging.info("  data/raw/tcga_brca/clinical/CF7_gdc_cases_raw.json")
    logging.info("  data/raw/tcga_brca/clinical/CF7_gdc_clinical_files_manifest.tsv")
    logging.info("  results/CF7_clinical_harmonization/CF7_bcr_xml_download_integrity.tsv")
    logging.info("  results/CF7_clinical_harmonization/CF7_conflict_audit.tsv")
    logging.info("  results/CF7_clinical_harmonization/CF7_field_completeness.tsv")
    logging.info("  results/CF7_clinical_harmonization/CF7_receptor_status_distribution.tsv")
    logging.info("  results/CF7_clinical_harmonization/CF7_endpoint_usability.tsv")
    logging.info("  results/CF7_clinical_harmonization/CF7_summary.tsv")
    logging.info("  results/CF7_clinical_harmonization/CF7_provenance.tsv")
    logging.info("  logs/CF7_clinical_harmonization.log")
    logging.info("")
    logging.info("IMPORTANT:")
    logging.info("CF6 cohort membership was not changed.")
    logging.info("No clinical value was imputed.")
    logging.info("No ML endpoint was selected.")
    logging.info("No expression data were modified.")
    logging.info("CF7 is ready for review before CF8 RNA-seq QC.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF7 ERROR: {exc}")
        sys.exit(1)