#!/usr/bin/env python
from __future__ import annotations

import hashlib, logging, os, platform, sys, time, warnings
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_selection import VarianceThreshold, SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, matthews_corrcoef, balanced_accuracy_score, confusion_matrix
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler

ROOT = Path.cwd()
CF15 = ROOT/'results'/'CF15_ml_experiment_design'
CF16 = ROOT/'results'/'CF16_nested_cv_training'
CF17 = ROOT/'results'/'CF17_combined_model_evaluation'
ML = ROOT/'data'/'processed'/'ml_ready'
RES = ROOT/'results'/'CF18_stable_signature_xai_final_model'
FIG = RES/'figures'; MODEL_DIR = ML/'CF18_final_model'; LOGDIR = ROOT/'logs'
for p in [RES, FIG, MODEL_DIR, LOGDIR]: p.mkdir(parents=True, exist_ok=True)

MATRIX = ML/'CF15_TCGA_HER2_rank_matrix.npz'
ASSIGN = CF15/'CF15_outer_cv_test_assignments.tsv'
CF16_SUM = CF16/'CF16_summary.tsv'
CF16_FEAT = CF16/'CF16_selected_features.tsv'
CF16_PRED = CF16/'CF16_outer_predictions.tsv'
CF16_METR = CF16/'CF16_outer_metrics.tsv'
LOCK_SUM = CF17/'CF17_LOCKED_summary.tsv'

OUT_STAB = RES/'CF18_ElasticNet_feature_stability.tsv'
OUT_CORE = RES/'CF18_stable_core_signature.tsv'
OUT_ERBB_FOLD = RES/'CF18_ERBB2_single_gene_outer_metrics.tsv'
OUT_ERBB_BOOT = RES/'CF18_ERBB2_vs_ElasticNet_bootstrap.tsv'
OUT_SEARCH = RES/'CF18_final_ElasticNet_inner_search.tsv'
OUT_PARAMS = RES/'CF18_final_ElasticNet_parameters.tsv'
OUT_FINAL_FEAT = RES/'CF18_final_ElasticNet_features.tsv'
OUT_CAL = RES/'CF18_calibration_and_threshold.tsv'
OUT_OOF = RES/'CF18_TCGA_OOF_calibrated_predictions.tsv'
OUT_SUM = RES/'CF18_summary.tsv'
OUT_PROV = RES/'CF18_provenance.tsv'
OUT_MODEL = MODEL_DIR/'CF18_final_ElasticNet_model_bundle.joblib'
OUT_MARKER = RES/'CF18_MODEL_AND_SIGNATURE_LOCKED.txt'

SEED=20260815; BSEED=20260818; B=2000
N=938; P=22106; POS=182; NEG=756
MODEL='ElasticNet_Logistic'
KVAL=[25,50,100,250,500]; CVAL=[0.01,0.1,1.0,10.0]; L1VAL=[0.0,0.25,0.5,0.75,1.0]
CORE_SEL=12; CORE_NZ=12; CORE_SIGN=0.80; CONS=8; NZTOL=1e-8

logging.basicConfig(level=logging.INFO,format='%(message)s',handlers=[logging.FileHandler(LOGDIR/'CF18_stable_signature_xai_final_model.log',mode='w',encoding='utf-8'),logging.StreamHandler(sys.stdout)],force=True)

def md5like_sha(path):
    h=hashlib.sha256();
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()

def kv(path):
    d=pd.read_csv(path,sep='\t',dtype=str); return dict(zip(d.iloc[:,0],d.iloc[:,1]))

def stability_table(feat):
    g=feat[feat.model.astype(str)==MODEL].copy(); g['coef']=pd.to_numeric(g.model_weight_or_importance)
    g['nz']=g.coef.abs()>NZTOL; g['pos']=g.coef>NZTOL; g['neg']=g.coef<-NZTOL
    rows=[]
    for gene,gg in g.groupby('gene_symbol'):
        sel=gg.split_id.nunique(); nz=gg.loc[gg.nz,'split_id'].nunique(); pos=gg.loc[gg.pos,'split_id'].nunique(); neg=gg.loc[gg.neg,'split_id'].nunique()
        sc=max(pos,neg)/nz if nz else 0.0
        sign='positive' if pos>neg else 'negative' if neg>pos else 'mixed_or_zero'
        tier='CORE_STABLE' if sel>=CORE_SEL and nz>=CORE_NZ and sc>=CORE_SIGN else ('CONSENSUS' if sel>=CONS and nz>=CONS and sc>=CORE_SIGN else 'OCCASIONAL')
        rows.append([gene,sel,sel/15,nz,nz/15,pos,neg,sign,sc,gg.coef.mean(),gg.coef.abs().mean(),gg.selector_f_score.mean(),tier])
    o=pd.DataFrame(rows,columns=['gene_symbol','selected_outer_splits','selection_frequency','nonzero_coefficient_outer_splits','nonzero_frequency','positive_coefficient_splits','negative_coefficient_splits','dominant_coefficient_sign','sign_consistency_among_nonzero','mean_coefficient_when_selected','mean_absolute_coefficient_when_selected','mean_selector_f_score','stability_tier'])
    o['mean_absolute_coefficient_all15']=o.mean_absolute_coefficient_when_selected*o.selected_outer_splits/15
    return o.sort_values(['nonzero_frequency','selection_frequency','sign_consistency_among_nonzero','mean_absolute_coefficient_all15'],ascending=False).reset_index(drop=True)

def erbb2_fold_metrics(X,y,genes,assign,em):
    jj=np.flatnonzero(genes=='ERBB2');
    if len(jj)!=1: raise RuntimeError(f'ERBB2 count={len(jj)}')
    j=int(jj[0]); rows=[]
    for sid in sorted(assign.split_id.unique(),key=lambda s:(int(s.split('_')[0][1:]),int(s.split('_')[1][1:]))):
        a=assign[assign.split_id==sid].sort_values('row_index'); idx=a.row_index.astype(int).to_numpy(); yy=y[idx]; sc=X[idx,j]
        e=em[em.split_id==sid].iloc[0]
        rows.append([sid,int(a.repeat.iloc[0]),int(a.fold.iloc[0]),len(idx),int(yy.sum()),roc_auc_score(yy,sc),average_precision_score(yy,sc),float(e.outer_AUROC),float(e.outer_average_precision)])
    d=pd.DataFrame(rows,columns=['split_id','repeat','fold','test_n','test_positive','ERBB2_AUROC','ERBB2_PR_AUC','ElasticNet_AUROC','ElasticNet_PR_AUC'])
    d['ElasticNet_minus_ERBB2_AUROC']=d.ElasticNet_AUROC-d.ERBB2_AUROC; d['ElasticNet_minus_ERBB2_PR_AUC']=d.ElasticNet_PR_AUC-d.ERBB2_PR_AUC
    return d

def erbb2_bootstrap(X,y,genes,assign,ep):
    jj=np.flatnonzero(genes=='ERBB2'); j=int(jj[0])
    pt=ep[['patient_id','y_true']].drop_duplicates().sort_values('patient_id').reset_index(drop=True); mp={p:i for i,p in enumerate(pt.patient_id.astype(str))}; yg=pt.y_true.to_numpy(int)
    pi=np.flatnonzero(yg==1); ni=np.flatnonzero(yg==0); rng=np.random.default_rng(BSEED)
    tabs=[]
    for sid in sorted(assign.split_id.unique(),key=lambda s:(int(s.split('_')[0][1:]),int(s.split('_')[1][1:]))):
        q=ep[ep.split_id==sid].sort_values('row_index'); idx=q.row_index.astype(int).to_numpy(); tabs.append((np.array([mp[p] for p in q.patient_id.astype(str)]),q.y_true.to_numpy(int),q.score.to_numpy(float),X[idx,j].astype(float)))
    da=np.empty(B); dp=np.empty(B)
    for b in range(B):
        cnt=np.bincount(np.r_[rng.choice(pi,len(pi),replace=True),rng.choice(ni,len(ni),replace=True)],minlength=N)
        ea=[]; ra=[]; epv=[]; rpv=[]
        for gi,yy,es,rs in tabs:
            ex=np.repeat(np.arange(len(gi)),cnt[gi]); y2=yy[ex]; ea.append(roc_auc_score(y2,es[ex])); ra.append(roc_auc_score(y2,rs[ex])); epv.append(average_precision_score(y2,es[ex])); rpv.append(average_precision_score(y2,rs[ex]))
        da[b]=np.mean(ea)-np.mean(ra); dp[b]=np.mean(epv)-np.mean(rpv)
        if (b+1)%250==0: logging.info(f'      ERBB2 bootstrap: {b+1}/{B}')
    return pd.DataFrame([
        ['ElasticNet_minus_ERBB2','AUROC',B,da.mean(),np.quantile(da,.025),np.quantile(da,.975),np.mean(da>0)],
        ['ElasticNet_minus_ERBB2','PR_AUC',B,dp.mean(),np.quantile(dp,.025),np.quantile(dp,.975),np.mean(dp>0)]],columns=['comparison','metric','bootstrap_replicates','bootstrap_mean_difference','ci_lower_95','ci_upper_95','fraction_bootstrap_difference_gt_0'])

def prepare_cache(X,y):
    cv=StratifiedKFold(4,shuffle=True,random_state=SEED); folds=[]
    for tr,va in cv.split(np.zeros(len(y)),y):
        vt=VarianceThreshold(0); a=vt.fit_transform(X[tr]); b=vt.transform(X[va]); sc=StandardScaler(); a=sc.fit_transform(a); b=sc.transform(b); kc={}
        for k in KVAL:
            sel=SelectKBest(f_classif,k=k)
            with warnings.catch_warnings(): warnings.simplefilter('ignore'); aa=sel.fit_transform(a,y[tr])
            kc[k]=(aa.astype(np.float32),sel.transform(b).astype(np.float32))
        folds.append((y[tr],y[va],kc))
    return folds

def final_search(cache):
    rows=[]; n=0; st=time.perf_counter()
    for k in KVAL:
      for C in CVAL:
       for l1 in L1VAL:
        n+=1; au=[]; ap=[]; cw=0
        for yt,yv,kc in cache:
            m=LogisticRegression(penalty='elasticnet',solver='saga',C=C,l1_ratio=l1,class_weight='balanced',max_iter=5000,tol=1e-3,random_state=SEED)
            with warnings.catch_warnings(record=True) as w: warnings.simplefilter('always'); m.fit(kc[k][0],yt)
            s=m.predict_proba(kc[k][1])[:,1]; au.append(roc_auc_score(yv,s)); ap.append(average_precision_score(yv,s)); cw+=sum(issubclass(x.category,ConvergenceWarning) for x in w)
        rows.append([n,k,C,l1,np.mean(au),np.std(au,ddof=1),np.mean(ap),np.std(ap,ddof=1),cw])
        if n%20==0: logging.info(f'      Final Elastic-Net search: {n}/100 candidates ({(time.perf_counter()-st)/60:.1f} min)')
    d=pd.DataFrame(rows,columns=['candidate_index','k','C','l1_ratio','mean_inner_AUROC','sd_inner_AUROC','mean_inner_PR_AUC','sd_inner_PR_AUC','convergence_warning_count']).sort_values(['mean_inner_AUROC','mean_inner_PR_AUC','k','C','l1_ratio'],ascending=[False,False,True,True,False],kind='mergesort').reset_index(drop=True)
    r=d.iloc[0]; return d,{'k':int(r.k),'C':float(r.C),'l1_ratio':float(r.l1_ratio),'mean_inner_AUROC':float(r.mean_inner_AUROC),'mean_inner_PR_AUC':float(r.mean_inner_PR_AUC)}

def fit_final(X,y,genes,stab,par):
    vt=VarianceThreshold(0); a=vt.fit_transform(X); sc=StandardScaler(); a=sc.fit_transform(a); sel=SelectKBest(f_classif,k=par['k'])
    with warnings.catch_warnings(): warnings.simplefilter('ignore'); ak=sel.fit_transform(a,y)
    m=LogisticRegression(penalty='elasticnet',solver='saga',C=par['C'],l1_ratio=par['l1_ratio'],class_weight='balanced',max_iter=5000,tol=1e-3,random_state=SEED)
    with warnings.catch_warnings(record=True) as w: warnings.simplefilter('always'); m.fit(ak,y)
    vti=np.flatnonzero(vt.get_support()); si=np.flatnonzero(sel.get_support()); oi=vti[si]; co=np.ravel(m.coef_)
    f=pd.DataFrame({'gene_symbol':genes[oi],'selector_f_score_full_TCGA':sel.scores_[si],'standardized_ElasticNet_coefficient':co,'absolute_coefficient':np.abs(co),'odds_ratio_per_1SD_increase':np.exp(np.clip(co,-50,50)),'final_model_nonzero':np.abs(co)>NZTOL}).merge(stab,on='gene_symbol',how='left')
    f['stability_tier']=f.stability_tier.fillna('NOT_SELECTED_IN_OUTER_FITS'); f=f.sort_values('absolute_coefficient',ascending=False).reset_index(drop=True); f['final_model_importance_rank']=np.arange(1,len(f)+1)
    return vt,sc,sel,m,f,sum(issubclass(x.category,ConvergenceWarning) for x in w)

def calibration(ep):
    g=ep.groupby(['patient_id','y_true'],as_index=False).agg(mean_oof_raw_probability=('score','mean'),sd_oof_raw_probability=('score','std'),oof_repeats=('repeat','nunique'))
    p=np.clip(g.mean_oof_raw_probability.to_numpy(float),1e-7,1-1e-7); z=np.log(p/(1-p)).reshape(-1,1); yy=g.y_true.to_numpy(int)
    cal=LogisticRegression(C=1e6,solver='lbfgs',max_iter=2000,random_state=SEED).fit(z,yy); cp=cal.predict_proba(z)[:,1]; g['calibrated_oof_probability']=cp
    u=np.unique(cp); th=np.unique(np.r_[0,(u[:-1]+u[1:])/2,1]); rows=[]
    for t in th:
        pr=(cp>=t).astype(int); tn,fp,fn,tp=confusion_matrix(yy,pr,labels=[0,1]).ravel(); rows.append([t,matthews_corrcoef(yy,pr),balanced_accuracy_score(yy,pr),tp/(tp+fn),tn/(tn+fp)])
    d=pd.DataFrame(rows,columns=['threshold','MCC','balanced_accuracy','sensitivity','specificity']); mx=d.MCC.max(); q=d[np.isclose(d.MCC,mx,atol=1e-12)].copy(); q['d']=abs(q.threshold-.5); r=q.sort_values(['d','threshold']).iloc[0]
    s=pd.DataFrame([['Calibration method','Sigmoid / logistic calibration'],['Calibrator coefficient',float(cal.coef_.ravel()[0])],['Calibrator intercept',float(cal.intercept_[0])],['Threshold selection metric','Maximum MCC'],['Chosen probability threshold',float(r.threshold)],['OOF threshold-selection MCC',float(r.MCC)],['OOF threshold-selection balanced accuracy',float(r.balanced_accuracy)],['OOF threshold-selection sensitivity',float(r.sensitivity)],['OOF threshold-selection specificity',float(r.specificity)]],columns=['metric','value'])
    return cal,g,s,float(r.threshold)

def figs(stab,finalf):
    a=stab.head(25).sort_values('selection_frequency'); fig,ax=plt.subplots(figsize=(8.5,8)); ax.barh(np.arange(len(a)),a.selection_frequency,edgecolor='black',linewidth=.5); ax.set_yticks(np.arange(len(a)),a.gene_symbol); ax.set_xlim(0,1.05); ax.set_xlabel('Selection frequency across 15 outer Elastic-Net fits'); ax.axvline(CORE_SEL/15,linestyle='--',linewidth=1); ax.grid(axis='x',alpha=.2); fig.tight_layout(); fig.savefig(FIG/'CF18_ElasticNet_feature_stability.png',dpi=600,bbox_inches='tight'); fig.savefig(FIG/'CF18_ElasticNet_feature_stability.pdf',bbox_inches='tight'); plt.close(fig)
    b=finalf[finalf.final_model_nonzero].head(25).sort_values('standardized_ElasticNet_coefficient');
    if len(b):
        fig,ax=plt.subplots(figsize=(8.5,8)); ax.barh(np.arange(len(b)),b.standardized_ElasticNet_coefficient,edgecolor='black',linewidth=.5); ax.set_yticks(np.arange(len(b)),b.gene_symbol); ax.axvline(0,linewidth=1); ax.set_xlabel('Standardized Elastic-Net coefficient (log-odds scale)'); ax.grid(axis='x',alpha=.2); fig.tight_layout(); fig.savefig(FIG/'CF18_final_ElasticNet_coefficients.png',dpi=600,bbox_inches='tight'); fig.savefig(FIG/'CF18_final_ElasticNet_coefficients.pdf',bbox_inches='tight'); plt.close(fig)

def main():
    t0=time.perf_counter(); logging.info('\n============================================================\n CF18 - STABLE SIGNATURE + XAI + FINAL TCGA MODEL\n============================================================\n'); logging.info('Estimated runtime: ~8-20 minutes\nLikely bottleneck: final 100-candidate Elastic-Net 4-fold search\nSecondary bottleneck: 2,000 ERBB2-vs-model patient bootstraps\nLong silent periods: NO\nSCAN-B accessed: NO\nAPOLLO accessed: NO\n')
    for p in [MATRIX,ASSIGN,CF16_SUM,CF16_FEAT,CF16_PRED,CF16_METR,LOCK_SUM]:
        if not p.exists(): raise FileNotFoundError(p)
    lk=kv(LOCK_SUM)
    if lk.get('CF17 lock gate')!='MODEL_ROLES_LOCKED_READY_FOR_CF18' or lk.get('Primary final model family')!=MODEL: raise RuntimeError('CF17 model-role lock invalid')
    logging.info('[1/8] CF17 model-role lock: PASS\n')
    z=np.load(MATRIX,allow_pickle=True); X=np.asarray(z['X'],np.float32); y=np.asarray(z['y'],np.int8); ids=z['patient_ids'].astype(str); genes=z['gene_symbols'].astype(str)
    if X.shape!=(N,P) or y.sum()!=POS or len(np.unique(ids))!=N: raise RuntimeError('CF15 matrix integrity failed')
    assign=pd.read_csv(ASSIGN,sep='\t'); feat=pd.read_csv(CF16_FEAT,sep='\t'); pred=pd.read_csv(CF16_PRED,sep='\t'); metr=pd.read_csv(CF16_METR,sep='\t')
    ep=pred[pred.model==MODEL].copy(); em=metr[metr.model==MODEL].copy(); logging.info(f'[2/8] TCGA matrix validated: {N} x {P}\n')
    stab=stability_table(feat); stab.to_csv(OUT_STAB,sep='\t',index=False); core=stab[stab.stability_tier=='CORE_STABLE'].copy(); core.insert(0,'core_signature_rank',np.arange(1,len(core)+1)); core.to_csv(OUT_CORE,sep='\t',index=False); logging.info(f'[3/8] Stable signature: {len(core)} CORE_STABLE genes; {(stab.stability_tier=="CONSENSUS").sum()} CONSENSUS genes\n')
    ef=erbb2_fold_metrics(X,y,genes,assign,em); ef.to_csv(OUT_ERBB_FOLD,sep='\t',index=False); logging.info(f'[4/8] ERBB2-only mean AUROC={ef.ERBB2_AUROC.mean():.4f}; Elastic-Net={ef.ElasticNet_AUROC.mean():.4f}'); eb=erbb2_bootstrap(X,y,genes,assign,ep); eb.to_csv(OUT_ERBB_BOOT,sep='\t',index=False); logging.info('      ERBB2 paired bootstrap complete\n')
    logging.info('[5/8] Final TCGA-only Elastic-Net retuning...'); cache=prepare_cache(X,y); sd,par=final_search(cache); sd.to_csv(OUT_SEARCH,sep='\t',index=False); pd.DataFrame(list(par.items()),columns=['parameter','value']).to_csv(OUT_PARAMS,sep='\t',index=False); logging.info(f"      best k={par['k']}, C={par['C']}, l1_ratio={par['l1_ratio']}; inner AUROC={par['mean_inner_AUROC']:.4f}\n")
    logging.info('[6/8] Fitting final Elastic-Net + model-native explainability...'); vt,sc,sel,model,ff,cw=fit_final(X,y,genes,stab,par); ff.to_csv(OUT_FINAL_FEAT,sep='\t',index=False); logging.info(f'      selected features={len(ff)}; nonzero coefficients={ff.final_model_nonzero.sum()}; warnings={cw}\n')
    logging.info('[7/8] Freezing sigmoid calibration + MCC threshold...'); cal,oof,cals,thr=calibration(ep); oof.to_csv(OUT_OOF,sep='\t',index=False); cals.to_csv(OUT_CAL,sep='\t',index=False); logging.info(f'      locked threshold={thr:.6f}\n')
    bundle={'artifact_stage':'CF18','primary_model_family':MODEL,'feature_universe_gene_symbols':genes,'rank_representation':'within-sample average percentile ranks across fixed 22106 genes','variance_threshold':vt,'standard_scaler':sc,'select_k_best':sel,'elasticnet_model':model,'sigmoid_calibrator':cal,'classification_threshold':thr,'final_hyperparameters':par,'core_signature_definition':{'min_selected_outer_splits':CORE_SEL,'min_nonzero_outer_splits':CORE_NZ,'min_sign_consistency':CORE_SIGN},'scanb_seen_before_lock':False,'apollo_seen_before_lock':False}; joblib.dump(bundle,OUT_MODEL,compress=3); figs(stab,ff)
    ea=eb[eb.metric=='AUROC'].iloc[0]; epb=eb[eb.metric=='PR_AUC'].iloc[0]; rt=(time.perf_counter()-t0)/60
    sm=pd.DataFrame([['Primary final model family',MODEL],['TCGA final training samples',N],['Feature universe',P],['Stable core signature genes',len(core)],['Final model selected k',par['k']],['Final model nonzero coefficients',int(ff.final_model_nonzero.sum())],['ERBB2-only mean outer AUROC',ef.ERBB2_AUROC.mean()],['Elastic-Net mean outer AUROC',ef.ElasticNet_AUROC.mean()],['ElasticNet minus ERBB2 AUROC bootstrap difference',ea.bootstrap_mean_difference],['ElasticNet minus ERBB2 AUROC 95% CI',f'{ea.ci_lower_95:.6f} to {ea.ci_upper_95:.6f}'],['ERBB2-only mean outer PR-AUC',ef.ERBB2_PR_AUC.mean()],['Elastic-Net mean outer PR-AUC',ef.ElasticNet_PR_AUC.mean()],['ElasticNet minus ERBB2 PR-AUC bootstrap difference',epb.bootstrap_mean_difference],['ElasticNet minus ERBB2 PR-AUC 95% CI',f'{epb.ci_lower_95:.6f} to {epb.ci_upper_95:.6f}'],['Locked calibrated probability threshold',thr],['SCAN-B accessed','NO'],['APOLLO accessed','NO'],['CF18 runtime minutes',rt],['CF18 stage gate','MODEL_AND_SIGNATURE_LOCKED_READY_FOR_CF19']],columns=['metric','value']); sm.to_csv(OUT_SUM,sep='\t',index=False)
    prov=pd.DataFrame([['code_file','CF18_stable_signature_xai_final_model.py'],['run_datetime_utc',datetime.now(timezone.utc).isoformat()],['CF15_matrix_sha256',md5like_sha(MATRIX)],['CF16_features_sha256',md5like_sha(CF16_FEAT)],['CF16_predictions_sha256',md5like_sha(CF16_PRED)],['CF17_lock_summary_sha256',md5like_sha(LOCK_SUM)],['stable_signature_sha256',md5like_sha(OUT_CORE)],['final_features_sha256',md5like_sha(OUT_FINAL_FEAT)],['final_model_bundle_sha256',md5like_sha(OUT_MODEL)],['core_signature_rule','selected >=12/15 AND nonzero >=12/15 AND sign consistency >=0.80; frozen before SCAN-B'],['ERBB2_benchmark_status','POST_HOC_BIOLOGICAL_BENCHMARK; does not reopen CF17 model selection'],['external_data_rule','SCAN-B and APOLLO not accessed before model/signature lock'],['python_version',platform.python_version()],['CF18_stage_gate','MODEL_AND_SIGNATURE_LOCKED_READY_FOR_CF19']],columns=['field','value']); prov.to_csv(OUT_PROV,sep='\t',index=False)
    OUT_MARKER.write_text(f'CF18 MODEL + STABLE SIGNATURE LOCKED\nPrimary final model family: {MODEL}\nStable core signature genes: {len(core)}\nFinal selected k: {par["k"]}\nCalibrated probability threshold: {thr:.8f}\nSCAN-B accessed before lock: NO\nAPOLLO accessed before lock: NO\nSTATUS: MODEL_AND_SIGNATURE_LOCKED_READY_FOR_CF19\n',encoding='utf-8')
    logging.info('============================================================\n CF18 COMPLETE - MODEL + SIGNATURE LOCKED\n============================================================'); logging.info(f'Stable core signature genes: {len(core)}'); logging.info(f"Final Elastic-Net: k={par['k']}, C={par['C']}, l1_ratio={par['l1_ratio']}"); logging.info(f'Final nonzero coefficients: {int(ff.final_model_nonzero.sum())}'); logging.info(f'ERBB2-only mean AUROC: {ef.ERBB2_AUROC.mean():.4f}'); logging.info(f'Elastic-Net mean AUROC: {ef.ElasticNet_AUROC.mean():.4f}'); logging.info(f'Locked calibrated probability threshold: {thr:.6f}'); logging.info('SCAN-B accessed: NO\nAPOLLO accessed: NO\nExternal validation performed: NO\nSTATUS: MODEL_AND_SIGNATURE_LOCKED_READY_FOR_CF19\n'); logging.info('Send the full terminal output before CF19 external validation.')

if __name__=='__main__':
    try: main()
    except Exception as e:
        logging.exception(f'\nCF18 ERROR: {e}'); sys.exit(1)
