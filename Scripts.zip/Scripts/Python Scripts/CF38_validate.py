"""Apply CF18 verbatim to METABRIC. No fitting, selection, or threshold tuning."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent / '_runtime'))
import hashlib, json, platform
from datetime import datetime, timezone
import joblib
import numpy as np
import pandas as pd
import sklearn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix, roc_curve, precision_recall_curve

OUT = Path(__file__).resolve().parents[1]
ROOT = OUT.parent
RES, FIG = OUT/'results', OUT/'figures'
DATA = ROOT/'data/external_validation/metabric/brca_metabric'
MODEL = ROOT/'data/processed/ml_ready/CF18_final_model/CF18_final_ElasticNet_model_bundle.joblib'
FEATURES = ROOT/'results/CF18_stable_signature_xai_final_model/CF18_final_ElasticNet_features.tsv'

def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(8*1024*1024), b''): h.update(block)
    return h.hexdigest()

def save(df, name):
    df.to_csv(RES/f'CF38_{name}.tsv', sep='\t', index=False)

def metrics(y, p, threshold):
    tn, fp, fn, tp = confusion_matrix(y, p >= threshold, labels=[0,1]).ravel()
    ratio = lambda a,b: float(a/b) if b else np.nan
    return {'AUROC':roc_auc_score(y,p), 'AUPRC_average_precision':average_precision_score(y,p),
            'accuracy':ratio(tp+tn,len(y)), 'sensitivity':ratio(tp,tp+fn), 'specificity':ratio(tn,tn+fp),
            'PPV':ratio(tp,tp+fp), 'NPV':ratio(tn,tn+fn)}

def main():
    inputs = [MODEL, FEATURES, DATA/'data_mrna_illumina_microarray.txt', DATA/'data_clinical_sample.txt',
              DATA/'data_clinical_patient.txt', DATA/'meta_mrna_illumina_microarray.txt', DATA/'meta_study.txt',
              ROOT/'scripts/CF7_clinical_harmonization.py', ROOT/'scripts/CF15_ml_experiment_design.py',
              ROOT/'scripts/CF18_stable_signature_xai_final_model.py', ROOT/'scripts/CF19_scanb_external_validation.py']
    before = {str(p.relative_to(ROOT)):sha(p) for p in inputs}
    b = joblib.load(MODEL)
    genes = np.asarray(b['feature_universe_gene_symbols']).astype(str)
    vi = np.flatnonzero(b['variance_threshold'].get_support())
    si = np.flatnonzero(b['select_k_best'].get_support())
    selected = genes[vi[si]]
    coef = b['elasticnet_model'].coef_.ravel()
    signature = selected[np.abs(coef)>1e-8]
    assert len(genes)==22106 and len(selected)==500 and len(signature)==86
    frozen = pd.read_csv(FEATURES, sep='\t').set_index('gene_symbol')
    assert set(signature)==set(frozen.index[frozen.standardized_ElasticNet_coefficient.abs()>1e-8])
    np.testing.assert_allclose(coef, frozen.loc[selected,'standardized_ElasticNet_coefficient'], atol=1e-14)
    threshold = float(b['classification_threshold'])
    print('Reading existing METABRIC source files...', flush=True)
    raw = pd.read_csv(DATA/'data_mrna_illumina_microarray.txt', sep='\t')
    raw_rows = len(raw)
    raw = raw.dropna(subset=['Hugo_Symbol'])
    columns = [c for c in raw if c not in ['Hugo_Symbol','Entrez_Gene_Id']]
    expr = raw.groupby('Hugo_Symbol',sort=False)[columns].mean()
    assert expr.columns.is_unique
    measured_locked = expr.loc[expr.index.intersection(genes)]
    bad_samples = measured_locked.columns[~np.isfinite(measured_locked.to_numpy()).all(axis=0)]
    missing_cells = measured_locked.isna().stack()
    save(missing_cells[missing_cells].rename('missing').reset_index().rename(columns={'level_1':'SAMPLE_ID'}), 'missing_measured_expression')
    del missing_cells, measured_locked, raw
    sample = pd.read_csv(DATA/'data_clinical_sample.txt', sep='\t', comment='#', dtype=str)
    patient = pd.read_csv(DATA/'data_clinical_patient.txt', sep='\t', comment='#', dtype=str)
    assert sample.SAMPLE_ID.is_unique and patient.PATIENT_ID.is_unique
    clinical = sample.merge(patient[['PATIENT_ID','HER2_SNP6']], on='PATIENT_ID', how='left', validate='many_to_one')
    clinical['has_expression'] = clinical.SAMPLE_ID.isin(expr.columns)
    clinical['valid_label'] = clinical.HER2_STATUS.isin(['Positive','Negative'])
    clinical['complete_measured_expression'] = ~clinical.SAMPLE_ID.isin(bad_samples)
    clinical['included'] = clinical.has_expression & clinical.valid_label & clinical.complete_measured_expression
    clinical['exclusion_reason'] = np.where(~clinical.has_expression,'No expression',np.where(~clinical.valid_label,'No definitive HER2 label',np.where(~clinical.complete_measured_expression,'Missing measured expression in locked universe','Included')))
    save(clinical[['PATIENT_ID','SAMPLE_ID','HER2_STATUS','HER2_SNP6','has_expression','valid_label','complete_measured_expression','included','exclusion_reason']], 'sample_inclusion')
    eligible = set(clinical.loc[clinical.included,'SAMPLE_ID'])
    c = clinical.loc[clinical.included].copy().set_index('SAMPLE_ID').loc[[s for s in expr.columns if s in eligible]]
    assert c.PATIENT_ID.is_unique
    y = (c.HER2_STATUS=='Positive').to_numpy(int)
    available_set = set(expr.index)
    mapping = pd.DataFrame({'gene_symbol':genes, 'present_in_METABRIC':[g in available_set for g in genes], 'selected_500':np.isin(genes,selected), 'signature_86':np.isin(genes,signature)})
    mapping['mapping_rule'] = np.where(mapping.present_in_METABRIC,'Exact HUGO symbol','Absent; frozen external zero-fill rule')
    save(mapping,'gene_universe_mapping')
    sig = mapping[mapping.signature_86].copy()
    sig['coefficient'] = frozen.loc[sig.gene_symbol,'standardized_ElasticNet_coefficient'].to_numpy()
    save(sig,'86_gene_signature_mapping')
    print('Applying frozen rank representation and all bundle transforms...', flush=True)
    locked = expr.reindex(index=genes, columns=c.index, fill_value=0.0)
    ranked = locked.rank(axis=0, method='average', pct=True).astype(np.float32)
    X = ranked.to_numpy().T
    assert np.isfinite(X).all()
    np.testing.assert_allclose(X.mean(axis=1), (len(genes)+1)/(2*len(genes)), atol=1e-6)
    z = b['standard_scaler'].transform(b['variance_threshold'].transform(X))
    xsel = b['select_k_best'].transform(z)
    rawp = b['elasticnet_model'].predict_proba(xsel)[:,1]
    clipped = np.clip(rawp,1e-7,1-1e-7)
    prob = b['sigmoid_calibrator'].predict_proba(np.log(clipped/(1-clipped)).reshape(-1,1))[:,1]
    # Independent arithmetic check against frozen coefficients; no model estimation.
    from scipy.special import expit
    np.testing.assert_allclose(rawp, expit(xsel @ coef + b['elasticnet_model'].intercept_[0]), atol=1e-12)
    pred = (prob >= threshold).astype(int)
    prediction = c[['PATIENT_ID','HER2_STATUS','HER2_SNP6']].reset_index()
    prediction['y_true']=y; prediction['raw_probability']=rawp
    prediction['calibrated_probability']=prob; prediction['threshold']=threshold; prediction['prediction']=pred
    save(prediction,'METABRIC_predictions')
    save(ranked.loc[signature].T.rename_axis('SAMPLE_ID').reset_index(),'86_gene_rank_input')
    point = metrics(y,prob,threshold)
    print(json.dumps(point,indent=2), flush=True)
    rng = np.random.default_rng(20260922)
    positives, negatives = np.flatnonzero(y==1), np.flatnonzero(y==0)
    boot=[]
    for _ in range(2000):
        idx=np.r_[rng.choice(positives,len(positives),replace=True),rng.choice(negatives,len(negatives),replace=True)]
        boot.append(metrics(y[idx],prob[idx],threshold))
    boot=pd.DataFrame(boot)
    performance=pd.DataFrame([{'metric':k,'estimate':v,'lower_95':boot[k].quantile(.025),'upper_95':boot[k].quantile(.975)} for k,v in point.items()])
    save(performance,'performance')
    cm = confusion_matrix(y,pred,labels=[0,1])
    save(pd.DataFrame(cm,columns=['predicted_negative','predicted_positive']).assign(actual=['negative','positive']), 'confusion_matrix')
    save(pd.crosstab(c.HER2_STATUS,c.HER2_SNP6).reset_index(),'label_provenance_cross_tab')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.dpi':400})
    blue, red = '#2878A5','#C44E52'
    def finish(fig,name):
        fig.tight_layout()
        for ext in ['png','pdf']: fig.savefig(FIG/f'CF38_{name}.{ext}',bbox_inches='tight')
        plt.close(fig)
    fpr,tpr,_=roc_curve(y,prob); precision,recall,_=precision_recall_curve(y,prob)
    fig,ax=plt.subplots(figsize=(5.5,5))
    ax.plot(fpr,tpr,color=blue,lw=2.2,label=f"AUROC = {point['AUROC']:.3f}")
    ax.plot([0,1],[0,1],'--',color='0.65'); ax.set(xlabel='False-positive rate',ylabel='Sensitivity',title='METABRIC | Locked TCGA model',xlim=(0,1),ylim=(0,1.02)); ax.legend(loc='lower right'); finish(fig,'ROC_curve')
    fig,ax=plt.subplots(figsize=(5.5,5))
    ax.step(recall,precision,where='post',color=blue,lw=2.2,label=f"Average precision = {point['AUPRC_average_precision']:.3f}")
    ax.axhline(y.mean(),ls='--',color='0.5',label=f'Prevalence = {y.mean():.3f}'); ax.set(xlabel='Recall (sensitivity)',ylabel='Precision (PPV)',title='METABRIC | Precision–recall',xlim=(0,1),ylim=(0,1.02)); ax.legend(loc='lower left'); finish(fig,'PR_curve')
    fig,ax=plt.subplots(figsize=(6.4,4.6))
    for label,color in [(0,blue),(1,red)]:
        ax.hist(prob[y==label],bins=np.linspace(0,1,31),weights=np.ones((y==label).sum())/(y==label).sum(),histtype='step',lw=2,color=color,label=f"HER2 {'positive' if label else 'negative'} (n={(y==label).sum():,})")
    ax.axvline(threshold,color='0.3',ls='--',label=f'Locked threshold = {threshold:.3f}')
    ax.set(xlabel='Frozen calibrated HER2 probability',ylabel='Fraction within HER2 group',title='METABRIC | Probability distribution',xlim=(0,1)); ax.legend(fontsize=9); finish(fig,'probability_distribution')
    fig,ax=plt.subplots(figsize=(5.5,5))
    jitter=np.random.default_rng(38)
    for label,color in [(0,blue),(1,red)]:
        vals=prob[y==label]; ax.scatter(label+jitter.uniform(-.16,.16,len(vals)),vals,s=8,alpha=.23,color=color,rasterized=True)
    ax.boxplot([prob[y==0],prob[y==1]],positions=[0,1],widths=.4,showfliers=False,medianprops={'color':'black','linewidth':2})
    ax.axhline(threshold,color='0.3',ls='--',label=f'Locked threshold = {threshold:.3f}')
    ax.set(xticks=[0,1],xticklabels=[f'HER2 negative\nn={len(negatives):,}',f'HER2 positive\nn={len(positives):,}'],ylabel='Frozen calibrated HER2 probability',title='METABRIC | Prediction separation',ylim=(-.02,1.02)); ax.legend(fontsize=9); finish(fig,'HER2_prediction_separation')
    unchanged = all(sha(ROOT/p)==h for p,h in before.items())
    assert unchanged
    provenance={'run_utc':datetime.now(timezone.utc).isoformat(),'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__, 'input_sha256':before,'input_hashes_unchanged':unchanged,'threshold':threshold,'n_expression_samples':len(expr.columns),'n_clinical_samples':len(clinical),'n_evaluable':len(y),'n_positive':int(y.sum()),'n_negative':int((y==0).sum()),'expression_rows':raw_rows,'unique_expression_symbols':len(expr),'universe_present':int(mapping.present_in_METABRIC.sum()),'signature_present':int(sig.present_in_METABRIC.sum()),'signature_missing':sig.loc[~sig.present_in_METABRIC,'gene_symbol'].tolist(),'retraining':False,'recalibration':False,'threshold_optimization':False,'bootstrap_replicates':2000,'bootstrap_seed':20260922}
    (RES/'CF38_provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
    table='\n'.join(f"| {r.metric} | {r.estimate:.4f} | {r.lower_95:.4f}–{r.upper_95:.4f} |" for r in performance.itertuples())
    missing=', '.join(provenance['signature_missing']) or 'None'
    report=f'''# CF38: Independent METABRIC validation of the locked TCGA HER2 model

## Question and conclusion

Does the locked TCGA-trained HER2 model generalize to an independent breast cancer cohort?

The unchanged CF18 model achieved AUROC **{point['AUROC']:.4f}** and average precision **{point['AUPRC_average_precision']:.4f}** in METABRIC. At its original calibrated threshold ({threshold:.10f}), sensitivity was **{point['sensitivity']:.4f}** and specificity **{point['specificity']:.4f}**. These results assess cross-cohort discrimination and the actual frozen operating point separately. They do not establish equivalence to clinical IHC/ISH testing or prospective clinical validity.

## Dataset and independence

METABRIC (Molecular Taxonomy of Breast Cancer International Consortium), cBioPortal study `brca_metabric`, uses Illumina HT-12 v3 microarray log2 expression intensities. The existing public DataHub files in `data/external_validation/metabric/brca_metabric/` were reused read-only; no new download or different data release was substituted. The source study metadata cites Curtis et al. (2012), Pereira et al. (2016), and Rueda et al. (2019). The broader 2,509-tumor study is not the expression-evaluable denominator.

There are {len(clinical):,} clinical records and {len(expr.columns):,} expression samples. After definitive-label and expression-completeness checks, the evaluable set contains **{len(y):,} unique patients/samples: {int(y.sum()):,} HER2 positive and {int((y==0).sum()):,} HER2 negative** (prevalence {y.mean():.2%}). {int((~clinical.has_expression).sum()):,} clinical records lack expression; {int((clinical.has_expression & ~clinical.valid_label).sum()):,} expression-matched records lack definitive labels; {int((clinical.has_expression & clinical.valid_label & ~clinical.complete_measured_expression).sum()):,} otherwise eligible samples have nonfinite measured expression within the locked universe and are excluded. This complete-case rule was applied before prediction, without examining outcomes, rather than inventing a new imputation rule. The sample inclusion and missing-cell tables document exclusions.

METABRIC is independent of the TCGA training cohort, but it was already examined in CF33 and CF33.5 for compact-model analyses. CF38 therefore is not a previously unseen project-level holdout. No METABRIC outcomes were used here to change the CF18 model, gene set, calibration, or threshold. Later 10-gene models were not substituted for the requested 86-gene model.

## Locked model and original label definition

Artifact: `data/processed/ml_ready/CF18_final_model/CF18_final_ElasticNet_model_bundle.joblib`. Signature: the 86 nonzero coefficients in `results/CF18_stable_signature_xai_final_model/CF18_final_ElasticNet_features.tsv`, verified against the bundle. The bundle selects 500 features; 86 contribute nonzero coefficients. The 20-gene stability core is a different object, not the final predictive signature. Training used 938 TCGA tumors (182 positive, 756 negative).

CF7 harmonizes definitive ISH/FISH first, then definitive IHC; unresolved equivocal/unknown labels are excluded, and contradictory definitive IHC/ISH results are marked unknown. CF15 codes Positive=1 and Negative=0. METABRIC uses explicit `HER2_STATUS` Positive/Negative, excluding any other values. `HER2_SNP6` is retained for provenance and cross-tabulated, not used as an expression predictor or to select cases. Published descriptions identify METABRIC HER2 status as SNP6 copy-number based; this endpoint is not interchangeable with TCGA IHC/ISH. PAM50 HER2-enriched subtype is not used as the label.

## Gene matching and preprocessing

1. Match exact `Hugo_Symbol` to the frozen TCGA symbols. Average duplicate expression rows by symbol before ranking; there are {raw_rows:,} source rows and {len(expr):,} usable unique symbols. No outcome-guided aliases, probe choices, or feature replacement.
2. Align to all 22,106 frozen genes in bundle order. {provenance['universe_present']:,} are measured. Of the 86 signature genes, **{provenance['signature_present']}/86** are measured; missing genes: **{missing}**. Full-universe and signature mapping tables are supplied.
3. Follow the CF19 external missing-gene convention: absent genes receive zero before ranking. This is a compatibility assumption, not recovered measurement. On a log2 microarray scale it can alter ranks and is an important limitation.
4. Exclude samples with nonfinite measured expression anywhere in the locked universe (distinct from wholly absent platform genes), then compute within-sample average percentile ranks over the fixed 22,106-gene universe, cast to float32 exactly as CF15/CF19. Do not rank only the 86 genes. No additional log transform is needed because positive monotone transforms preserve observed ranks; no cohort z-scoring, batch correction, or quantile matching is introduced. Complete-case exclusions may introduce selection bias.
5. Apply the stored variance filter, TCGA StandardScaler, and stored SelectKBest using `transform` only, then the stored Elastic-Net `predict_proba`. No `fit` calls occur.
6. Clip raw probabilities to [1e-7, 1−1e-7], take logits, and apply the stored CF18 sigmoid calibrator. Classify calibrated probabilities >= {threshold:.10f} as positive. This preserves the calibration/threshold pairing saved in CF18; no external recalibration or threshold optimization occurs.

## Performance

| Metric | Estimate | 95% bootstrap interval |
|---|---:|---:|
{table}

AUPRC is reported as scikit-learn average precision (stepwise integration), not trapezoidal PR area. Intervals use 2,000 stratified patient bootstrap replicates, fixed seed 20260922, and the unchanged model and threshold. They condition on observed prevalence and do not quantify model-development or assay-mapping uncertainty. The no-skill average precision reference is {y.mean():.4f}.

| Actual status | Predicted negative | Predicted positive |
|---|---:|---:|
| Negative | {cm[0,0]} | {cm[0,1]} |
| Positive | {cm[1,0]} | {cm[1,1]} |

## Interpretation and limitations

The answer is qualified: the locked model generalizes strongly for ranking METABRIC tumors, but its frozen operating threshold transfers poorly for detecting HER2-positive cases. It misses {cm[1,0]} of {int(y.sum())} positive cases ({1-point['sensitivity']:.1%}). Thus CF38 supports cross-cohort discrimination under incomplete platform coverage, not successful transfer of the complete clinical decision rule. The seven unmeasured signature genes mean this is not a full-measurement validation of all 86 genes.

AUROC and average precision describe ranking across HER2 groups; sensitivity, specificity, PPV, NPV, and accuracy describe transfer of the original operating threshold. Good ranking alone must not be interpreted as good probability calibration or adequate case detection. The class imbalance makes accuracy alone insufficient. PPV and NPV depend on cohort prevalence.

This is a retrospective cross-platform assessment. Missing signature genes and zero-filled background genes limit fidelity to the complete RNA-seq input. Microarray probe specificity, dynamic range, exact-symbol mapping, and different gene coverage can shift within-sample ranks. The model was not adapted to correct these shifts. Endpoint differences (SNP6 versus IHC/ISH), prior METABRIC use elsewhere in this project, and retrospective cohort selection constrain any claim of independent clinical validation. This experiment cannot distinguish all biological generalization effects from assay and label differences.

## Figures and reproducibility

The figures directory contains 400-dpi PNG and vector PDF versions of ROC, precision–recall, probability distribution, and HER2-group separation. Distribution histograms normalize within each group; separation plots show individual cases and boxplots. Dashed probability thresholds are frozen TCGA thresholds.

Run from the project root: `.venv/Scripts/python.exe CF38_Metabric_external_validation/scripts/CF38_validate.py`.

The script writes only inside CF38, verifies signature coefficients and manual logistic predictions, checks finite ranks and unique patients, and verifies input SHA-256 hashes are unchanged. The provenance JSON records file hashes, versions, counts, and settings. CF1–CF37 scripts were inspected but never executed or edited. A CF38-local copy of the official CPython 3.10.11 `_strptime.py` works around an existing corrupted system module without modifying the installed environment; source: https://raw.githubusercontent.com/python/cpython/v3.10.11/Lib/_strptime.py .

## Sources

- [cBioPortal METABRIC DataHub source](https://github.com/cBioPortal/datahub/tree/master/public/brca_metabric)
- [METABRIC study](https://www.cbioportal.org/study/summary?id=brca_metabric)
- [Published cohort methods identifying SNP6-derived HER2 status](https://pmc.ncbi.nlm.nih.gov/articles/PMC11882987/)

No retraining, model redevelopment, feature reselection, or additional experiments were performed.
'''
    (OUT/'report/CF38_report.md').write_text(report,encoding='utf-8')
    print('COMPLETE: '+str(OUT/'report/CF38_report.md'),flush=True)

if __name__=='__main__': main()
