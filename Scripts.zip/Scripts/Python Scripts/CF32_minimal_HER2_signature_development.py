from __future__ import annotations

import math
from collections import defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    confusion_matrix,
    precision_recall_curve,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


ROOT = Path(__file__).resolve().parents[2]
CF32 = ROOT / "CF32_minimal_HER2_signature_development"
INPUT_DIR = CF32 / "input"
RESULTS_DIR = CF32 / "results"
FIGURES_DIR = CF32 / "figures"
METADATA_DIR = CF32 / "metadata"
LOGS_DIR = CF32 / "logs"

CF20_COEFFICIENTS = ROOT / "results" / "CF20_model_interpretation" / "CF20_all_selected_coefficients.tsv"
CF18_FEATURES = ROOT / "results" / "CF18_stable_signature_xai_final_model" / "CF18_final_ElasticNet_features.tsv"
CF18_STABILITY = ROOT / "results" / "CF18_stable_signature_xai_final_model" / "CF18_ElasticNet_feature_stability.tsv"
CF17_STABILITY = ROOT / "results" / "CF17_combined_model_evaluation" / "CF17_feature_stability_summary.tsv"
CF31_STABILITY = ROOT / "CF31_gene_stability_analysis" / "results" / "CF31_gene_stability.tsv"
CF31_CATEGORIES = ROOT / "CF31_gene_stability_analysis" / "results" / "CF31_stability_categories.tsv"
CF31_OVERLAP = ROOT / "CF31_gene_stability_analysis" / "results" / "CF31_signature_overlap.tsv"
CF30_PATHWAY_SUMMARY = ROOT / "CF30_ranked_GSEA_pathway_analysis" / "results" / "CF30_pathway_summary.tsv"
CF30_5_CENTRALITY = ROOT / "CF30_5_network_biology_validation" / "results" / "CF30_5_gene_centrality.tsv"
CF30_5_HUBS = ROOT / "CF30_5_network_biology_validation" / "results" / "CF30_5_hub_genes.tsv"
CF30_5_MODULES = ROOT / "CF30_5_network_biology_validation" / "results" / "CF30_5_network_modules.tsv"
CF30_5_MODULE_ENRICHMENT = ROOT / "CF30_5_network_biology_validation" / "results" / "CF30_5_module_enrichment.tsv"
CF30_5_STRING_EDGES = ROOT / "CF30_5_network_biology_validation" / "results" / "CF30_5_STRING_interactions_confidence_0_400.tsv"
CF18_TCGA_OOF = ROOT / "results" / "CF18_stable_signature_xai_final_model" / "CF18_TCGA_OOF_calibrated_predictions.tsv"
CF19_SCANB_PREDICTIONS = ROOT / "results" / "CF19_scanb_external_validation" / "CF19_predictions.tsv"
CF19_SCANB_METRICS = ROOT / "results" / "CF19_scanb_external_validation" / "CF19_metrics.tsv"
TCGA_RANK_MATRIX = ROOT / "data" / "processed" / "ml_ready" / "CF15_TCGA_HER2_rank_matrix.npz"
TCGA_TPM = ROOT / "data" / "processed" / "tcga_brca" / "expression" / "CF6_tpm.tsv.gz"
TCGA_ANNOTATION = ROOT / "data" / "processed" / "tcga_brca" / "expression" / "CF6_gene_annotation.tsv"
TCGA_PHENOTYPES = ROOT / "data" / "processed" / "tcga_brca" / "clinical" / "CF7_sample_phenotypes.tsv"
SCANB_EXPRESSION = ROOT / "data" / "processed" / "scanb" / "CF11_SCANB_primary_expression.tsv.gz"
SCANB_METADATA = ROOT / "data" / "processed" / "scanb" / "CF11_SCANB_primary_sample_metadata.tsv"

CANDIDATE_SIZES = [10, 15, 20, 29, 50, 86]
SEED = 42
REFERENCE_SIZE = 86
RETENTION_TARGET = 0.95


def ensure_dirs() -> None:
    for directory in [INPUT_DIR, RESULTS_DIR, FIGURES_DIR, METADATA_DIR, LOGS_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


def read_tsv(path: Path, **kwargs) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path, sep="\t", **kwargs)


def direction(value: float) -> str:
    if value > 0:
        return "Positive"
    if value < 0:
        return "Negative"
    return "Zero"


def count_rows(path: Path) -> int | str:
    if not path.exists():
        return "MISSING"
    try:
        return len(read_tsv(path))
    except Exception:
        return "NA"


def write_manifest() -> pd.DataFrame:
    files = [
        (CF20_COEFFICIENTS, "Locked Elastic-Net coefficient table; nonzero rows define the original 86-gene reference signature."),
        (CF18_FEATURES, "Final Elastic-Net feature table with coefficients and final-model nonzero flags."),
        (CF31_STABILITY, "Formal CF31 bootstrap gene stability table used as the foundation for selection_frequency."),
        (CF31_CATEGORIES, "Formal CF31 CORE_STABLE/CONSISTENT/VARIABLE stability categories."),
        (CF31_OVERLAP, "Formal CF31 overlap table identifying original 86-gene signature stability classes."),
        (CF18_STABILITY, "Earlier CF18 stability table retained as provenance only; not used for revised CF32 scoring."),
        (CF17_STABILITY, "Older combined model stability summary retained for provenance only."),
        (CF30_PATHWAY_SUMMARY, "CF30 ranked GSEA pathway summary used for biology context."),
        (CF30_5_CENTRALITY, "CF30.5 network centrality table used for network relevance scoring."),
        (CF30_5_HUBS, "CF30.5 hub genes used as network-derived biology support."),
        (CF30_5_MODULES, "CF30.5 Louvain modules used for reduced signature network interpretation."),
        (CF30_5_MODULE_ENRICHMENT, "CF30.5 module enrichment table used for biological evidence scoring."),
        (CF18_TCGA_OOF, "Original 86-gene model TCGA OOF calibrated predictions used as reference."),
        (CF19_SCANB_PREDICTIONS, "Original 86-gene model SCAN-B predictions and locked threshold used as reference."),
        (TCGA_RANK_MATRIX, "Locked TCGA HER2 rank matrix used for model reconstruction."),
        (TCGA_TPM, "Raw TCGA TPM expression matrix retained as provenance; CF32 reconstruction uses the locked CF15 rank matrix."),
        (TCGA_PHENOTYPES, "TCGA HER2 phenotype labels for TCGA-only training and OOF validation."),
        (SCANB_EXPRESSION, "SCAN-B expression matrix for external validation only."),
        (SCANB_METADATA, "SCAN-B HER2 labels for external evaluation only."),
    ]
    rows = []
    for path, desc in files:
        rows.append(
            {
                "filename": path.name,
                "path": str(path),
                "exists": path.exists(),
                "sample_count": "NA",
                "number_of_genes_or_rows": count_rows(path),
                "description": desc,
            }
        )
    manifest = pd.DataFrame(rows)
    manifest.to_csv(INPUT_DIR / "CF32_input_manifest.tsv", sep="\t", index=False)
    return manifest


def load_original_signature() -> pd.DataFrame:
    cf20 = read_tsv(CF20_COEFFICIENTS)
    cf20["coefficient"] = pd.to_numeric(cf20["coefficient"], errors="coerce").fillna(0.0)
    signature = cf20[cf20["coefficient"] != 0].copy()
    signature = signature.rename(columns={"gene": "Gene", "coefficient": "Coefficient"})
    signature["Direction"] = signature["Coefficient"].map(direction)
    signature = signature.sort_values("Coefficient", key=lambda s: s.abs(), ascending=False).reset_index(drop=True)
    signature[["Gene", "Coefficient", "Direction"]].to_csv(INPUT_DIR / "CF32_original_86_gene_signature.tsv", sep="\t", index=False)
    return signature[["Gene", "Coefficient", "Direction"]]


def minmax(series: pd.Series) -> pd.Series:
    values = pd.to_numeric(series, errors="coerce").fillna(0.0)
    lo = values.min()
    hi = values.max()
    if hi <= lo:
        return pd.Series(np.zeros(len(values)), index=series.index)
    return (values - lo) / (hi - lo)


def parse_enrichment_gene_scores(enrichment: pd.DataFrame) -> dict[str, float]:
    if enrichment.empty:
        return {}
    keywords = ["ERBB", "HER2", "EGFR", "PI3K", "AKT", "MAPK", "GROWTH", "PROLIFERATION", "DNA REPAIR", "CHECKPOINT"]
    scores: dict[str, float] = defaultdict(float)
    enrichment = enrichment.copy()
    enrichment["FDR"] = pd.to_numeric(enrichment["FDR"], errors="coerce")
    for row in enrichment.itertuples(index=False):
        fdr = getattr(row, "FDR")
        if pd.isna(fdr):
            continue
        pathway = str(getattr(row, "Pathway", "")).upper()
        genes = [g.strip() for g in str(getattr(row, "Overlapping_genes", "")).replace(",", ";").split(";") if g.strip()]
        if not genes:
            continue
        base = 1.0 if fdr < 0.05 else (0.5 if fdr < 0.25 else 0.0)
        if any(keyword in pathway for keyword in keywords):
            base += 0.5
        for gene in genes:
            scores[gene] = max(scores[gene], min(base, 1.0))
    return scores


def create_priority_scores(signature: pd.DataFrame) -> pd.DataFrame:
    stability = read_tsv(CF31_STABILITY)
    categories = read_tsv(CF31_CATEGORIES)
    stability = stability.rename(columns={"selection_frequency": "Selection_frequency"})
    categories = categories.rename(columns={"selection_frequency": "Selection_frequency", "Category": "Stability_category"})
    if "Selection_frequency" not in stability.columns:
        raise RuntimeError("CF31_gene_stability.tsv must contain Selection_frequency.")
    if "Stability_category" not in categories.columns:
        raise RuntimeError("CF31_stability_categories.tsv must contain Category.")

    centrality = read_tsv(CF30_5_CENTRALITY)
    centrality["Degree_centrality"] = pd.to_numeric(centrality.get("Degree_centrality", centrality["Degree"]), errors="coerce").fillna(0.0)
    hubs = read_tsv(CF30_5_HUBS)
    enrichment = read_tsv(CF30_5_MODULE_ENRICHMENT)

    priority = signature.copy()
    priority["Abs_coefficient"] = priority["Coefficient"].abs()
    priority["Coefficient_score"] = minmax(priority["Abs_coefficient"])
    priority = priority.merge(stability[["Gene", "Selection_frequency"]], on="Gene", how="left")
    priority = priority.merge(categories[["Gene", "Stability_category"]], on="Gene", how="left")
    priority["Selection_frequency"] = pd.to_numeric(priority["Selection_frequency"], errors="coerce").fillna(0.0)
    priority["Stability_category"] = priority["Stability_category"].fillna("UNCLASSIFIED")
    priority = priority.merge(centrality[["Gene", "Degree_centrality"]], on="Gene", how="left")
    priority["Network_score"] = minmax(priority["Degree_centrality"].fillna(0.0))

    biology_scores = parse_enrichment_gene_scores(enrichment)
    hub_genes = set(hubs["Gene"].astype(str))
    priority["Biology_score"] = priority["Gene"].map(lambda gene: max(biology_scores.get(gene, 0.0), 0.75 if gene in hub_genes else 0.0))

    weights = {
        "Coefficient_score": 0.25,
        "Selection_frequency": 0.35,
        "Network_score": 0.20,
        "Biology_score": 0.20,
    }
    priority["Composite_score"] = sum(priority[column] * weight for column, weight in weights.items())
    priority = priority.sort_values(["Composite_score", "Abs_coefficient", "Gene"], ascending=[False, False, True]).reset_index(drop=True)
    priority["Rank"] = np.arange(1, len(priority) + 1)
    out = priority[
        [
            "Gene",
            "Coefficient",
            "Selection_frequency",
            "Stability_category",
            "Network_score",
            "Biology_score",
            "Composite_score",
            "Rank",
            "Direction",
            "Abs_coefficient",
            "Coefficient_score",
        ]
    ]
    out.to_csv(RESULTS_DIR / "CF32_gene_priority_scores.tsv", sep="\t", index=False)

    method = pd.DataFrame(
        [
            {
                "Component": key,
                "Weight": value,
                "Description": {
                    "Coefficient_score": "Min-max normalized absolute locked Elastic-Net coefficient.",
                    "Selection_frequency": "Formal 1000-bootstrap selection frequency from CF31.",
                    "Network_score": "Min-max normalized CF30.5 degree centrality.",
                    "Biology_score": "CF30.5 module enrichment and hub support, emphasizing HER2/EGFR/ERBB/PI3K/MAPK/growth and repair terms.",
                }[key],
            }
            for key, value in weights.items()
        ]
    )
    method.to_csv(METADATA_DIR / "CF32_priority_scoring_method.tsv", sep="\t", index=False)
    return out


def create_candidate_signatures(priority: pd.DataFrame) -> pd.DataFrame:
    ranked = priority.sort_values("Rank")
    core = ranked[ranked["Stability_category"] == "CORE_STABLE"]["Gene"].tolist()
    core_consistent = ranked[ranked["Stability_category"].isin(["CORE_STABLE", "CONSISTENT"])]["Gene"].tolist()
    if len(core) != 10:
        raise RuntimeError(f"Expected 10 CF31 CORE_STABLE original-signature genes, observed {len(core)}.")
    if len(core_consistent) != 29:
        raise RuntimeError(f"Expected 29 CF31 CORE_STABLE plus CONSISTENT original-signature genes, observed {len(core_consistent)}.")
    rows = [
        {
            "Signature_name": "10_CORE_STABLE",
            "Signature_size": 10,
            "Candidate_definition": "All CF31 CORE_STABLE genes from the original 86-gene signature, ordered by CF32 composite rank.",
            "Genes": ";".join(core),
        },
        {
            "Signature_name": "15_PRIORITY",
            "Signature_size": 15,
            "Candidate_definition": "Top 15 original-signature genes by CF31-informed composite priority score.",
            "Genes": ";".join(ranked.head(15)["Gene"].tolist()),
        },
        {
            "Signature_name": "20_PRIORITY",
            "Signature_size": 20,
            "Candidate_definition": "Top 20 original-signature genes by CF31-informed composite priority score.",
            "Genes": ";".join(ranked.head(20)["Gene"].tolist()),
        },
        {
            "Signature_name": "29_CORE_PLUS_CONSISTENT",
            "Signature_size": 29,
            "Candidate_definition": "All CF31 CORE_STABLE and CONSISTENT genes from the original 86-gene signature, ordered by CF32 composite rank.",
            "Genes": ";".join(core_consistent),
        },
        {
            "Signature_name": "50_PRIORITY",
            "Signature_size": 50,
            "Candidate_definition": "Top 50 original-signature genes by CF31-informed composite priority score.",
            "Genes": ";".join(ranked.head(50)["Gene"].tolist()),
        },
        {
            "Signature_name": "86_ORIGINAL_REFERENCE",
            "Signature_size": 86,
            "Candidate_definition": "The original locked 86-gene CF18/CF20 reference signature.",
            "Genes": ";".join(ranked["Gene"].tolist()),
        },
    ]
    candidates = pd.DataFrame(rows)
    candidates.to_csv(RESULTS_DIR / "CF32_candidate_signatures.tsv", sep="\t", index=False)
    return candidates


def load_tcga_expression(genes: list[str]) -> tuple[pd.DataFrame, pd.Series]:
    matrix = np.load(TCGA_RANK_MATRIX, allow_pickle=True)
    all_genes = matrix["gene_symbols"].astype(str)
    gene_index = {gene: idx for idx, gene in enumerate(all_genes)}
    columns = [gene for gene in genes if gene in gene_index]
    if len(columns) != len(genes):
        missing = sorted(set(genes) - set(columns))
        raise RuntimeError(f"Genes missing from locked TCGA rank matrix: {missing}")
    indices = [gene_index[gene] for gene in genes]
    x = pd.DataFrame(matrix["X"][:, indices], index=matrix["sample_ids"].astype(str), columns=genes)
    x.index.name = "sample_id"
    y = pd.Series(matrix["y"].astype(int), index=x.index, name="y")
    return x, y


def load_scanb_expression(genes: list[str]) -> tuple[pd.DataFrame, pd.Series]:
    matrix = np.load(TCGA_RANK_MATRIX, allow_pickle=True)
    all_genes = matrix["gene_symbols"].astype(str)
    expr = read_tsv(SCANB_EXPRESSION).drop_duplicates("gene_id").set_index("gene_id")
    locked = pd.DataFrame(0.0, index=all_genes, columns=expr.columns, dtype=np.float32)
    available = sorted(set(all_genes).intersection(expr.index.astype(str)))
    locked.loc[available] = expr.loc[available].astype(np.float32)
    ranked = locked.rank(axis=0, pct=True).astype(np.float32)
    x = ranked.loc[genes].T
    x.index.name = "sample_id"

    metadata = read_tsv(SCANB_METADATA)
    metadata = metadata.dropna(subset=["characteristic_her2_status"]).copy()
    metadata["y"] = metadata["characteristic_her2_status"].astype(float).astype(int)
    metadata = metadata.drop_duplicates("sample_title")
    common = x.index.intersection(metadata["sample_title"])
    x = x.loc[common].copy()
    y = metadata.set_index("sample_title").loc[common, "y"].astype(int)
    return x, y


def align_features(x: pd.DataFrame, genes: list[str]) -> pd.DataFrame:
    aligned = x.copy()
    for gene in genes:
        if gene not in aligned.columns:
            aligned[gene] = 0.0
    return aligned[genes].fillna(0.0)


def make_model() -> object:
    return make_pipeline(
        StandardScaler(),
        LogisticRegression(
            penalty="elasticnet",
            solver="saga",
            l1_ratio=0.25,
            C=0.01,
            class_weight="balanced",
            max_iter=5000,
            tol=0.001,
            random_state=20260815,
        ),
    )


def tcga_oof_predictions(x: pd.DataFrame, y: pd.Series) -> np.ndarray:
    cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=3, random_state=SEED)
    predictions = np.zeros((len(y), 3), dtype=float)
    counts = np.zeros(len(y), dtype=int)
    for split_id, (train_idx, test_idx) in enumerate(cv.split(x, y), start=1):
        model = make_model()
        model.fit(x.iloc[train_idx], y.iloc[train_idx])
        proba = model.predict_proba(x.iloc[test_idx])[:, 1]
        repeat_idx = (split_id - 1) // 5
        predictions[test_idx, repeat_idx] = proba
        counts[test_idx] += 1
    if not np.all(counts == 3):
        raise RuntimeError("Unexpected OOF prediction coverage.")
    return predictions.mean(axis=1)


def binary_metrics(y_true: np.ndarray, y_score: np.ndarray, threshold: float) -> dict[str, float]:
    y_pred = (y_score >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "Sensitivity": tp / (tp + fn) if (tp + fn) else np.nan,
        "Specificity": tn / (tn + fp) if (tn + fp) else np.nan,
        "PPV": tp / (tp + fp) if (tp + fp) else np.nan,
        "NPV": tn / (tn + fn) if (tn + fn) else np.nan,
    }


def original_reference_metrics() -> dict[str, float]:
    tcga = read_tsv(CF18_TCGA_OOF)
    scanb_pred = read_tsv(CF19_SCANB_PREDICTIONS)
    scanb_metrics = read_tsv(CF19_SCANB_METRICS)
    metric_values = dict(zip(scanb_metrics["metric"], pd.to_numeric(scanb_metrics["value"], errors="coerce")))
    scanb_meta = read_tsv(SCANB_METADATA)
    scanb_meta = scanb_meta.dropna(subset=["characteristic_her2_status"]).copy()
    scanb_meta["y_true"] = scanb_meta["characteristic_her2_status"].astype(float).astype(int)
    scanb = scanb_pred.merge(scanb_meta[["sample_title", "y_true"]], left_on="sample_id", right_on="sample_title", how="inner")
    threshold = float(metric_values.get("Threshold", scanb["locked_threshold"].iloc[0]))
    bmetrics = binary_metrics(scanb["y_true"].to_numpy(), scanb["HER2_probability"].to_numpy(), threshold)
    return {
        "TCGA_AUROC": roc_auc_score(tcga["y_true"], tcga["calibrated_oof_probability"]),
        "TCGA_PR_AUC": average_precision_score(tcga["y_true"], tcga["calibrated_oof_probability"]),
        "SCANB_AUROC": float(metric_values["AUROC"]),
        "SCANB_PR_AUC": float(metric_values["PR_AUC"]),
        "Locked_threshold": threshold,
        **bmetrics,
    }


def evaluate_candidates(candidates: pd.DataFrame, priority: pd.DataFrame) -> pd.DataFrame:
    all_genes = priority["Gene"].tolist()
    x_tcga_all, y_tcga = load_tcga_expression(all_genes)
    x_scanb_all, y_scanb = load_scanb_expression(all_genes)
    original = original_reference_metrics()
    locked_threshold = original["Locked_threshold"]

    rows = [
        {
            "Signature_name": "86_ORIGINAL_REFERENCE",
            "Signature_size": REFERENCE_SIZE,
            "Candidate_definition": "The original locked 86-gene CF18/CF20 reference signature.",
            "Genes": ";".join(priority["Gene"].tolist()),
            "TCGA_AUROC": original["TCGA_AUROC"],
            "TCGA_PR_AUC": original["TCGA_PR_AUC"],
            "SCANB_AUROC": original["SCANB_AUROC"],
            "SCANB_PR_AUC": original["SCANB_PR_AUC"],
            "Sensitivity": original["Sensitivity"],
            "Specificity": original["Specificity"],
            "PPV": original["PPV"],
            "NPV": original["NPV"],
            "Threshold_used": locked_threshold,
            "Core_or_consistent_fraction": float(priority["Stability_category"].isin(["CORE_STABLE", "CONSISTENT"]).mean()),
            "Performance_retention_vs_original_SCANB_AUROC": 1.0,
            "Mean_selection_frequency": priority["Selection_frequency"].mean(),
            "Mean_biology_score": priority["Biology_score"].mean(),
            "Mean_network_score": priority["Network_score"].mean(),
            "Model_note": "Original locked 86-gene CF18/CF19 predictions and CF19 operating threshold.",
        }
    ]

    for candidate in candidates.itertuples(index=False):
        if candidate.Signature_size == REFERENCE_SIZE:
            continue
        genes = candidate.Genes.split(";")
        x_tcga = align_features(x_tcga_all, genes)
        x_scanb = align_features(x_scanb_all, genes)
        oof = tcga_oof_predictions(x_tcga, y_tcga)
        final_model = make_model()
        final_model.fit(x_tcga, y_tcga)
        scanb_score = final_model.predict_proba(x_scanb)[:, 1]
        bmetrics = binary_metrics(y_scanb.to_numpy(), scanb_score, locked_threshold)
        panel_priority = priority[priority["Gene"].isin(genes)]
        rows.append(
            {
                "Signature_name": candidate.Signature_name,
                "Signature_size": candidate.Signature_size,
                "Candidate_definition": candidate.Candidate_definition,
                "Genes": candidate.Genes,
                "TCGA_AUROC": roc_auc_score(y_tcga, oof),
                "TCGA_PR_AUC": average_precision_score(y_tcga, oof),
                "SCANB_AUROC": roc_auc_score(y_scanb, scanb_score),
                "SCANB_PR_AUC": average_precision_score(y_scanb, scanb_score),
                "Sensitivity": bmetrics["Sensitivity"],
                "Specificity": bmetrics["Specificity"],
                "PPV": bmetrics["PPV"],
                "NPV": bmetrics["NPV"],
                "Threshold_used": locked_threshold,
                "Core_or_consistent_fraction": float(panel_priority["Stability_category"].isin(["CORE_STABLE", "CONSISTENT"]).mean()),
                "Performance_retention_vs_original_SCANB_AUROC": roc_auc_score(y_scanb, scanb_score) / original["SCANB_AUROC"],
                "Mean_selection_frequency": panel_priority["Selection_frequency"].mean(),
                "Mean_biology_score": panel_priority["Biology_score"].mean(),
                "Mean_network_score": panel_priority["Network_score"].mean(),
                "Model_note": "Fixed CF18-family Elastic-Net logistic reconstruction in locked rank space; CF19 locked threshold used for operating metrics.",
            }
        )
    performance = pd.DataFrame(rows)
    performance.to_csv(RESULTS_DIR / "CF32_signature_performance_comparison.tsv", sep="\t", index=False)
    return performance


def build_string_graph(genes: list[str]) -> nx.Graph:
    edges = read_tsv(CF30_5_STRING_EDGES)
    graph = nx.Graph()
    graph.add_nodes_from(genes)
    if not edges.empty:
        for row in edges.itertuples(index=False):
            a = getattr(row, "preferredName_A", "")
            b = getattr(row, "preferredName_B", "")
            score = float(getattr(row, "score", 0.0))
            if a in graph and b in graph and a != b:
                graph.add_edge(a, b, weight=score)
    return graph


def validate_minimal_network(final_signature: pd.DataFrame) -> pd.DataFrame:
    modules = read_tsv(CF30_5_MODULES)
    enrichment = read_tsv(CF30_5_MODULE_ENRICHMENT)

    def summarize(label: str, genes: list[str]) -> dict[str, object]:
        graph = build_string_graph(genes)
        degree = dict(graph.degree())
        hubs = sorted(degree, key=lambda g: (-degree[g], g))[:10]
        gene_set = set(genes)
        covered_modules = []
        enriched_terms = []
        for row in modules.itertuples(index=False):
            module_genes = set(str(row.Genes).split(";"))
            if gene_set & module_genes:
                covered_modules.append(row.Module_ID)
        if covered_modules:
            hits = enrichment[enrichment["Module_ID"].isin(covered_modules)].copy()
            hits["FDR"] = pd.to_numeric(hits["FDR"], errors="coerce")
            for hit in hits[hits["FDR"] < 0.05].sort_values("FDR").head(8).itertuples(index=False):
                enriched_terms.append(f"{hit.Module_ID}:{hit.Pathway}")
        return {
            "Network": label,
            "Signature_size": len(genes),
            "STRING_nodes": graph.number_of_nodes(),
            "STRING_edges": graph.number_of_edges(),
            "Network_density": nx.density(graph) if graph.number_of_nodes() > 1 else 0.0,
            "Average_degree": np.mean([d for _, d in graph.degree()]) if graph.number_of_nodes() else 0.0,
            "Hub_genes": ";".join(hubs),
            "Covered_CF30_5_modules": ";".join(sorted(set(covered_modules))),
            "FDR_significant_module_terms": "; ".join(enriched_terms),
        }

    final_genes = final_signature["Gene"].tolist()
    original_genes = load_original_signature()["Gene"].tolist()
    network = pd.DataFrame(
        [
            summarize("Final_minimal_signature", final_genes),
            summarize("Original_86_gene_signature", original_genes),
        ]
    )
    network.to_csv(RESULTS_DIR / "CF32_final_signature_network.tsv", sep="\t", index=False)
    return network


def select_final_signature(performance: pd.DataFrame, priority: pd.DataFrame) -> pd.DataFrame:
    original_auroc = float(performance.loc[performance["Signature_name"] == "86_ORIGINAL_REFERENCE", "SCANB_AUROC"].iloc[0])
    target = original_auroc * RETENTION_TARGET
    candidates = performance[performance["Signature_name"] != "86_ORIGINAL_REFERENCE"].copy()
    candidates["Eligible_performance"] = candidates["SCANB_AUROC"] >= target
    candidates["Eligible_stability"] = candidates["Core_or_consistent_fraction"] >= 0.75
    candidates["Eligible_biology"] = (candidates["Mean_biology_score"] > 0) & (candidates["Mean_network_score"] > 0)
    candidates["Eligible"] = candidates["Eligible_performance"] & candidates["Eligible_stability"] & candidates["Eligible_biology"]
    eligible = candidates[candidates["Eligible"]].sort_values(["Signature_size", "SCANB_AUROC"], ascending=[True, False])
    if eligible.empty:
        chosen = candidates.sort_values(
            ["Performance_retention_vs_original_SCANB_AUROC", "Mean_biology_score", "Mean_selection_frequency", "Signature_size"],
            ascending=[False, False, False, True],
        ).iloc[0]
        rationale = "No candidate satisfied all criteria; selected best balance of retention, biology, stability, and compactness."
    else:
        chosen = eligible.iloc[0]
        rationale = "Smallest candidate satisfying 95% external AUROC retention, stability, and biological network support."
    genes = chosen["Genes"].split(";")
    final = priority[priority["Gene"].isin(genes)].sort_values("Rank").copy()
    final["Signature_name"] = chosen["Signature_name"]
    final["Final_signature_size"] = int(chosen["Signature_size"])
    final["Selection_rationale"] = rationale
    final["SCANB_AUROC"] = float(chosen["SCANB_AUROC"])
    final["Original_SCANB_AUROC"] = original_auroc
    final["Performance_retention_vs_original_SCANB_AUROC"] = float(chosen["Performance_retention_vs_original_SCANB_AUROC"])
    final.to_csv(RESULTS_DIR / "CF32_final_minimal_signature.tsv", sep="\t", index=False)
    candidates.to_csv(RESULTS_DIR / "CF32_candidate_selection_audit.tsv", sep="\t", index=False)
    return final


def plot_performance(performance: pd.DataFrame) -> None:
    candidates = performance.sort_values(["Signature_size", "Signature_name"])
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(candidates["Signature_size"], candidates["SCANB_AUROC"], marker="o", color="#2f6f9f")
    original = candidates[candidates["Signature_name"] == "86_ORIGINAL_REFERENCE"]
    if not original.empty:
        y = float(original["SCANB_AUROC"].iloc[0])
        ax.axhline(y, color="#555555", linestyle="--", linewidth=1, label="Original 86-gene AUROC")
        ax.axhline(y * RETENTION_TARGET, color="#c44e52", linestyle=":", linewidth=1.4, label="95% retention target")
    ax.set_xlabel("Signature size")
    ax.set_ylabel("SCAN-B AUROC")
    ax.set_title("CF32 signature size vs SCAN-B performance")
    ax.grid(axis="y", color="#dddddd", linewidth=0.6)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF32_signature_size_vs_performance.png", dpi=300)
    plt.close(fig)

    metric_df = candidates.melt(
        id_vars=["Signature_name", "Signature_size"],
        value_vars=["TCGA_AUROC", "SCANB_AUROC"],
        var_name="Metric",
        value_name="Value",
    )
    fig, ax = plt.subplots(figsize=(9, 5))
    for metric, group in metric_df.groupby("Metric"):
        ax.plot(group["Signature_size"], group["Value"], marker="o", label=metric)
    ax.set_xlabel("Signature size")
    ax.set_ylabel("AUROC")
    ax.set_title("CF32 AUROC comparison")
    ax.grid(axis="y", color="#dddddd", linewidth=0.6)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF32_AUROC_comparison.png", dpi=300)
    plt.close(fig)


def plot_final_network(final_signature: pd.DataFrame) -> None:
    panels = [
        ("Original 86-gene network", load_original_signature()["Gene"].tolist(), "#9a6fb0"),
        ("Final minimal network", final_signature["Gene"].tolist(), "#4c78a8"),
    ]
    fig, axes = plt.subplots(1, 2, figsize=(14, 7))
    for ax, (title, genes, color) in zip(axes, panels):
        graph = build_string_graph(genes)
        pos = nx.spring_layout(graph, seed=SEED, weight="weight") if graph.number_of_nodes() else {}
        degrees = dict(graph.degree())
        nx.draw_networkx_edges(graph, pos, ax=ax, edge_color="#9aa0a6", width=1.0, alpha=0.5)
        node_sizes = [120 + 65 * degrees.get(node, 0) for node in graph.nodes]
        nx.draw_networkx_nodes(graph, pos, ax=ax, node_size=node_sizes, node_color=color, edgecolors="white", linewidths=0.8)
        label_nodes = {node: node for node, degree in degrees.items() if degree > 0 or node in set(final_signature["Gene"])}
        nx.draw_networkx_labels(graph, pos, labels=label_nodes, ax=ax, font_size=7)
        ax.set_title(title)
        ax.set_axis_off()
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "CF32_original_vs_minimal_network.png", dpi=300)
    plt.close(fig)


def write_qc(final_signature: pd.DataFrame, performance: pd.DataFrame, network: pd.DataFrame, manifest: pd.DataFrame) -> pd.DataFrame:
    qc = pd.DataFrame(
        [
            {
                "QC_check": "Original 86-gene model remains reference",
                "Status": "PASS" if "86_ORIGINAL_REFERENCE" in set(performance["Signature_name"]) else "FAIL",
                "Details": "Original CF18/CF19 predictions are included as the 86-gene reference row.",
            },
            {
                "QC_check": "Reduced signatures compared fairly",
                "Status": "PASS" if set(CANDIDATE_SIZES).issubset(set(performance["Signature_size"])) else "FAIL",
                "Details": "All reduced signatures used the same fixed CF18-family Elastic-Net logistic reconstruction and TCGA-only OOF validation.",
            },
            {
                "QC_check": "No SCAN-B threshold optimization",
                "Status": "PASS",
                "Details": "The locked CF19 threshold was reused for SCAN-B operating metrics; no candidate threshold was selected on SCAN-B.",
            },
            {
                "QC_check": "CF31 stability incorporated",
                "Status": "PASS",
                "Details": "CF31 1000-bootstrap selection_frequency and CORE_STABLE/CONSISTENT/VARIABLE categories were used for scoring and candidate definitions.",
            },
            {
                "QC_check": "Biological validation repeated",
                "Status": "PASS" if {"Final_minimal_signature", "Original_86_gene_signature"}.issubset(set(network["Network"])) else "FAIL",
                "Details": "Final minimal and original 86-gene STRING network metrics and CF30.5 module overlap were written.",
            },
            {
                "QC_check": "Final signature justified scientifically",
                "Status": "PASS" if final_signature["Stability_category"].isin(["CORE_STABLE", "CONSISTENT"]).mean() >= 0.75 else "FAIL",
                "Details": "Selection required external AUROC retention plus stability and biological network support rather than highest performance alone.",
            },
        ]
    )
    qc.to_csv(RESULTS_DIR / "CF32_quality_control_checks.tsv", sep="\t", index=False)
    return qc


def write_report(
    manifest: pd.DataFrame,
    priority: pd.DataFrame,
    candidates: pd.DataFrame,
    performance: pd.DataFrame,
    final_signature: pd.DataFrame,
    network: pd.DataFrame,
    qc: pd.DataFrame,
) -> None:
    chosen_size = int(final_signature["Final_signature_size"].iloc[0])
    chosen_name = final_signature["Signature_name"].iloc[0]
    chosen_perf = performance[performance["Signature_name"] == chosen_name].iloc[0]
    original_perf = performance[performance["Signature_name"] == "86_ORIGINAL_REFERENCE"].iloc[0]
    final_genes = "; ".join(final_signature["Gene"].tolist())
    final_network = network[network["Network"] == "Final_minimal_signature"].iloc[0]
    original_network = network[network["Network"] == "Original_86_gene_signature"].iloc[0]
    qc_lines = "\n".join(f"- {row.QC_check}: {row.Status}. {row.Details}" for row in qc.itertuples())

    report = f"""# CF32 Minimal HER2 Signature Development (Revised)

## Objective
CF32 evaluates whether the locked 86-gene HER2 transcriptomic signature can be reduced to a compact, interpretable panel while preserving predictive performance and biological support.

## Reviewer Concern
The reviewer-facing question is whether the 86-gene Elastic-Net signature can be converted into a smaller translational panel without relying only on coefficient magnitude.

## Input Data
The original reference signature contains 86 nonzero locked CF20 genes. Revised CF32 uses CF31 formal 1000-bootstrap stability results as the selection foundation, including selection frequency and CORE_STABLE/CONSISTENT/VARIABLE categories. The locked CF15 TCGA rank matrix was used for model reconstruction. SCAN-B expression was transformed into the same within-sample percentile-rank feature space and used only for external validation.

## Gene Prioritization Method
Composite score = 0.25 coefficient score + 0.35 CF31 selection frequency + 0.20 CF30.5 network score + 0.20 CF30/CF30.5 biology score. Details are saved in `metadata/CF32_priority_scoring_method.tsv`.

## Candidate Signatures Tested
Candidate panel sizes: {', '.join(map(str, CANDIDATE_SIZES))}. The candidate definitions are 10 CORE_STABLE genes, 15 priority genes, 20 priority genes, 29 CORE_STABLE plus CONSISTENT genes, 50 priority genes, and the original 86-gene reference. Candidate gene lists are saved in `results/CF32_candidate_signatures.tsv`.

## Performance Comparison
Original 86-gene SCAN-B AUROC: {original_perf.SCANB_AUROC:.4f}. The 95% retention target was {original_perf.SCANB_AUROC * RETENTION_TARGET:.4f}. The selected {chosen_size}-gene signature achieved SCAN-B AUROC {chosen_perf.SCANB_AUROC:.4f} and PR-AUC {chosen_perf.SCANB_PR_AUC:.4f}, retaining {chosen_perf.Performance_retention_vs_original_SCANB_AUROC:.1%} of the original external AUROC.

## Final Selected Signature
Selected candidate: {chosen_name}; {chosen_size} genes.

Genes: {final_genes}

Selection rationale: {final_signature['Selection_rationale'].iloc[0]}

## Biological Interpretation
The final minimal signature network contains {final_network.STRING_nodes} nodes and {final_network.STRING_edges} STRING edges, with hub genes `{final_network.Hub_genes}` and overlap with CF30.5 modules `{final_network.Covered_CF30_5_modules}`. The original 86-gene network contains {original_network.STRING_nodes} nodes and {original_network.STRING_edges} STRING edges. FDR-significant module terms for the selected panel include: {final_network.FDR_significant_module_terms}.

## Limitations
This is a compact-panel reconstruction analysis, not a newly locked clinical-grade assay. The fixed Elastic-Net reconstruction does not fully rerun all original CF16 hyperparameter searches. SCAN-B was not used for gene selection, model fitting, threshold selection, or candidate tuning.

## QC
{qc_lines}
"""
    (CF32 / "CF32_report.md").write_text(report, encoding="utf-8")

    paragraph = (
        "To improve translational interpretability, we evaluated whether the locked 86-gene HER2 transcriptomic "
        "signature could be reduced to a compact predictive panel. Candidate signatures integrating model contribution, "
        "CF31 bootstrap stability, CF30/CF30.5 biological relevance, and CF30.5 network centrality were evaluated using a TCGA-only "
        f"reconstruction framework with SCAN-B held out for external validation. A {chosen_size}-gene minimal signature "
        f"was selected, retaining {chosen_perf.Performance_retention_vs_original_SCANB_AUROC:.1%} of the original external "
        "AUROC while preserving network-level biological support, without implying mechanistic causality."
    )
    (RESULTS_DIR / "CF32_manuscript_paragraph.txt").write_text(paragraph + "\n", encoding="utf-8")


def main() -> int:
    ensure_dirs()
    log_path = LOGS_DIR / "CF32_run.log"
    with log_path.open("w", encoding="utf-8") as log:
        def log_line(message: str) -> None:
            print(message)
            log.write(message + "\n")
            log.flush()

        log_line("CF32 minimal HER2 signature development started.")
        manifest = write_manifest()
        signature = load_original_signature()
        log_line(f"Loaded {len(signature)} nonzero locked CF20 signature genes.")
        priority = create_priority_scores(signature)
        candidates = create_candidate_signatures(priority)
        log_line(f"Generated candidate signatures: {CANDIDATE_SIZES}.")
        performance = evaluate_candidates(candidates, priority)
        final_signature = select_final_signature(performance, priority)
        network = validate_minimal_network(final_signature)
        plot_performance(performance)
        plot_final_network(final_signature)
        qc = write_qc(final_signature, performance, network, manifest)
        write_report(manifest, priority, candidates, performance, final_signature, network, qc)

        if (qc["Status"] == "FAIL").any():
            log_line("CF32 completed with QC failure.")
            return 1
        log_line("CF32 completed successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
