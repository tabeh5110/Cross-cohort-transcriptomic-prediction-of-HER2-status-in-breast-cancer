#!/usr/bin/env python
"""
CF13 - Cross-cohort identifier and endpoint harmonization

Cohort roles
------------
TCGA-BRCA : discovery / model-development cohort
SCAN-B    : independent external transcriptomic validation cohort
APOLLO    : orthogonal transcriptomic/proteogenomic confirmation cohort

Scientific rule for CF13
------------------------
CF13 harmonizes IDENTIFIERS and endpoint labels only. It intentionally does
NOT combine expression matrices and does NOT force unlike expression scales
onto one common distribution.

Native expression scales remain:
  TCGA-BRCA : TPM (CF6)
  SCAN-B    : deposited log2(FPKM + 0.1)
  APOLLO    : deposited UQ-normalized log2 RNA expression
  APOLLO protein/phosphoprotein : deposited Level-3 quantitative values

Forbidden in CF13:
  - pooled normalization across cohorts
  - ComBat across discovery and validation cohorts
  - quantile normalization across cohorts
  - cohort-wide z-scoring that uses validation-cohort distribution
  - feature selection
  - ML training/tuning

The key output is a one-to-one gene-symbol crosswalk and endpoint audit.
No large duplicate expression matrices are written.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import logging
import os
import platform
import re
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path.cwd()

# Upstream stage gates
CF11_SUMMARY = ROOT / "results" / "CF11_scanb_acquisition_qc" / "CF11_summary.tsv"
CF12_SUMMARY = ROOT / "results" / "CF12_apollo_brca1_acquisition_qc" / "CF12_summary.tsv"

# TCGA
TCGA_DIR = ROOT / "data" / "processed" / "tcga_brca"
TCGA_EXPRESSION_DIR = TCGA_DIR / "expression"
TCGA_GENE_ANNOTATION = TCGA_EXPRESSION_DIR / "CF6_gene_annotation.tsv"
TCGA_TPM = TCGA_EXPRESSION_DIR / "CF6_tpm.tsv.gz"
TCGA_SAMPLE_MANIFEST = TCGA_EXPRESSION_DIR / "CF6_final_sample_manifest.tsv"

# SCAN-B
SCANB_EXPRESSION = ROOT / "data" / "processed" / "scanb" / "CF11_SCANB_primary_expression.tsv.gz"
SCANB_METADATA = ROOT / "data" / "processed" / "scanb" / "CF11_SCANB_primary_sample_metadata.tsv"

# APOLLO
APOLLO_RAW = ROOT / "data" / "raw" / "apollo_brca1" / "open"
APOLLO_PROCESSED = ROOT / "data" / "processed" / "apollo_brca1"

APOLLO_RNA = APOLLO_RAW / "apollo-brca1.rnaseq.expressed_genes.level3.UQnorm_log2.txt"
APOLLO_PROTEIN = APOLLO_RAW / "apollo-brca1.globalproteomics_level3_unimputed.txt"
APOLLO_PHOSPHO = APOLLO_RAW / "apollo-brca1.phosphoproteomics_level3_adjusted_by_global_unimputed.txt"
APOLLO_CASES = APOLLO_PROCESSED / "CF12_case_sample_inventory.tsv"

# CF13 outputs
RESULTS = ROOT / "results" / "CF13_cross_cohort_harmonization"
PROCESSED = ROOT / "data" / "processed" / "cross_cohort"
LOG_DIR = ROOT / "logs"
LOG_FILE = LOG_DIR / "CF13_cross_cohort_harmonization.log"

EXPECTED_TCGA_SAMPLES = 1206
EXPECTED_SCANB_SAMPLES = 3273
EXPECTED_SCANB_GENES = 30865
EXPECTED_APOLLO_CASES = 68

# Endpoint fields should come from pathology/clinical data, never expression-derived
# classifier outputs.
FORBIDDEN_ENDPOINT_NAME_TOKENS = {
    "sgc", "mgc", "prediction", "predicted", "classifier", "pam50",
    "rna_classifier", "expression_classifier",
}


# ============================================================
# UTILITIES
# ============================================================

def setup_logging() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    PROCESSED.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(block_size), b""):
            h.update(block)
    return h.hexdigest()


def load_gate(path: Path, metric_name: str) -> str:
    df = pd.read_csv(path, sep="\t", dtype=str)
    if not {"metric", "value"}.issubset(df.columns):
        raise RuntimeError(f"Summary lacks metric/value columns: {path}")
    d = dict(zip(df["metric"], df["value"]))
    return str(d.get(metric_name, ""))


def clean_symbol(x) -> Optional[str]:
    if pd.isna(x):
        return None
    s = str(x).strip().strip('"')
    if s == "" or s.lower() in {"na", "nan", "none", "null"}:
        return None
    return s


def stream_first_field_gzip(path: Path, delimiter: bytes = b"\t") -> Tuple[str, List[str]]:
    """
    Read only the first field of each row from a wide gzipped text matrix.
    This avoids parsing millions of numerical cells.

    Returns header first-field name and data-row first fields.
    """
    vals: List[str] = []
    with gzip.open(path, "rb") as fh:
        header = fh.readline()
        if not header:
            raise RuntimeError(f"Empty gzip table: {path}")
        first_header = header.split(delimiter, 1)[0].decode("utf-8", errors="replace").strip()

        for raw in fh:
            if not raw:
                continue
            first = raw.split(delimiter, 1)[0].decode("utf-8", errors="replace").strip()
            vals.append(first)

    return first_header, vals


def table_header(path: Path, sep: str = "\t", compression=None) -> List[str]:
    return list(pd.read_csv(path, sep=sep, nrows=0, compression=compression).columns)


def find_tcga_clinical_table() -> Path:
    """
    Locate the CF7 processed clinical table by header content rather than
    hard-coding a filename that may differ from earlier script versions.
    """
    candidates = sorted(set(
        list(TCGA_DIR.rglob("*CF7*.tsv"))
        + list((ROOT / "results").rglob("CF7*.tsv"))
        + list((ROOT / "results").rglob("*CF7*clinical*.tsv"))
    ))
    if not candidates:
        raise FileNotFoundError(
            "No frozen CF7 clinical TSV could be found under "
            "data/processed/tcga_brca or results/. "
            "CF13 requires the CF7 clinical harmonization output."
        )

    scored = []
    for path in candidates:
        try:
            cols = [norm_col(c) for c in pd.read_csv(path, sep="\t", nrows=0).columns]
        except Exception:
            continue

        score = 0
        joined = " ".join(cols)
        for token in ["patient", "er", "pr", "pgr", "her2", "tnbc", "receptor"]:
            if token in joined:
                score += 1

        # Prefer tables in a clinical-named directory/file.
        if "clinical" in str(path).lower():
            score += 3

        scored.append((score, path))

    if not scored:
        raise RuntimeError("CF7 TSV files were found but none could be read.")

    scored.sort(key=lambda x: (x[0], str(x[1])), reverse=True)
    best_score, best = scored[0]

    if best_score < 4:
        raise RuntimeError(
            "Could not confidently identify the frozen CF7 clinical table. "
            "Candidates: " + "; ".join(str(p) for _, p in scored[:10])
        )

    return best


def norm_col(x: str) -> str:
    s = str(x).strip().lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    return s.strip("_")


def choose_column(
    df: pd.DataFrame,
    candidates: Sequence[str],
    required_tokens: Sequence[str] = (),
    reject_tokens: Sequence[str] = (),
) -> Optional[str]:
    """
    Deterministic clinical-field selection.
    Exact normalized candidate names are preferred, then token matching.
    """
    normalized = {c: norm_col(c) for c in df.columns}

    # Exact candidate match.
    candidate_norms = [norm_col(x) for x in candidates]
    exact = [
        c for c, n in normalized.items()
        if n in candidate_norms
        and not any(tok in n for tok in reject_tokens)
    ]
    if len(exact) == 1:
        return exact[0]
    if len(exact) > 1:
        # Prefer shortest, most literal name.
        return sorted(exact, key=lambda c: (len(norm_col(c)), norm_col(c)))[0]

    # Token fallback.
    hits = []
    for c, n in normalized.items():
        if any(tok in n for tok in reject_tokens):
            continue
        if required_tokens and all(tok in n for tok in required_tokens):
            hits.append(c)

    if len(hits) == 1:
        return hits[0]

    return None


def normalize_receptor_value(x) -> Optional[str]:
    """
    Normalize pathology/clinical receptor values to POSITIVE / NEGATIVE / NA.
    Conservative: equivocal, borderline and indeterminate stay missing.
    """
    if pd.isna(x):
        return None

    s = str(x).strip().lower()
    if s in {"", "na", "nan", "none", "null", "unknown", "not reported",
             "not available", "not evaluated", "indeterminate", "equivocal",
             "borderline", "ambiguous"}:
        return None

    # Exact common encodings.
    if s in {"1", "1.0", "positive", "pos", "yes", "true", "present"}:
        return "POSITIVE"
    if s in {"0", "0.0", "negative", "neg", "no", "false", "absent"}:
        return "NEGATIVE"

    # Conservative phrase handling.
    if "positive" in s and "negative" not in s:
        return "POSITIVE"
    if "negative" in s and "positive" not in s:
        return "NEGATIVE"

    return None


def compute_tnbc(er: Optional[str], pr: Optional[str], her2: Optional[str]) -> Optional[str]:
    if er is None or pr is None or her2 is None:
        return None
    if er == "NEGATIVE" and pr == "NEGATIVE" and her2 == "NEGATIVE":
        return "TNBC"
    return "NON_TNBC"


def normalize_apollo_sample_id(x: str) -> str:
    """
    RNA uses AP-RP88-9X whereas proteomics commonly uses AP.RP88.9X.
    Convert both forms to AP-RP88-9X.
    """
    s = str(x).strip().strip('"')
    if s.startswith("AP."):
        s = s.replace(".", "-")
    return s


def apollo_sample_columns(columns: Sequence[str]) -> List[str]:
    return [c for c in columns if re.match(r"^AP[.-]", str(c))]


def split_gene_tokens(raw) -> List[str]:
    """
    Preserve unambiguous gene mappings while supporting occasional multi-gene
    annotations. Hyphens are not delimiters because they occur in HGNC symbols.
    """
    s = clean_symbol(raw)
    if s is None:
        return []

    # Most rows are one gene. Split only on strong multi-gene separators.
    tokens = re.split(r"[;,|/]+", s)
    out = []
    for token in tokens:
        token = token.strip()
        if token and token.lower() not in {"na", "nan"}:
            out.append(token)

    # Stable de-duplication.
    return list(dict.fromkeys(out))


def unique_symbol_table(
    source_name: str,
    raw_symbols: Sequence[str],
    raw_ids: Optional[Sequence[str]] = None,
) -> pd.DataFrame:
    if raw_ids is None:
        raw_ids = [""] * len(raw_symbols)

    rows = []
    for rid, sym in zip(raw_ids, raw_symbols):
        cs = clean_symbol(sym)
        if cs is not None:
            rows.append((str(rid), cs))

    tmp = pd.DataFrame(rows, columns=["source_feature_id", "gene_symbol"])
    counts = tmp.groupby("gene_symbol").size().rename("source_symbol_multiplicity")
    tmp = tmp.merge(counts, on="gene_symbol", how="left")
    tmp["one_to_one_symbol"] = tmp["source_symbol_multiplicity"].eq(1)
    tmp["source"] = source_name
    return tmp


def get_tcga_symbol_column(annotation: pd.DataFrame) -> str:
    for candidate in ["gene_name", "gene_symbol", "symbol", "hugo_symbol", "gene"]:
        for c in annotation.columns:
            if norm_col(c) == candidate:
                return c
    raise RuntimeError(
        "CF6_gene_annotation.tsv lacks a recognizable gene-symbol column. "
        f"Columns: {list(annotation.columns)}"
    )


def get_tcga_id_column(annotation: pd.DataFrame) -> str:
    for candidate in ["gene_id", "ensembl_gene_id", "ensembl_id"]:
        for c in annotation.columns:
            if norm_col(c) == candidate:
                return c
    return annotation.columns[0]


def receptor_field_map(df: pd.DataFrame, cohort: str) -> Dict[str, Optional[str]]:
    reject = list(FORBIDDEN_ENDPOINT_NAME_TOKENS)

    er = choose_column(
        df,
        candidates=[
            "er_status", "er_status_final", "final_er_status", "er_status_harmonized",
            "er_status_definitive", "estrogen_receptor_status",
            "characteristic_er_status", "er",
        ],
        required_tokens=["er", "status"],
        reject_tokens=reject,
    )

    pr = choose_column(
        df,
        candidates=[
            "pr_status", "pgr_status", "pr_status_final", "pgr_status_final",
            "final_pr_status", "final_pgr_status", "pr_status_harmonized",
            "pgr_status_harmonized", "pr_status_definitive", "pgr_status_definitive",
            "progesterone_receptor_status", "characteristic_pgr_status",
            "characteristic_pr_status", "pr", "pgr",
        ],
        required_tokens=[],
        reject_tokens=reject,
    )

    # Safer fallback for PR/PgR.
    if pr is None:
        possible = []
        for c in df.columns:
            n = norm_col(c)
            if any(tok in n for tok in reject):
                continue
            if ("pgr" in n or re.search(r"(^|_)pr(_|$)", n)) and "status" in n:
                possible.append(c)
        if len(possible) == 1:
            pr = possible[0]

    her2 = choose_column(
        df,
        candidates=[
            "her2_status", "her2_status_final", "final_her2_status",
            "her2_status_harmonized", "her2_status_definitive",
            "her2_receptor_status", "characteristic_her2_status",
        ],
        required_tokens=["her2", "status"],
        reject_tokens=reject,
    )

    return {"ER": er, "PR": pr, "HER2": her2}


def sample_id_column(df: pd.DataFrame, cohort: str) -> str:
    candidates = [
        "patient_id", "case_submitter_id", "submitter_id", "case_id",
        "sample_title", "sample_id", "geo_accession",
    ]
    for cand in candidates:
        for c in df.columns:
            if norm_col(c) == cand:
                return c
    raise RuntimeError(f"Could not find ID column for {cohort} metadata.")


def build_endpoint_manifest(df: pd.DataFrame, cohort: str) -> Tuple[pd.DataFrame, Dict[str, Optional[str]]]:
    fmap = receptor_field_map(df, cohort)
    sid = sample_id_column(df, cohort)

    if not all(fmap.values()):
        missing = [k for k, v in fmap.items() if v is None]
        raise RuntimeError(
            f"{cohort}: could not resolve measured/pathology receptor columns for {missing}. "
            f"Detected columns: {list(df.columns)}"
        )

    out = pd.DataFrame({
        "cohort": cohort,
        "source_id": df[sid].astype(str),
        "ER_source": df[fmap["ER"]],
        "PR_source": df[fmap["PR"]],
        "HER2_source": df[fmap["HER2"]],
    })

    out["ER"] = out["ER_source"].map(normalize_receptor_value)
    out["PR"] = out["PR_source"].map(normalize_receptor_value)
    out["HER2"] = out["HER2_source"].map(normalize_receptor_value)
    out["TNBC"] = [
        compute_tnbc(e, p, h)
        for e, p, h in zip(out["ER"], out["PR"], out["HER2"])
    ]

    return out, fmap


def write_feature_map_from_apollo_protein(path: Path) -> Tuple[pd.DataFrame, List[str]]:
    header_cols = table_header(path, sep="\t")
    sample_cols = apollo_sample_columns(header_cols)

    df = pd.read_csv(
        path,
        sep="\t",
        usecols=["Accession", "Protein", "Gene"],
        low_memory=False,
    )

    required = {"Accession", "Protein", "Gene"}
    if not required.issubset(df.columns):
        raise RuntimeError(f"APOLLO protein file missing columns: {required - set(df.columns)}")

    rows = []
    for idx, row in df[["Accession", "Protein", "Gene"]].iterrows():
        genes = split_gene_tokens(row["Gene"])
        if not genes:
            rows.append({
                "protein_row_index": idx,
                "accession": row["Accession"],
                "protein_description": row["Protein"],
                "gene_symbol": None,
                "raw_gene_field": row["Gene"],
                "gene_mapping_count_for_feature": 0,
                "unambiguous_gene_mapping": False,
            })
        else:
            for g in genes:
                rows.append({
                    "protein_row_index": idx,
                    "accession": row["Accession"],
                    "protein_description": row["Protein"],
                    "gene_symbol": g,
                    "raw_gene_field": row["Gene"],
                    "gene_mapping_count_for_feature": len(genes),
                    "unambiguous_gene_mapping": len(genes) == 1,
                })

    return pd.DataFrame(rows), sample_cols


def write_feature_map_from_apollo_phospho(path: Path) -> Tuple[pd.DataFrame, List[str]]:
    needed = {
        "Accession_Sites_numSitesPresent_numSitesBest_Oxidation_mapper",
        "Gene", "Accession", "Protein", "Sites", "INglobal",
    }

    header_cols = table_header(path, sep="\t")
    sample_cols = apollo_sample_columns(header_cols)

    df = pd.read_csv(
        path,
        sep="\t",
        usecols=list(needed),
        low_memory=False,
    )

    missing = needed - set(df.columns)
    if missing:
        raise RuntimeError(f"APOLLO phosphoproteomics file missing columns: {missing}")
    feature_col = "Accession_Sites_numSitesPresent_numSitesBest_Oxidation_mapper"

    rows = []
    for idx, row in df[list(needed)].iterrows():
        genes = split_gene_tokens(row["Gene"])
        if not genes:
            rows.append({
                "phospho_row_index": idx,
                "phospho_feature_id": row[feature_col],
                "accession": row["Accession"],
                "protein_description": row["Protein"],
                "sites": row["Sites"],
                "in_global_proteome": row["INglobal"],
                "gene_symbol": None,
                "raw_gene_field": row["Gene"],
                "gene_mapping_count_for_feature": 0,
                "unambiguous_gene_mapping": False,
            })
        else:
            for g in genes:
                rows.append({
                    "phospho_row_index": idx,
                    "phospho_feature_id": row[feature_col],
                    "accession": row["Accession"],
                    "protein_description": row["Protein"],
                    "sites": row["Sites"],
                    "in_global_proteome": row["INglobal"],
                    "gene_symbol": g,
                    "raw_gene_field": row["Gene"],
                    "gene_mapping_count_for_feature": len(genes),
                    "unambiguous_gene_mapping": len(genes) == 1,
                })

    return pd.DataFrame(rows), sample_cols


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    setup_logging()
    t0 = time.time()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF13 - CROSS-COHORT HARMONIZATION")
    logging.info("============================================================")
    logging.info("")
    logging.info("Estimated runtime: ~5-15 minutes")
    logging.info("Likely bottleneck: streaming the wide SCAN-B gzip matrix")
    logging.info("Long silent period expected: at most a few minutes during SCAN-B row-ID scan")
    logging.info("No large duplicate expression matrices will be created.")
    logging.info("")

    # --------------------------------------------------------
    # 1. Upstream gate + input validation
    # --------------------------------------------------------
    logging.info("[1/8] Validating frozen upstream stages and required inputs...")
    logging.info("")

    required = [
        CF11_SUMMARY, CF12_SUMMARY,
        TCGA_GENE_ANNOTATION, TCGA_TPM, TCGA_SAMPLE_MANIFEST,
        SCANB_EXPRESSION, SCANB_METADATA,
        APOLLO_RNA, APOLLO_PROTEIN, APOLLO_PHOSPHO, APOLLO_CASES,
    ]
    for p in required:
        if not p.exists():
            raise FileNotFoundError(f"Required CF13 input missing: {p}")

    if not load_gate(CF11_SUMMARY, "CF11 stage gate").upper().startswith("PASS"):
        raise RuntimeError("CF11 is not frozen with PASS.")
    if not load_gate(CF12_SUMMARY, "CF12 stage gate").upper().startswith("PASS"):
        raise RuntimeError("CF12 is not frozen with PASS.")

    tcga_clinical_path = find_tcga_clinical_table()
    logging.info(f"Resolved CF7 clinical table: {tcga_clinical_path}")
    logging.info("CF11 gate: PASS")
    logging.info("CF12 gate: PASS")
    logging.info("")

    # --------------------------------------------------------
    # 2. TCGA gene-symbol mapping
    # --------------------------------------------------------
    logging.info("[2/8] Building one-to-one TCGA Ensembl-to-symbol map...")
    logging.info("")

    anno = pd.read_csv(TCGA_GENE_ANNOTATION, sep="\t", dtype=str)
    tcga_id_col = get_tcga_id_column(anno)
    tcga_symbol_col = get_tcga_symbol_column(anno)

    tcga_map = unique_symbol_table(
        "TCGA",
        anno[tcga_symbol_col].tolist(),
        anno[tcga_id_col].tolist(),
    )

    # Preserve annotation context where possible.
    context_cols = [
        c for c in anno.columns
        if norm_col(c) in {"gene_type", "gene_biotype", "chromosome", "seqname"}
    ]
    if context_cols:
        context = anno[[tcga_id_col] + context_cols].copy()
        context = context.rename(columns={tcga_id_col: "source_feature_id"})
        tcga_map = tcga_map.merge(context, on="source_feature_id", how="left")

    tcga_unique = tcga_map.loc[tcga_map["one_to_one_symbol"], "gene_symbol"]
    tcga_unique_set = set(tcga_unique)

    tpm_header = table_header(TCGA_TPM, sep="\t", compression="gzip")
    tcga_tpm_samples = len(tpm_header) - 1

    if tcga_tpm_samples != EXPECTED_TCGA_SAMPLES:
        raise RuntimeError(
            f"TCGA TPM sample columns={tcga_tpm_samples}; expected {EXPECTED_TCGA_SAMPLES}."
        )

    logging.info(f"TCGA annotation rows: {len(anno)}")
    logging.info(f"TCGA non-missing symbols: {tcga_map['gene_symbol'].nunique()}")
    logging.info(f"TCGA one-to-one symbols: {len(tcga_unique_set)}")
    logging.info(f"TCGA TPM sample columns: {tcga_tpm_samples}")
    logging.info("")

    # --------------------------------------------------------
    # 3. SCAN-B gene symbols
    # --------------------------------------------------------
    logging.info("[3/8] Streaming SCAN-B gene-symbol identifiers...")
    logging.info("      Native values remain deposited log2(FPKM + 0.1).")
    logging.info("")

    scanb_first_col, scanb_symbols_raw = stream_first_field_gzip(SCANB_EXPRESSION)

    if len(scanb_symbols_raw) != EXPECTED_SCANB_GENES:
        raise RuntimeError(
            f"SCAN-B gene rows={len(scanb_symbols_raw)}; expected {EXPECTED_SCANB_GENES}."
        )

    scanb_map = unique_symbol_table("SCANB", scanb_symbols_raw, scanb_symbols_raw)
    scanb_unique_set = set(
        scanb_map.loc[scanb_map["one_to_one_symbol"], "gene_symbol"]
    )

    scanb_header = table_header(SCANB_EXPRESSION, sep="\t", compression="gzip")
    scanb_samples = len(scanb_header) - 1
    if scanb_samples != EXPECTED_SCANB_SAMPLES:
        raise RuntimeError(
            f"SCAN-B expression columns={scanb_samples}; expected {EXPECTED_SCANB_SAMPLES}."
        )

    logging.info(f"SCAN-B identifier column: {scanb_first_col}")
    logging.info(f"SCAN-B gene rows: {len(scanb_symbols_raw)}")
    logging.info(f"SCAN-B one-to-one symbols: {len(scanb_unique_set)}")
    logging.info(f"SCAN-B primary sample columns: {scanb_samples}")
    logging.info("")

    # --------------------------------------------------------
    # 4. APOLLO RNA + sample-ID harmonization
    # --------------------------------------------------------
    logging.info("[4/8] Harmonizing APOLLO RNA and cross-omics sample identifiers...")
    logging.info("      Native RNA values remain deposited UQ-normalized log2.")
    logging.info("")

    apollo_rna_header = table_header(APOLLO_RNA, sep="\t")
    if "Hugo_Symbol" not in apollo_rna_header:
        raise RuntimeError("APOLLO RNA lacks Hugo_Symbol.")

    rna_sample_cols = apollo_sample_columns(apollo_rna_header)
    apollo_rna = pd.read_csv(
        APOLLO_RNA,
        sep="\t",
        usecols=["Hugo_Symbol"],
        dtype=str,
    )
    apollo_rna_map = unique_symbol_table(
        "APOLLO_RNA",
        apollo_rna["Hugo_Symbol"].tolist(),
        apollo_rna["Hugo_Symbol"].tolist(),
    )
    apollo_rna_unique_set = set(
        apollo_rna_map.loc[apollo_rna_map["one_to_one_symbol"], "gene_symbol"]
    )

    protein_map, protein_sample_cols = write_feature_map_from_apollo_protein(APOLLO_PROTEIN)
    phospho_map, phospho_sample_cols = write_feature_map_from_apollo_phospho(APOLLO_PHOSPHO)

    cases = pd.read_csv(APOLLO_CASES, sep="\t", dtype=str)
    if "patient_id" not in cases.columns:
        raise RuntimeError("CF12 case inventory lacks patient_id.")

    case_ids = set(cases["patient_id"].astype(str).map(normalize_apollo_sample_id))
    rna_ids = set(map(normalize_apollo_sample_id, rna_sample_cols))
    protein_ids = set(map(normalize_apollo_sample_id, protein_sample_cols))
    phospho_ids = set(map(normalize_apollo_sample_id, phospho_sample_cols))

    if len(case_ids) != EXPECTED_APOLLO_CASES:
        raise RuntimeError(
            f"APOLLO unique case IDs={len(case_ids)}; expected {EXPECTED_APOLLO_CASES}."
        )

    sample_union = sorted(case_ids | rna_ids | protein_ids | phospho_ids)
    sample_crosswalk = pd.DataFrame({
        "harmonized_sample_id": sample_union,
        "in_case_inventory": [x in case_ids for x in sample_union],
        "in_RNA": [x in rna_ids for x in sample_union],
        "in_global_proteomics_unimputed": [x in protein_ids for x in sample_union],
        "in_adjusted_phosphoproteomics_unimputed": [x in phospho_ids for x in sample_union],
    })

    logging.info(f"APOLLO RNA gene rows: {len(apollo_rna)}")
    logging.info(f"APOLLO RNA one-to-one symbols: {len(apollo_rna_unique_set)}")
    logging.info(f"APOLLO cases: {len(case_ids)}")
    logging.info(f"APOLLO RNA sample columns: {len(rna_ids)}")
    logging.info(f"APOLLO protein sample columns: {len(protein_ids)}")
    logging.info(f"APOLLO phosphoprotein sample columns: {len(phospho_ids)}")
    logging.info("")

    # --------------------------------------------------------
    # 5. Cross-cohort transcriptomic feature universe
    # --------------------------------------------------------
    logging.info("[5/8] Constructing leakage-safe transcriptomic feature crosswalk...")
    logging.info("")

    tcga_scanb = tcga_unique_set & scanb_unique_set
    tcga_scanb_apollo = tcga_scanb & apollo_rna_unique_set

    protein_unambig_set = set(
        protein_map.loc[
            protein_map["unambiguous_gene_mapping"] & protein_map["gene_symbol"].notna(),
            "gene_symbol",
        ].astype(str)
    )
    phospho_unambig_set = set(
        phospho_map.loc[
            phospho_map["unambiguous_gene_mapping"] & phospho_map["gene_symbol"].notna(),
            "gene_symbol",
        ].astype(str)
    )

    all_symbols = sorted(tcga_unique_set | scanb_unique_set | apollo_rna_unique_set)

    tcga_symbol_to_id = (
        tcga_map.loc[tcga_map["one_to_one_symbol"]]
        .set_index("gene_symbol")["source_feature_id"]
        .to_dict()
    )

    crosswalk = pd.DataFrame({
        "gene_symbol": all_symbols,
        "TCGA_one_to_one": [g in tcga_unique_set for g in all_symbols],
        "SCANB_one_to_one": [g in scanb_unique_set for g in all_symbols],
        "APOLLO_RNA_one_to_one": [g in apollo_rna_unique_set for g in all_symbols],
        "APOLLO_protein_unambiguous": [g in protein_unambig_set for g in all_symbols],
        "APOLLO_phospho_unambiguous": [g in phospho_unambig_set for g in all_symbols],
        "TCGA_ensembl_gene_id": [tcga_symbol_to_id.get(g, "") for g in all_symbols],
    })

    crosswalk["eligible_TCGA_SCANB_external_validation"] = (
        crosswalk["TCGA_one_to_one"] & crosswalk["SCANB_one_to_one"]
    )
    crosswalk["present_all_three_transcriptomes"] = (
        crosswalk["eligible_TCGA_SCANB_external_validation"]
        & crosswalk["APOLLO_RNA_one_to_one"]
    )
    crosswalk["cross_omics_protein_available"] = (
        crosswalk["present_all_three_transcriptomes"]
        & crosswalk["APOLLO_protein_unambiguous"]
    )
    crosswalk["cross_omics_phospho_available"] = (
        crosswalk["present_all_three_transcriptomes"]
        & crosswalk["APOLLO_phospho_unambiguous"]
    )

    crosswalk.to_csv(
        PROCESSED / "CF13_transcriptomic_feature_crosswalk.tsv",
        sep="\t",
        index=False,
    )

    tcga_map.to_csv(
        RESULTS / "CF13_TCGA_ensembl_symbol_audit.tsv",
        sep="\t",
        index=False,
    )
    protein_map.to_csv(
        RESULTS / "CF13_APOLLO_protein_feature_gene_map.tsv",
        sep="\t",
        index=False,
    )
    phospho_map.to_csv(
        RESULTS / "CF13_APOLLO_phospho_feature_gene_map.tsv",
        sep="\t",
        index=False,
    )
    sample_crosswalk.to_csv(
        PROCESSED / "CF13_APOLLO_sample_id_crosswalk.tsv",
        sep="\t",
        index=False,
    )

    logging.info(f"TCGA ∩ SCAN-B one-to-one symbols: {len(tcga_scanb)}")
    logging.info(f"TCGA ∩ SCAN-B ∩ APOLLO-RNA symbols: {len(tcga_scanb_apollo)}")
    logging.info(
        f"Three-transcriptome genes with APOLLO protein evidence: "
        f"{sum(g in protein_unambig_set for g in tcga_scanb_apollo)}"
    )
    logging.info(
        f"Three-transcriptome genes with APOLLO phospho evidence: "
        f"{sum(g in phospho_unambig_set for g in tcga_scanb_apollo)}"
    )
    logging.info("")

    # --------------------------------------------------------
    # 6. Clinical endpoint harmonization
    # --------------------------------------------------------
    logging.info("[6/8] Harmonizing measured/pathology ER, PR, HER2, TNBC labels...")
    logging.info("      Expression-derived SGC/MGC/PAM50 fields are forbidden.")
    logging.info("")

    tcga_clin = pd.read_csv(tcga_clinical_path, sep="\t", dtype=str)
    scanb_meta = pd.read_csv(SCANB_METADATA, sep="\t", dtype=str)

    tcga_endpoint, tcga_fields = build_endpoint_manifest(tcga_clin, "TCGA")
    scanb_endpoint, scanb_fields = build_endpoint_manifest(scanb_meta, "SCANB")

    tcga_endpoint.to_csv(
        PROCESSED / "CF13_TCGA_endpoint_manifest.tsv",
        sep="\t",
        index=False,
    )
    scanb_endpoint.to_csv(
        PROCESSED / "CF13_SCANB_endpoint_manifest.tsv",
        sep="\t",
        index=False,
    )

    endpoint_rows = []
    for cohort_name, ep, fields in [
        ("TCGA", tcga_endpoint, tcga_fields),
        ("SCANB", scanb_endpoint, scanb_fields),
    ]:
        endpoint_rows.append({
            "cohort": cohort_name,
            "ER_source_column": fields["ER"],
            "PR_source_column": fields["PR"],
            "HER2_source_column": fields["HER2"],
            "ER_known": int(ep["ER"].notna().sum()),
            "PR_known": int(ep["PR"].notna().sum()),
            "HER2_known": int(ep["HER2"].notna().sum()),
            "TNBC_classifiable": int(ep["TNBC"].notna().sum()),
            "TNBC_positive": int((ep["TNBC"] == "TNBC").sum()),
        })

    endpoint_audit = pd.DataFrame(endpoint_rows)
    endpoint_audit.to_csv(
        RESULTS / "CF13_endpoint_coverage_audit.tsv",
        sep="\t",
        index=False,
    )

    logging.info("TCGA source receptor fields:")
    logging.info(f"  ER={tcga_fields['ER']} | PR={tcga_fields['PR']} | HER2={tcga_fields['HER2']}")
    logging.info("SCAN-B source receptor fields:")
    logging.info(f"  ER={scanb_fields['ER']} | PR={scanb_fields['PR']} | HER2={scanb_fields['HER2']}")
    logging.info("")
    for _, r in endpoint_audit.iterrows():
        logging.info(
            f"{r['cohort']} known: ER={r['ER_known']}, PR={r['PR_known']}, "
            f"HER2={r['HER2_known']}, TNBC classifiable={r['TNBC_classifiable']}"
        )
    logging.info("")

    # --------------------------------------------------------
    # 7. Freeze scale-separation protocol
    # --------------------------------------------------------
    logging.info("[7/8] Freezing cross-cohort scale-separation protocol...")
    logging.info("")

    scale_plan = pd.DataFrame(
        [
            (
                "TCGA",
                "TPM",
                "CF6_tpm.tsv.gz",
                "KEEP_NATIVE_CF13",
                "Discovery/model development; ML transformation locked only at CF14",
            ),
            (
                "SCANB",
                "log2(FPKM + 0.1)",
                "CF11_SCANB_primary_expression.tsv.gz",
                "KEEP_NATIVE_CF13",
                "Independent external validation; do not pool-normalize with TCGA",
            ),
            (
                "APOLLO_RNA",
                "UQ-normalized log2",
                "apollo-brca1.rnaseq.expressed_genes.level3.UQnorm_log2.txt",
                "KEEP_NATIVE_CF13",
                "Orthogonal transcriptomic confirmation",
            ),
            (
                "APOLLO_GLOBAL_PROTEIN",
                "Level-3 global proteomics, unimputed",
                "apollo-brca1.globalproteomics_level3_unimputed.txt",
                "KEEP_NATIVE_CF13",
                "Protein confirmation; preserve missingness",
            ),
            (
                "APOLLO_PHOSPHO",
                "Level-3 global-adjusted phosphoproteomics, unimputed",
                "apollo-brca1.phosphoproteomics_level3_adjusted_by_global_unimputed.txt",
                "KEEP_NATIVE_CF13",
                "Phosphosite confirmation; preserve missingness",
            ),
        ],
        columns=[
            "cohort_layer",
            "native_scale",
            "source",
            "CF13_action",
            "planned_role",
        ],
    )
    scale_plan.to_csv(
        RESULTS / "CF13_expression_scale_protocol.tsv",
        sep="\t",
        index=False,
    )

    forbidden = pd.DataFrame(
        [
            ("Cross-cohort ComBat before external validation", "FORBIDDEN"),
            ("Pooled quantile normalization across TCGA and SCAN-B", "FORBIDDEN"),
            ("Use SCAN-B labels for feature selection/tuning", "FORBIDDEN"),
            ("Require APOLLO protein presence for ML feature eligibility", "FORBIDDEN"),
            ("Use CF9 stable DEGs as a global preselected ML feature set", "FORBIDDEN"),
            ("Select final endpoint during CF13", "FORBIDDEN"),
            ("Train ML during CF13", "FORBIDDEN"),
        ],
        columns=["operation", "CF13_status"],
    )
    forbidden.to_csv(
        RESULTS / "CF13_leakage_prevention_rules.tsv",
        sep="\t",
        index=False,
    )

    logging.info("Native cohort scales preserved.")
    logging.info("No batch correction, pooled normalization, feature selection, or ML.")
    logging.info("")

    # --------------------------------------------------------
    # 8. Summary + provenance
    # --------------------------------------------------------
    logging.info("[8/8] Writing CF13 summary and provenance...")
    logging.info("")

    runtime = (time.time() - t0) / 60.0

    protein_features = int(protein_map["protein_row_index"].nunique())
    protein_unambig_features = int(
        protein_map.loc[protein_map["unambiguous_gene_mapping"], "protein_row_index"].nunique()
    )
    phospho_features = int(phospho_map["phospho_row_index"].nunique())
    phospho_unambig_features = int(
        phospho_map.loc[phospho_map["unambiguous_gene_mapping"], "phospho_row_index"].nunique()
    )

    complete_apollo_samples = int(
        (
            sample_crosswalk["in_case_inventory"]
            & sample_crosswalk["in_RNA"]
            & sample_crosswalk["in_global_proteomics_unimputed"]
            & sample_crosswalk["in_adjusted_phosphoproteomics_unimputed"]
        ).sum()
    )

    summary = pd.DataFrame(
        [
            ("TCGA TPM sample columns", tcga_tpm_samples),
            ("SCAN-B primary sample columns", scanb_samples),
            ("SCAN-B gene rows", len(scanb_symbols_raw)),
            ("APOLLO cases", len(case_ids)),
            ("APOLLO RNA sample columns", len(rna_ids)),
            ("APOLLO protein sample columns", len(protein_ids)),
            ("APOLLO phosphoprotein sample columns", len(phospho_ids)),
            ("APOLLO samples present in case+RNA+protein+phospho", complete_apollo_samples),
            ("TCGA one-to-one gene symbols", len(tcga_unique_set)),
            ("SCAN-B one-to-one gene symbols", len(scanb_unique_set)),
            ("APOLLO RNA one-to-one gene symbols", len(apollo_rna_unique_set)),
            ("TCGA-SCANB common one-to-one symbols", len(tcga_scanb)),
            ("Three-transcriptome common one-to-one symbols", len(tcga_scanb_apollo)),
            (
                "Three-transcriptome genes with APOLLO protein evidence",
                sum(g in protein_unambig_set for g in tcga_scanb_apollo),
            ),
            (
                "Three-transcriptome genes with APOLLO phospho evidence",
                sum(g in phospho_unambig_set for g in tcga_scanb_apollo),
            ),
            ("APOLLO protein features", protein_features),
            ("APOLLO unambiguous single-gene protein features", protein_unambig_features),
            ("APOLLO phosphoprotein features", phospho_features),
            ("APOLLO unambiguous single-gene phosphoprotein features", phospho_unambig_features),
            ("Expression matrices merged", "NO"),
            ("Cross-cohort batch correction performed", "NO"),
            ("Feature selection performed", "NO"),
            ("ML performed", "NO"),
            ("Final endpoint selected", "NO"),
            ("CF13 runtime minutes", round(runtime, 2)),
            ("CF13 stage gate", "PASS"),
        ],
        columns=["metric", "value"],
    )
    summary.to_csv(
        RESULTS / "CF13_summary.tsv",
        sep="\t",
        index=False,
    )

    provenance = pd.DataFrame(
        [
            ("code_file", "CF13_cross_cohort_harmonization.py"),
            ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
            ("CF7_clinical_table_resolved", str(tcga_clinical_path)),
            ("TCGA_gene_annotation_sha256", sha256_file(TCGA_GENE_ANNOTATION)),
            ("TCGA_sample_manifest_sha256", sha256_file(TCGA_SAMPLE_MANIFEST)),
            ("SCANB_metadata_sha256", sha256_file(SCANB_METADATA)),
            ("APOLLO_case_inventory_sha256", sha256_file(APOLLO_CASES)),
            (
                "symbol_matching_rule",
                "Exact gene-symbol matching after whitespace/NA cleanup; only symbols "
                "that are one-to-one within each transcriptomic source are eligible",
            ),
            (
                "duplicate_symbol_rule",
                "Ambiguous duplicated transcriptomic symbols excluded from cross-cohort "
                "eligible universe; raw source rows remain unchanged",
            ),
            (
                "proteomics_mapping_rule",
                "Protein/phosphoprotein features remain feature-level; multi-gene mappings "
                "are preserved and flagged rather than arbitrarily collapsed",
            ),
            (
                "APOLLO_sample_id_rule",
                "Proteomics dot-form AP.X.Y normalized to RNA/case hyphen-form AP-X-Y",
            ),
            (
                "expression_scale_rule",
                "Native scales preserved; cross-cohort numerical preprocessing deferred "
                "to CF14 protocol lock",
            ),
            (
                "external_validation_rule",
                "SCAN-B remains untouched by model training, feature selection, and tuning",
            ),
            (
                "APOLLO_role",
                "Orthogonal cross-omics confirmation; not ML performance validation",
            ),
            ("python_version", sys.version.replace("\n", " ")),
            ("pandas_version", pd.__version__),
            ("numpy_version", np.__version__),
            ("platform", platform.platform()),
            ("CF13_stage_gate", "PASS"),
        ],
        columns=["field", "value"],
    )
    provenance.to_csv(
        RESULTS / "CF13_provenance.tsv",
        sep="\t",
        index=False,
    )

    logging.info("============================================================")
    logging.info(" CF13 COMPLETE - CROSS-COHORT HARMONIZATION GATE PASSED")
    logging.info("============================================================")
    logging.info("")
    logging.info(f"TCGA-SCANB common one-to-one symbols: {len(tcga_scanb)}")
    logging.info(f"Three-transcriptome common symbols: {len(tcga_scanb_apollo)}")
    logging.info(
        "Three-transcriptome genes with APOLLO protein evidence: "
        f"{sum(g in protein_unambig_set for g in tcga_scanb_apollo)}"
    )
    logging.info(
        "Three-transcriptome genes with APOLLO phospho evidence: "
        f"{sum(g in phospho_unambig_set for g in tcga_scanb_apollo)}"
    )
    logging.info(f"APOLLO complete RNA+protein+phospho sample overlap: {complete_apollo_samples}")
    logging.info(f"CF13 runtime: {runtime:.1f} min")
    logging.info("")
    logging.info("IMPORTANT:")
    logging.info("CF13 harmonized identifiers and measured/pathology endpoints only.")
    logging.info("Native expression scales remain separate.")
    logging.info("No feature selection or ML was performed.")
    logging.info("Next stage is CF14 HARD MANUAL PRE-ML PROTOCOL LOCK.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF13 ERROR: {exc}")
        sys.exit(1)
