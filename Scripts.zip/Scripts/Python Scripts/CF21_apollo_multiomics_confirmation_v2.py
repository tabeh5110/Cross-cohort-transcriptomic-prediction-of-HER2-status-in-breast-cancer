"""
============================================================
CF21 v2 - APOLLO MULTI-OMICS CONFIRMATION
============================================================

Improvement over CF21:
- Correct extraction of CF18 non-zero Elastic-Net genes
- Robust APOLLO protein/phosphoprotein identifier parsing
- No model retraining
- No feature modification

============================================================
"""

import os
import time
import re
import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

START = time.time()

BASE = r"D:\Masters\Research\TCGA_BRCA"

MODEL_FILE = os.path.join(
    BASE, "data", "processed", "ml_ready",
    "CF18_final_model",
    "CF18_final_ElasticNet_model_bundle.joblib"
)

APOLLO_DIR = os.path.join(
    BASE, "data", "raw", "apollo_brca1", "open"
)

FILES = {
    "RNA": "apollo-brca1.rnaseq.expressed_genes.level3.UQnorm_log2.txt",
    "Protein": "apollo-brca1.globalproteomics_level3_unimputed.txt",
    "Phospho": "apollo-brca1.phosphoproteomics_level3_adjusted_by_global_unimputed.txt"
}

OUT = os.path.join(
    BASE, "results", "CF21_apollo_multiomics_confirmation_v2"
)

os.makedirs(OUT, exist_ok=True)


def normalize_identifier(x):
    x = str(x).upper()

    # UniProt style: SP|P04626|ERBB2_HUMAN
    if "|" in x:
        x = x.split("|")[-1]

    # remove human suffix
    x = re.sub(r"_HUMAN$", "", x)

    # remove phosphosite suffixes
    x = re.split(r"[_;:.-]", x)[0]

    # keep gene-like part
    return x.strip()


def get_predictive_genes():

    print("[1/6] Loading CF18 model bundle...")

    bundle = joblib.load(MODEL_FILE)

    genes = np.array(
        bundle["feature_universe_gene_symbols"]
    )

    selector = bundle["select_k_best"]
    selected = genes[selector.get_support()]

    coef = (
        bundle["elasticnet_model"]
        .coef_
        .flatten()
    )

    df = pd.DataFrame({
        "gene": selected,
        "coefficient": coef
    })

    df = df[df.coefficient != 0].copy()

    print("Predictive genes:", len(df))

    return df


def read_identifiers(path):

    df = pd.read_csv(
        path,
        sep="\t",
        nrows=3,
        low_memory=False
    )

    col = df.columns[0]

    full = pd.read_csv(
        path,
        sep="\t",
        usecols=[col],
        low_memory=False
    )

    return set(
        full[col]
        .astype(str)
        .map(normalize_identifier)
    )


def main():

    print("""
============================================================
 CF21 v2 - APOLLO MULTI-OMICS CONFIRMATION
============================================================
NO ML
NO RETRAINING
NO FEATURE SELECTION
============================================================
""")

    genes = get_predictive_genes()

    genes["gene_norm"] = (
        genes["gene"]
        .astype(str)
        .map(normalize_identifier)
    )

    evidence = genes.copy()

    for layer, fname in FILES.items():

        print(f"\nChecking APOLLO {layer}...")

        path = os.path.join(
            APOLLO_DIR,
            fname
        )

        ids = read_identifiers(path)

        evidence[layer + "_support"] = (
            evidence["gene_norm"]
            .isin(ids)
        )

        print(
            layer,
            "supported:",
            int(evidence[layer + "_support"].sum()),
            "/",
            len(evidence)
        )

    def classify(r):
        if r.RNA_support and r.Protein_support and r.Phospho_support:
            return "RNA+Protein+Phospho"
        if r.RNA_support and r.Protein_support:
            return "RNA+Protein"
        if r.RNA_support:
            return "RNA_only"
        return "No_match"

    evidence["evidence_level"] = evidence.apply(
        classify,
        axis=1
    )

    evidence.to_csv(
        os.path.join(
            OUT,
            "CF21v2_predictive_gene_multiomics_table.tsv"
        ),
        sep="\t",
        index=False
    )

    summary = (
        evidence.evidence_level
        .value_counts()
        .reset_index()
    )

    summary.columns = [
        "evidence_level",
        "gene_count"
    ]

    summary.to_csv(
        os.path.join(
            OUT,
            "CF21v2_multiomics_summary.tsv"
        ),
        sep="\t",
        index=False
    )

    plt.figure(figsize=(7,4))
    plt.bar(
        summary.evidence_level,
        summary.gene_count
    )
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("Genes")
    plt.title("CF21 v2 APOLLO Multi-Omics Evidence")
    plt.tight_layout()

    plt.savefig(
        os.path.join(
            OUT,
            "CF21v2_evidence_barplot.png"
        ),
        dpi=300
    )

    plt.close()

    print("""
============================================================
 CF21 v2 COMPLETE
============================================================
""")

    print("Genes evaluated:", len(evidence))
    print("Runtime:", round((time.time()-START)/60,2), "min")
    print("STATUS: READY_FOR_REVIEW")


if __name__ == "__main__":
    main()
