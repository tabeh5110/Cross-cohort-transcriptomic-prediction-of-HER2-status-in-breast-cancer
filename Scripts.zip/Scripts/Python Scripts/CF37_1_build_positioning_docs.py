from __future__ import annotations

import json
from pathlib import Path

from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "CF37_1_Final_Scientific_Positioning"
DOCS = OUT / "docs"
TABLES = OUT / "tables"
SCRIPTS = OUT / "scripts"
QA = OUT / "qa"
REFERENCE = Path(
    "C:/Users/USER/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/"
    "skills/artifact-template-experiment-analysis/assets/reference.docx"
)

FINAL_TITLE = (
    "A stability-informed 10-gene transcriptomic signature for HER2 prediction in breast cancer: "
    "multi-cohort validation and explainable analysis"
)

FINAL_GENES = "STARD3, PGAP3, MIEN1, PSMD3, MED1, CDK12, MIR4728, GSDMB, FBXL20, and FCGBP"

EVIDENCE = {
    "CF31": "1000 TCGA bootstrap iterations identified 10 CORE_STABLE genes with selection frequency >= 0.90.",
    "CF32": "The compact 10-gene panel achieved SCAN-B AUROC 0.9262 and PR-AUC 0.8239, retaining 100.8% of the original 86-gene external AUROC.",
    "CF32.5": "The 10-gene model showed comparable or improved discrimination versus ERBB2-only and the 86-gene reference in SCAN-B; paired AUROC differences were not statistically significant.",
    "CF33": "METABRIC provided a second external cohort with 1980 samples; 10-gene AUROC was 0.9945 and PR-AUC was 0.9672 using the locked threshold and no external fitting.",
    "CF33.5": "Calibration evaluated across TCGA, SCAN-B, and METABRIC showed cohort-specific probability scaling; MIR4728 sensitivity analysis supported robust external discrimination in the tested cohorts.",
    "CF34": "Decision curve analysis evaluated potential clinical utility under explicit threshold preferences against ERBB2-only, treat-all, and treat-none comparators.",
    "CF35": "Explainable analysis identified STARD3, MIEN1, PSMD3, FCGBP, and MIR4728 as leading log-odds contributors and linked several high-importance genes to stability and network support.",
    "CF36.5": "Publication audit found no package integrity failures but required clearer Figure 2, Figure 6, Table 2, and conservative wording.",
    "CF36.6": "Final figure and table revision package incorporated the audit findings without changing model results or statistical outputs.",
}

TITLE_ROWS = [
    [1, FINAL_TITLE, "Best balance of accuracy, novelty, validation, and reviewer acceptance.", 5, 5, 5, 5],
    [2, "Development and multi-cohort validation of a compact HER2-associated transcriptomic signature in breast cancer", "Very suitable and concise, but less explicit about stability and explainability.", 5, 4, 5, 5],
    [3, "Stability, explainability, and external validation of a compact HER2 transcriptomic signature", "Strong concept framing, but omits breast cancer from the title.", 4, 5, 5, 4],
    [4, "A biologically supported 10-gene signature for transcriptomic HER2 prediction across breast cancer cohorts", "Strong biological framing, slightly less direct about validation design.", 5, 4, 4, 5],
    [5, "Multi-cohort validation of a stability-selected transcriptomic HER2 signature in breast cancer", "Clear validation emphasis, but less specific about panel size.", 5, 4, 4, 5],
    [6, "An explainable compact transcriptomic signature for HER2 status prediction in breast cancer", "Readable and accurate, but underplays stability and multi-cohort evidence.", 5, 4, 4, 4],
    [7, "Stability-guided reduction of a HER2 transcriptomic predictor to a 10-gene breast cancer signature", "Good methods novelty, but sounds more like a reduction paper than a full validation study.", 5, 4, 4, 4],
    [8, "A stable and interpretable transcriptomic panel for HER2-associated risk stratification in breast cancer", "Good translational tone, but 'panel' may imply an assay unless carefully contextualized.", 4, 4, 4, 4],
    [9, "A 10-gene HER2-associated transcriptomic model with external validation and decision curve analysis in breast cancer", "Accurate and transparent, but less elegant for a main manuscript title.", 5, 4, 4, 4],
    [10, "A compact transcriptomic HER2 signature benchmarked against ERBB2 expression in breast cancer", "Clear benchmark focus, but too narrow for the full study contribution.", 5, 4, 4, 4],
    [11, "Explainable multi-cohort assessment of a 10-gene HER2 transcriptomic signature in breast cancer", "Good explainability emphasis, but weaker on how the panel was derived.", 5, 4, 4, 4],
    [12, "A stability-selected breast cancer transcriptomic signature for HER2 prediction and risk stratification", "Accurate, but less specific about compactness and validation breadth.", 5, 4, 4, 4],
    [13, "From high-dimensional transcriptomics to a compact HER2 prediction signature in breast cancer", "Readable, but phrasing is more narrative and less Q1-specific.", 4, 4, 3, 4],
    [14, "Biologically supported compression of a HER2 transcriptomic classifier into a 10-gene signature", "Useful technical framing, but 'compression' may sound engineering-heavy.", 4, 4, 3, 4],
    [15, "Cross-cohort evaluation of a compact transcriptomic signature for HER2-associated prediction in breast cancer", "Safe and accurate, but novelty is less visible.", 5, 3, 4, 4],
]

CONTRIBUTIONS = [
    {
        "Contribution": "Stability-informed derivation of the final compact signature",
        "Supporting_CF_experiment": "CF31, CF32",
        "Evidence": "CF31 identified 10 CORE_STABLE genes after 1000 bootstrap iterations; CF32 used stability, coefficient, network, and biology scores to select the smallest retained-performance panel.",
        "Manuscript_role": "Positions the model as reproducibility-guided rather than a purely performance-selected gene list.",
    },
    {
        "Contribution": "Development of a compact 10-gene HER2-associated transcriptomic panel",
        "Supporting_CF_experiment": "CF32",
        "Evidence": f"The final genes were {FINAL_GENES}. The 10-gene model retained 100.8% of the original 86-gene external AUROC in SCAN-B.",
        "Manuscript_role": "Addresses the reviewer concern that large transcriptomic signatures can be difficult to interpret or translate.",
    },
    {
        "Contribution": "Benchmarking against ERBB2 expression and the original 86-gene model",
        "Supporting_CF_experiment": "CF32.5",
        "Evidence": "SCAN-B AUROC was 0.9262 for the 10-gene model, 0.9158 for ERBB2-only, and 0.9186 for the 86-gene reference; paired AUROC superiority was not supported by DeLong testing.",
        "Manuscript_role": "Frames the result as comparable or improved discrimination without overstating statistical separation from ERBB2-only.",
    },
    {
        "Contribution": "Independent multi-cohort validation across TCGA, SCAN-B, and METABRIC",
        "Supporting_CF_experiment": "CF32, CF33, CF36.6",
        "Evidence": "The signature was developed in TCGA, externally evaluated in SCAN-B, and further tested in METABRIC with 1980 samples and 9 of 10 genes available.",
        "Manuscript_role": "Separates development from external evaluation and supports cross-cohort predictive generalization.",
    },
    {
        "Contribution": "Calibration and threshold transport assessment",
        "Supporting_CF_experiment": "CF33.5",
        "Evidence": "Calibration evaluated across cohorts showed cohort-specific Brier scores, slopes, intercepts, and locked-threshold operating behavior.",
        "Manuscript_role": "Prevents overinterpretation of probability estimates and supports a careful distinction between discrimination and calibration.",
    },
    {
        "Contribution": "Decision curve analysis for potential clinical utility",
        "Supporting_CF_experiment": "CF34",
        "Evidence": "DCA compared the 10-gene signature against ERBB2-only, treat-all, and treat-none strategies over threshold probabilities from 0.05 to 0.95.",
        "Manuscript_role": "Adds threshold-preference context without deployment claims.",
    },
    {
        "Contribution": "Explainable and biologically supported model interpretation",
        "Supporting_CF_experiment": "CF30.5, CF35",
        "Evidence": "SHAP-style analysis identified STARD3, MIEN1, PSMD3, FCGBP, and MIR4728 as leading contributors; several high-importance genes had bootstrap stability and network support.",
        "Manuscript_role": "Connects predictive features to a HER2-associated transcriptomic neighborhood while avoiding mechanistic overinterpretation.",
    },
]

JOURNAL_ROWS = [
    ["Bioinformatics", "High", "Best fit if the manuscript foregrounds stability-informed feature reduction, external validation, benchmarking, and explainability.", "Reviewers may ask for method novelty beyond applied modeling and for reproducible code/data availability."],
    ["Computational biology", "High", "Suitable if the story emphasizes transcriptomic signature biology, network support, and cross-cohort generalization.", "Needs careful biological interpretation because pathway enrichment was not broadly FDR-significant in CF30."],
    ["Cancer informatics", "High", "Strong fit for predictive oncology modeling, compact signatures, cohort harmonization, and model interpretation.", "May require clear distinction between HER2 prediction and direct clinical assay replacement."],
    ["Translational oncology", "Moderate to high", "Suitable if positioned around risk stratification, external validation, threshold behavior, and potential utility.", "Prospective validation and clinical workflow studies are absent, so claims must remain research-stage."],
    ["Breast cancer specialty journals", "Moderate", "Good audience alignment for HER2 biology and breast cancer cohort validation.", "Computational details must be presented clearly enough for non-methods reviewers."],
    ["Precision oncology", "Moderate", "Potential fit if the manuscript highlights interpretable transcriptomic stratification and decision-curve context.", "Avoid implying therapy selection or prospective implementation without clinical outcome validation."],
]


def remove_body_content(doc: Document) -> None:
    body = doc._body._element
    for child in list(body):
        if child.tag != qn("w:sectPr"):
            body.remove(child)


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_border(cell, color: str = "D9D9D9") -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = f"w:{edge}"
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "4")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), color)


def format_table(table, widths: list[float] | None = None) -> None:
    try:
        table.style = "Table Grid"
    except KeyError:
        pass
    table.autofit = True
    for row_idx, row in enumerate(table.rows):
        for cell_idx, cell in enumerate(row.cells):
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after = Pt(2)
                for run in paragraph.runs:
                    run.font.name = "Georgia"
                    run.font.size = Pt(8.5)
            set_cell_border(cell)
            if row_idx == 0:
                set_cell_shading(cell, "1F4E78")
                for paragraph in cell.paragraphs:
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    for run in paragraph.runs:
                        run.font.color.rgb = RGBColor(255, 255, 255)
                        run.font.bold = True
            elif row_idx % 2 == 0:
                set_cell_shading(cell, "F3F6FA")
            if widths and cell_idx < len(widths):
                cell.width = Inches(widths[cell_idx])


def add_paragraph(doc: Document, text: str, style: str | None = None):
    paragraph = doc.add_paragraph(text, style=style)
    paragraph.paragraph_format.space_after = Pt(7)
    paragraph.paragraph_format.line_spacing = 1.08
    for run in paragraph.runs:
        run.font.name = "Georgia"
        run.font.size = Pt(10.5)
        run.font.color.rgb = RGBColor(0, 0, 0)
    return paragraph


def add_bullets(doc: Document, items: list[str]) -> None:
    for item in items:
        paragraph = doc.add_paragraph()
        paragraph.paragraph_format.left_indent = Inches(0.22)
        paragraph.paragraph_format.first_line_indent = Inches(-0.12)
        paragraph.paragraph_format.space_after = Pt(4)
        run = paragraph.add_run(f"- {item}")
        run.font.name = "Georgia"
        run.font.size = Pt(10.2)
        run.font.color.rgb = RGBColor(0, 0, 0)


def add_heading(doc: Document, text: str, level: int = 1) -> None:
    paragraph = doc.add_heading(text, level=level)
    paragraph.paragraph_format.space_before = Pt(10 if level == 1 else 6)
    paragraph.paragraph_format.space_after = Pt(5)
    for run in paragraph.runs:
        run.font.name = "Georgia"
        run.font.color.rgb = RGBColor(0, 0, 0)


def create_doc(filename: str, title: str, intro: str, sections: list[dict]) -> None:
    doc = Document(str(REFERENCE))
    remove_body_content(doc)
    for section in doc.sections:
        section.top_margin = Inches(0.9)
        section.bottom_margin = Inches(0.85)
        section.left_margin = Inches(0.9)
        section.right_margin = Inches(0.9)
    title_p = doc.add_paragraph(style="Title")
    title_p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    title_run = title_p.add_run(title)
    title_run.font.name = "Georgia"
    title_run.font.size = Pt(20)
    title_run.font.color.rgb = RGBColor(0, 0, 0)
    add_paragraph(doc, intro)
    for section in sections:
        add_heading(doc, section["heading"], section.get("level", 1))
        if section.get("paragraphs"):
            for paragraph in section["paragraphs"]:
                add_paragraph(doc, paragraph)
        if section.get("bullets"):
            add_bullets(doc, section["bullets"])
        if section.get("table"):
            headers = section["table"]["headers"]
            rows = section["table"]["rows"]
            table = doc.add_table(rows=1, cols=len(headers))
            for idx, header in enumerate(headers):
                table.rows[0].cells[idx].text = str(header)
            for row in rows:
                cells = table.add_row().cells
                for idx, value in enumerate(row):
                    cells[idx].text = str(value)
            format_table(table, section["table"].get("widths"))
            doc.add_paragraph()
    doc.core_properties.title = title
    doc.core_properties.subject = "CF37.1 final scientific positioning"
    doc.core_properties.keywords = "TCGA-BRCA, HER2, transcriptomics, machine learning, manuscript positioning"
    doc.save(DOCS / filename)


def build_documents() -> None:
    core_sections = [
        {
            "heading": "Core Contribution",
            "paragraphs": [
                "The real contribution of this study is the transformation of a high-dimensional HER2 transcriptomic predictor into a compact, stable, biologically supported, and explainable 10-gene signature that maintains strong predictive performance across independent breast cancer cohorts. The study is strongest when positioned as a reproducibility-guided signature refinement and validation framework, not as a new clinical assay.",
                f"The final panel is {FINAL_GENES}. The signature excludes ERBB2 itself, which makes the ERBB2-only benchmark central to the manuscript narrative: the 10-gene model captures a HER2-associated transcriptomic neighborhood rather than simply restating one canonical marker.",
            ],
        },
        {
            "heading": "Evidence Backbone",
            "table": {
                "headers": ["Evidence layer", "Supporting CF experiments", "What it supports"],
                "rows": [
                    ["Stability", "CF31", EVIDENCE["CF31"]],
                    ["Compact model development", "CF32", EVIDENCE["CF32"]],
                    ["Benchmarking", "CF32.5", EVIDENCE["CF32.5"]],
                    ["External validation", "CF32, CF33", "SCAN-B and METABRIC evaluate cross-cohort predictive generalization without external fitting or threshold selection."],
                    ["Calibration and threshold transport", "CF33.5", EVIDENCE["CF33.5"]],
                    ["Potential utility", "CF34", EVIDENCE["CF34"]],
                    ["Interpretability", "CF35", EVIDENCE["CF35"]],
                ],
                "widths": [1.55, 1.65, 4.65],
            },
        },
        {
            "heading": "Recommended Positioning",
            "bullets": [
                "Frame the manuscript around a stability-informed, compact, interpretable HER2 transcriptomic signature.",
                "Describe model performance as predictive discrimination across cohorts, with ERBB2 comparison stated as comparable or improved discrimination.",
                "Present decision curve analysis as evidence of potential utility under specified threshold preferences.",
                "Avoid wording that implies prospective implementation, direct replacement of current pathology workflows, or causal effects of individual genes.",
            ],
        },
    ]

    title_sections = [
        {
            "heading": "Title Candidates",
            "table": {
                "headers": ["Rank", "Candidate title", "Positioning note"],
                "rows": [[row[0], row[1], row[2]] for row in TITLE_ROWS],
                "widths": [0.55, 4.35, 2.75],
            },
        },
        {
            "heading": "Excluded Language",
            "paragraphs": [
                "The title set avoids promotional wording and assay-deployment language. The recommended language stays with predictive, transcriptomic, compact, stability-informed, explainable, and multi-cohort validation."
            ],
        },
    ]

    recommendation_sections = [
        {
            "heading": "Recommended Final Title",
            "paragraphs": [FINAL_TITLE],
        },
        {
            "heading": "Ranking Basis",
            "table": {
                "headers": ["Rank", "Candidate title", "Accuracy", "Novelty", "Journal fit", "Reviewer acceptance"],
                "rows": [[r[0], r[1], r[3], r[4], r[5], r[6]] for r in TITLE_ROWS],
                "widths": [0.45, 4.2, 0.65, 0.65, 0.7, 0.95],
            },
        },
        {
            "heading": "Rationale",
            "paragraphs": [
                "The recommended title is specific about the study object, accurate about the predictive endpoint, and explicit about the features that distinguish the work: stability-informed selection, a 10-gene transcriptomic signature, multi-cohort validation, and explainable analysis. It avoids implying clinical deployment or superiority beyond the statistical evidence."
            ],
        },
    ]

    gap_sections = [
        {
            "heading": "Manuscript Ready Research Gap",
            "paragraphs": [
                "Transcriptomic machine learning models have been explored for molecular subtype and biomarker prediction in breast cancer, but many published approaches remain difficult to evaluate for manuscript-level translation because they rely on large gene sets, limited external validation, or insufficient explanation of the biological and statistical basis for selected features.",
                "For HER2 status prediction, a model that performs well in one development cohort is not enough. A publication-ready contribution should show whether the signature is reproducible under resampling, whether a compact form retains predictive discrimination, whether it generalizes across independent cohorts and expression platforms, whether it adds context beyond ERBB2 expression alone, and whether probability calibration and threshold-dependent behavior have been evaluated.",
            ],
        },
        {
            "heading": "Gap Addressed by This Study",
            "paragraphs": [
                "This study addresses that gap by developing a stability-informed 10-gene HER2-associated transcriptomic signature, validating it across TCGA, SCAN-B, and METABRIC, benchmarking it against ERBB2 expression and the original 86-gene model, and adding calibration, decision-curve, and explainable analyses. The contribution is a compact and biologically supported predictive framework, not a claim of direct clinical deployment."
            ],
        },
    ]

    novelty_sections = [
        {
            "heading": "Novelty Statement",
            "table": {
                "headers": ["Element", "Statement"],
                "rows": [
                    ["Previous studies", "Many transcriptomic ML studies report HER2 or breast cancer subtype prediction, often with high-dimensional signatures and incomplete external validation or interpretability."],
                    ["Remaining limitation", "A compact HER2-associated signature with stability-informed feature selection, ERBB2 benchmarking, multi-cohort validation, calibration evaluation, DCA, and explainability is less commonly presented as one integrated manuscript framework."],
                    ["Our approach", "We used bootstrap stability and biological evidence to reduce an 86-gene transcriptomic predictor to a 10-gene panel, then evaluated discrimination, calibration, threshold behavior, benchmark performance, and explainable gene-level contributions across independent cohorts."],
                    ["Scientific contribution", "The study provides a reproducibility-guided and interpretable HER2 transcriptomic risk stratification framework with potential utility assessed under explicit decision thresholds."],
                ],
                "widths": [1.65, 6.0],
            },
        },
        {
            "heading": "Preferred Novelty Wording",
            "paragraphs": [
                "The novelty of this work lies in combining stability-informed signature reduction, compact 10-gene modeling, ERBB2 benchmarking, multi-cohort validation, calibration evaluation, decision-curve analysis, and explainable gene-level interpretation within a single HER2 transcriptomic prediction study."
            ],
        },
    ]

    journal_sections = [
        {
            "heading": "Journal Category Positioning",
            "table": {
                "headers": ["Category", "Scope match", "Why suitable", "Potential concerns"],
                "rows": JOURNAL_ROWS,
                "widths": [1.45, 1.0, 3.0, 2.25],
            },
        },
        {
            "heading": "Positioning Guidance",
            "paragraphs": [
                "The strongest first-pass positioning is bioinformatics, computational biology, or cancer informatics. Translational oncology and breast cancer specialty venues are plausible if the manuscript foregrounds validation, threshold behavior, and biological interpretation while keeping implementation claims conservative.",
                "Acceptance should not be assumed. The most likely reviewer pressure points are the applied nature of the modeling method, the absence of prospective validation, METABRIC platform differences and missing MIR4728, and the need to avoid overstating DCA or ERBB2 benchmark findings.",
            ],
        },
    ]

    narrative_sections = [
        {"heading": "Opening Problem", "paragraphs": ["HER2 status is central to breast cancer biology and treatment context, but transcriptomic prediction studies often struggle to balance predictive performance, compactness, reproducibility, and interpretability. Large ML signatures can perform well while remaining difficult to explain or externally assess."]},
        {"heading": "Research Gap", "paragraphs": ["The key gap is not merely whether HER2 can be predicted from expression data. The stronger gap is whether a HER2-associated transcriptomic signature can be reduced to a stable, compact, biologically interpretable form and evaluated across independent cohorts with calibration and threshold-dependent utility considered."]},
        {"heading": "Methodological Solution", "paragraphs": ["The manuscript should present a stepwise framework: start with the locked 86-gene model, quantify bootstrap stability, derive the 10-gene stable panel, compare it with ERBB2-only and the 86-gene reference, validate in SCAN-B and METABRIC, evaluate calibration and threshold transport, perform DCA, and interpret gene-level contributions."]},
        {"heading": "Major Findings", "bullets": [
            "A 10-gene CORE_STABLE panel retained strong external discrimination relative to the original 86-gene model.",
            "The 10-gene model showed comparable or improved discrimination relative to ERBB2-only, without claiming unsupported statistical superiority.",
            "METABRIC extended validation to an independent microarray cohort, while also highlighting threshold transport and platform limitations.",
            "Calibration evaluation showed cohort-specific probability behavior, supporting careful interpretation of absolute probabilities.",
            "Explainable analysis connected leading contributors to stability and biological network support.",
        ]},
        {"heading": "Scientific Impact", "paragraphs": ["The study contributes a compact, explainable, and biologically supported transcriptomic HER2 prediction framework that is more manuscript-ready than a generic high-dimensional ML classifier because it explicitly addresses feature stability, comparator performance, external validation, calibration, threshold behavior, and interpretability."]},
        {"heading": "Limitations", "bullets": [
            "The work remains retrospective and does not establish prospective deployment.",
            "The signature should be framed as predictive risk stratification rather than a replacement for established HER2 assessment workflows.",
            "DCA estimates potential utility under threshold preferences and does not establish patient outcome benefit.",
            "Individual genes should be interpreted as predictive contributors within the model, not as causal mediators of HER2 biology.",
            "METABRIC lacks MIR4728, and cross-platform expression differences require conservative interpretation.",
        ]},
    ]

    create_doc(
        "Core_Contribution_Framework.docx",
        "Core Contribution Framework",
        "This document defines the central scientific identity of the completed TCGA-BRCA HER2 transcriptomic ML study before manuscript writing.",
        core_sections,
    )
    create_doc(
        "Title_Candidates.docx",
        "Title Candidates",
        "This document provides 15 Q1-style manuscript title options that emphasize scientific novelty while avoiding unsupported claims.",
        title_sections,
    )
    create_doc(
        "Final_Title_Recommendation.docx",
        "Final Title Recommendation",
        "This document ranks the title candidates by scientific accuracy, novelty, journal suitability, and reviewer acceptance potential.",
        recommendation_sections,
    )
    create_doc(
        "Research_Gap_Statement.docx",
        "Research Gap Statement",
        "This document provides a manuscript-ready research gap for the completed HER2 transcriptomic prediction study.",
        gap_sections,
    )
    create_doc(
        "Novelty_Statement.docx",
        "Novelty Statement",
        "This document structures the novelty argument as previous studies, remaining limitation, our approach, and scientific contribution.",
        novelty_sections,
    )
    create_doc(
        "Journal_Positioning_Report.docx",
        "Journal Positioning Report",
        "This document summarizes suitable journal categories for the manuscript and the likely positioning concerns for each category.",
        journal_sections,
    )
    create_doc(
        "Manuscript_Narrative_Framework.docx",
        "Manuscript Narrative Framework",
        "This document outlines the final manuscript storyline from problem framing through limitations.",
        narrative_sections,
    )


def write_supporting_json() -> None:
    payload = {
        "final_title": FINAL_TITLE,
        "novelty_statement": "The novelty of this work lies in combining stability-informed signature reduction, compact 10-gene modeling, ERBB2 benchmarking, multi-cohort validation, calibration evaluation, decision-curve analysis, and explainable gene-level interpretation within a single HER2 transcriptomic prediction study.",
        "research_gap": "Many transcriptomic HER2 prediction studies remain limited by large feature sets, incomplete external validation, limited interpretability, and uncommon clinical utility assessment. This study addresses those gaps with a compact stability-informed signature and multi-layer validation.",
        "contributions": CONTRIBUTIONS,
        "title_rows": TITLE_ROWS,
        "journal_rows": JOURNAL_ROWS,
        "evidence": EVIDENCE,
    }
    (SCRIPTS / "CF37_1_positioning_content.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")


def write_summary_report() -> None:
    report = f"""# CF37.1 Final Scientific Positioning

## Final Recommended Title
{FINAL_TITLE}

## Core Contribution
The study's central contribution is a stability-informed reduction of a high-dimensional HER2 transcriptomic predictor into a compact, interpretable 10-gene HER2-associated signature that was evaluated across TCGA, SCAN-B, and METABRIC with benchmarking, calibration evaluation, decision curve analysis, and explainable gene-level interpretation.

## Novelty Statement
The novelty of this work lies in combining stability-informed signature reduction, compact 10-gene modeling, ERBB2 benchmarking, multi-cohort validation, calibration evaluation, decision-curve analysis, and explainable gene-level interpretation within a single HER2 transcriptomic prediction study.

## Research Gap
Many transcriptomic HER2 prediction studies remain limited by large feature sets, incomplete external validation, limited interpretability, and uncommon clinical utility assessment. This study addresses those gaps with a compact stability-informed signature and multi-layer validation.

## Key Contributions
""" + "\n".join(
        f"- {row['Contribution']} ({row['Supporting_CF_experiment']}): {row['Evidence']}"
        for row in CONTRIBUTIONS
    ) + f"""

## Manuscript Positioning
The strongest journal-category positioning is bioinformatics, computational biology, or cancer informatics. Translational oncology and breast cancer specialty venues are also plausible if the manuscript emphasizes predictive risk stratification, external validation, biologically supported interpretation, and potential utility while keeping deployment claims conservative.

## Output Files
- Core_Contribution_Framework.docx
- Title_Candidates.docx
- Final_Title_Recommendation.docx
- Research_Gap_Statement.docx
- Novelty_Statement.docx
- Key_Contributions_Table.xlsx
- Journal_Positioning_Report.docx
- Manuscript_Narrative_Framework.docx

## Render QA Limitation
The packaged DOCX renderer could not run because soffice.exe was unavailable in this environment. Structural DOCX checks and workbook checks were completed instead.
"""
    (OUT / "CF37_1_Report.md").write_text(report, encoding="utf-8")


def main() -> None:
    DOCS.mkdir(parents=True, exist_ok=True)
    TABLES.mkdir(parents=True, exist_ok=True)
    SCRIPTS.mkdir(parents=True, exist_ok=True)
    QA.mkdir(parents=True, exist_ok=True)
    build_documents()
    write_supporting_json()
    write_summary_report()
    print("CF37.1 DOCX positioning documents created.")
    print(f"Final recommended title: {FINAL_TITLE}")


if __name__ == "__main__":
    main()
