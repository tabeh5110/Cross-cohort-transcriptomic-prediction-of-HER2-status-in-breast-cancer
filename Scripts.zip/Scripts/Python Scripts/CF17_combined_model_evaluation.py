#!/usr/bin/env python
"""
CF17 - COMBINED INTERNAL MODEL EVALUATION + MANUAL MODEL-LOCK GATE

Purpose
-------
Evaluate all seven TCGA model families after:
- CF16 pre-specified primary model comparison:
    Elastic-Net Logistic Regression
    Linear SVM
    XGBoost
- CF16B post-hoc exploratory extension:
    Ridge Logistic Regression
    RBF-SVM
    Extra Trees
    LightGBM

CF17 performs NO model retraining and DOES NOT access SCAN-B or APOLLO.

Core evaluation
---------------
1) Validate all frozen CF16 / CF16B outputs.
2) Preserve PRE_SPECIFIED vs POST_HOC_EXPLORATORY status.
3) Summarize 15 untouched outer-fold AUROC and average precision values.
4) Compute stratified PATIENT-LEVEL PAIRED bootstrap confidence intervals.
   Bootstrap resampling is propagated across all three CV repeats, preserving
   the paired comparison between model families and avoiding the incorrect
   assumption that the 15 folds are independent experiments.
5) Quantify selected-k and preliminary feature-selection stability.
6) Generate publication-ready AUROC and PR-AUC model-comparison figures.
7) Write decision evidence, but DO NOT automatically lock the final model.

Why the bootstrap metric is fold-wise
-------------------------------------
Scores from independently fitted CV folds can differ in numerical scale,
especially decision_function outputs from SVM models. Therefore, CF17 does NOT
pool raw scores across different folds. For each patient-level bootstrap sample,
AUROC and average precision are calculated separately inside each frozen outer
test fold and then averaged across the 15 evaluations. This preserves the exact
primary evaluation structure used in CF16/CF16B.

Final state
-----------
EVALUATION_COMPLETE_MANUAL_MODEL_LOCK_REQUIRED

After manual review, a short CF17 lock stage can freeze the selected model family
before CF18 stable-signature / explainability work.
"""

from __future__ import annotations

import hashlib
import importlib.metadata as ilm
import itertools
import logging
import math
import os
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path.cwd()

CF16_DIR = ROOT / "results" / "CF16_nested_cv_training"
CF16_SUMMARY = CF16_DIR / "CF16_summary.tsv"
CF16_METRICS = CF16_DIR / "CF16_outer_metrics.tsv"
CF16_PRED = CF16_DIR / "CF16_outer_predictions.tsv"
CF16_FEATURES = CF16_DIR / "CF16_selected_features.tsv"
CF16_BEST = CF16_DIR / "CF16_best_params.tsv"

CF16B_DIR = ROOT / "results" / "CF16B_exploratory_model_extension"
CF16B_SUMMARY = CF16B_DIR / "CF16B_summary.tsv"
CF16B_METRICS = CF16B_DIR / "CF16B_outer_metrics.tsv"
CF16B_PRED = CF16B_DIR / "CF16B_outer_predictions.tsv"
CF16B_FEATURES = CF16B_DIR / "CF16B_selected_features.tsv"
CF16B_BEST = CF16B_DIR / "CF16B_best_params.tsv"

RESULTS = ROOT / "results" / "CF17_combined_model_evaluation"
FIGURES = RESULTS / "figures"
LOG_DIR = ROOT / "logs"
LOG_FILE = LOG_DIR / "CF17_combined_model_evaluation.log"

STATUS_REGISTRY_OUT = RESULTS / "CF17_model_status_registry.tsv"
PERFORMANCE_OUT = RESULTS / "CF17_combined_model_performance.tsv"
BOOTSTRAP_CI_OUT = RESULTS / "CF17_patient_bootstrap_CIs.tsv"
PAIRWISE_OUT = RESULTS / "CF17_paired_model_differences.tsv"
K_DIST_OUT = RESULTS / "CF17_selected_k_distribution.tsv"
FEATURE_FREQ_OUT = RESULTS / "CF17_feature_selection_frequency.tsv"
FEATURE_STABILITY_SUMMARY_OUT = RESULTS / "CF17_feature_stability_summary.tsv"
DECISION_OUT = RESULTS / "CF17_model_selection_decision_evidence.tsv"
SUMMARY_OUT = RESULTS / "CF17_summary.tsv"
PROVENANCE_OUT = RESULTS / "CF17_provenance.tsv"
MANUAL_GATE = RESULTS / "CF17_MANUAL_MODEL_LOCK_REQUIRED.txt"

EXPECTED_N = 938
EXPECTED_POS = 182
EXPECTED_NEG = 756
EXPECTED_SPLITS = 15
EXPECTED_REPEATS = 3

PRE_SPECIFIED_MODELS = [
    "ElasticNet_Logistic",
    "Linear_SVM",
    "XGBoost",
]

EXPLORATORY_MODELS = [
    "Ridge_Logistic",
    "RBF_SVM",
    "Extra_Trees",
    "LightGBM",
]

ALL_MODELS = PRE_SPECIFIED_MODELS + EXPLORATORY_MODELS

# Locked before model results:
PRIMARY_METRIC = "AUROC"
KEY_SECONDARY_METRIC = "Average Precision / PR-AUC"
AUROC_SIMPLICITY_TIE_ZONE = 0.01

BOOTSTRAP_REPLICATES = 2000
BOOTSTRAP_SEED = 20260816

# Consistent publication palette.
MODEL_COLORS = {
    "ElasticNet_Logistic": "#0072B2",
    "Linear_SVM": "#56B4E9",
    "XGBoost": "#009E73",
    "Ridge_Logistic": "#E69F00",
    "RBF_SVM": "#D55E00",
    "Extra_Trees": "#CC79A7",
    "LightGBM": "#6A51A3",
}

DISPLAY_LABELS = {
    "ElasticNet_Logistic": "Elastic-Net\n(P)",
    "Linear_SVM": "Linear SVM\n(P)",
    "XGBoost": "XGBoost\n(P)",
    "Ridge_Logistic": "Ridge Logistic\n(E)",
    "RBF_SVM": "RBF-SVM\n(E)",
    "Extra_Trees": "Extra Trees\n(E)",
    "LightGBM": "LightGBM\n(E)",
}


# ============================================================
# UTILITIES
# ============================================================

def setup_logging() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    FIGURES.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def package_version(name: str) -> str:
    try:
        return ilm.version(name)
    except ilm.PackageNotFoundError:
        return "MISSING"


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(block_size), b""):
            h.update(block)
    return h.hexdigest()


def metric_dict(path: Path) -> Dict[str, str]:
    df = pd.read_csv(path, sep="\t", dtype=str)
    if not {"metric", "value"}.issubset(df.columns):
        raise RuntimeError(f"Expected metric/value columns in {path}")
    return dict(zip(df["metric"].astype(str), df["value"].astype(str)))


def model_status(model: str) -> str:
    if model in PRE_SPECIFIED_MODELS:
        return "PRE_SPECIFIED_PRIMARY_ANALYSIS"
    if model in EXPLORATORY_MODELS:
        return "POST_HOC_EXPLORATORY"
    raise RuntimeError(f"Unexpected model: {model}")


def split_sort_key(split_id: str) -> Tuple[int, int]:
    a, b = str(split_id).split("_")
    return int(a[1:]), int(b[1:])


# ============================================================
# WEIGHTED METRICS FOR PATIENT-LEVEL BOOTSTRAP
# ============================================================

def score_group_starts(sorted_scores: np.ndarray) -> np.ndarray:
    if len(sorted_scores) == 0:
        return np.array([], dtype=int)
    return np.r_[0, 1 + np.flatnonzero(np.diff(sorted_scores) != 0)]


def weighted_auc_sorted_ascending(
    y_sorted: np.ndarray,
    w_sorted: np.ndarray,
    group_starts: np.ndarray,
) -> float:
    """
    Weighted binary AUROC using the Mann-Whitney interpretation.
    Scores must already be sorted ascending. Ties receive 0.5 credit.
    """
    pos_w = w_sorted * y_sorted
    neg_w = w_sorted * (1 - y_sorted)

    total_pos = float(pos_w.sum())
    total_neg = float(neg_w.sum())

    if total_pos <= 0 or total_neg <= 0:
        return np.nan

    pos_group = np.add.reduceat(pos_w, group_starts)
    neg_group = np.add.reduceat(neg_w, group_starts)

    neg_before = np.cumsum(neg_group) - neg_group

    numerator = np.sum(
        pos_group * (neg_before + 0.5 * neg_group)
    )

    return float(numerator / (total_pos * total_neg))


def weighted_average_precision_sorted_descending(
    y_sorted: np.ndarray,
    w_sorted: np.ndarray,
    group_starts: np.ndarray,
) -> float:
    """
    Weighted average precision. Scores must already be sorted descending.
    Tied scores are handled as one threshold group.
    """
    pos_w = w_sorted * y_sorted
    total_w = w_sorted

    total_pos = float(pos_w.sum())
    if total_pos <= 0:
        return np.nan

    pos_group = np.add.reduceat(pos_w, group_starts)
    total_group = np.add.reduceat(total_w, group_starts)

    cum_pos = np.cumsum(pos_group)
    cum_total = np.cumsum(total_group)

    precision = np.divide(
        cum_pos,
        cum_total,
        out=np.zeros_like(cum_pos, dtype=float),
        where=cum_total > 0,
    )

    delta_recall = pos_group / total_pos
    return float(np.sum(delta_recall * precision))


def build_metric_cache(
    pred: pd.DataFrame,
    patient_to_global_index: Dict[str, int],
) -> Dict[str, Dict[str, dict]]:
    cache: Dict[str, Dict[str, dict]] = {}

    for model in ALL_MODELS:
        cache[model] = {}
        gm = pred.loc[pred["model"] == model].copy()

        for split_id in sorted(gm["split_id"].unique(), key=split_sort_key):
            g = gm.loc[gm["split_id"] == split_id].copy()

            global_idx = np.array(
                [patient_to_global_index[p] for p in g["patient_id"].astype(str)],
                dtype=int,
            )
            y = g["y_true"].to_numpy(dtype=np.int8)
            scores = g["score"].to_numpy(dtype=float)

            asc_order = np.argsort(scores, kind="mergesort")
            desc_order = np.argsort(-scores, kind="mergesort")

            asc_scores = scores[asc_order]
            desc_scores = scores[desc_order]

            cache[model][split_id] = {
                "asc_global_idx": global_idx[asc_order],
                "asc_y": y[asc_order],
                "asc_starts": score_group_starts(asc_scores),
                "desc_global_idx": global_idx[desc_order],
                "desc_y": y[desc_order],
                "desc_starts": score_group_starts(desc_scores),
            }

    return cache


# ============================================================
# BOOTSTRAP
# ============================================================

def run_patient_bootstrap(
    pred: pd.DataFrame,
    patient_table: pd.DataFrame,
    B: int,
) -> Tuple[pd.DataFrame, pd.DataFrame, np.ndarray, np.ndarray]:
    """
    Stratified patient-level paired bootstrap.

    The same patient resample is used for all models, and the resulting patient
    multiplicities are propagated through all 15 frozen outer test partitions.
    """
    patient_table = patient_table.reset_index(drop=True)
    patient_to_idx = {
        p: i for i, p in enumerate(patient_table["patient_id"].astype(str))
    }

    y_global = patient_table["y_true"].to_numpy(dtype=np.int8)

    pos_idx = np.flatnonzero(y_global == 1)
    neg_idx = np.flatnonzero(y_global == 0)

    if len(pos_idx) != EXPECTED_POS or len(neg_idx) != EXPECTED_NEG:
        raise RuntimeError(
            f"Patient table class counts changed: "
            f"{len(pos_idx)} positive / {len(neg_idx)} negative."
        )

    cache = build_metric_cache(pred, patient_to_idx)
    split_ids = sorted(pred["split_id"].astype(str).unique(), key=split_sort_key)

    if len(split_ids) != EXPECTED_SPLITS:
        raise RuntimeError(f"Expected 15 splits, observed {len(split_ids)}.")

    model_to_col = {m: i for i, m in enumerate(ALL_MODELS)}
    auc_boot = np.empty((B, len(ALL_MODELS)), dtype=np.float64)
    ap_boot = np.empty((B, len(ALL_MODELS)), dtype=np.float64)

    rng = np.random.default_rng(BOOTSTRAP_SEED)

    for b in range(B):
        sampled_pos = rng.choice(pos_idx, size=len(pos_idx), replace=True)
        sampled_neg = rng.choice(neg_idx, size=len(neg_idx), replace=True)

        counts = np.bincount(
            np.r_[sampled_pos, sampled_neg],
            minlength=len(patient_table),
        ).astype(float)

        for model in ALL_MODELS:
            fold_aucs = []
            fold_aps = []

            for split_id in split_ids:
                c = cache[model][split_id]

                w_asc = counts[c["asc_global_idx"]]
                auc = weighted_auc_sorted_ascending(
                    c["asc_y"],
                    w_asc,
                    c["asc_starts"],
                )

                w_desc = counts[c["desc_global_idx"]]
                ap = weighted_average_precision_sorted_descending(
                    c["desc_y"],
                    w_desc,
                    c["desc_starts"],
                )

                if np.isfinite(auc):
                    fold_aucs.append(auc)
                if np.isfinite(ap):
                    fold_aps.append(ap)

            if len(fold_aucs) != EXPECTED_SPLITS:
                raise RuntimeError(
                    f"Bootstrap {b}: {model} had invalid AUROC in a split."
                )
            if len(fold_aps) != EXPECTED_SPLITS:
                raise RuntimeError(
                    f"Bootstrap {b}: {model} had invalid AP in a split."
                )

            j = model_to_col[model]
            auc_boot[b, j] = float(np.mean(fold_aucs))
            ap_boot[b, j] = float(np.mean(fold_aps))

        if (b + 1) % 250 == 0 or (b + 1) == B:
            logging.info(
                f"      Patient bootstrap: {b+1}/{B} replicates complete"
            )

    ci_rows = []
    for model in ALL_MODELS:
        j = model_to_col[model]

        ci_rows.append(
            {
                "model": model,
                "analysis_status": model_status(model),
                "metric": "AUROC",
                "bootstrap_replicates": B,
                "ci_lower_95": float(np.quantile(auc_boot[:, j], 0.025)),
                "ci_upper_95": float(np.quantile(auc_boot[:, j], 0.975)),
            }
        )
        ci_rows.append(
            {
                "model": model,
                "analysis_status": model_status(model),
                "metric": "Average_Precision_PR_AUC",
                "bootstrap_replicates": B,
                "ci_lower_95": float(np.quantile(ap_boot[:, j], 0.025)),
                "ci_upper_95": float(np.quantile(ap_boot[:, j], 0.975)),
            }
        )

    pair_rows = []
    for model_a, model_b in itertools.combinations(ALL_MODELS, 2):
        ja = model_to_col[model_a]
        jb = model_to_col[model_b]

        for metric_name, matrix in [
            ("AUROC", auc_boot),
            ("Average_Precision_PR_AUC", ap_boot),
        ]:
            diff = matrix[:, ja] - matrix[:, jb]

            pair_rows.append(
                {
                    "model_A": model_a,
                    "status_A": model_status(model_a),
                    "model_B": model_b,
                    "status_B": model_status(model_b),
                    "metric": metric_name,
                    "bootstrap_replicates": B,
                    "difference_A_minus_B_bootstrap_mean": float(
                        np.mean(diff)
                    ),
                    "difference_ci_lower_95": float(
                        np.quantile(diff, 0.025)
                    ),
                    "difference_ci_upper_95": float(
                        np.quantile(diff, 0.975)
                    ),
                    "fraction_bootstrap_A_gt_B": float(
                        np.mean(diff > 0)
                    ),
                }
            )

    return (
        pd.DataFrame(ci_rows),
        pd.DataFrame(pair_rows),
        auc_boot,
        ap_boot,
    )


# ============================================================
# FIGURES
# ============================================================

def publication_boxplot(
    metrics: pd.DataFrame,
    value_col: str,
    ylabel: str,
    output_stem: str,
) -> None:
    ordered = sorted(
        ALL_MODELS,
        key=lambda m: metrics.loc[
            metrics["model"] == m, value_col
        ].mean(),
        reverse=True,
    )

    data = [
        metrics.loc[metrics["model"] == model, value_col].to_numpy(dtype=float)
        for model in ordered
    ]

    fig, ax = plt.subplots(figsize=(10.5, 6.2))

    bp = ax.boxplot(
        data,
        patch_artist=True,
        widths=0.58,
        showfliers=False,
        medianprops={"color": "black", "linewidth": 1.4},
        whiskerprops={"color": "black", "linewidth": 1.0},
        capprops={"color": "black", "linewidth": 1.0},
        boxprops={"linewidth": 1.0, "edgecolor": "black"},
    )

    for box, model in zip(bp["boxes"], ordered):
        box.set_facecolor(MODEL_COLORS[model])
        box.set_alpha(0.78)

    # Deterministic horizontal offsets for the 15 outer evaluations.
    offsets = np.linspace(-0.18, 0.18, EXPECTED_SPLITS)
    for i, model in enumerate(ordered, start=1):
        vals = (
            metrics.loc[metrics["model"] == model]
            .sort_values(["repeat", "fold"])[value_col]
            .to_numpy(dtype=float)
        )
        ax.scatter(
            np.full(len(vals), i, dtype=float) + offsets[:len(vals)],
            vals,
            s=20,
            facecolors="white",
            edgecolors="black",
            linewidths=0.6,
            zorder=3,
        )

    ax.set_xticks(
        np.arange(1, len(ordered) + 1),
        [DISPLAY_LABELS[m] for m in ordered],
    )
    ax.set_ylabel(ylabel, fontname="Times New Roman", fontsize=12)
    ax.set_xlabel(
        "Model family  (P = pre-specified; E = post-hoc exploratory)",
        fontname="Times New Roman",
        fontsize=11,
    )
    ax.tick_params(axis="both", labelsize=9)
    ax.grid(axis="y", alpha=0.18)
    ax.set_axisbelow(True)

    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontname("Times New Roman")

    fig.tight_layout()

    png = FIGURES / f"{output_stem}.png"
    pdf = FIGURES / f"{output_stem}.pdf"

    fig.savefig(png, dpi=600, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    setup_logging()
    t0 = time.perf_counter()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF17 - COMBINED INTERNAL MODEL EVALUATION")
    logging.info("============================================================")
    logging.info("")
    logging.info("Estimated runtime: ~3-15 minutes")
    logging.info("Likely bottleneck: 2,000 stratified patient-level paired bootstraps")
    logging.info("Long silent periods: NO; bootstrap progress prints every 250 replicates")
    logging.info("NO model retraining will occur.")
    logging.info("SCAN-B accessed: NO")
    logging.info("APOLLO accessed: NO")
    logging.info("")

    required = [
        CF16_SUMMARY,
        CF16_METRICS,
        CF16_PRED,
        CF16_FEATURES,
        CF16_BEST,
        CF16B_SUMMARY,
        CF16B_METRICS,
        CF16B_PRED,
        CF16B_FEATURES,
        CF16B_BEST,
    ]
    for p in required:
        if not p.exists():
            raise FileNotFoundError(f"Required CF17 input missing: {p}")

    # --------------------------------------------------------
    # 1. Validate frozen upstream gates
    # --------------------------------------------------------
    logging.info("[1/8] Validating CF16 and CF16B gates...")
    logging.info("")

    s16 = metric_dict(CF16_SUMMARY)
    s16b = metric_dict(CF16B_SUMMARY)

    if s16.get("CF16 stage gate") != "PASS_READY_FOR_CF17":
        raise RuntimeError(
            f"CF16 gate is not ready: {s16.get('CF16 stage gate')}"
        )

    if (
        s16b.get("CF16B stage gate")
        != "PASS_READY_FOR_CF17_COMBINED_EVALUATION"
    ):
        raise RuntimeError(
            f"CF16B gate is not ready: {s16b.get('CF16B stage gate')}"
        )

    logging.info("CF16 pre-specified primary analysis: PASS")
    logging.info("CF16B post-hoc exploratory extension: PASS")
    logging.info("")

    # --------------------------------------------------------
    # 2. Load and validate all seven models
    # --------------------------------------------------------
    logging.info("[2/8] Combining model outputs while preserving analysis status...")
    logging.info("")

    m16 = pd.read_csv(CF16_METRICS, sep="\t")
    p16 = pd.read_csv(CF16_PRED, sep="\t")
    f16 = pd.read_csv(CF16_FEATURES, sep="\t")
    b16 = pd.read_csv(CF16_BEST, sep="\t")

    m16b = pd.read_csv(CF16B_METRICS, sep="\t")
    p16b = pd.read_csv(CF16B_PRED, sep="\t")
    f16b = pd.read_csv(CF16B_FEATURES, sep="\t")
    b16b = pd.read_csv(CF16B_BEST, sep="\t")

    # Never trust an input status column more than the fixed registry.
    for df in [m16, p16, f16, b16]:
        df["analysis_status"] = "PRE_SPECIFIED_PRIMARY_ANALYSIS"
    for df in [m16b, p16b, f16b, b16b]:
        df["analysis_status"] = "POST_HOC_EXPLORATORY"

    metrics = pd.concat([m16, m16b], ignore_index=True, sort=False)
    pred = pd.concat([p16, p16b], ignore_index=True, sort=False)
    features = pd.concat([f16, f16b], ignore_index=True, sort=False)
    best = pd.concat([b16, b16b], ignore_index=True, sort=False)

    observed_models = set(metrics["model"].astype(str))
    if observed_models != set(ALL_MODELS):
        raise RuntimeError(
            f"Unexpected model registry. Observed={sorted(observed_models)}"
        )

    metric_counts = metrics.groupby("model").size()
    if not (metric_counts == EXPECTED_SPLITS).all():
        raise RuntimeError(
            f"Each model must have 15 outer metric rows: {metric_counts.to_dict()}"
        )

    # Every patient has one outer-test prediction per repeat per model.
    pred_counts = pred.groupby(["model", "repeat", "patient_id"]).size()
    if not (pred_counts == 1).all():
        raise RuntimeError(
            "Prediction registry is not exactly one OOF prediction per "
            "patient/repeat/model."
        )

    patient_table = (
        pred[["patient_id", "y_true"]]
        .drop_duplicates()
        .sort_values("patient_id")
        .reset_index(drop=True)
    )

    if len(patient_table) != EXPECTED_N:
        raise RuntimeError(
            f"Unique patients={len(patient_table)}; expected {EXPECTED_N}."
        )
    if int(patient_table["y_true"].sum()) != EXPECTED_POS:
        raise RuntimeError("HER2-positive count changed.")

    registry = pd.DataFrame(
        [
            {
                "model": m,
                "analysis_status": model_status(m),
                "pre_specified_before_CF16_results": (
                    m in PRE_SPECIFIED_MODELS
                ),
                "eligible_for_descriptive_combined_comparison": True,
                "can_be_rewritten_as_pre_specified": False
                if m in EXPLORATORY_MODELS
                else True,
            }
            for m in ALL_MODELS
        ]
    )
    registry.to_csv(STATUS_REGISTRY_OUT, sep="\t", index=False)

    logging.info("Seven model families validated.")
    logging.info("Pre-specified models: 3")
    logging.info("Post-hoc exploratory models: 4")
    logging.info(f"Unique TCGA patients: {len(patient_table)}")
    logging.info("")

    # --------------------------------------------------------
    # 3. Outer-fold performance summary
    # --------------------------------------------------------
    logging.info("[3/8] Summarizing the 15 untouched outer evaluations...")
    logging.info("")

    perf = (
        metrics.groupby(["analysis_status", "model"], as_index=False)
        .agg(
            mean_AUROC=("outer_AUROC", "mean"),
            sd_AUROC=("outer_AUROC", "std"),
            median_AUROC=("outer_AUROC", "median"),
            min_AUROC=("outer_AUROC", "min"),
            max_AUROC=("outer_AUROC", "max"),
            mean_PR_AUC=("outer_average_precision", "mean"),
            sd_PR_AUC=("outer_average_precision", "std"),
            median_PR_AUC=("outer_average_precision", "median"),
            min_PR_AUC=("outer_average_precision", "min"),
            max_PR_AUC=("outer_average_precision", "max"),
            mean_selected_k=("selected_k", "mean"),
            median_selected_k=("selected_k", "median"),
        )
    )

    perf["AUROC_rank_all7"] = perf["mean_AUROC"].rank(
        method="min", ascending=False
    ).astype(int)
    perf["PR_AUC_rank_all7"] = perf["mean_PR_AUC"].rank(
        method="min", ascending=False
    ).astype(int)

    perf = perf.sort_values(
        ["mean_AUROC", "mean_PR_AUC"],
        ascending=[False, False],
    ).reset_index(drop=True)

    perf.to_csv(PERFORMANCE_OUT, sep="\t", index=False)

    for _, r in perf.iterrows():
        label = (
            "P"
            if r["analysis_status"] == "PRE_SPECIFIED_PRIMARY_ANALYSIS"
            else "E"
        )
        logging.info(
            f"{r['model']} [{label}]: "
            f"AUROC={r['mean_AUROC']:.4f}±{r['sd_AUROC']:.4f}; "
            f"PR-AUC={r['mean_PR_AUC']:.4f}±{r['sd_PR_AUC']:.4f}"
        )
    logging.info("")

    # --------------------------------------------------------
    # 4. Patient-level paired bootstrap
    # --------------------------------------------------------
    logging.info("[4/8] Running stratified patient-level paired bootstrap...")
    logging.info("")

    ci_df, pair_df, auc_boot, ap_boot = run_patient_bootstrap(
        pred,
        patient_table,
        BOOTSTRAP_REPLICATES,
    )

    # Add the observed fold-mean point estimates.
    point_map_auc = dict(zip(perf["model"], perf["mean_AUROC"]))
    point_map_ap = dict(zip(perf["model"], perf["mean_PR_AUC"]))

    ci_df["point_estimate"] = ci_df.apply(
        lambda r: (
            point_map_auc[r["model"]]
            if r["metric"] == "AUROC"
            else point_map_ap[r["model"]]
        ),
        axis=1,
    )

    ci_df.to_csv(BOOTSTRAP_CI_OUT, sep="\t", index=False)

    # Add observed pairwise point difference.
    def point_diff(row):
        if row["metric"] == "AUROC":
            return (
                point_map_auc[row["model_A"]]
                - point_map_auc[row["model_B"]]
            )
        return (
            point_map_ap[row["model_A"]]
            - point_map_ap[row["model_B"]]
        )

    pair_df["observed_difference_A_minus_B"] = pair_df.apply(
        point_diff,
        axis=1,
    )
    pair_df.to_csv(PAIRWISE_OUT, sep="\t", index=False)

    logging.info("Patient-level paired bootstrap complete.")
    logging.info("")

    # --------------------------------------------------------
    # 5. Selected k + preliminary feature stability
    # --------------------------------------------------------
    logging.info("[5/8] Auditing selected-k and preliminary feature stability...")
    logging.info("")

    k_dist = (
        best.groupby(["analysis_status", "model", "k"], as_index=False)
        .size()
        .rename(columns={"size": "outer_splits_selected"})
    )
    k_dist["selection_fraction"] = (
        k_dist["outer_splits_selected"] / EXPECTED_SPLITS
    )
    k_dist.to_csv(K_DIST_OUT, sep="\t", index=False)

    freq = (
        features.groupby(
            ["analysis_status", "model", "gene_symbol"],
            as_index=False,
        )
        .agg(
            selected_outer_splits=("split_id", "nunique"),
            mean_selector_f_score=("selector_f_score", "mean"),
        )
    )
    freq["selection_frequency"] = (
        freq["selected_outer_splits"] / EXPECTED_SPLITS
    )
    freq = freq.sort_values(
        ["model", "selected_outer_splits", "mean_selector_f_score"],
        ascending=[True, False, False],
    )
    freq.to_csv(FEATURE_FREQ_OUT, sep="\t", index=False)

    stability_rows = []
    for model in ALL_MODELS:
        g = freq.loc[freq["model"] == model]
        stability_rows.append(
            {
                "model": model,
                "analysis_status": model_status(model),
                "unique_selected_genes": int(g["gene_symbol"].nunique()),
                "genes_selected_15_of_15": int(
                    (g["selected_outer_splits"] == 15).sum()
                ),
                "genes_selected_at_least_12_of_15": int(
                    (g["selected_outer_splits"] >= 12).sum()
                ),
                "genes_selected_at_least_8_of_15": int(
                    (g["selected_outer_splits"] >= 8).sum()
                ),
            }
        )

    pd.DataFrame(stability_rows).to_csv(
        FEATURE_STABILITY_SUMMARY_OUT,
        sep="\t",
        index=False,
    )

    logging.info("Feature-selection frequency audit complete.")
    logging.info(
        "Detailed biomarker interpretation is intentionally deferred to CF18."
    )
    logging.info("")

    # --------------------------------------------------------
    # 6. Decision evidence
    # --------------------------------------------------------
    logging.info("[6/8] Constructing manual model-selection evidence...")
    logging.info("")

    pre = perf.loc[
        perf["analysis_status"] == "PRE_SPECIFIED_PRIMARY_ANALYSIS"
    ].sort_values("mean_AUROC", ascending=False)

    exp = perf.loc[
        perf["analysis_status"] == "POST_HOC_EXPLORATORY"
    ].sort_values("mean_AUROC", ascending=False)

    best_pre = pre.iloc[0]
    best_exp = exp.iloc[0]
    overall = perf.iloc[0]

    auc_gain_exp_over_pre = float(
        best_exp["mean_AUROC"] - best_pre["mean_AUROC"]
    )
    ap_gain_exp_over_pre = float(
        best_exp["mean_PR_AUC"] - best_pre["mean_PR_AUC"]
    )

    def pair_lookup(a: str, b: str, metric: str) -> dict:
        direct = pair_df.loc[
            (pair_df["model_A"] == a)
            & (pair_df["model_B"] == b)
            & (pair_df["metric"] == metric)
        ]
        if len(direct) == 1:
            r = direct.iloc[0]
            return {
                "diff": float(r["observed_difference_A_minus_B"]),
                "lo": float(r["difference_ci_lower_95"]),
                "hi": float(r["difference_ci_upper_95"]),
            }

        reverse = pair_df.loc[
            (pair_df["model_A"] == b)
            & (pair_df["model_B"] == a)
            & (pair_df["metric"] == metric)
        ]
        if len(reverse) != 1:
            raise RuntimeError(f"Pairwise comparison not found: {a}, {b}")

        r = reverse.iloc[0]
        return {
            "diff": -float(r["observed_difference_A_minus_B"]),
            "lo": -float(r["difference_ci_upper_95"]),
            "hi": -float(r["difference_ci_lower_95"]),
        }

    exp_vs_pre_auc = pair_lookup(
        str(best_exp["model"]),
        str(best_pre["model"]),
        "AUROC",
    )
    exp_vs_pre_ap = pair_lookup(
        str(best_exp["model"]),
        str(best_pre["model"]),
        "Average_Precision_PR_AUC",
    )

    decision_rows = [
        (
            "Best pre-specified model by locked primary metric",
            str(best_pre["model"]),
        ),
        (
            "Best exploratory model by locked primary metric",
            str(best_exp["model"]),
        ),
        (
            "Descriptive best model among all seven",
            str(overall["model"]),
        ),
        (
            "Exploratory minus pre-specified best AUROC",
            auc_gain_exp_over_pre,
        ),
        (
            "Exploratory minus pre-specified best PR-AUC",
            ap_gain_exp_over_pre,
        ),
        (
            "AUROC simplicity tie-zone threshold locked before results",
            AUROC_SIMPLICITY_TIE_ZONE,
        ),
        (
            "Exploratory AUROC gain exceeds 0.01 tie-zone",
            bool(
                auc_gain_exp_over_pre
                > AUROC_SIMPLICITY_TIE_ZONE
            ),
        ),
        (
            "Bootstrap AUROC difference exploratory-best minus pre-specified-best",
            exp_vs_pre_auc["diff"],
        ),
        (
            "Bootstrap AUROC difference 95% CI",
            f"{exp_vs_pre_auc['lo']:.6f} to {exp_vs_pre_auc['hi']:.6f}",
        ),
        (
            "Bootstrap PR-AUC difference exploratory-best minus pre-specified-best",
            exp_vs_pre_ap["diff"],
        ),
        (
            "Bootstrap PR-AUC difference 95% CI",
            f"{exp_vs_pre_ap['lo']:.6f} to {exp_vs_pre_ap['hi']:.6f}",
        ),
        (
            "Automatic final model selection performed",
            "NO",
        ),
        (
            "Reason manual lock is required",
            "CF16B was post-hoc exploratory and the pre-locked phrase "
            "'PR-AUC not materially worse' did not specify a numeric threshold.",
        ),
        (
            "SCAN-B used for model selection",
            "NO",
        ),
    ]

    pd.DataFrame(
        decision_rows,
        columns=["decision_item", "value"],
    ).to_csv(DECISION_OUT, sep="\t", index=False)

    logging.info(
        f"Best pre-specified model: {best_pre['model']} "
        f"(AUROC={best_pre['mean_AUROC']:.4f})"
    )
    logging.info(
        f"Best exploratory model: {best_exp['model']} "
        f"(AUROC={best_exp['mean_AUROC']:.4f})"
    )
    logging.info(
        f"Exploratory AUROC gain over best pre-specified: "
        f"{auc_gain_exp_over_pre:+.4f}"
    )
    logging.info(
        "Final model is intentionally NOT locked automatically."
    )
    logging.info("")

    # --------------------------------------------------------
    # 7. Publication-ready figures
    # --------------------------------------------------------
    logging.info("[7/8] Generating publication-ready comparison figures...")
    logging.info("")

    publication_boxplot(
        metrics,
        "outer_AUROC",
        "Outer-fold AUROC",
        "CF17_AUROC_model_comparison",
    )
    publication_boxplot(
        metrics,
        "outer_average_precision",
        "Outer-fold average precision (PR-AUC)",
        "CF17_PR_AUC_model_comparison",
    )

    logging.info("AUROC comparison figure: PNG + PDF")
    logging.info("PR-AUC comparison figure: PNG + PDF")
    logging.info("")

    # --------------------------------------------------------
    # 8. Summary / provenance / manual gate
    # --------------------------------------------------------
    logging.info("[8/8] Writing CF17 summary and provenance...")
    logging.info("")

    runtime_min = (time.perf_counter() - t0) / 60.0

    summary = pd.DataFrame(
        [
            ("TCGA patients evaluated", EXPECTED_N),
            ("HER2 positive", EXPECTED_POS),
            ("HER2 negative", EXPECTED_NEG),
            ("Pre-specified models", len(PRE_SPECIFIED_MODELS)),
            ("Post-hoc exploratory models", len(EXPLORATORY_MODELS)),
            ("Total models compared", len(ALL_MODELS)),
            ("Outer evaluations per model", EXPECTED_SPLITS),
            ("Patient bootstrap replicates", BOOTSTRAP_REPLICATES),
            ("Best pre-specified model by mean AUROC", best_pre["model"]),
            ("Best pre-specified mean AUROC", round(float(best_pre["mean_AUROC"]), 6)),
            ("Best pre-specified mean PR-AUC", round(float(best_pre["mean_PR_AUC"]), 6)),
            ("Best exploratory model by mean AUROC", best_exp["model"]),
            ("Best exploratory mean AUROC", round(float(best_exp["mean_AUROC"]), 6)),
            ("Best exploratory mean PR-AUC", round(float(best_exp["mean_PR_AUC"]), 6)),
            ("Exploratory-best AUROC gain over pre-specified-best", round(auc_gain_exp_over_pre, 6)),
            ("Exploratory-best AUROC gain exceeds 0.01", "YES" if auc_gain_exp_over_pre > 0.01 else "NO"),
            ("SCAN-B accessed", "NO"),
            ("APOLLO accessed", "NO"),
            ("Model retraining in CF17", "NO"),
            ("Final model family locked", "NO"),
            ("CF17 runtime minutes", round(runtime_min, 2)),
            ("CF17 stage gate", "EVALUATION_COMPLETE_MANUAL_MODEL_LOCK_REQUIRED"),
        ],
        columns=["metric", "value"],
    )
    summary.to_csv(SUMMARY_OUT, sep="\t", index=False)

    provenance = pd.DataFrame(
        [
            ("code_file", "CF17_combined_model_evaluation.py"),
            ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
            ("CF16_summary_sha256", sha256_file(CF16_SUMMARY)),
            ("CF16_metrics_sha256", sha256_file(CF16_METRICS)),
            ("CF16_predictions_sha256", sha256_file(CF16_PRED)),
            ("CF16B_summary_sha256", sha256_file(CF16B_SUMMARY)),
            ("CF16B_metrics_sha256", sha256_file(CF16B_METRICS)),
            ("CF16B_predictions_sha256", sha256_file(CF16B_PRED)),
            (
                "bootstrap_rule",
                "2000 stratified patient-level paired resamples; patient "
                "multiplicity propagated across all three repeated CV runs; "
                "metric computed separately within each frozen outer test fold "
                "then averaged across 15 evaluations",
            ),
            (
                "score_pooling_rule",
                "Raw scores from different outer models are NOT pooled across folds",
            ),
            (
                "analysis_status_rule",
                "CF16 models remain PRE_SPECIFIED; CF16B models remain POST_HOC_EXPLORATORY",
            ),
            (
                "external_data_rule",
                "SCAN-B and APOLLO are not accessed in CF17",
            ),
            ("python_version", platform.python_version()),
            ("numpy_version", package_version("numpy")),
            ("pandas_version", package_version("pandas")),
            ("matplotlib_version", package_version("matplotlib")),
            ("CF17_stage_gate", "EVALUATION_COMPLETE_MANUAL_MODEL_LOCK_REQUIRED"),
        ],
        columns=["field", "value"],
    )
    provenance.to_csv(PROVENANCE_OUT, sep="\t", index=False)

    MANUAL_GATE.write_text(
        "CF17 combined internal model evaluation is complete.\n"
        "The final model family is NOT yet locked.\n"
        "Review CF17_model_selection_decision_evidence.tsv, "
        "CF17_patient_bootstrap_CIs.tsv, and "
        "CF17_paired_model_differences.tsv before CF18.\n"
        "SCAN-B and APOLLO remain untouched.\n",
        encoding="utf-8",
    )

    logging.info("============================================================")
    logging.info(" CF17 EVALUATION COMPLETE - MANUAL MODEL LOCK REQUIRED")
    logging.info("============================================================")
    logging.info("")
    logging.info(
        f"Best pre-specified by mean AUROC: "
        f"{best_pre['model']} ({best_pre['mean_AUROC']:.4f})"
    )
    logging.info(
        f"Best exploratory by mean AUROC: "
        f"{best_exp['model']} ({best_exp['mean_AUROC']:.4f})"
    )
    logging.info(
        f"Exploratory AUROC gain: {auc_gain_exp_over_pre:+.4f}"
    )
    logging.info(
        f"Gain > locked 0.01 AUROC tie zone: "
        f"{'YES' if auc_gain_exp_over_pre > 0.01 else 'NO'}"
    )
    logging.info("")
    logging.info("SCAN-B accessed: NO")
    logging.info("APOLLO accessed: NO")
    logging.info("Model retraining: NO")
    logging.info("Final model family locked: NO")
    logging.info(
        "STATUS: EVALUATION_COMPLETE_MANUAL_MODEL_LOCK_REQUIRED"
    )
    logging.info("")
    logging.info("Send the full terminal output before the CF17 model lock.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF17 ERROR: {exc}")
        sys.exit(1)
