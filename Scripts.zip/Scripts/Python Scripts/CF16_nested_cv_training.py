#!/usr/bin/env python
"""
CF16 - Nested-CV feature selection + model training (TCGA only)

Scientific role
---------------
This is the first formal ML training stage.

Locked inputs:
- Primary endpoint: HER2 measured/pathology status
- Discovery cohort: 938 classifiable TCGA tumors
- Positive / negative: 182 / 756
- Feature universe: 22,106 exact TCGA∩SCAN-B genes
- Representation: within-sample percentile ranks
- Outer CV: frozen 5-fold × 3 repeats = 15 evaluations
- Inner CV: stratified 4-fold
- Models: Elastic-Net Logistic Regression, Linear SVM, XGBoost
- Primary tuning metric: AUROC
- Key secondary tuning metric: Average Precision / PR-AUC
- Feature selection: SelectKBest(f_classif), inside training folds only
- No SMOTE / oversampling
- SCAN-B and APOLLO are NOT accessed.

Efficiency
----------
The implementation manually caches fold-specific preprocessing:
VarianceThreshold + StandardScaler are fitted once per inner fold, and each
SelectKBest(k) representation is fitted once per k per inner fold. This avoids
recomputing the same preprocessing thousands of times while preserving the
locked leakage-safe design.

Checkpoint/resume
-----------------
Each outer-split/model job writes independent checkpoint files and a DONE
marker. Re-running the script skips completed jobs and resumes from the first
unfinished job.

CF16 does NOT:
- use SCAN-B;
- use APOLLO;
- choose the final model family;
- calibrate the final model;
- choose the final classification threshold;
- claim external validation.

Those decisions belong to later frozen stages.
"""

from __future__ import annotations

import hashlib
import importlib.metadata as ilm
import json
import logging
import math
import os
import platform
import re
import sys
import time
import warnings
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Tuple, Any

import numpy as np
import pandas as pd

from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_selection import SelectKBest, VarianceThreshold, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC


# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path.cwd()

CF15_DIR = ROOT / "results" / "CF15_ml_experiment_design"
CF15_SUMMARY = CF15_DIR / "CF15_summary.tsv"
OUTER_ASSIGNMENTS = CF15_DIR / "CF15_outer_cv_test_assignments.tsv"

ML_READY = ROOT / "data" / "processed" / "ml_ready"
MATRIX_NPZ = ML_READY / "CF15_TCGA_HER2_rank_matrix.npz"

RESULTS = ROOT / "results" / "CF16_nested_cv_training"
CHECKPOINTS = RESULTS / "checkpoints"
LOG_DIR = ROOT / "logs"
LOG_FILE = LOG_DIR / "CF16_nested_cv_training.log"

# Aggregate formal outputs
INNER_SEARCH_OUT = RESULTS / "CF16_inner_search_results.tsv"
BEST_PARAMS_OUT = RESULTS / "CF16_best_params.tsv"
OUTER_PRED_OUT = RESULTS / "CF16_outer_predictions.tsv"
OUTER_METRICS_OUT = RESULTS / "CF16_outer_metrics.tsv"
FEATURES_OUT = RESULTS / "CF16_selected_features.tsv"
JOB_STATUS_OUT = RESULTS / "CF16_job_status.tsv"
SUMMARY_OUT = RESULTS / "CF16_summary.tsv"
PROVENANCE_OUT = RESULTS / "CF16_provenance.tsv"

# Locked study values
SEED = 20260815
EXPECTED_N = 938
EXPECTED_P = 22106
EXPECTED_POS = 182
EXPECTED_NEG = 756
EXPECTED_OUTER_SPLITS = 15
EXPECTED_MODELS = 3
EXPECTED_JOBS = EXPECTED_OUTER_SPLITS * EXPECTED_MODELS

K_VALUES = [25, 50, 100, 250, 500]

ELASTIC_C_VALUES = [0.01, 0.1, 1.0, 10.0]
ELASTIC_L1_VALUES = [0.0, 0.25, 0.5, 0.75, 1.0]

SVM_C_VALUES = [0.01, 0.1, 1.0, 10.0]

XGB_N_ESTIMATORS = [100, 200, 400]
XGB_MAX_DEPTH = [2, 3, 4, 5]
XGB_LEARNING_RATE = [0.02, 0.05, 0.1]
XGB_SUBSAMPLE = [0.7, 0.9, 1.0]
XGB_COLSAMPLE = [0.5, 0.75, 1.0]
XGB_MIN_CHILD_WEIGHT = [1, 3, 5]
XGB_REG_ALPHA = [0.0, 0.1, 1.0]
XGB_REG_LAMBDA = [1.0, 5.0, 10.0]
XGB_RANDOM_CANDIDATES = 15

INNER_FOLDS = 4
CPU_COUNT = os.cpu_count() or 1
XGB_THREADS = max(1, min(4, CPU_COUNT - 1 if CPU_COUNT > 1 else 1))


# ============================================================
# BASIC UTILITIES
# ============================================================

def setup_logging() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    CHECKPOINTS.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def package_version(name: str) -> str:
    try:
        return ilm.version(name)
    except ilm.PackageNotFoundError:
        return "MISSING"


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(block_size), b""):
            h.update(block)
    return h.hexdigest()


def metric_dict(path: Path) -> Dict[str, str]:
    df = pd.read_csv(path, sep="\t", dtype=str)
    if not {"metric", "value"}.issubset(df.columns):
        raise RuntimeError(f"Expected metric/value columns in {path}")
    return dict(zip(df["metric"].astype(str), df["value"].astype(str)))


def atomic_write_json(obj: dict, path: Path) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(path)


def safe_model_name(model: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", model).strip("_")


def job_prefix(split_id: str, model: str) -> Path:
    return CHECKPOINTS / f"CF16_{split_id}_{safe_model_name(model)}"


def checkpoint_paths(split_id: str, model: str) -> Dict[str, Path]:
    prefix = job_prefix(split_id, model)
    return {
        "search": Path(str(prefix) + "_inner_search.tsv"),
        "best": Path(str(prefix) + "_best_params.tsv"),
        "pred": Path(str(prefix) + "_outer_predictions.tsv"),
        "metric": Path(str(prefix) + "_outer_metrics.tsv"),
        "features": Path(str(prefix) + "_selected_features.tsv"),
        "done": Path(str(prefix) + "_DONE.json"),
    }


def checkpoint_complete(split_id: str, model: str) -> bool:
    p = checkpoint_paths(split_id, model)
    required = ["search", "best", "pred", "metric", "features", "done"]
    return all(p[x].exists() for x in required)


def outer_split_sort_key(split_id: str) -> Tuple[int, int]:
    m = re.fullmatch(r"R(\d+)_F(\d+)", str(split_id))
    if not m:
        raise RuntimeError(f"Unexpected outer split ID: {split_id}")
    return int(m.group(1)), int(m.group(2))


# ============================================================
# MODEL / SEARCH HELPERS
# ============================================================

def make_elastic(params: dict) -> LogisticRegression:
    return LogisticRegression(
        penalty="elasticnet",
        solver="saga",
        C=float(params["C"]),
        l1_ratio=float(params["l1_ratio"]),
        class_weight="balanced",
        max_iter=5000,
        tol=1e-3,
        random_state=SEED,
    )


def make_svm(params: dict) -> LinearSVC:
    return LinearSVC(
        C=float(params["C"]),
        class_weight="balanced",
        dual="auto",
        max_iter=10000,
        tol=1e-4,
        random_state=SEED,
    )


def make_xgb(params: dict, y_train: np.ndarray):
    from xgboost import XGBClassifier

    pos = int((y_train == 1).sum())
    neg = int((y_train == 0).sum())
    if pos == 0 or neg == 0:
        raise RuntimeError("XGBoost training fold contains only one class.")

    return XGBClassifier(
        objective="binary:logistic",
        eval_metric="logloss",
        tree_method="hist",
        n_estimators=int(params["n_estimators"]),
        max_depth=int(params["max_depth"]),
        learning_rate=float(params["learning_rate"]),
        subsample=float(params["subsample"]),
        colsample_bytree=float(params["colsample_bytree"]),
        min_child_weight=float(params["min_child_weight"]),
        reg_alpha=float(params["reg_alpha"]),
        reg_lambda=float(params["reg_lambda"]),
        scale_pos_weight=float(neg / pos),
        n_jobs=XGB_THREADS,
        random_state=SEED,
        verbosity=0,
    )


def model_scores(model_name: str, model, X: np.ndarray) -> Tuple[np.ndarray, str]:
    if model_name in {"ElasticNet_Logistic", "XGBoost"}:
        return model.predict_proba(X)[:, 1].astype(float), "probability"
    if model_name == "Linear_SVM":
        return model.decision_function(X).astype(float), "decision_function"
    raise RuntimeError(f"Unknown model: {model_name}")


def fit_and_score(
    model_name: str,
    params: dict,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_valid: np.ndarray,
    y_valid: np.ndarray,
) -> Tuple[float, float, int]:
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")

        if model_name == "ElasticNet_Logistic":
            model = make_elastic(params)
        elif model_name == "Linear_SVM":
            model = make_svm(params)
        elif model_name == "XGBoost":
            model = make_xgb(params, y_train)
        else:
            raise RuntimeError(f"Unknown model: {model_name}")

        model.fit(X_train, y_train)
        scores, _ = model_scores(model_name, model, X_valid)

    auc = float(roc_auc_score(y_valid, scores))
    ap = float(average_precision_score(y_valid, scores))
    convergence_warnings = sum(
        issubclass(w.category, ConvergenceWarning) for w in caught
    )
    return auc, ap, convergence_warnings


def generate_xgb_candidates() -> List[dict]:
    """
    Deterministically generate 15 unique random candidates from the locked
    discrete search space. The same candidate set is used in each outer split.
    """
    rng = np.random.default_rng(SEED)
    seen = set()
    candidates = []

    while len(candidates) < XGB_RANDOM_CANDIDATES:
        tup = (
            int(rng.choice(K_VALUES)),
            int(rng.choice(XGB_N_ESTIMATORS)),
            int(rng.choice(XGB_MAX_DEPTH)),
            float(rng.choice(XGB_LEARNING_RATE)),
            float(rng.choice(XGB_SUBSAMPLE)),
            float(rng.choice(XGB_COLSAMPLE)),
            int(rng.choice(XGB_MIN_CHILD_WEIGHT)),
            float(rng.choice(XGB_REG_ALPHA)),
            float(rng.choice(XGB_REG_LAMBDA)),
        )
        if tup in seen:
            continue
        seen.add(tup)
        candidates.append(
            {
                "k": tup[0],
                "n_estimators": tup[1],
                "max_depth": tup[2],
                "learning_rate": tup[3],
                "subsample": tup[4],
                "colsample_bytree": tup[5],
                "min_child_weight": tup[6],
                "reg_alpha": tup[7],
                "reg_lambda": tup[8],
            }
        )
    return candidates


XGB_CANDIDATES = generate_xgb_candidates()


def prepare_inner_cache(
    X_outer: np.ndarray,
    y_outer: np.ndarray,
) -> List[dict]:
    """
    Prepare leakage-safe inner folds once and cache the 5 locked k values.

    Every scaler/selector is fitted only on that inner training fold.
    """
    cv = StratifiedKFold(
        n_splits=INNER_FOLDS,
        shuffle=True,
        random_state=SEED,
    )

    folds = []

    for fold_i, (tr_idx, va_idx) in enumerate(
        cv.split(np.zeros(len(y_outer)), y_outer),
        start=1,
    ):
        Xtr = X_outer[tr_idx]
        Xva = X_outer[va_idx]
        ytr = y_outer[tr_idx]
        yva = y_outer[va_idx]

        vt = VarianceThreshold(threshold=0.0)
        Xtr_v = vt.fit_transform(Xtr)
        Xva_v = vt.transform(Xva)

        scaler = StandardScaler()
        Xtr_s = scaler.fit_transform(Xtr_v)
        Xva_s = scaler.transform(Xva_v)

        k_cache = {}
        for k in K_VALUES:
            if k > Xtr_s.shape[1]:
                raise RuntimeError(
                    f"k={k} exceeds nonzero-variance features={Xtr_s.shape[1]}"
                )

            selector = SelectKBest(score_func=f_classif, k=k)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                Xtr_k = selector.fit_transform(Xtr_s, ytr)
            Xva_k = selector.transform(Xva_s)

            k_cache[k] = {
                "X_train": np.asarray(Xtr_k, dtype=np.float32),
                "X_valid": np.asarray(Xva_k, dtype=np.float32),
            }

        folds.append(
            {
                "fold": fold_i,
                "y_train": ytr,
                "y_valid": yva,
                "k_cache": k_cache,
            }
        )

    return folds


def candidate_rows_for_model(model_name: str) -> List[dict]:
    rows = []

    if model_name == "ElasticNet_Logistic":
        for k in K_VALUES:
            for C in ELASTIC_C_VALUES:
                for l1 in ELASTIC_L1_VALUES:
                    rows.append(
                        {"k": k, "C": C, "l1_ratio": l1}
                    )
        return rows

    if model_name == "Linear_SVM":
        for k in K_VALUES:
            for C in SVM_C_VALUES:
                rows.append({"k": k, "C": C})
        return rows

    if model_name == "XGBoost":
        return [dict(x) for x in XGB_CANDIDATES]

    raise RuntimeError(f"Unknown model: {model_name}")


def choose_best_candidate(
    results: pd.DataFrame,
    model_name: str,
) -> pd.Series:
    """
    Primary key = mean inner AUROC.
    Secondary key = mean inner AP.
    Remaining exact ties favor simpler configurations.
    """
    df = results.copy()

    if model_name == "ElasticNet_Logistic":
        # Simpler: fewer genes, stronger regularization (smaller C),
        # then more sparse penalty (larger l1_ratio).
        df = df.sort_values(
            ["mean_inner_auc", "mean_inner_ap", "k", "C", "l1_ratio"],
            ascending=[False, False, True, True, False],
            kind="mergesort",
        )
    elif model_name == "Linear_SVM":
        df = df.sort_values(
            ["mean_inner_auc", "mean_inner_ap", "k", "C"],
            ascending=[False, False, True, True],
            kind="mergesort",
        )
    elif model_name == "XGBoost":
        df = df.sort_values(
            [
                "mean_inner_auc",
                "mean_inner_ap",
                "k",
                "max_depth",
                "n_estimators",
            ],
            ascending=[False, False, True, True, True],
            kind="mergesort",
        )
    else:
        raise RuntimeError(model_name)

    return df.iloc[0]


def search_model(
    model_name: str,
    split_id: str,
    inner_cache: List[dict],
) -> Tuple[pd.DataFrame, dict]:
    candidates = candidate_rows_for_model(model_name)
    rows = []

    model_start = time.perf_counter()

    for cand_i, params in enumerate(candidates, start=1):
        fold_aucs = []
        fold_aps = []
        warning_count = 0
        k = int(params["k"])

        for fold in inner_cache:
            cached = fold["k_cache"][k]
            auc, ap, warns = fit_and_score(
                model_name,
                params,
                cached["X_train"],
                fold["y_train"],
                cached["X_valid"],
                fold["y_valid"],
            )
            fold_aucs.append(auc)
            fold_aps.append(ap)
            warning_count += warns

        row = {
            "split_id": split_id,
            "model": model_name,
            "candidate_index": cand_i,
            **params,
            "mean_inner_auc": float(np.mean(fold_aucs)),
            "sd_inner_auc": float(np.std(fold_aucs, ddof=1)),
            "mean_inner_ap": float(np.mean(fold_aps)),
            "sd_inner_ap": float(np.std(fold_aps, ddof=1)),
            "convergence_warning_count": int(warning_count),
        }

        for i, v in enumerate(fold_aucs, start=1):
            row[f"fold{i}_auc"] = v
        for i, v in enumerate(fold_aps, start=1):
            row[f"fold{i}_ap"] = v

        rows.append(row)

        # Frequent progress without excessive terminal output.
        if model_name == "ElasticNet_Logistic":
            # 20 candidates per k block.
            if cand_i % 20 == 0:
                elapsed = time.perf_counter() - model_start
                logging.info(
                    f"      Elastic-Net {cand_i:3d}/100 candidates "
                    f"({elapsed/60:.1f} min)"
                )
        elif model_name == "Linear_SVM":
            if cand_i % 5 == 0:
                logging.info(
                    f"      Linear SVM {cand_i:2d}/20 candidates"
                )
        elif model_name == "XGBoost":
            if cand_i % 5 == 0:
                elapsed = time.perf_counter() - model_start
                logging.info(
                    f"      XGBoost {cand_i:2d}/15 candidates "
                    f"({elapsed/60:.1f} min)"
                )

    results = pd.DataFrame(rows)
    best = choose_best_candidate(results, model_name)

    best_params = {}
    if model_name == "ElasticNet_Logistic":
        best_params = {
            "k": int(best["k"]),
            "C": float(best["C"]),
            "l1_ratio": float(best["l1_ratio"]),
        }
    elif model_name == "Linear_SVM":
        best_params = {
            "k": int(best["k"]),
            "C": float(best["C"]),
        }
    elif model_name == "XGBoost":
        for field in [
            "k", "n_estimators", "max_depth", "learning_rate",
            "subsample", "colsample_bytree", "min_child_weight",
            "reg_alpha", "reg_lambda",
        ]:
            val = best[field]
            if field in {"k", "n_estimators", "max_depth", "min_child_weight"}:
                best_params[field] = int(val)
            else:
                best_params[field] = float(val)

    best_params["mean_inner_auc"] = float(best["mean_inner_auc"])
    best_params["mean_inner_ap"] = float(best["mean_inner_ap"])
    best_params["convergence_warning_count"] = int(
        best["convergence_warning_count"]
    )

    return results, best_params


def refit_outer_and_predict(
    model_name: str,
    best_params: dict,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    gene_symbols: np.ndarray,
) -> Tuple[np.ndarray, str, float, float, pd.DataFrame, int]:
    """
    Refit all preprocessing and the selected estimator using ONLY outer training
    data, then evaluate the untouched outer test fold.
    """
    vt = VarianceThreshold(threshold=0.0)
    Xtr_v = vt.fit_transform(X_train)
    Xte_v = vt.transform(X_test)

    scaler = StandardScaler()
    Xtr_s = scaler.fit_transform(Xtr_v)
    Xte_s = scaler.transform(Xte_v)

    k = int(best_params["k"])
    selector = SelectKBest(score_func=f_classif, k=k)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        Xtr_k = selector.fit_transform(Xtr_s, y_train)
    Xte_k = selector.transform(Xte_s)

    if model_name == "ElasticNet_Logistic":
        model = make_elastic(best_params)
    elif model_name == "Linear_SVM":
        model = make_svm(best_params)
    elif model_name == "XGBoost":
        model = make_xgb(best_params, y_train)
    else:
        raise RuntimeError(model_name)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        model.fit(Xtr_k, y_train)

    scores, score_type = model_scores(model_name, model, Xte_k)

    auc = float(roc_auc_score(y_test, scores))
    ap = float(average_precision_score(y_test, scores))
    convergence_warnings = sum(
        issubclass(w.category, ConvergenceWarning) for w in caught
    )

    # Map selected features back to the original locked gene universe.
    vt_indices = np.flatnonzero(vt.get_support())
    selector_indices = np.flatnonzero(selector.get_support())
    original_indices = vt_indices[selector_indices]
    selected_genes = gene_symbols[original_indices]

    selector_scores = selector.scores_[selector_indices]

    if model_name in {"ElasticNet_Logistic", "Linear_SVM"}:
        weights = np.ravel(model.coef_).astype(float)
        importance_type = "coefficient"
    else:
        weights = np.ravel(model.feature_importances_).astype(float)
        importance_type = "xgboost_feature_importance"

    feature_df = pd.DataFrame(
        {
            "gene_symbol": selected_genes.astype(str),
            "selector_f_score": selector_scores.astype(float),
            "model_weight_or_importance": weights,
            "importance_type": importance_type,
        }
    )
    feature_df["absolute_weight_or_importance"] = np.abs(
        feature_df["model_weight_or_importance"].astype(float)
    )
    feature_df = feature_df.sort_values(
        "absolute_weight_or_importance",
        ascending=False,
        kind="mergesort",
    ).reset_index(drop=True)
    feature_df["within_model_rank"] = np.arange(1, len(feature_df) + 1)

    return (
        scores,
        score_type,
        auc,
        ap,
        feature_df,
        convergence_warnings,
    )


# ============================================================
# CHECKPOINT AGGREGATION
# ============================================================

def write_job_checkpoint(
    split_id: str,
    model_name: str,
    search_df: pd.DataFrame,
    best_df: pd.DataFrame,
    pred_df: pd.DataFrame,
    metric_df: pd.DataFrame,
    features_df: pd.DataFrame,
    elapsed_seconds: float,
) -> None:
    p = checkpoint_paths(split_id, model_name)

    search_df.to_csv(p["search"], sep="\t", index=False)
    best_df.to_csv(p["best"], sep="\t", index=False)
    pred_df.to_csv(p["pred"], sep="\t", index=False)
    metric_df.to_csv(p["metric"], sep="\t", index=False)
    features_df.to_csv(p["features"], sep="\t", index=False)

    done = {
        "split_id": split_id,
        "model": model_name,
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": round(elapsed_seconds, 3),
        "search_sha256": sha256_file(p["search"]),
        "best_sha256": sha256_file(p["best"]),
        "pred_sha256": sha256_file(p["pred"]),
        "metric_sha256": sha256_file(p["metric"]),
        "features_sha256": sha256_file(p["features"]),
    }
    atomic_write_json(done, p["done"])


def aggregate_checkpoints(split_ids: List[str], model_names: List[str]) -> None:
    frames = {
        "search": [],
        "best": [],
        "pred": [],
        "metric": [],
        "features": [],
    }

    for split_id in split_ids:
        for model in model_names:
            if not checkpoint_complete(split_id, model):
                raise RuntimeError(
                    f"Cannot aggregate: incomplete checkpoint {split_id}/{model}"
                )
            p = checkpoint_paths(split_id, model)
            for key in frames:
                frames[key].append(pd.read_csv(p[key], sep="\t"))

    pd.concat(frames["search"], ignore_index=True).to_csv(
        INNER_SEARCH_OUT, sep="\t", index=False
    )
    pd.concat(frames["best"], ignore_index=True).to_csv(
        BEST_PARAMS_OUT, sep="\t", index=False
    )
    pd.concat(frames["pred"], ignore_index=True).to_csv(
        OUTER_PRED_OUT, sep="\t", index=False
    )
    pd.concat(frames["metric"], ignore_index=True).to_csv(
        OUTER_METRICS_OUT, sep="\t", index=False
    )
    pd.concat(frames["features"], ignore_index=True).to_csv(
        FEATURES_OUT, sep="\t", index=False
    )


def write_job_status(split_ids: List[str], model_names: List[str]) -> pd.DataFrame:
    rows = []
    for split_id in split_ids:
        for model in model_names:
            p = checkpoint_paths(split_id, model)
            done = checkpoint_complete(split_id, model)
            elapsed = np.nan
            completed_utc = ""
            if done:
                meta = json.loads(p["done"].read_text(encoding="utf-8"))
                elapsed = meta.get("elapsed_seconds", np.nan)
                completed_utc = meta.get("completed_utc", "")
            rows.append(
                {
                    "split_id": split_id,
                    "model": model,
                    "complete": done,
                    "elapsed_seconds": elapsed,
                    "completed_utc": completed_utc,
                }
            )
    df = pd.DataFrame(rows)
    df.to_csv(JOB_STATUS_OUT, sep="\t", index=False)
    return df


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    setup_logging()
    global_start = time.perf_counter()

    logging.info("")
    logging.info("============================================================")
    logging.info(" CF16 - NESTED-CV FEATURE SELECTION + MODEL TRAINING")
    logging.info("============================================================")
    logging.info("")
    logging.info("Machine-specific planning range from preflight: ~0.74-2.82 hours")
    logging.info("Optimized implementation caches fold preprocessing, so ~0.8-2.5 h is expected.")
    logging.info("Allow up to ~3 h on Windows if Elastic-Net convergence is slower at k=500.")
    logging.info("Likely bottleneck: Elastic-Net inner search.")
    logging.info("Progress is printed after every Elastic-Net k block and every model job.")
    logging.info("Checkpoint/resume: ENABLED.")
    logging.info("SCAN-B accessed: NO.")
    logging.info("APOLLO accessed: NO.")
    logging.info("")

    required = [CF15_SUMMARY, OUTER_ASSIGNMENTS, MATRIX_NPZ]
    for p in required:
        if not p.exists():
            raise FileNotFoundError(f"Required CF16 input missing: {p}")

    cf15 = metric_dict(CF15_SUMMARY)
    if cf15.get("CF15 stage gate") != "PASS_READY_FOR_CF16":
        raise RuntimeError(
            f"CF15 is not ready: {cf15.get('CF15 stage gate')}"
        )

    if package_version("xgboost") == "MISSING":
        raise RuntimeError("xgboost is missing.")

    # Trusted locally generated CF15 artifact. IDs were stored as object strings.
    z = np.load(MATRIX_NPZ, allow_pickle=True)
    X = np.asarray(z["X"], dtype=np.float32)
    y = np.asarray(z["y"], dtype=np.int8)
    patient_ids = z["patient_ids"].astype(str)
    sample_ids = z["sample_ids"].astype(str)
    gene_symbols = z["gene_symbols"].astype(str)

    if X.shape != (EXPECTED_N, EXPECTED_P):
        raise RuntimeError(f"Unexpected CF15 matrix shape: {X.shape}")
    if len(np.unique(patient_ids)) != EXPECTED_N:
        raise RuntimeError("Duplicate patient IDs in CF15 matrix.")
    if int((y == 1).sum()) != EXPECTED_POS or int((y == 0).sum()) != EXPECTED_NEG:
        raise RuntimeError("CF15 HER2 class counts changed.")
    if len(gene_symbols) != EXPECTED_P:
        raise RuntimeError("CF15 gene-symbol vector has wrong length.")

    assignments = pd.read_csv(OUTER_ASSIGNMENTS, sep="\t")
    required_assignment_cols = {
        "split_id", "repeat", "fold", "row_index",
        "patient_id", "expression_sample_id", "y_HER2",
    }
    missing = required_assignment_cols - set(assignments.columns)
    if missing:
        raise RuntimeError(
            f"Outer split registry missing columns: {sorted(missing)}"
        )

    split_ids = sorted(
        assignments["split_id"].astype(str).unique().tolist(),
        key=outer_split_sort_key,
    )
    if len(split_ids) != EXPECTED_OUTER_SPLITS:
        raise RuntimeError(
            f"Outer split registry has {len(split_ids)} splits; expected 15."
        )

    model_names = [
        "ElasticNet_Logistic",
        "Linear_SVM",
        "XGBoost",
    ]

    status = write_job_status(split_ids, model_names)
    already_done = int(status["complete"].sum())

    logging.info(
        f"Existing completed checkpoints: {already_done}/{EXPECTED_JOBS}"
    )
    if already_done > 0:
        logging.info("Completed jobs will be skipped.")
    logging.info("")

    all_indices = np.arange(EXPECTED_N)
    completed_job_times = (
        status.loc[status["complete"], "elapsed_seconds"]
        .dropna()
        .astype(float)
        .tolist()
    )

    job_counter = 0

    for outer_i, split_id in enumerate(split_ids, start=1):
        split_rows = assignments.loc[
            assignments["split_id"].astype(str) == split_id
        ].copy()

        test_idx = np.sort(split_rows["row_index"].astype(int).to_numpy())
        train_idx = np.setdiff1d(all_indices, test_idx, assume_unique=True)

        # Registry identity validation.
        if not np.array_equal(
            patient_ids[test_idx],
            split_rows.sort_values("row_index")["patient_id"].astype(str).to_numpy(),
        ):
            raise RuntimeError(
                f"Patient identity mismatch in frozen split {split_id}."
            )
        if not np.array_equal(
            y[test_idx],
            split_rows.sort_values("row_index")["y_HER2"].astype(int).to_numpy(),
        ):
            raise RuntimeError(
                f"HER2 label mismatch in frozen split {split_id}."
            )

        X_outer_train = X[train_idx]
        y_outer_train = y[train_idx]
        X_outer_test = X[test_idx]
        y_outer_test = y[test_idx]

        logging.info("------------------------------------------------------------")
        logging.info(
            f"[Outer {outer_i:02d}/15] {split_id} | "
            f"train={len(train_idx)} test={len(test_idx)} | "
            f"test HER2+={int(y_outer_test.sum())}"
        )

        pending_models = [
            m for m in model_names if not checkpoint_complete(split_id, m)
        ]

        if not pending_models:
            logging.info("All 3 model jobs already complete; skipping outer split.")
            logging.info("")
            continue

        prep_start = time.perf_counter()
        logging.info("  Preparing 4 leakage-safe inner folds and cached k representations...")
        inner_cache = prepare_inner_cache(X_outer_train, y_outer_train)
        prep_sec = time.perf_counter() - prep_start
        logging.info(f"  Inner preprocessing cache ready in {prep_sec/60:.2f} min.")
        logging.info("")

        for model_name in model_names:
            job_counter += 1

            if checkpoint_complete(split_id, model_name):
                logging.info(
                    f"  [Job {job_counter:02d}/45] {model_name}: CHECKPOINT EXISTS -> SKIP"
                )
                continue

            logging.info(
                f"  [Job {job_counter:02d}/45] {model_name}: START"
            )

            job_start = time.perf_counter()

            search_df, best_params = search_model(
                model_name,
                split_id,
                inner_cache,
            )

            (
                scores,
                score_type,
                outer_auc,
                outer_ap,
                feature_df,
                outer_warns,
            ) = refit_outer_and_predict(
                model_name,
                best_params,
                X_outer_train,
                y_outer_train,
                X_outer_test,
                y_outer_test,
                gene_symbols,
            )

            elapsed = time.perf_counter() - job_start

            best_row = {
                "split_id": split_id,
                "model": model_name,
                **best_params,
                "outer_refit_convergence_warning_count": outer_warns,
                "job_elapsed_seconds": elapsed,
            }
            best_df = pd.DataFrame([best_row])

            pred_df = pd.DataFrame(
                {
                    "split_id": split_id,
                    "repeat": int(split_rows["repeat"].iloc[0]),
                    "fold": int(split_rows["fold"].iloc[0]),
                    "model": model_name,
                    "row_index": test_idx,
                    "patient_id": patient_ids[test_idx],
                    "expression_sample_id": sample_ids[test_idx],
                    "y_true": y_outer_test,
                    "score": scores,
                    "score_type": score_type,
                }
            )

            metric_df = pd.DataFrame(
                [
                    {
                        "split_id": split_id,
                        "repeat": int(split_rows["repeat"].iloc[0]),
                        "fold": int(split_rows["fold"].iloc[0]),
                        "model": model_name,
                        "test_n": len(test_idx),
                        "test_positive": int(y_outer_test.sum()),
                        "test_negative": int((y_outer_test == 0).sum()),
                        "outer_AUROC": outer_auc,
                        "outer_average_precision": outer_ap,
                        "selected_k": int(best_params["k"]),
                        "best_mean_inner_AUROC": float(
                            best_params["mean_inner_auc"]
                        ),
                        "best_mean_inner_average_precision": float(
                            best_params["mean_inner_ap"]
                        ),
                        "outer_refit_convergence_warning_count": int(
                            outer_warns
                        ),
                    }
                ]
            )

            feature_df.insert(0, "model", model_name)
            feature_df.insert(0, "split_id", split_id)

            write_job_checkpoint(
                split_id,
                model_name,
                search_df,
                best_df,
                pred_df,
                metric_df,
                feature_df,
                elapsed,
            )

            completed_job_times.append(elapsed)
            status = write_job_status(split_ids, model_names)
            n_done = int(status["complete"].sum())
            n_left = EXPECTED_JOBS - n_done

            # Conservative ETA based on observed average completed job time.
            avg_job = float(np.mean(completed_job_times))
            eta_hours = (avg_job * n_left) / 3600.0

            logging.info(
                f"      BEST inner AUROC={best_params['mean_inner_auc']:.4f}, "
                f"inner AP={best_params['mean_inner_ap']:.4f}, "
                f"k={int(best_params['k'])}"
            )
            logging.info(
                f"      OUTER AUROC={outer_auc:.4f}, "
                f"outer AP={outer_ap:.4f}"
            )
            logging.info(
                f"      Job time={elapsed/60:.1f} min | "
                f"completed={n_done}/45 | rough ETA={eta_hours:.2f} h"
            )
            logging.info("")

        # Explicitly release the per-outer-fold cache before next split.
        del inner_cache

    # --------------------------------------------------------
    # Final aggregation and validation
    # --------------------------------------------------------
    status = write_job_status(split_ids, model_names)
    n_complete = int(status["complete"].sum())

    if n_complete != EXPECTED_JOBS:
        logging.info("============================================================")
        logging.info(" CF16 INCOMPLETE - CHECKPOINTS PRESERVED")
        logging.info("============================================================")
        logging.info(f"Completed jobs: {n_complete}/{EXPECTED_JOBS}")
        logging.info("Re-run the same command to resume.")
        return

    aggregate_checkpoints(split_ids, model_names)

    search_all = pd.read_csv(INNER_SEARCH_OUT, sep="\t")
    best_all = pd.read_csv(BEST_PARAMS_OUT, sep="\t")
    pred_all = pd.read_csv(OUTER_PRED_OUT, sep="\t")
    metric_all = pd.read_csv(OUTER_METRICS_OUT, sep="\t")
    features_all = pd.read_csv(FEATURES_OUT, sep="\t")

    # Expected aggregate sizes.
    expected_search_rows = EXPECTED_OUTER_SPLITS * (
        len(K_VALUES) * len(ELASTIC_C_VALUES) * len(ELASTIC_L1_VALUES)
        + len(K_VALUES) * len(SVM_C_VALUES)
        + XGB_RANDOM_CANDIDATES
    )
    if len(search_all) != expected_search_rows:
        raise RuntimeError(
            f"Inner search rows={len(search_all)}; expected {expected_search_rows}."
        )

    if len(best_all) != EXPECTED_JOBS:
        raise RuntimeError(
            f"Best-parameter rows={len(best_all)}; expected 45."
        )
    if len(metric_all) != EXPECTED_JOBS:
        raise RuntimeError(
            f"Outer metric rows={len(metric_all)}; expected 45."
        )

    expected_prediction_rows = EXPECTED_N * 3 * EXPECTED_MODELS
    if len(pred_all) != expected_prediction_rows:
        raise RuntimeError(
            f"Outer prediction rows={len(pred_all)}; "
            f"expected {expected_prediction_rows}."
        )

    # Each patient must have exactly one outer-test prediction per repeat/model.
    pred_counts = pred_all.groupby(
        ["model", "repeat", "patient_id"]
    ).size()
    if not (pred_counts == 1).all():
        raise RuntimeError(
            "Outer prediction registry is not exactly one test prediction "
            "per patient/repeat/model."
        )

    total_warnings = int(
        pd.to_numeric(
            best_all["outer_refit_convergence_warning_count"],
            errors="coerce",
        ).fillna(0).sum()
    )

    runtime_min = (time.perf_counter() - global_start) / 60.0

    summary = pd.DataFrame(
        [
            ("Primary endpoint", "HER2"),
            ("TCGA model-development samples", EXPECTED_N),
            ("HER2 positive", EXPECTED_POS),
            ("HER2 negative", EXPECTED_NEG),
            ("Feature universe", EXPECTED_P),
            ("Outer evaluations", EXPECTED_OUTER_SPLITS),
            ("Models", EXPECTED_MODELS),
            ("Completed outer/model jobs", n_complete),
            ("Inner search candidate rows", len(search_all)),
            ("Outer prediction rows", len(pred_all)),
            ("Selected-feature rows", len(features_all)),
            ("Outer refit convergence warnings", total_warnings),
            ("SCAN-B accessed", "NO"),
            ("APOLLO accessed", "NO"),
            ("Final model family selected", "NO"),
            ("Final threshold selected", "NO"),
            ("CF16 runtime minutes this invocation", round(runtime_min, 2)),
            ("CF16 stage gate", "PASS_READY_FOR_CF17"),
        ],
        columns=["metric", "value"],
    )
    summary.to_csv(SUMMARY_OUT, sep="\t", index=False)

    provenance = pd.DataFrame(
        [
            ("code_file", "CF16_nested_cv_training.py"),
            ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
            ("CF15_summary_sha256", sha256_file(CF15_SUMMARY)),
            ("CF15_matrix_sha256", sha256_file(MATRIX_NPZ)),
            ("outer_assignment_sha256", sha256_file(OUTER_ASSIGNMENTS)),
            ("inner_search_sha256", sha256_file(INNER_SEARCH_OUT)),
            ("outer_predictions_sha256", sha256_file(OUTER_PRED_OUT)),
            ("outer_metrics_sha256", sha256_file(OUTER_METRICS_OUT)),
            ("best_params_sha256", sha256_file(BEST_PARAMS_OUT)),
            ("selected_features_sha256", sha256_file(FEATURES_OUT)),
            (
                "inner_preprocessing_rule",
                "VarianceThreshold -> StandardScaler -> SelectKBest fitted "
                "separately inside each inner training fold",
            ),
            (
                "outer_refit_rule",
                "All preprocessing refit using outer training data only before "
                "untouched outer-test prediction",
            ),
            (
                "xgboost_weight_rule",
                "scale_pos_weight recomputed from the labels of each actual "
                "training fold; no validation labels used",
            ),
            (
                "model_selection_rule",
                "Mean inner AUROC primary, mean inner average precision secondary, "
                "deterministic simplicity tie-break",
            ),
            (
                "external_data_rule",
                "SCAN-B and APOLLO not accessed in CF16",
            ),
            ("python_version", platform.python_version()),
            ("numpy_version", package_version("numpy")),
            ("pandas_version", package_version("pandas")),
            ("scipy_version", package_version("scipy")),
            ("scikit_learn_version", package_version("scikit-learn")),
            ("xgboost_version", package_version("xgboost")),
            ("cpu_logical_count", CPU_COUNT),
            ("xgboost_threads", XGB_THREADS),
            ("CF16_stage_gate", "PASS_READY_FOR_CF17"),
        ],
        columns=["field", "value"],
    )
    provenance.to_csv(PROVENANCE_OUT, sep="\t", index=False)

    logging.info("============================================================")
    logging.info(" CF16 COMPLETE - NESTED-CV TRAINING GATE PASSED")
    logging.info("============================================================")
    logging.info("")
    logging.info(f"Completed jobs: {n_complete}/45")
    logging.info(f"Inner candidate summaries: {len(search_all)}")
    logging.info(f"Outer prediction rows: {len(pred_all)}")
    logging.info(f"Selected-feature rows: {len(features_all)}")
    logging.info(f"Outer refit convergence warnings: {total_warnings}")
    logging.info(f"Runtime this invocation: {runtime_min/60:.2f} h")
    logging.info("")
    logging.info("SCAN-B accessed: NO")
    logging.info("APOLLO accessed: NO")
    logging.info("Final model family selected: NO")
    logging.info("Final threshold selected: NO")
    logging.info("STATUS: PASS_READY_FOR_CF17")
    logging.info("")
    logging.info("Send the final terminal output before CF17 evaluation.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logging.info("")
        logging.info("CF16 interrupted by user. Completed checkpoints are preserved.")
        logging.info("Re-run the same command to resume.")
        sys.exit(130)
    except Exception as exc:
        logging.exception(f"\nCF16 ERROR: {exc}")
        logging.info("")
        logging.info("Completed checkpoints are preserved. Fix the error and re-run to resume.")
        sys.exit(1)
