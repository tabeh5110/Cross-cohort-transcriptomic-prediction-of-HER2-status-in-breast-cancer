#!/usr/bin/env python
"""
CF6 - TCGA-BRCA Expression Matrix Construction + Technical Replicate Resolution

Purpose
-------
Convert the CF5-validated GDC augmented STAR-count files into reusable
expression matrices while resolving multiple RNA aliquots associated with the
same TCGA biological sample using biospecimen provenance plus expression-level
QC evidence.

Formal outputs are intentionally limited to reusable matrices, gene/sample
provenance, replicate-resolution evidence, checksums, summary, provenance, and
one log. No DESeq2, clinical analysis, PCA exclusion, feature selection, or ML
is performed here.
"""

from __future__ import annotations

import gzip
import hashlib
import itertools
import logging
import os
import platform
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

# ============================================================
# CONFIGURATION
# ============================================================
PROJECT_ROOT = Path.cwd()

CF3_DIR = PROJECT_ROOT / "results" / "CF3_tcga_cohort_resolution"
CF3_MANIFEST = CF3_DIR / "CF3_final_candidate_manifest.tsv"

CF5_DIR = PROJECT_ROOT / "results" / "CF5_post_download_integrity_check"
CF5_FILE_RESULTS = CF5_DIR / "CF5_file_integrity_results.tsv"
CF5_SUMMARY = CF5_DIR / "CF5_summary.tsv"
CF5_PROVENANCE = CF5_DIR / "CF5_provenance.tsv"

OUTPUT_DIR = PROJECT_ROOT / "results" / "CF6_expression_matrix_construction"
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed" / "tcga_brca" / "expression"
INTERIM_DIR = PROJECT_ROOT / "data" / "interim" / "tcga_brca" / "CF6_work"
LOG_DIR = PROJECT_ROOT / "logs"
LOG_FILE = LOG_DIR / "CF6_expression_matrix_construction.log"

# Replicate aliquot selection is provenance-based, not correlation-threshold-based.
# Expression correlations are retained as descriptive QC evidence. For multiple
# aliquots from the same TCGA RNA analyte, the later plate is selected, matching
# the historical Broad TCGA GDAC Firehose replicate-filter precedent.
TCGA_BARCODE_SOURCE = "https://docs.gdc.cancer.gov/Encyclopedia/pages/TCGA_Barcode/"
GDAC_REPLICATE_RULE_SOURCE = "https://gdac.broadinstitute.org/runs/stddata__2014_01_15/samples_report/READ_Replicate_Samples.html"

WRITE_GENE_CHUNK = 1000
GZIP_LEVEL = 5

REQUIRED_STAR_COLUMNS = {
    "gene_id", "gene_name", "gene_type", "unstranded", "tpm_unstranded"
}

# ============================================================
# UTILITIES
# ============================================================

def setup_logging() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    INTERIM_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )


def hash_file(path: Path, algorithm: str = "sha256", chunk_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


def load_metric_table(path: Path) -> Dict[str, str]:
    if not path.exists():
        return {}
    df = pd.read_csv(path, sep="\t", dtype=str)
    if {"metric", "value"}.issubset(df.columns):
        return dict(zip(df["metric"].astype(str), df["value"].astype(str)))
    if {"field", "value"}.issubset(df.columns):
        return dict(zip(df["field"].astype(str), df["value"].astype(str)))
    return {}


def as_bool(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    return (
        series.astype(str).str.strip().str.lower()
        .map({"true": True, "false": False, "1": True, "0": False})
        .fillna(False).astype(bool)
    )


def safe_corr(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    if x.size < 2 or y.size < 2:
        return float("nan")
    if np.all(x == x[0]) or np.all(y == y[0]):
        return 1.0 if np.array_equal(x, y) else float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def spearman_corr(x: np.ndarray, y: np.ndarray) -> float:
    rx = pd.Series(np.asarray(x, dtype=np.float64)).rank(method="average").to_numpy()
    ry = pd.Series(np.asarray(y, dtype=np.float64)).rank(method="average").to_numpy()
    return safe_corr(rx, ry)


def find_header_line(path: Path) -> int:
    with path.open("r", encoding="utf-8-sig", errors="strict") as handle:
        for idx, line in enumerate(handle):
            if line.rstrip("\r\n").split("\t", 1)[0].strip() == "gene_id":
                return idx
            if idx >= 250:
                break
    raise RuntimeError(f"gene_id header not found in first 250 lines: {path}")

# ============================================================
# STAR FILE READER
# ============================================================

def read_star_expression(path: Path) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    header_line = find_header_line(path)
    df = pd.read_csv(
        path,
        sep="\t",
        skiprows=header_line,
        usecols=lambda c: c in REQUIRED_STAR_COLUMNS,
        dtype=str,
        low_memory=False,
    )
    missing = REQUIRED_STAR_COLUMNS.difference(df.columns)
    if missing:
        raise RuntimeError(f"Missing required STAR columns in {path.name}: {sorted(missing)}")

    # STAR N_* rows are alignment counters, not genes.
    genes = df[df["gene_id"].astype(str).str.startswith("ENSG")].copy()
    if genes.empty:
        raise RuntimeError(f"No ENSG gene rows found in {path}")
    if genes["gene_id"].duplicated().any():
        dup = genes.loc[genes["gene_id"].duplicated(), "gene_id"].head(5).tolist()
        raise RuntimeError(f"Duplicate gene_id values in {path.name}: {dup}")

    counts_num = pd.to_numeric(genes["unstranded"], errors="coerce")
    tpm_num = pd.to_numeric(genes["tpm_unstranded"], errors="coerce")
    if counts_num.isna().any():
        raise RuntimeError(f"Non-numeric/missing unstranded count found in {path.name}")
    if tpm_num.isna().any():
        raise RuntimeError(f"Non-numeric/missing TPM found in {path.name}")

    counts_float = counts_num.to_numpy(dtype=np.float64)
    tpm = tpm_num.to_numpy(dtype=np.float64)
    if not np.isfinite(counts_float).all() or not np.isfinite(tpm).all():
        raise RuntimeError(f"Non-finite expression value found in {path.name}")
    if (counts_float < 0).any() or (tpm < 0).any():
        raise RuntimeError(f"Negative expression value found in {path.name}")
    if not np.all(counts_float == np.floor(counts_float)):
        raise RuntimeError(f"Non-integer raw counts found in {path.name}")

    counts = counts_float.astype(np.int64)
    annotation = genes[["gene_id", "gene_name", "gene_type"]].fillna("").copy()
    annotation["ensembl_gene_id"] = annotation["gene_id"].astype(str).str.replace(r"\.\d+$", "", regex=True)
    return annotation.reset_index(drop=True), counts, tpm


def validate_annotation_match(reference: pd.DataFrame, current: pd.DataFrame, path: Path) -> None:
    if len(reference) != len(current):
        raise RuntimeError(
            f"Gene-row count differs in {path.name}: {len(current)} vs reference {len(reference)}"
        )
    for col in ["gene_id", "gene_name", "gene_type"]:
        a = reference[col].astype(str).to_numpy()
        b = current[col].astype(str).to_numpy()
        if not np.array_equal(a, b):
            mismatch = np.flatnonzero(a != b)
            first = int(mismatch[0]) if mismatch.size else -1
            raise RuntimeError(
                f"Gene annotation/order mismatch in {path.name}; column={col}, row={first}"
            )

# ============================================================
# TECHNICAL REPLICATE QC
# ============================================================

def file_quality_metrics(counts: np.ndarray, tpm: np.ndarray) -> Dict[str, object]:
    return {
        "gene_assigned_counts": int(counts.sum(dtype=np.int64)),
        "detected_genes_count_gt0": int(np.count_nonzero(counts > 0)),
        "genes_tpm_ge_1": int(np.count_nonzero(tpm >= 1.0)),
        "median_tpm_detected": float(np.median(tpm[tpm > 0])) if np.any(tpm > 0) else 0.0,
    }


def duplicate_pair_metrics(sample_id, file_a, file_b, counts_a, counts_b, tpm_a, tpm_b):
    informative_counts = (counts_a > 0) | (counts_b > 0)
    informative_tpm = (tpm_a > 0) | (tpm_b > 0)
    lc_a = np.log1p(counts_a[informative_counts].astype(np.float64))
    lc_b = np.log1p(counts_b[informative_counts].astype(np.float64))
    lt_a = np.log1p(tpm_a[informative_tpm])
    lt_b = np.log1p(tpm_b[informative_tpm])
    pearson = safe_corr(lc_a, lc_b)
    spearman = spearman_corr(lc_a, lc_b)
    tpm_pearson = safe_corr(lt_a, lt_b)
    return {
        "sample_id": sample_id,
        "file_id_a": file_a,
        "file_id_b": file_b,
        "informative_genes_counts": int(informative_counts.sum()),
        "informative_genes_tpm": int(informative_tpm.sum()),
        "pearson_log1p_counts": pearson,
        "spearman_log1p_counts": spearman,
        "pearson_log1p_tpm": tpm_pearson,
        "exact_count_vector": bool(np.array_equal(counts_a, counts_b)),
        "exact_tpm_vector": bool(np.array_equal(tpm_a, tpm_b)),
        "correlation_qc_status": "DESCRIPTIVE_ONLY_NOT_SELECTION_GATE",
    }


def analyte_barcode_from_aliquot(aliquot_barcode: str) -> str:
    """Return TCGA analyte-level barcode from a full aliquot barcode."""
    parts = str(aliquot_barcode).split("-")
    if len(parts) != 7:
        raise RuntimeError(f"Unexpected TCGA aliquot barcode format: {aliquot_barcode}")
    return "-".join(parts[:5])


def select_representative(group, quality_by_file):
    """
    Resolve multiple current GDC RNA expression files for the same biological
    TCGA sample when they represent different aliquots of the SAME RNA analyte.

    Scientific rule
    ---------------
    TCGA barcodes encode sample -> vial -> portion -> analyte -> plate -> center.
    When sample, portion, RNA analyte, analyte-level barcode, and center are the
    same and only plate differs, select the later (highest lexicographic) plate.
    This follows the historical Broad TCGA GDAC Firehose replicate-filter rule
    for multiple aliquots associated with the same RNA analyte.

    Correlation, library depth, and detected-gene metrics remain descriptive QC
    and are not allowed to override biospecimen provenance.
    """
    g = group.copy()
    g["aliquot_barcode"] = g["aliquot_barcode"].astype(str)
    g["portion"] = g["portion"].astype(str)
    g["analyte"] = g["analyte"].astype(str)
    g["plate"] = g["plate"].astype(str)
    g["center"] = g["center"].astype(str)
    g["analyte_barcode"] = g["aliquot_barcode"].map(analyte_barcode_from_aliquot)

    # This automatic rule is valid only for multiple aliquots from one RNA
    # analyte. Anything structurally different must stop for manual review.
    checks = {
        "portion": g["portion"].nunique(dropna=False) == 1,
        "analyte": g["analyte"].nunique(dropna=False) == 1,
        "analyte_barcode": g["analyte_barcode"].nunique(dropna=False) == 1,
        "center": g["center"].nunique(dropna=False) == 1,
    }
    if not all(checks.values()):
        failed = [k for k, ok in checks.items() if not ok]
        raise RuntimeError(
            f"Replicate aliquots for sample {g['sample_id'].iloc[0]} differ at "
            f"biospecimen levels that are not covered by the later-plate rule: {failed}. "
            "Manual review required."
        )

    if not (g["analyte"].str.upper() == "R").all():
        raise RuntimeError(
            f"Replicate aliquots for sample {g['sample_id'].iloc[0]} are not all RNA (R) analytes."
        )

    if g["plate"].duplicated().any():
        raise RuntimeError(
            f"Replicate aliquots for sample {g['sample_id'].iloc[0]} contain duplicate plate values; "
            "later-plate selection is not uniquely resolvable."
        )

    later_plate = max(g["plate"].tolist())
    selected_rows = g[g["plate"] == later_plate]
    if len(selected_rows) != 1:
        raise RuntimeError(
            f"Later plate selection is ambiguous for sample {g['sample_id'].iloc[0]}."
        )

    selected = str(selected_rows.iloc[0]["file_id"])
    return selected, "same_RNA_analyte_later_TCGA_plate"

# ============================================================
# MATRIX WRITER
# ============================================================

def write_matrix_gzip(path: Path, matrix: np.memmap, gene_ids: np.ndarray, sample_ids: List[str], is_float: bool) -> None:
    tmp = path.with_name(path.name + ".tmp")
    if tmp.exists():
        tmp.unlink()
    with gzip.open(tmp, "wt", encoding="utf-8", newline="", compresslevel=GZIP_LEVEL) as handle:
        n_genes = matrix.shape[0]
        for start in range(0, n_genes, WRITE_GENE_CHUNK):
            end = min(start + WRITE_GENE_CHUNK, n_genes)
            df = pd.DataFrame(np.asarray(matrix[start:end, :]), index=gene_ids[start:end], columns=sample_ids)
            df.to_csv(
                handle,
                sep="\t",
                index=True,
                index_label="gene_id",
                header=(start == 0),
                float_format="%.8g" if is_float else None,
            )
    if path.exists():
        path.unlink()
    tmp.replace(path)

# ============================================================
# MAIN
# ============================================================

def main() -> None:
    setup_logging()
    logging.info("")
    logging.info("============================================================")
    logging.info(" CF6 - EXPRESSION MATRIX CONSTRUCTION + REPLICATE ALIQUOT RESOLUTION")
    logging.info("============================================================")
    logging.info("")

    logging.info("[1/10] Validating frozen CF3 cohort and CF5 integrity gate...")
    logging.info("")
    for path in [CF3_MANIFEST, CF5_FILE_RESULTS, CF5_SUMMARY, CF5_PROVENANCE]:
        if not path.exists():
            raise FileNotFoundError(f"Required upstream file not found: {path}")

    cf5_summary = load_metric_table(CF5_SUMMARY)
    cf5_gate = cf5_summary.get("CF5 integrity gate", "")
    if cf5_gate.upper() != "PASS":
        raise RuntimeError(f"CF5 integrity gate is not PASS (found: {cf5_gate!r}). CF6 is blocked.")

    cf3 = pd.read_csv(CF3_MANIFEST, sep="\t", dtype=str)
    cf5 = pd.read_csv(CF5_FILE_RESULTS, sep="\t", dtype=str)
    required_cf3 = {"file_id", "file_name", "sample_id", "patient_id", "sample_type", "aliquot_barcode", "portion", "analyte", "plate", "center"}
    missing_cf3 = required_cf3.difference(cf3.columns)
    if missing_cf3:
        raise RuntimeError(f"CF3 manifest missing columns: {sorted(missing_cf3)}")
    if "integrity_pass" not in cf5.columns or "actual_path" not in cf5.columns:
        raise RuntimeError("CF5 file results missing integrity_pass/actual_path.")

    cf5["integrity_pass_bool"] = as_bool(cf5["integrity_pass"])
    if (~cf5["integrity_pass_bool"]).any():
        raise RuntimeError("CF5 contains file(s) that did not pass integrity.")

    cf3_ids = set(cf3["file_id"].astype(str))
    cf5_ids = set(cf5["file_id"].astype(str))
    if cf3_ids != cf5_ids:
        raise RuntimeError(
            f"CF3 and CF5 UUID sets differ. Only CF3={len(cf3_ids-cf5_ids)}, only CF5={len(cf5_ids-cf3_ids)}"
        )

    merged = cf3.merge(
        cf5[["file_id", "filename", "actual_path", "actual_md5", "actual_size"]],
        on="file_id", how="inner", validate="one_to_one"
    )
    mismatch = merged["file_name"].astype(str) != merged["filename"].astype(str)
    if mismatch.any():
        raise RuntimeError(f"{int(mismatch.sum())} filename mismatch(es) between CF3 and CF5.")

    duplicate_sample_counts = merged["sample_id"].value_counts()
    duplicate_samples = sorted(duplicate_sample_counts[duplicate_sample_counts > 1].index)
    duplicate_file_ids = set(merged.loc[merged["sample_id"].isin(duplicate_samples), "file_id"].astype(str))

    logging.info(f"CF5 integrity-passed files: {len(merged)}")
    logging.info(f"Unique biological sample IDs before resolution: {merged['sample_id'].nunique()}")
    logging.info(f"Replicate aliquot sample groups: {len(duplicate_samples)}")
    logging.info(f"Files participating in technical duplicate groups: {len(duplicate_file_ids)}")
    logging.info("")

    logging.info("[2/10] Freezing technical replicate resolution rules...")
    logging.info("")
    rules = pd.DataFrame([
        ("R1", "Scope", "Resolve only multiple GDC expression files sharing the same CF3 biological sample_id."),
        ("R2", "Biospecimen identity gate", "Automatic resolution requires identical TCGA portion, RNA analyte, analyte-level barcode, and center; only the plate may differ."),
        ("R3", "Representative aliquot rule", "For multiple aliquots associated with the same RNA analyte, select the later/highest lexicographic TCGA plate, following the historical Broad TCGA GDAC Firehose replicate-filter precedent."),
        ("R4", "Expression QC role", "Pearson/Spearman correlations, library depth, detected genes, and TPM coverage are retained as descriptive evidence and do not determine the representative aliquot."),
        ("R5", "No summation/averaging", "Do not sum or average aliquot-level GDC expression files; preserve one standard GDC aliquot profile per biological sample."),
        ("R6", "Ambiguous provenance", "If replicate files differ in portion, analyte, analyte-level barcode, or center, or if later-plate selection is not unique, stop for manual review."),
        ("R7", "Sensitivity preservation", "Earlier-plate aliquots remain documented in CF6 outputs and can be revisited in CF22 sensitivity analysis; raw GDC files are never deleted."),
    ], columns=["rule_id", "rule", "rationale"])
    rules.to_csv(OUTPUT_DIR / "CF6_selection_rules.tsv", sep="\t", index=False)
    logging.info("Replicate-aliquot selection rules written.")
    logging.info("")

    logging.info("[3/10] Validating common gene universe and collecting replicate evidence...")
    logging.info("")
    reference_annotation: Optional[pd.DataFrame] = None
    quality_by_file: Dict[str, Dict[str, object]] = {}
    vector_by_file: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}
    ordered = merged.sort_values("file_id").reset_index(drop=True)

    for idx, row in enumerate(ordered.itertuples(index=False), start=1):
        path = Path(row.actual_path)
        if not path.exists():
            raise FileNotFoundError(f"CF5-validated file no longer exists: {path}")
        annotation, counts, tpm = read_star_expression(path)
        if reference_annotation is None:
            reference_annotation = annotation
        else:
            validate_annotation_match(reference_annotation, annotation, path)
        if str(row.file_id) in duplicate_file_ids:
            quality_by_file[str(row.file_id)] = file_quality_metrics(counts, tpm)
            vector_by_file[str(row.file_id)] = (counts.copy(), tpm.copy())
        if idx % 100 == 0 or idx == len(ordered):
            logging.info(f"Gene-universe validated: {idx}/{len(ordered)} files")

    assert reference_annotation is not None
    n_genes = len(reference_annotation)
    logging.info("")
    logging.info(f"Common GENCODE ENSG gene rows: {n_genes}")
    logging.info("Gene order + annotation: CONSISTENT ACROSS ALL FILES")
    logging.info("")

    logging.info("[4/10] Evaluating and resolving technical replicate groups...")
    logging.info("")
    pair_rows = []
    decision_rows = []
    selected_file_by_sample: Dict[str, str] = {}

    for sample_id in duplicate_samples:
        group = merged[merged["sample_id"] == sample_id].copy()
        file_ids = sorted(group["file_id"].astype(str).tolist())
        group_pairs = []
        for file_a, file_b in itertools.combinations(file_ids, 2):
            ca, ta = vector_by_file[file_a]
            cb, tb = vector_by_file[file_b]
            pair = duplicate_pair_metrics(sample_id, file_a, file_b, ca, cb, ta, tb)
            qa = quality_by_file[file_a]
            qb = quality_by_file[file_b]
            meta_a = group.loc[group["file_id"].astype(str) == file_a].iloc[0]
            meta_b = group.loc[group["file_id"].astype(str) == file_b].iloc[0]
            pair.update({
                "aliquot_barcode_a": str(meta_a["aliquot_barcode"]),
                "aliquot_barcode_b": str(meta_b["aliquot_barcode"]),
                "plate_a": str(meta_a["plate"]),
                "plate_b": str(meta_b["plate"]),
                "file_a_gene_assigned_counts": qa["gene_assigned_counts"],
                "file_b_gene_assigned_counts": qb["gene_assigned_counts"],
                "file_a_detected_genes": qa["detected_genes_count_gt0"],
                "file_b_detected_genes": qb["detected_genes_count_gt0"],
                "file_a_genes_tpm_ge_1": qa["genes_tpm_ge_1"],
                "file_b_genes_tpm_ge_1": qb["genes_tpm_ge_1"],
            })
            pair_rows.append(pair)
            group_pairs.append(pair)

        selected, basis = select_representative(group, quality_by_file)
        selected_file_by_sample[sample_id] = selected
        for fid in file_ids:
            meta = group.loc[group["file_id"].astype(str) == fid].iloc[0]
            decision_rows.append({
                "sample_id": sample_id,
                "file_id": fid,
                "aliquot_barcode": str(meta["aliquot_barcode"]),
                "portion": str(meta["portion"]),
                "analyte": str(meta["analyte"]),
                "plate": str(meta["plate"]),
                "center": str(meta["center"]),
                "decision": "KEEP" if fid == selected else "EXCLUDE_EARLIER_PLATE_REPLICATE_ALIQUOT",
                "selection_basis": basis,
                **quality_by_file[fid],
            })

    pair_df = pd.DataFrame(pair_rows)
    decision_df = pd.DataFrame(decision_rows)
    if pair_df.empty:
        pair_df = pd.DataFrame(columns=["sample_id", "file_id_a", "file_id_b", "aliquot_barcode_a", "aliquot_barcode_b", "plate_a", "plate_b", "pearson_log1p_counts", "spearman_log1p_counts", "pearson_log1p_tpm", "correlation_qc_status"])
    if decision_df.empty:
        decision_df = pd.DataFrame(columns=["sample_id", "file_id", "aliquot_barcode", "portion", "analyte", "plate", "center", "decision", "selection_basis", "gene_assigned_counts", "detected_genes_count_gt0", "genes_tpm_ge_1"])
    pair_df.to_csv(OUTPUT_DIR / "CF6_technical_replicate_qc.tsv", sep="\t", index=False)
    decision_df.to_csv(OUTPUT_DIR / "CF6_technical_replicate_decisions.tsv", sep="\t", index=False)

    replicate_groups_pass = len(selected_file_by_sample) == len(duplicate_samples)
    logging.info(f"Replicate aliquot groups evaluated: {len(duplicate_samples)}")
    logging.info(f"Replicate aliquot groups resolved by provenance rule: {len(selected_file_by_sample)}/{len(duplicate_samples)}")
    if not replicate_groups_pass:
        logging.error("CF6 STOPPED BEFORE MATRIX CONSTRUCTION.")
        logging.error("Review CF6_technical_replicate_qc.tsv and CF6_technical_replicate_decisions.tsv.")
        raise RuntimeError("Replicate aliquot manual review is required.")
    logging.info("Replicate aliquot resolution: PASS")
    logging.info("")
    vector_by_file.clear()

    logging.info("[5/10] Freezing final one-file-per-biological-sample cohort...")
    logging.info("")
    keep_mask = []
    reasons = []
    for row in merged.itertuples(index=False):
        sample_id = str(row.sample_id)
        file_id = str(row.file_id)
        if sample_id not in duplicate_samples:
            keep_mask.append(True)
            reasons.append("unique_biological_sample")
        else:
            keep = selected_file_by_sample[sample_id] == file_id
            keep_mask.append(keep)
            reasons.append("selected_later_plate_replicate_aliquot" if keep else "excluded_earlier_plate_replicate_aliquot")
    merged["CF6_keep_file"] = keep_mask
    merged["CF6_resolution_reason"] = reasons
    final_manifest = merged[merged["CF6_keep_file"]].copy()
    if final_manifest["sample_id"].duplicated().any():
        raise RuntimeError("Final CF6 sample manifest still contains duplicate sample IDs.")
    final_manifest = final_manifest.sort_values(["patient_id", "sample_type", "sample_id", "file_id"]).reset_index(drop=True)
    final_sample_ids = final_manifest["sample_id"].astype(str).tolist()
    final_file_ids = final_manifest["file_id"].astype(str).tolist()

    n_final = len(final_manifest)
    n_unique_patients = final_manifest["patient_id"].nunique()
    tumor_count = int((final_manifest["sample_type"] == "Primary Tumor").sum())
    normal_count = int((final_manifest["sample_type"] == "Solid Tissue Normal").sum())
    paired_sets = final_manifest.groupby("patient_id")["sample_type"].agg(lambda x: set(x.astype(str)))
    paired_patients = int(sum({"Primary Tumor", "Solid Tissue Normal"}.issubset(v) for v in paired_sets))

    final_manifest_out = PROCESSED_DIR / "CF6_final_sample_manifest.tsv"
    final_manifest.to_csv(final_manifest_out, sep="\t", index=False)
    logging.info(f"Final biological samples: {n_final}")
    logging.info(f"Unique patients: {n_unique_patients}")
    logging.info(f"Primary Tumor samples: {tumor_count}")
    logging.info(f"Solid Tissue Normal samples: {normal_count}")
    logging.info(f"Paired tumor-normal patients: {paired_patients}")
    logging.info("")

    logging.info("[6/10] Saving frozen gene annotation...")
    logging.info("")
    gene_annotation_out = PROCESSED_DIR / "CF6_gene_annotation.tsv"
    reference_annotation.to_csv(gene_annotation_out, sep="\t", index=False)
    logging.info(f"Gene annotation rows: {len(reference_annotation)}")
    logging.info("")

    logging.info("[7/10] Building final raw-count and TPM matrices...")
    logging.info("")
    logging.info("Using temporary on-disk memmaps to keep RAM requirements controlled.")
    counts_memmap_path = INTERIM_DIR / "CF6_counts.memmap.dat"
    tpm_memmap_path = INTERIM_DIR / "CF6_tpm.memmap.dat"
    for p in [counts_memmap_path, tpm_memmap_path]:
        if p.exists():
            p.unlink()

    counts_mm = np.memmap(counts_memmap_path, dtype=np.int64, mode="w+", shape=(n_genes, n_final))
    tpm_mm = np.memmap(tpm_memmap_path, dtype=np.float64, mode="w+", shape=(n_genes, n_final))
    final_by_file = final_manifest.set_index("file_id", drop=False)
    for col_idx, file_id in enumerate(final_file_ids):
        row = final_by_file.loc[file_id]
        path = Path(row["actual_path"])
        annotation, counts, tpm = read_star_expression(path)
        validate_annotation_match(reference_annotation, annotation, path)
        counts_mm[:, col_idx] = counts
        tpm_mm[:, col_idx] = tpm
        if (col_idx + 1) % 100 == 0 or (col_idx + 1) == n_final:
            logging.info(f"Matrix columns loaded: {col_idx + 1}/{n_final}")
    counts_mm.flush(); tpm_mm.flush()
    logging.info("")
    logging.info(f"Raw-count matrix shape: {n_genes} genes x {n_final} samples")
    logging.info(f"TPM matrix shape: {n_genes} genes x {n_final} samples")
    logging.info("")

    logging.info("[8/10] Writing compressed expression matrices...")
    logging.info("")
    gene_ids = reference_annotation["gene_id"].astype(str).to_numpy()
    counts_out = PROCESSED_DIR / "CF6_raw_unstranded_counts.tsv.gz"
    tpm_out = PROCESSED_DIR / "CF6_tpm.tsv.gz"
    logging.info("Writing raw unstranded counts...")
    write_matrix_gzip(counts_out, counts_mm, gene_ids, final_sample_ids, is_float=False)
    logging.info("Writing TPM...")
    write_matrix_gzip(tpm_out, tpm_mm, gene_ids, final_sample_ids, is_float=True)
    del counts_mm; del tpm_mm
    for p in [counts_memmap_path, tpm_memmap_path]:
        try: p.unlink()
        except FileNotFoundError: pass
    try: INTERIM_DIR.rmdir()
    except OSError: pass
    logging.info("Compressed matrices written.")
    logging.info("")

    logging.info("[9/10] Writing checksums, summary, and provenance...")
    logging.info("")
    output_artifacts = [
        ("raw_unstranded_counts", counts_out, n_genes, n_final),
        ("tpm", tpm_out, n_genes, n_final),
        ("gene_annotation", gene_annotation_out, n_genes, 4),
        ("final_sample_manifest", final_manifest_out, n_final, len(final_manifest.columns)),
    ]
    checksum_rows = []
    for label, path, rows, cols in output_artifacts:
        checksum_rows.append({
            "artifact": label,
            "path": str(path.resolve()),
            "sha256": hash_file(path, "sha256"),
            "file_bytes": path.stat().st_size,
            "rows": rows,
            "columns": cols,
        })
    pd.DataFrame(checksum_rows).to_csv(OUTPUT_DIR / "CF6_matrix_checksums.tsv", sep="\t", index=False)

    summary_rows = [
        ("CF5 integrity gate", "PASS"),
        ("Input validated GDC files", len(merged)),
        ("Input unique biological sample IDs", merged["sample_id"].nunique()),
        ("Replicate aliquot sample groups", len(duplicate_samples)),
        ("Earlier-plate replicate aliquots excluded", len(merged) - n_final),
        ("Replicate aliquot groups resolved by provenance", len(selected_file_by_sample)),
        ("Final biological samples", n_final),
        ("Final unique patients", n_unique_patients),
        ("Final Primary Tumor samples", tumor_count),
        ("Final Solid Tissue Normal samples", normal_count),
        ("Final paired tumor-normal patients", paired_patients),
        ("GENCODE ENSG genes", n_genes),
        ("Raw-count matrix rows", n_genes),
        ("Raw-count matrix columns", n_final),
        ("TPM matrix rows", n_genes),
        ("TPM matrix columns", n_final),
        ("CF6 stage gate", "PASS"),
    ]
    pd.DataFrame(summary_rows, columns=["metric", "value"]).to_csv(OUTPUT_DIR / "CF6_summary.tsv", sep="\t", index=False)

    provenance_rows = [
        ("code_file", "CF6_expression_matrix_construction.py"),
        ("run_datetime_utc", datetime.now(timezone.utc).isoformat()),
        ("project_root", str(PROJECT_ROOT.resolve())),
        ("cf3_manifest", str(CF3_MANIFEST.resolve())),
        ("cf3_manifest_sha256", hash_file(CF3_MANIFEST, "sha256")),
        ("cf5_file_results", str(CF5_FILE_RESULTS.resolve())),
        ("cf5_file_results_sha256", hash_file(CF5_FILE_RESULTS, "sha256")),
        ("cf5_summary_sha256", hash_file(CF5_SUMMARY, "sha256")),
        ("cf5_provenance_sha256", hash_file(CF5_PROVENANCE, "sha256")),
        ("replicate_aliquot_selection_rule", "same RNA analyte -> later/highest lexicographic TCGA plate"),
        ("tcga_barcode_source", TCGA_BARCODE_SOURCE),
        ("historical_gdac_replicate_rule_source", GDAC_REPLICATE_RULE_SOURCE),
        ("expression_correlations_role", "descriptive QC only; not a selection threshold"),
        ("raw_count_column", "unstranded"),
        ("normalized_expression_column", "tpm_unstranded"),
        ("gene_row_definition", "gene_id starts with ENSG; STAR N_* summary rows excluded"),
        ("matrix_orientation", "genes_rows_samples_columns"),
        ("matrix_compression", f"gzip level {GZIP_LEVEL}"),
        ("python_version", sys.version.replace("\n", " ")),
        ("numpy_version", np.__version__),
        ("pandas_version", pd.__version__),
        ("platform", platform.platform()),
        ("cf6_stage_gate", "PASS"),
    ]
    pd.DataFrame(provenance_rows, columns=["field", "value"]).to_csv(OUTPUT_DIR / "CF6_provenance.tsv", sep="\t", index=False)
    logging.info("Output SHA256 checksums recorded.")
    logging.info("")

    logging.info("[10/10] Final CF6 stage gate...")
    logging.info("")
    logging.info("============================================================")
    logging.info(" CF6 COMPLETE - EXPRESSION CONSTRUCTION GATE PASSED")
    logging.info("============================================================")
    logging.info("")
    logging.info(f"Input validated files: {len(merged)}")
    logging.info(f"Replicate aliquot sample groups: {len(duplicate_samples)}")
    logging.info(f"Earlier-plate replicate aliquots excluded: {len(merged) - n_final}")
    logging.info(f"Final biological samples: {n_final}")
    logging.info(f"Unique patients: {n_unique_patients}")
    logging.info(f"Primary Tumor: {tumor_count}")
    logging.info(f"Solid Tissue Normal: {normal_count}")
    logging.info(f"Paired tumor-normal patients: {paired_patients}")
    logging.info(f"GENCODE ENSG genes: {n_genes}")
    logging.info(f"Raw-count matrix: {n_genes} x {n_final}")
    logging.info(f"TPM matrix: {n_genes} x {n_final}")
    logging.info("")
    logging.info("CF6 generated:")
    logging.info("  data/processed/tcga_brca/expression/CF6_raw_unstranded_counts.tsv.gz")
    logging.info("  data/processed/tcga_brca/expression/CF6_tpm.tsv.gz")
    logging.info("  data/processed/tcga_brca/expression/CF6_gene_annotation.tsv")
    logging.info("  data/processed/tcga_brca/expression/CF6_final_sample_manifest.tsv")
    logging.info("  results/CF6_expression_matrix_construction/CF6_technical_replicate_qc.tsv")
    logging.info("  results/CF6_expression_matrix_construction/CF6_technical_replicate_decisions.tsv")
    logging.info("  results/CF6_expression_matrix_construction/CF6_selection_rules.tsv")
    logging.info("  results/CF6_expression_matrix_construction/CF6_matrix_checksums.tsv")
    logging.info("  results/CF6_expression_matrix_construction/CF6_summary.tsv")
    logging.info("  results/CF6_expression_matrix_construction/CF6_provenance.tsv")
    logging.info("  logs/CF6_expression_matrix_construction.log")
    logging.info("")
    logging.info("IMPORTANT:")
    logging.info("Raw GDC files were not modified.")
    logging.info("No gene filtering for biological analysis was performed.")
    logging.info("No DESeq2, clinical analysis, PCA exclusion, or ML was performed.")
    logging.info("TPM was kept separate from raw counts.")
    logging.info("CF6 is ready for review before CF7 clinical harmonization.")
    logging.info("")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception(f"\nCF6 ERROR: {exc}")
        sys.exit(1)