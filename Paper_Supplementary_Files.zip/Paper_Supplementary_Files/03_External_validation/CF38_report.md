# CF38: Independent METABRIC validation of the locked TCGA HER2 model

## Question and conclusion

Does the locked TCGA-trained HER2 model generalize to an independent breast cancer cohort?

The unchanged CF18 model achieved AUROC **0.9909** and average precision **0.9498** in METABRIC. At its original calibrated threshold (0.4345288895), sensitivity was **0.3061** and specificity **0.9994**. These results assess cross-cohort discrimination and the actual frozen operating point separately. They do not establish equivalence to clinical IHC/ISH testing or prospective clinical validity.

## Dataset and independence

METABRIC (Molecular Taxonomy of Breast Cancer International Consortium), cBioPortal study `brca_metabric`, uses Illumina HT-12 v3 microarray log2 expression intensities. The existing public DataHub files in `data/external_validation/metabric/brca_metabric/` were reused read-only; no new download or different data release was substituted. The source study metadata cites Curtis et al. (2012), Pereira et al. (2016), and Rueda et al. (2019). The broader 2,509-tumor study is not the expression-evaluable denominator.

There are 2,509 clinical records and 1,980 expression samples. After definitive-label and expression-completeness checks, the evaluable set contains **1,964 unique patients/samples: 245 HER2 positive and 1,719 HER2 negative** (prevalence 12.47%). 529 clinical records lack expression; 0 expression-matched records lack definitive labels; 16 otherwise eligible samples have nonfinite measured expression within the locked universe and are excluded. This complete-case rule was applied before prediction, without examining outcomes, rather than inventing a new imputation rule. The sample inclusion and missing-cell tables document exclusions.

METABRIC is independent of the TCGA training cohort, but it was already examined in CF33 and CF33.5 for compact-model analyses. CF38 therefore is not a previously unseen project-level holdout. No METABRIC outcomes were used here to change the CF18 model, gene set, calibration, or threshold. Later 10-gene models were not substituted for the requested 86-gene model.

## Locked model and original label definition

Artifact: `data/processed/ml_ready/CF18_final_model/CF18_final_ElasticNet_model_bundle.joblib`. Signature: the 86 nonzero coefficients in `results/CF18_stable_signature_xai_final_model/CF18_final_ElasticNet_features.tsv`, verified against the bundle. The bundle selects 500 features; 86 contribute nonzero coefficients. The 20-gene stability core is a different object, not the final predictive signature. Training used 938 TCGA tumors (182 positive, 756 negative).

CF7 harmonizes definitive ISH/FISH first, then definitive IHC; unresolved equivocal/unknown labels are excluded, and contradictory definitive IHC/ISH results are marked unknown. CF15 codes Positive=1 and Negative=0. METABRIC uses explicit `HER2_STATUS` Positive/Negative, excluding any other values. `HER2_SNP6` is retained for provenance and cross-tabulated, not used as an expression predictor or to select cases. Published descriptions identify METABRIC HER2 status as SNP6 copy-number based; this endpoint is not interchangeable with TCGA IHC/ISH. PAM50 HER2-enriched subtype is not used as the label.

## Gene matching and preprocessing

1. Match exact `Hugo_Symbol` to the frozen TCGA symbols. Average duplicate expression rows by symbol before ranking; there are 20,603 source rows and 20,385 usable unique symbols. No outcome-guided aliases, probe choices, or feature replacement.
2. Align to all 22,106 frozen genes in bundle order. 18,129 are measured. Of the 86 signature genes, **79/86** are measured; missing genes: **CBX3P2, LAMB2P1, MIR4728, MIR8067, NDUFA6, RPL23P8, TMEM210**. Full-universe and signature mapping tables are supplied.
3. Follow the CF19 external missing-gene convention: absent genes receive zero before ranking. This is a compatibility assumption, not recovered measurement. On a log2 microarray scale it can alter ranks and is an important limitation.
4. Exclude samples with nonfinite measured expression anywhere in the locked universe (distinct from wholly absent platform genes), then compute within-sample average percentile ranks over the fixed 22,106-gene universe, cast to float32 exactly as CF15/CF19. Do not rank only the 86 genes. No additional log transform is needed because positive monotone transforms preserve observed ranks; no cohort z-scoring, batch correction, or quantile matching is introduced. Complete-case exclusions may introduce selection bias.
5. Apply the stored variance filter, TCGA StandardScaler, and stored SelectKBest using `transform` only, then the stored Elastic-Net `predict_proba`. No `fit` calls occur.
6. Clip raw probabilities to [1e-7, 1−1e-7], take logits, and apply the stored CF18 sigmoid calibrator. Classify calibrated probabilities >= 0.4345288895 as positive. This preserves the calibration/threshold pairing saved in CF18; no external recalibration or threshold optimization occurs.

## Performance

| Metric | Estimate | 95% bootstrap interval |
|---|---:|---:|
| AUROC | 0.9909 | 0.9868–0.9946 |
| AUPRC_average_precision | 0.9498 | 0.9280–0.9691 |
| accuracy | 0.9129 | 0.9058–0.9206 |
| sensitivity | 0.3061 | 0.2489–0.3673 |
| specificity | 0.9994 | 0.9983–1.0000 |
| PPV | 0.9868 | 0.9571–1.0000 |
| NPV | 0.9100 | 0.9031–0.9172 |

AUPRC is reported as scikit-learn average precision (stepwise integration), not trapezoidal PR area. Intervals use 2,000 stratified patient bootstrap replicates, fixed seed 20260922, and the unchanged model and threshold. They condition on observed prevalence and do not quantify model-development or assay-mapping uncertainty. The no-skill average precision reference is 0.1247.

| Actual status | Predicted negative | Predicted positive |
|---|---:|---:|
| Negative | 1718 | 1 |
| Positive | 170 | 75 |

## Interpretation and limitations

The answer is qualified: the locked model generalizes strongly for ranking METABRIC tumors, but its frozen operating threshold transfers poorly for detecting HER2-positive cases. It misses 170 of 245 positive cases (69.4%). Thus CF38 supports cross-cohort discrimination under incomplete platform coverage, not successful transfer of the complete clinical decision rule. The seven unmeasured signature genes mean this is not a full-measurement validation of all 86 genes.

AUROC and average precision describe ranking across HER2 groups; sensitivity, specificity, PPV, NPV, and accuracy describe transfer of the original operating threshold. Good ranking alone must not be interpreted as good probability calibration or adequate case detection. The class imbalance makes accuracy alone insufficient. PPV and NPV depend on cohort prevalence.

This is a retrospective cross-platform assessment. Missing signature genes and zero-filled background genes limit fidelity to the complete RNA-seq input. Microarray probe specificity, dynamic range, exact-symbol mapping, and different gene coverage can shift within-sample ranks. The model was not adapted to correct these shifts. Endpoint differences (SNP6 versus IHC/ISH), prior METABRIC use elsewhere in this project, and retrospective cohort selection constrain any claim of independent clinical validation. This experiment cannot distinguish all biological generalization effects from assay and label differences.

## Figures and reproducibility

The figures directory contains 400-dpi PNG and vector PDF versions of ROC, precision–recall, probability distribution, and HER2-group separation. Distribution histograms normalize within each group; separation plots show individual cases and boxplots. Dashed probability thresholds are frozen TCGA thresholds.

Run from the project root: `.venv/Scripts/python.exe CF38_Metabric_external_validation/scripts/CF38_validate.py`.

The script writes only inside CF38, verifies signature coefficients and manual logistic predictions, checks finite ranks and unique patients, and verifies input SHA-256 hashes are unchanged. The provenance JSON records file hashes, versions, counts, and settings. CF1–CF37 scripts were inspected but never executed or edited. A CF38-local copy of the official CPython 3.10.11 `_strptime.py` works around an existing corrupted system module without modifying the installed environment; source: https://raw.githubusercontent.com/python/cpython/v3.10.11/Lib/_strptime.py .

## Sources

- [cBioPortal METABRIC DataHub source](https://github.com/cBioPortal/datahub/tree/master/public/brca_metabric)
- [METABRIC study](https://www.cbioportal.org/study/summary?id=brca_metabric)
- [Published cohort methods identifying SNP6-derived HER2 status](https://pmc.ncbi.nlm.nih.gov/articles/PMC11882987/)

No retraining, model redevelopment, feature reselection, or additional experiments were performed.
